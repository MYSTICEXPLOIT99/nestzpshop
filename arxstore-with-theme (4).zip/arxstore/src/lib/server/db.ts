import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { User, Order, TopupTransaction, BgmSettings, SiteContent, ResellerSettings, SlipApiConfig } from '@/types';

const DATA_DIR = path.join(process.cwd(), 'src', 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
const TOPUPS_FILE = path.join(DATA_DIR, 'topups.json');
const COUPONS_FILE = path.join(DATA_DIR, 'coupons.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');
const SESSIONS_FILE = path.join(DATA_DIR, 'sessions.json');
const SITE_CONTENT_FILE = path.join(DATA_DIR, 'site-content.json');
const RESELLER_SETTINGS_FILE = path.join(DATA_DIR, 'reseller-settings.json');
const SLIP_CONFIG_FILE = path.join(DATA_DIR, 'slip-config.json');

export interface Coupon {
  code: string;
  discountPercent: number;
  minSpend?: number;
  isActive: boolean;
  usedCount: number;
  maxUsage?: number;
  description?: string;
}

export interface StoredUser extends Omit<User, 'password'> {
  passwordHash: string;
}

export interface ServerSettings {
  discordWebhookUrl?: string;
  notifyOrder?: boolean;
  notifyTopup?: boolean;
  notifyRegister?: boolean;
  notifyStock?: boolean;
}

export interface Session {
  token: string;
  userId: string;
  role: 'admin' | 'user';
  createdAt: number;
  expiresAt: number;
}

function ensureDirectory() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readJsonFile<T>(filePath: string, defaultValue: T): T {
  ensureDirectory();
  try {
    if (!fs.existsSync(filePath)) {
      writeJsonFile(filePath, defaultValue);
      return defaultValue;
    }
    const raw = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(raw) as T;
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
    return defaultValue;
  }
}

function writeJsonFile<T>(filePath: string, data: T) {
  ensureDirectory();
  try {
    const tempFile = `${filePath}.tmp.${Date.now()}`;
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tempFile, filePath);
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
  }
}

// ----------------------------------------------------
// Password Hashing (PBKDF2 with SHA-512 & Salt)
// ----------------------------------------------------
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
  return `pbkdf2:100000:${salt}:${hash}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash) return false;
  // If legacy plaintext exists, support safe comparison and trigger rehash
  if (!storedHash.startsWith('pbkdf2:')) {
    return storedHash === password;
  }
  try {
    const parts = storedHash.split(':');
    if (parts.length !== 4) return false;
    const iterations = parseInt(parts[1], 10) || 100000;
    const salt = parts[2];
    const originalHash = parts[3];
    const testHash = crypto.pbkdf2Sync(password, salt, iterations, 64, 'sha512').toString('hex');
    return crypto.timingSafeEqual(Buffer.from(testHash, 'hex'), Buffer.from(originalHash, 'hex'));
  } catch {
    return false;
  }
}

// ----------------------------------------------------
// Initial Seeds & Admin Setup
// ----------------------------------------------------
function getInitialUsers(): StoredUser[] {
  const adminPass = process.env.ADMIN_PASSWORD || 'faith17488';
  return [
    {
      id: 'usr-admin-arx',
      username: 'arxstore',
      passwordHash: hashPassword(adminPass),
      email: 'admin@arxstore.xyz',
      role: 'admin',
      balance: 999999,
      totalSpent: 125000,
      freeHwidResets: 999,
      accumulatedHwidResets: 0,
      avatar: '/brand/logo.png',
      createdAt: '2026-09-01',
      memberSince: '1 กันยายน 2026'
    },
    {
      id: 'usr-demo-1',
      username: 'demouser',
      passwordHash: hashPassword('password123'),
      email: 'user@arxstore.xyz',
      role: 'user',
      balance: 1500,
      totalSpent: 3500,
      freeHwidResets: 1,
      accumulatedHwidResets: 0,
      avatar: '/brand/logo.png',
      createdAt: '2026-09-15',
      memberSince: '15 กันยายน 2026'
    }
  ];
}

function getInitialCoupons(): Coupon[] {
  return [
    {
      code: 'ARXSTORE',
      discountPercent: 10,
      minSpend: 0,
      isActive: true,
      usedCount: 15,
      description: 'ส่วนลดพิเศษฉลองเปิดร้าน ARX STORE 10%'
    },
    {
      code: 'DEMOX10',
      discountPercent: 10,
      minSpend: 50,
      isActive: true,
      usedCount: 42,
      description: 'คูปองโปรโมชั่น DEMOX 10%'
    },
    {
      code: 'SALE',
      discountPercent: 5,
      minSpend: 0,
      isActive: true,
      usedCount: 88,
      description: 'ส่วนลดพิเศษ Flash Sale 5%'
    }
  ];
}

// ----------------------------------------------------
// Session Management
// ----------------------------------------------------
export function createSession(userId: string, role: 'admin' | 'user'): Session {
  const sessions = readJsonFile<Session[]>(SESSIONS_FILE, []);
  const token = crypto.randomBytes(32).toString('hex');
  const now = Date.now();
  const session: Session = {
    token,
    userId,
    role,
    createdAt: now,
    expiresAt: now + (role === 'admin' ? 12 * 60 * 60 * 1000 : 30 * 24 * 60 * 60 * 1000) // Admin 12h, User 30d
  };
  // Clean expired
  const activeSessions = sessions.filter(s => s.expiresAt > now);
  activeSessions.push(session);
  writeJsonFile(SESSIONS_FILE, activeSessions);
  return session;
}

export function getSession(token: string): Session | null {
  if (!token) return null;
  const sessions = readJsonFile<Session[]>(SESSIONS_FILE, []);
  const now = Date.now();
  const found = sessions.find(s => s.token === token && s.expiresAt > now);
  return found || null;
}

export function revokeSession(token: string) {
  if (!token) return;
  const sessions = readJsonFile<Session[]>(SESSIONS_FILE, []);
  writeJsonFile(SESSIONS_FILE, sessions.filter(s => s.token !== token));
}

export function getSessionFromRequest(request: Request): Session | null {
  // 1. Check Authorization Bearer header
  const authHeader = request.headers.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7).trim();
    const session = getSession(token);
    if (session) return session;
  }

  // 2. Check x-session-token header
  const xToken = request.headers.get('x-session-token');
  if (xToken) {
    const session = getSession(xToken);
    if (session) return session;
  }

  // 3. Check Cookie
  const cookieHeader = request.headers.get('cookie') || '';
  const match = cookieHeader.match(/arx_session=([a-f0-9]+)/);
  if (match && match[1]) {
    const session = getSession(match[1]);
    if (session) return session;
  }

  return null;
}

// ----------------------------------------------------
// User Repository
// ----------------------------------------------------
export function getUsers(): StoredUser[] {
  return readJsonFile<StoredUser[]>(USERS_FILE, getInitialUsers());
}

export function getUserById(id: string): StoredUser | null {
  const users = getUsers();
  return users.find(u => u.id === id) || null;
}

export function getUserByUsername(username: string): StoredUser | null {
  const users = getUsers();
  const clean = username.trim().toLowerCase();
  return users.find(u => u.username.toLowerCase() === clean) || null;
}

export function createUser(userData: {
  username: string;
  password: string;
  role?: 'admin' | 'user';
  email?: string;
  avatar?: string;
}): StoredUser {
  const users = getUsers();
  const cleanUser = userData.username.trim();
  const newUser: StoredUser = {
    id: 'usr-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
    username: cleanUser,
    passwordHash: hashPassword(userData.password),
    role: userData.role || 'user',
    email: userData.email || `${cleanUser.toLowerCase()}@arxstore.xyz`,
    avatar: userData.avatar || '/brand/logo.png',
    balance: 0,
    totalSpent: 0,
    freeHwidResets: 0,
    accumulatedHwidResets: 0,
    createdAt: new Date().toISOString(),
    memberSince: new Date().toLocaleDateString('th-TH')
  };
  users.push(newUser);
  writeJsonFile(USERS_FILE, users);
  return newUser;
}

export function updateUser(id: string, updates: Partial<Omit<StoredUser, 'id' | 'passwordHash'>> & { newPassword?: string }): StoredUser | null {
  const users = getUsers();
  const index = users.findIndex(u => u.id === id);
  if (index === -1) return null;

  const current = users[index];
  const updated: StoredUser = {
    ...current,
    ...updates,
    passwordHash: updates.newPassword ? hashPassword(updates.newPassword) : current.passwordHash
  };

  users[index] = updated;
  writeJsonFile(USERS_FILE, users);
  return updated;
}

export function deleteUser(id: string): boolean {
  const users = getUsers();
  const index = users.findIndex(u => u.id === id);
  if (index === -1) return false;
  users.splice(index, 1);
  writeJsonFile(USERS_FILE, users);
  return true;
}

export function adjustUserBalance(id: string, amount: number): { success: boolean; newBalance?: number; error?: string } {
  const users = getUsers();
  const user = users.find(u => u.id === id);
  if (!user) return { success: false, error: 'User not found' };

  if (amount < 0 && user.balance + amount < 0) {
    return { success: false, error: 'ยอดเงินคงเหลือไม่เพียงพอ' };
  }

  user.balance += amount;
  if (amount < 0) {
    user.totalSpent += Math.abs(amount);
  }
  writeJsonFile(USERS_FILE, users);
  return { success: true, newBalance: user.balance };
}

export function sanitizeUser(user: StoredUser): User {
  const { passwordHash: _, ...safe } = user;
  const storeLogo = getSiteContent()?.branding?.logoUrl || '/brand/logo.png';
  if (safe.role === 'admin' || !safe.avatar || safe.avatar === '/brand/logo.png' || safe.avatar === '/brand/arx-default-logo.png') {
    safe.avatar = storeLogo;
  }
  return safe;
}

// ----------------------------------------------------
// Orders Repository
// ----------------------------------------------------
export function getOrders(): Order[] {
  return readJsonFile<Order[]>(ORDERS_FILE, []);
}

export function getOrdersByUserId(userId: string): Order[] {
  const orders = getOrders();
  return orders.filter(o => o.userId === userId);
}

export function createOrder(order: Omit<Order, 'id' | 'createdAt'>): Order {
  const orders = getOrders();
  const newOrder: Order = {
    ...order,
    id: 'ord-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
    createdAt: new Date().toISOString()
  };
  orders.unshift(newOrder);
  // Cap at 10,000 orders
  if (orders.length > 10000) orders.splice(10000);
  writeJsonFile(ORDERS_FILE, orders);
  return newOrder;
}

// ----------------------------------------------------
// Topup Repository
// ----------------------------------------------------
export function getTopups(): TopupTransaction[] {
  return readJsonFile<TopupTransaction[]>(TOPUPS_FILE, []);
}

export function getTopupsByUserId(userId: string): TopupTransaction[] {
  const topups = getTopups();
  return topups.filter(t => t.userId === userId);
}

export function createTopup(topupData: Omit<TopupTransaction, 'id' | 'createdAt'>): TopupTransaction {
  const topups = getTopups();
  const newTopup: TopupTransaction = {
    ...topupData,
    id: 'topup-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
    createdAt: new Date().toISOString()
  };
  topups.unshift(newTopup);
  if (topups.length > 5000) topups.splice(5000);
  writeJsonFile(TOPUPS_FILE, topups);
  return newTopup;
}

export function updateTopupStatus(id: string, status: 'approved' | 'rejected', reviewer: string): { success: boolean; topup?: TopupTransaction; error?: string } {
  const topups = getTopups();
  const topup = topups.find(t => t.id === id);
  if (!topup) return { success: false, error: 'Transaction not found' };

  if (topup.status !== 'pending') {
    return { success: false, error: 'รายการนี้ได้รับการพิจารณาไปแล้ว' };
  }

  topup.status = status;
  writeJsonFile(TOPUPS_FILE, topups);

  // If approved, credit balance to user
  if (status === 'approved') {
    adjustUserBalance(topup.userId, topup.amount);
  }

  return { success: true, topup };
}

// ----------------------------------------------------
// Coupons Repository
// ----------------------------------------------------
export function getCoupons(): Coupon[] {
  return readJsonFile<Coupon[]>(COUPONS_FILE, getInitialCoupons());
}

export function validateCouponCode(code: string, orderAmount: number): {
  valid: boolean;
  coupon?: Coupon;
  discountPercent?: number;
  discountAmount?: number;
  message?: string;
} {
  const cleanCode = (code || '').trim().toUpperCase();
  if (!cleanCode) return { valid: false, message: 'กรุณากรอกโค้ดส่วนลด' };

  const coupons = getCoupons();
  const coupon = coupons.find(c => c.code.toUpperCase() === cleanCode && c.isActive);

  if (!coupon) {
    return { valid: false, message: 'โค้ดส่วนลดไม่ถูกต้องหรือถูกปิดใช้งาน' };
  }

  if (coupon.minSpend && orderAmount < coupon.minSpend) {
    return { valid: false, message: `โค้ดนี้ต้องมียอดสั่งซื้อขั้นต่ำ ฿${coupon.minSpend}` };
  }

  if (coupon.maxUsage && coupon.usedCount >= coupon.maxUsage) {
    return { valid: false, message: 'โค้ดส่วนลดนี้มีผู้ใช้งานเต็มจำนวนแล้ว' };
  }

  const discountAmount = Math.round((orderAmount * coupon.discountPercent) / 100);
  return {
    valid: true,
    coupon,
    discountPercent: coupon.discountPercent,
    discountAmount
  };
}

export function recordCouponUsage(code: string) {
  const coupons = getCoupons();
  const coupon = coupons.find(c => c.code.toUpperCase() === code.trim().toUpperCase());
  if (coupon) {
    coupon.usedCount += 1;
    writeJsonFile(COUPONS_FILE, coupons);
  }
}

// ----------------------------------------------------
// Settings & Discord Webhook Repository
// ----------------------------------------------------
export function getServerSettings(): ServerSettings {
  return readJsonFile<ServerSettings>(SETTINGS_FILE, {
    notifyOrder: true,
    notifyTopup: true,
    notifyRegister: true,
    notifyStock: true
  });
}

export function updateServerSettings(updates: Partial<ServerSettings>): ServerSettings {
  const current = getServerSettings();
  const next = { ...current, ...updates };
  writeJsonFile(SETTINGS_FILE, next);
  return next;
}

// ----------------------------------------------------
// SEO & Discord Embed Settings Repository
// ----------------------------------------------------
const SEO_FILE = path.join(DATA_DIR, 'seo.json');

export interface SeoSettings {
  title: string;
  description: string;
  ogImage: string;
  themeColor: string;
  siteName: string;
  keywords?: string;
}

export const DEFAULT_SEO_SETTINGS: SeoSettings = {
  title: 'Arx Store',
  description: 'ARX STORE I บริการจำหน่าย Setting , BoostFPS , Windows ต่างๆ ซอฟต์แวร์เพิ่มประสิทธิภาพ สั่งซื้อออนไลน์ พร้อมบริการเติมเงินและรีเซ็ต HWID อัตโนมัติ 24 ชม.',
  ogImage: '/brand/logo.png',
  themeColor: '#00e5ff',
  siteName: 'Arx Store',
  keywords: 'ARX STORE, Setting, BoostFPS, Windows, บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ, ร้านค้าออนไลน์, สินค้าดิจิทัล, FiveM, FiveM Mod, Cheat Game, Spoofer, HWID Reset, Topup TrueMoney, PromptPay'
};

export function getSeoSettings(): SeoSettings {
  return readJsonFile<SeoSettings>(SEO_FILE, DEFAULT_SEO_SETTINGS);
}

export function updateSeoSettings(updates: Partial<SeoSettings>): SeoSettings {
  const current = getSeoSettings();
  const next = { ...current, ...updates };
  writeJsonFile(SEO_FILE, next);
  return next;
}

// ----------------------------------------------------
// Welcome Hero Banner Settings Repository
// ----------------------------------------------------
const WELCOME_BANNER_FILE = path.join(DATA_DIR, 'welcome-banner.json');

export interface WelcomeBannerSettings {
  enabled: boolean;
  titlePrefix: string;
  titleHighlight: string;
  highlightColor?: string;
  description: string;
  button1Text: string;
  button1Link: string;
  button2Text: string;
  button2Link: string;
}

export const DEFAULT_WELCOME_BANNER_SETTINGS: WelcomeBannerSettings = {
  enabled: true,
  titlePrefix: 'ยินดีต้อนรับสู่ร้าน',
  titleHighlight: 'ARXSTORE.XYZ',
  highlightColor: '#00e5ff',
  description: 'ร้านบริการจำหน่ายโปรแกรมช่วยเล่น Fivem / ปลดแบนFivem ราคาถูกและปลอดภัยต่อผู้ใช้ ตอบโจทย์ทุกการใช้งาน ต่างๆ ไม่ว่าจะเป็นโปรแกรม External / Unban / Internal / CMD',
  button1Text: 'ซื้อเลย',
  button1Link: '#products-catalog',
  button2Text: 'วิธีใช้งาน',
  button2Link: '/how-to'
};

export function getWelcomeBannerSettings(): WelcomeBannerSettings {
  return readJsonFile<WelcomeBannerSettings>(WELCOME_BANNER_FILE, DEFAULT_WELCOME_BANNER_SETTINGS);
}

export function updateWelcomeBannerSettings(updates: Partial<WelcomeBannerSettings>): WelcomeBannerSettings {
  const current = getWelcomeBannerSettings();
  const next = { ...current, ...updates };
  writeJsonFile(WELCOME_BANNER_FILE, next);
  return next;
}

// ----------------------------------------------------
// Background Music (BGM) Repository
// ----------------------------------------------------
const BGM_FILE = path.join(DATA_DIR, 'bgm.json');

export const DEFAULT_BGM_SERVER_SETTINGS: BgmSettings = {
  enabled: true,
  title: '9tokyo - สายไป feat. BLVCKHEART (Official Music Video)',
  subtitle: '9tokyo',
  url: 'https://www.youtube.com/watch?v=j1qw79H4eHU',
  volume: 50,
  autoplay: true,
  loop: true,
  showVisualizer: true,
  position: 'bottom-left'
};

export function getBgmSettingsServer(): BgmSettings {
  return readJsonFile<BgmSettings>(BGM_FILE, DEFAULT_BGM_SERVER_SETTINGS);
}

export function updateBgmSettingsServer(updates: Partial<BgmSettings>): BgmSettings {
  const current = getBgmSettingsServer();
  const next = { ...current, ...updates };
  writeJsonFile(BGM_FILE, next);
  return next;
}

// ----------------------------------------------------
// Anti-DevTools & Client Security Settings Repository
// ----------------------------------------------------
const SECURITY_SETTINGS_FILE = path.join(DATA_DIR, 'security-settings.json');

export interface AntiDevtoolSettings {
  enabled: boolean;
  blockF12: boolean;
  blockRightClick: boolean;
  detectWindowResize: boolean;
  debuggerTrap: boolean;
  clearConsole: boolean;
  adminBypass: boolean;
}

export const DEFAULT_ANTI_DEVTOOL_SETTINGS: AntiDevtoolSettings = {
  enabled: true,
  blockF12: true,
  blockRightClick: true,
  detectWindowResize: true,
  debuggerTrap: true,
  clearConsole: true,
  adminBypass: true
};

export function getAntiDevtoolSettingsServer(): AntiDevtoolSettings {
  return readJsonFile<AntiDevtoolSettings>(SECURITY_SETTINGS_FILE, DEFAULT_ANTI_DEVTOOL_SETTINGS);
}

export function updateAntiDevtoolSettingsServer(updates: Partial<AntiDevtoolSettings>): AntiDevtoolSettings {
  const current = getAntiDevtoolSettingsServer();
  const next = { ...current, ...updates };
  writeJsonFile(SECURITY_SETTINGS_FILE, next);
  return next;
}

// ----------------------------------------------------
// Slip API & Payment Channels Configuration Repository
// ----------------------------------------------------
export const DEFAULT_SERVER_SLIP_CONFIG: SlipApiConfig = {
  provider: 'slipok',
  apiKey: '',
  branchId: '',
  promptPayNumber: '5160906053',
  accountName: 'ณัฐพงศ์ แซ่หลู่',
  bankName: 'กสิกรไทย (KBANK / K+)',
  trueMoneyPhone: '098-XXX-XXXX',
  autoApprove: true,
  channelPromptPayEnabled: true,
  channelBankTransferEnabled: true,
  channelAngpaoEnabled: true,
  channelTrueMoneyWalletEnabled: true,
  angpaoFeePercent: 2.9
};

export function getSlipConfigServer(): SlipApiConfig {
  return readJsonFile<SlipApiConfig>(SLIP_CONFIG_FILE, DEFAULT_SERVER_SLIP_CONFIG);
}

export function updateSlipConfigServer(updates: Partial<SlipApiConfig>): SlipApiConfig {
  const current = getSlipConfigServer();
  const next = { ...current, ...updates };
  writeJsonFile(SLIP_CONFIG_FILE, next);
  return next;
}

// ----------------------------------------------------
// Random Account & Gacha Boxes Repository
// ----------------------------------------------------
const RANDOM_BOXES_FILE = path.join(DATA_DIR, 'random-boxes.json');

export interface RandomBoxItem {
  id: string;
  name: string;
  tier: 'common' | 'rare' | 'epic' | 'legendary';
  chance: number; // percentage (e.g. 10, 30, 50)
  accounts: string[]; // pool of "user:pass" or prizes
  image?: string;
}

export interface RandomBox {
  id: string;
  name: string;
  game: string;
  category?: string;
  image: string;
  price: number;
  badge?: string;
  isActive: boolean;
  totalSpins: number;
  stock?: number;
  warningText?: string;
  items: RandomBoxItem[];
}

export interface RandomBoxRollRecord {
  id: string;
  boxId: string;
  boxName: string;
  userId: string;
  username: string;
  itemName: string;
  tier: string;
  resultAccount: string;
  resultAccounts?: string[];
  quantity?: number;
  price: number;
  createdAt: string;
}

export interface RandomBoxesData {
  boxes: RandomBox[];
  history: RandomBoxRollRecord[];
}

export function getRandomBoxesData(): RandomBoxesData {
  return readJsonFile<RandomBoxesData>(RANDOM_BOXES_FILE, {
    boxes: [],
    history: []
  });
}

export function saveRandomBoxesData(data: RandomBoxesData) {
  writeJsonFile(RANDOM_BOXES_FILE, data);
}

export function rollRandomBox(boxId: string, userId: string, quantity: number = 1): {
  success: boolean;
  result?: RandomBoxRollRecord;
  results?: RandomBoxRollRecord[];
  newBalance?: number;
  error?: string;
} {
  const users = getUsers();
  const user = users.find(u => u.id === userId);
  if (!user) return { success: false, error: 'ไม่พบข้อมูลผู้ใช้งาน กรุณาเข้าสู่ระบบ' };

  const data = getRandomBoxesData();
  const box = data.boxes.find(b => b.id === boxId);
  if (!box || !box.isActive) {
    return { success: false, error: 'ไม่พบกล่องสุ่มนี้หรือกล่องนี้ถูกปิดใช้งาน' };
  }

  if (box.items.length === 0) {
    return { success: false, error: 'กล่องนี้ยังไม่มีของรางวัล' };
  }

  const qty = Math.max(1, Math.min(20, Math.floor(quantity || 1)));
  const totalPrice = Math.round(box.price * qty * 100) / 100;

  // Check balance and deduct
  if (user.balance < totalPrice) {
    return {
      success: false,
      error: `ยอดเงินคงเหลือไม่เพียงพอ (ต้องการ ฿${totalPrice.toLocaleString('th-TH', { minimumFractionDigits: 2 })})`
    };
  }

  const balanceResult = adjustUserBalance(userId, -totalPrice);
  if (!balanceResult.success) {
    return { success: false, error: balanceResult.error || 'หักเงินไม่สำเร็จ' };
  }

  const totalChance = box.items.reduce((sum, item) => sum + (item.chance || 0), 0) || 100;
  const now = new Date();
  const dateStr = now.toLocaleDateString('th-TH') + ' ' + now.toLocaleTimeString('th-TH');

  const records: RandomBoxRollRecord[] = [];

  for (let i = 0; i < qty; i++) {
    let rand = Math.random() * totalChance;
    let selectedItem = box.items[0];

    for (const item of box.items) {
      if (rand <= (item.chance || 0)) {
        selectedItem = item;
        break;
      }
      rand -= (item.chance || 0);
    }

    let prizeAccount = 'ขอบคุณที่ร่วมสนุก!';
    if (selectedItem.accounts && selectedItem.accounts.length > 0) {
      const accIdx = Math.floor(Math.random() * selectedItem.accounts.length);
      prizeAccount = selectedItem.accounts[accIdx];
    }

    const rec: RandomBoxRollRecord = {
      id: 'roll-' + Date.now() + '-' + i + '-' + Math.floor(Math.random() * 1000),
      boxId: box.id,
      boxName: box.name,
      userId: user.id,
      username: user.username,
      itemName: selectedItem.name,
      tier: selectedItem.tier,
      resultAccount: prizeAccount,
      price: box.price,
      createdAt: dateStr
    };
    records.push(rec);
  }

  box.totalSpins = (box.totalSpins || 0) + qty;
  if (typeof box.stock === 'number') {
    box.stock = Math.max(0, box.stock - qty);
  }

  data.history = [...records, ...(data.history || [])].slice(0, 500);
  saveRandomBoxesData(data);

  // Consolidated record
  const primaryRecord: RandomBoxRollRecord = {
    ...records[0],
    quantity: qty,
    price: totalPrice,
    resultAccount: records.map(r => r.resultAccount).join('\n'),
    resultAccounts: records.map(r => r.resultAccount)
  };

  return {
    success: true,
    result: primaryRecord,
    results: records,
    newBalance: balanceResult.newBalance
  };
}

// ----------------------------------------------------
// Site Content & FAQ & Contact Modal Repository
// ----------------------------------------------------
export function getSiteContent(): SiteContent {
  const defaultContent: SiteContent = {
    branding: {
      siteName: 'ARX STORE',
      siteTitle: 'ARX STORE | บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ',
      slogan: 'บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ ซื้อขายระบบอัตโนมัติ 24 ชม.',
      logoUrl: '/brand/logo.png',
      faviconUrl: '/icon.png'
    },
    stepsSection: {
      subtitle: 'ขั้นตอน',
      title: 'ซื้อยังไง',
      steps: [
        { number: '01', title: 'เลือกสินค้า', description: 'ดูรายละเอียดและจำนวนคงเหลือก่อนซื้อสินค้า' },
        { number: '02', title: 'ชำระเงิน', description: 'มีเครดิตกดจ่ายได้เลย ไม่มีก็เติมเข้าบัญชีก่อน' },
        { number: '03', title: 'รับสินค้า', description: 'ข้อมูลขึ้นบนหน้าเว็บและส่งเข้าอีเมล เปิดดูย้อนหลังได้' },
        { number: '04', title: 'มีปัญหา ทักเลย', description: 'แจ้งเคลมเองได้จากหน้าคำสั่งซื้อภายในเวลารับประกัน' }
      ]
    },
    faqSection: {
      subtitle: 'คำถามที่พบบ่อย',
      title: 'สงสัยอะไรไหม',
      faqs: [
        { id: 'faq-1', question: 'ต้องสมัครสมาชิกไหม', answer: 'สมัครสมาชิกง่ายๆ เพียงกรอกชื่อผู้ใช้และรหัสผ่าน ไม่จำเป็นต้องใช้อีเมลจริง เพื่อเก็บประวัติการสั่งซื้อ ดูรหัสคีย์ย้อนหลังได้ตลอดเวลา' },
        { id: 'faq-2', question: 'ได้ของเมื่อไหร่', answer: 'ได้รับสินค้าทันทีหลังชำระเงินเสร็จสิ้น ระบบทำงานจัดส่งอัตโนมัติ 24 ชม. ข้อมูลจะแสดงบนหน้าจอและบันทึกลงบัญชีของคุณทันที' },
        { id: 'faq-3', question: 'ถ้าสินค้าใช้ไม่ได้ทำยังไง', answer: 'สินค้าทุกตัวมีคลิปสอนและวิธีใช้งานอย่างละเอียด หากติดขัดสามารถกดปุ่มติดต่อเพื่อส่งข้อความให้แอดมินช่วยตรวจสอบและเคลมสินค้าได้ตลอดเวลา' },
        { id: 'faq-4', question: 'เติมเงินได้ทางไหนบ้าง', answer: 'รองรับระบบสแกน QR Code พร้อมเพย์ และ TrueMoney Wallet ยอดเงินเข้าบัญชีอัตโนมัติทันที สะดวก ปลอดภัย 100%' }
      ]
    },
    contactModal: {
      title: 'ARX STORE',
      subtitle: 'ช่องทางติดต่อและติดตามเรา',
      channels: [
        { id: 'facebook', platform: 'facebook', label: 'Facebook', url: '#', color: '#1877F2', enabled: true },
        { id: 'discord', platform: 'discord', label: 'Discord', url: '#', color: '#5865F2', enabled: true },
        { id: 'instagram', platform: 'instagram', label: 'Instagram', url: '#', color: '#E1306C', enabled: true }
      ]
    },
    footer: {
      description: 'ซื้อไปแล้วกลัวใช้ไม่ได้? ไม่ต้องกังวลครับ ทุกโปรแกรมมีคลิปสอนให้ ใช้งานง่ายไม่ต้องเซ็ตเอง พร้อมแลกและมีแอดมินคอยให้คำปรึกษาตลอดการใช้งาน',
      reportText: 'ติดต่อร้านค้าไม่ได้ หรือต้องการรายงานปัญหาร้านค้าขี้โกง? แจ้งเรื่องกับทีมงานกลาง',
      reportUrl: '#',
      copyright: '© 2026 ARX STORE',
      currencyNote: 'ราคาทั้งหมดเป็นเงินบาท'
    }
  };
  return readJsonFile<SiteContent>(SITE_CONTENT_FILE, defaultContent);
}

export function saveSiteContent(data: SiteContent): void {
  writeJsonFile(SITE_CONTENT_FILE, data);
}

export function getResellerSettings(): ResellerSettings {
  const defaultSettings: ResellerSettings = {
    title: 'โปรแกรมตัวแทนจำหน่าย',
    subtitle: 'เติมสะสมยิ่งเยอะ ยิ่งลดเยอะทุกออเดอร์ — ระบบเลื่อนระดับให้อัตโนมัติเมื่อยอดเติมสะสมถึงเกณฑ์ ส่วนลดหักให้ทันทีตอนสั่งซื้อ',
    badgeTitle: 'ยศของคุณไม่มีวันหมดอายุ',
    badgeDescription: 'ยศนี้ไม่มีเงื่อนไขยอดรักษายศ — ใช้สิทธิ์ได้ต่อเนื่อง เติมสะสมเพื่อเลื่อนระดับถัดไป',
    allTiersTitle: 'ระดับทั้งหมด',
    allTiersSubtitle: 'เลื่อนอัตโนมัติเมื่อยอดเติมสะสมถึงเกณฑ์',
    leaderboardTitle: 'อันดับตัวแทนจำหน่าย',
    leaderboardSubtitle: 'ตัวแทนที่มียอดเติมสะสมสูงสุดในร้าน',
    tiers: [
      {
        id: 'tier-1',
        name: 'ลูกค้าทั่วไป',
        minTopup: 0,
        discountPercent: 0,
        badgeText: 'ยังไม่มีส่วนลด',
        displayDiscount: '—',
        color: '#00e5ff',
        description: 'เริ่มต้นใช้งาน สั่งซื้อสินค้าได้ทันที'
      },
      {
        id: 'tier-2',
        name: 'ลดราคาสินค้าทุกอย่าง 15%',
        minTopup: 1500,
        discountPercent: 20,
        badgeText: 'ลดทุกออเดอร์',
        displayDiscount: '-20%',
        color: '#f97316',
        description: 'เติมสะสมครบ 1,500 บาท เลื่อนยศทันที'
      },
      {
        id: 'tier-3',
        name: 'ลดราคาสินค้าทุกอย่าง 50%',
        minTopup: 5000,
        discountPercent: 50,
        badgeText: 'ลดทุกออเดอร์',
        displayDiscount: '-50%',
        color: '#eab308',
        description: 'สิทธิ์ตัวแทนสูงสุด ประหยัดสูงสุดทุกรายการ'
      }
    ],
    leaderboard: [
      {
        id: 'lb-1',
        rank: 1,
        username: 'bea•••xa',
        tierName: 'ลดราคาสินค้าทุกอย่าง 50%',
        discountLabel: 'ลด 50%',
        color: '#eab308',
        totalTopup: 12500
      },
      {
        id: 'lb-2',
        rank: 2,
        username: 'ggu•••67',
        tierName: 'ลดราคาสินค้าทุกอย่าง 15%',
        discountLabel: 'ลด 20%',
        color: '#f97316',
        totalTopup: 3400
      },
      {
        id: 'lb-3',
        rank: 3,
        username: 'won•••ht',
        tierName: 'ลดราคาสินค้าทุกอย่าง 15%',
        discountLabel: 'ลด 20%',
        color: '#f97316',
        totalTopup: 2100
      }
    ]
  };
  return readJsonFile<ResellerSettings>(RESELLER_SETTINGS_FILE, defaultSettings);
}

export function updateResellerSettings(updates: Partial<ResellerSettings>): ResellerSettings {
  const current = getResellerSettings();
  const updated: ResellerSettings = {
    ...current,
    ...updates,
    tiers: updates.tiers || current.tiers,
    leaderboard: updates.leaderboard || current.leaderboard
  };
  writeJsonFile(RESELLER_SETTINGS_FILE, updated);
  return updated;
}






// ----------------------------------------------------
// Theme (ระบบปรับสีเว็บ) Settings Repository
// ----------------------------------------------------
import { ThemeSettings, DEFAULT_THEME, sanitizeTheme } from '@/lib/theme';
const THEME_FILE = path.join(DATA_DIR, 'theme.json');

export function getThemeSettings(): ThemeSettings {
  return sanitizeTheme(readJsonFile<Partial<ThemeSettings>>(THEME_FILE, DEFAULT_THEME));
}

export function updateThemeSettings(updates: Partial<ThemeSettings>): ThemeSettings {
  const next = sanitizeTheme({ ...getThemeSettings(), ...updates, updatedAt: new Date().toISOString() });
  writeJsonFile(THEME_FILE, next);
  return next;
}

export function resetThemeSettings(): ThemeSettings {
  const next = sanitizeTheme({ ...DEFAULT_THEME, updatedAt: new Date().toISOString() });
  writeJsonFile(THEME_FILE, next);
  return next;
}
