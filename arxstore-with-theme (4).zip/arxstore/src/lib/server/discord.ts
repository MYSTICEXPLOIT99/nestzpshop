import { getServerSettings } from './db';

export async function dispatchDiscordNotification(
  type: 'order' | 'topup' | 'register' | 'stock',
  payload: {
    title: string;
    description?: string;
    fields?: Array<{ name: string; value: string; inline?: boolean }>;
    color?: number;
  }
) {
  try {
    const settings = getServerSettings();
    const webhookUrl = settings.discordWebhookUrl || process.env.DISCORD_WEBHOOK_URL;
    if (!webhookUrl) return; // No webhook configured

    // Check toggle
    if (type === 'order' && settings.notifyOrder === false) return;
    if (type === 'topup' && settings.notifyTopup === false) return;
    if (type === 'register' && settings.notifyRegister === false) return;
    if (type === 'stock' && settings.notifyStock === false) return;

    const colors = {
      order: 0x00FF9D,    // Neon Green
      topup: 0x00D8FF,    // Cyan
      register: 0x9D00FF, // Purple
      stock: 0xFFB800     // Gold
    };

    const embed = {
      title: payload.title,
      description: payload.description,
      color: payload.color || colors[type] || 0x00FF9D,
      fields: payload.fields || [],
      footer: {
        text: 'ARX STORE · Automated Cyber Notification',
        icon_url: 'https://arxstore.xyz/brand/logo.png'
      },
      timestamp: new Date().toISOString()
    };

    await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'ARX STORE NOTIFIER',
        avatar_url: 'https://arxstore.xyz/brand/webhook-avatar.png',
        embeds: [embed]
      })
    });
  } catch (err) {
    console.error('Failed to dispatch Discord notification:', err);
  }
}
