// ระบบปรับสีเว็บ (Theme) — ใช้ร่วมกันได้ทั้งฝั่ง Server และ Client (ไม่ใช้ fs)

export interface ThemeSettings {
  /** สีหลัก: ปุ่ม, ลิงก์, ไฮไลต์ (แทนที่สีน้ำเงิน #0000ff และชุดสี blue ทั้งเว็บ) */
  main: string;
  /** สีรอง: ไล่เฉด/ป้ายรอง (แทน #1a1aff และชุดสี purple/indigo/violet) */
  secondary: string;
  /** สีเน้น: ตัวเลข/ไอคอน/เส้นเรืองแสง และหลังบ้านทั้งหมด (แทน #00e5ff และชุดสี cyan/sky) */
  accent: string;
  /** พื้นหลังหน้าเว็บ + หลังบ้าน (โหมดมืด) */
  background: string;
  /** พื้นหลังการ์ด/แผง (โหมดมืด) */
  card: string;
  /** สีตัวอักษรหลัก (โหมดมืด) */
  text: string;
  /** สีตัวอักษรรอง/จาง (โหมดมืด) */
  textMuted: string;
  /** สีขอบการ์ด (ความโปร่งใสคำนวณอัตโนมัติ) */
  border: string;
  /** เปิด/ปิดระบบ — ปิดแล้วใช้สีเดิมของเว็บ */
  enabled: boolean;
  updatedAt?: string;
}

export const DEFAULT_THEME: ThemeSettings = {
  main: '#0000ff',
  secondary: '#1a1aff',
  accent: '#00e5ff',
  background: '#000000',
  card: '#101012',
  text: '#f5f5f5',
  textMuted: '#a3a3a3',
  border: '#ffffff',
  enabled: true
};

export const COLOR_KEYS = ['main', 'secondary', 'accent', 'background', 'card', 'text', 'textMuted', 'border'] as const;
export type ColorKey = (typeof COLOR_KEYS)[number];

export interface ThemePreset {
  id: string;
  label: string;
  values: Omit<ThemeSettings, 'enabled' | 'updatedAt'>;
}

export const THEME_PRESETS: ThemePreset[] = [
  { id: 'electric-blue', label: 'Electric Blue (ค่าเดิม)', values: { ...DEFAULT_THEME } },
  { id: 'cyan-arx', label: 'Cyan ARX', values: { main: '#00b8d4', secondary: '#0284c7', accent: '#00e5ff', background: '#05090d', card: '#0c141a', text: '#f1fbff', textMuted: '#8fb0bd', border: '#00e5ff' } },
  { id: 'neon-purple', label: 'Neon Purple', values: { main: '#a21cff', secondary: '#a855f7', accent: '#e879f9', background: '#09090b', card: '#13141f', text: '#ffffff', textMuted: '#a3a3a3', border: '#ffffff' } },
  { id: 'emerald', label: 'Neon Emerald', values: { main: '#059669', secondary: '#34d399', accent: '#6ee7b7', background: '#04100c', card: '#0b1a15', text: '#ecfdf5', textMuted: '#86b9a6', border: '#10b981' } },
  { id: 'cyber-red', label: 'Cyber Red', values: { main: '#dc2626', secondary: '#f97316', accent: '#fb923c', background: '#0b0505', card: '#170d0d', text: '#fef2f2', textMuted: '#b69090', border: '#ef4444' } },
  { id: 'golden', label: 'Golden Amber', values: { main: '#d97706', secondary: '#fbbf24', accent: '#fde047', background: '#0a0803', card: '#16120a', text: '#fffbeb', textMuted: '#b3a37a', border: '#f59e0b' } },
  { id: 'rose', label: 'Rose Pink', values: { main: '#db2777', secondary: '#f472b6', accent: '#f9a8d4', background: '#0b0509', card: '#170c13', text: '#fdf2f8', textMuted: '#b890a6', border: '#ec4899' } },
  { id: 'blurple', label: 'Discord Blurple', values: { main: '#5865f2', secondary: '#7983f5', accent: '#38bdf8', background: '#0a0a10', card: '#14151f', text: '#f2f3ff', textMuted: '#9a9db8', border: '#5865f2' } }
];

/** สีเข้มที่เขียนตายตัวในโค้ดเดิม (bg-[#xxxxxx]) — ถูกแปลงเป็นตัวแปร --arx-dk-xxxxxx แล้วเลื่อนตามสีพื้นหลัง/การ์ด */
export const ARX_DARK_HEXES: string[] = ["#020408", "#04060c", "#04060d", "#040e1a", "#050811", "#060913", "#061524", "#061824", "#07080d", "#07090e", "#070912", "#070b13", "#070b14", "#070b16", "#08090d", "#08090e", "#080a10", "#080b14", "#080d16", "#080d1a", "#090b12", "#090b14", "#090d16", "#090e1b", "#0a0a0f", "#0a0c12", "#0a0d14", "#0a0d16", "#0b0c10", "#0b0e1b", "#0c0d12", "#0c0e14", "#0c0e17", "#0c1017", "#0c1220", "#0d0e12", "#0d1017", "#0e0e17", "#0e0f14", "#0e1017", "#0e121e", "#0e1222", "#111216", "#111217", "#11131a", "#121029", "#13141a", "#14151a", "#14151c", "#141722", "#171d27", "#181920", "#181c22", "#191c26", "#1a1f29", "#1c1e26", "#1e1f22", "#1e232a", "#232428", "#242932", "#242b36", "#2b2d31"];

const HEX_RE = /^#([0-9a-f]{6})$/i;

export function isValidHex(v: unknown): v is string {
  return typeof v === 'string' && HEX_RE.test(v.trim());
}

/** รับ #rgb หรือ #rrggbb แล้วคืน #rrggbb (ตัวพิมพ์เล็ก) หรือ null ถ้าไม่ถูกต้อง */
export function normalizeHex(v: unknown): string | null {
  if (typeof v !== 'string') return null;
  let s = v.trim().toLowerCase();
  if (/^#[0-9a-f]{3}$/.test(s)) s = '#' + s.slice(1).split('').map(c => c + c).join('');
  return HEX_RE.test(s) ? s : null;
}

export function hexToRgb(hex: string): [number, number, number] {
  const h = normalizeHex(hex) || '#000000';
  return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
}

function rgbToHex(r: number, g: number, b: number): string {
  const c = (n: number) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0');
  return `#${c(r)}${c(g)}${c(b)}`;
}

/** ผสมสี a -> b ตามสัดส่วน t (0..1) */
export function mix(a: string, b: string, t: number): string {
  const [ar, ag, ab] = hexToRgb(a);
  const [br, bg, bb] = hexToRgb(b);
  return rgbToHex(ar + (br - ar) * t, ag + (bg - ag) * t, ab + (bb - ab) * t);
}

function luminance(hex: string): number {
  const [r, g, b] = hexToRgb(hex).map(v => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** อัตราส่วนความคมชัด WCAG (1–21) */
export function contrastRatio(a: string, b: string): number {
  const la = luminance(a);
  const lb = luminance(b);
  const [hi, lo] = la > lb ? [la, lb] : [lb, la];
  return (hi + 0.05) / (lo + 0.05);
}

/** ตัวอักษรบนพื้นสีนี้ควรเป็นขาวหรือดำ */
export function readableOn(hex: string): '#ffffff' | '#0a0a0a' {
  return contrastRatio(hex, '#ffffff') >= contrastRatio(hex, '#0a0a0a') ? '#ffffff' : '#0a0a0a';
}

/** รวมค่าที่รับมากับค่าเริ่มต้น และตัดค่าที่ไม่ใช่ hex ออก */
export function sanitizeTheme(input: Partial<ThemeSettings> | null | undefined): ThemeSettings {
  const out: ThemeSettings = { ...DEFAULT_THEME };
  if (!input || typeof input !== 'object') return out;
  COLOR_KEYS.forEach(k => {
    const n = normalizeHex(input[k]);
    if (n) out[k] = n;
  });
  if (typeof input.enabled === 'boolean') out.enabled = input.enabled;
  if (typeof input.updatedAt === 'string') out.updatedAt = input.updatedAt;
  return out;
}

// ---------- ชุดเฉดสี (Tailwind 50–950) ----------

const STEPS = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950] as const;

/** สร้างเฉดสี 50–950 จากสีเดียว โดยให้ 500 = สีที่เลือก */
function accentScale(base: string): Record<number, string> {
  const light: Record<number, number> = { 50: 0.93, 100: 0.85, 200: 0.7, 300: 0.5, 400: 0.25 };
  const darkT: Record<number, number> = { 600: 0.14, 700: 0.3, 800: 0.46, 900: 0.6, 950: 0.76 };
  const out: Record<number, string> = {};
  for (const s of STEPS) {
    if (s === 500) out[s] = base;
    else if (light[s] !== undefined) out[s] = mix(base, '#ffffff', light[s]);
    else out[s] = mix(base, '#000000', darkT[s]);
  }
  return out;
}

/** เฉดสีกลาง (slate/zinc/gray) ที่ไล่จากพื้นหลัง -> การ์ด -> ตัวอักษร */
function neutralScale(t: ThemeSettings): Record<number, string> {
  return {
    950: t.background,
    900: t.card,
    800: mix(t.card, t.textMuted, 0.12),
    700: mix(t.card, t.textMuted, 0.26),
    600: mix(t.card, t.textMuted, 0.42),
    500: mix(t.card, t.textMuted, 0.72),
    400: t.textMuted,
    300: mix(t.textMuted, t.text, 0.4),
    200: mix(t.textMuted, t.text, 0.7),
    100: mix(t.textMuted, t.text, 0.9),
    50: t.text
  };
}

function scaleVars(family: string, scale: Record<number, string>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const s of STEPS) out[`--color-${family}-${s}`] = scale[s];
  return out;
}

function decl(vars: Record<string, string>): string {
  return Object.entries(vars).map(([k, v]) => `${k}:${v}`).join(';');
}

const rgbStr = (hex: string) => hexToRgb(hex).join(', ');
const changed = (t: ThemeSettings, ...keys: ColorKey[]) => keys.some(k => t[k] !== DEFAULT_THEME[k]);

/**
 * ตัวแปร CSS ที่จะใช้ทับค่าเดิมของเว็บ — แยกเป็นกลุ่ม และจะสร้างเฉพาะกลุ่มที่ผู้ดูแลเปลี่ยนจากค่าเดิม
 * (ถ้าไม่เปลี่ยนอะไรเลย เว็บจะหน้าตาเหมือนเดิม 100%)
 */
export function buildThemeVars(t: ThemeSettings): { global: Record<string, string>; dark: Record<string, string> } {
  const g: Record<string, string> = {};
  const d: Record<string, string> = {};

  if (changed(t, 'main')) {
    Object.assign(g, {
      '--theme-main': t.main,
      '--theme-main-rgb': rgbStr(t.main),
      '--theme-main-contrast': readableOn(t.main),
      '--theme-glow': `rgba(${rgbStr(t.main)}, 0.45)`,
      '--glass-border-color': `rgba(${rgbStr(t.main)}, 0.25)`
    }, scaleVars('blue', accentScale(t.main)));
  }
  if (changed(t, 'secondary')) {
    const sc = accentScale(t.secondary);
    Object.assign(g, { '--theme-sec': t.secondary, '--theme-sec-rgb': rgbStr(t.secondary), '--theme-accent-blue': t.secondary });
    for (const fam of ['indigo', 'violet', 'purple', 'fuchsia']) Object.assign(g, scaleVars(fam, sc));
  }
  if (changed(t, 'accent')) {
    const sc = accentScale(t.accent);
    Object.assign(g, { '--theme-accent': t.accent, '--theme-accent-rgb': rgbStr(t.accent) });
    for (const fam of ['cyan', 'sky']) Object.assign(g, scaleVars(fam, sc));
  }
  if (changed(t, 'background', 'card', 'text', 'textMuted', 'border')) {
    const ns = neutralScale(t);
    Object.assign(d, {
      '--theme-bg': t.background,
      '--background': t.background,
      '--theme-font': t.text,
      '--theme-font-rgb': rgbStr(t.text),
      '--foreground': t.text,
      '--theme-card-bg': t.card,
      '--theme-card-bg-safe': t.card,
      '--theme-surface-safe': t.card,
      '--nav-panel-bg': t.card,
      '--theme-card-border': `rgba(${rgbStr(t.border)}, 0.12)`,
      '--theme-card-border-safe': `rgba(${rgbStr(t.border)}, 0.12)`,
      '--theme-text-safe': t.text,
      '--theme-text-muted-safe': t.textMuted,
      '--nav-text': t.text,
      '--nav-muted': t.textMuted
    });
    for (const fam of ['slate', 'zinc', 'gray', 'neutral']) Object.assign(d, scaleVars(fam, ns));
    // สีเข้มตายตัวเดิม ๆ: เลื่อนตามตำแหน่งความสว่างระหว่าง "พื้นหลัง" -> "การ์ด"
    const cardLum = luminance(DEFAULT_THEME.card) || 0.006;
    for (const h of ARX_DARK_HEXES) {
      const k = Math.min(1, luminance(h) / cardLum);
      d[`--arx-dk-${h.slice(1)}`] = mix(t.background, t.card, k);
    }
  }
  return { global: g, dark: d };
}

/** สร้างข้อความ CSS สำหรับฉีดใน <style> (ค่าทั้งหมดผ่าน sanitizeTheme แล้ว จึงปลอดภัย) */
export function buildThemeCss(theme: ThemeSettings): string {
  if (!theme.enabled) return '';
  const { global, dark } = buildThemeVars(theme);
  let css = '';
  if (Object.keys(global).length) css += `:root{${decl(global)}}`;
  // พื้นหลัง/ตัวอักษรใช้เฉพาะโหมดมืด (โหมดสว่างมีชุดสีของตัวเอง)
  if (Object.keys(dark).length) css += `html:not(.light){${decl(dark)}}html:not(.light),html:not(.light) body{background-color:${theme.background}}`;
  return css;
}

/** ใช้ในหน้าแอดมินเพื่อพรีวิวสดบนหน้าจริงก่อนกดบันทึก */
export function applyThemeToDocument(theme: ThemeSettings | null) {
  if (typeof document === 'undefined') return;
  const id = 'arx-theme-live';
  let el = document.getElementById(id) as HTMLStyleElement | null;
  if (!theme || !theme.enabled) {
    el?.remove();
    // ปิดระบบ: ซ่อน <style> ฝั่งเซิร์ฟเวอร์ด้วยเพื่อพรีวิวสีเดิม
  }
  const server = document.getElementById('arx-theme') as HTMLStyleElement | null;
  if (server) server.media = theme ? 'not all' : '';
  if (!theme || !theme.enabled) return;
  if (!el) {
    el = document.createElement('style');
    el.id = id;
    document.head.appendChild(el);
  }
  el.textContent = buildThemeCss(theme);
}
