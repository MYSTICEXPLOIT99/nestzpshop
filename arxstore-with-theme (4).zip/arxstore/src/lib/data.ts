import { Product, Category, ServiceStatusItem, Announcement, User } from '@/types';

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'cat-test-1',
    name: 'หมวดหมู่ทดสอบ 1',
    slug: 'test-category-1',
    iconName: 'Sparkles',
    description: 'หมวดหมู่สินค้าทดสอบระบบที่ 1 (ตัวเลือกเดียว)',
    itemCount: 1,
    badge: '01',
    image: '/catalog/imported/banner_fivem.webp',
    linkUrl: '/store?category=cat-test-1#products-catalog'
  },
  {
    id: 'cat-test-2',
    name: 'หมวดหมู่ทดสอบ 2',
    slug: 'test-category-2',
    iconName: 'Flame',
    description: 'หมวดหมู่สินค้าทดสอบระบบที่ 2 (หลายตัวเลือก)',
    itemCount: 1,
    badge: '02',
    image: '/catalog/imported/banner_cheat.webp',
    linkUrl: '/store?category=cat-test-2#products-catalog'
  },
  {
    id: 'cat-test-3',
    name: 'หมวดหมู่ทดสอบ 3',
    slug: 'test-category-3',
    iconName: 'Shield',
    description: 'หมวดหมู่สินค้าทดสอบระบบที่ 3 (ตัวเลือกเดียว)',
    itemCount: 1,
    badge: '03',
    image: '/catalog/imported/banner_customos.webp',
    linkUrl: '/store?category=cat-test-3#products-catalog'
  },
  {
    id: 'cat-test-4',
    name: 'หมวดหมู่ทดสอบ 4',
    slug: 'test-category-4',
    iconName: 'Zap',
    description: 'หมวดหมู่สินค้าทดสอบระบบที่ 4 (หลายตัวเลือก)',
    itemCount: 1,
    badge: '04',
    image: '/catalog/imported/banner_cheat.webp',
    linkUrl: '/store?category=cat-test-4#products-catalog'
  },
  {
    id: 'cat-test-5',
    name: 'หมวดหมู่ทดสอบ 5',
    slug: 'test-category-5',
    iconName: 'Crown',
    description: 'หมวดหมู่สินค้าทดสอบระบบที่ 5 (หลายตัวเลือก VVIP)',
    itemCount: 1,
    badge: '05',
    image: '/catalog/imported/banner_fivem.webp',
    linkUrl: '/store?category=cat-test-5#products-catalog'
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-test-1',
    name: 'สินค้าทดสอบ 1 (ตัวเลือกเดียว)',
    slug: 'test-product-1',
    categoryId: 'cat-test-1',
    categoryName: 'หมวดหมู่ทดสอบ 1',
    subCategoryId: 'sub-test-1',
    subCategoryName: 'สินค้าทดสอบตัวเลือกเดียว',
    description: 'สินค้าทดสอบระบบรูปแบบตัวเลือกเดียว (Single Option) ชำระเงินแล้วรับคีย์ทันที จัดส่งอัตโนมัติ 24 ชม.',
    shortDescription: 'สินค้าทดสอบระบบรูปแบบตัวเลือกเดียว จัดส่งอัตโนมัติ',
    image: '/catalog/imported/46ebc6a271269458ec9b.webp',
    badge: 'สินค้าเทส',
    rating: 5,
    salesCount: 0,
    isPopular: true,
    rank: 1,
    status: 'ready',
    optionType: 'single',
    packages: [
      {
        id: 'pkg-t1-1',
        name: 'สั่งซื้อแบบถาวร (1 ชิ้น)',
        duration: 'ถาวร',
        price: 10,
        stock: 99,
        inStock: true,
        stockItems: [
          {
            id: 'stk-t1-1',
            key: 'TEST-KEY-SINGLE-001',
            isUsed: false,
            createdAt: '2026-10-14'
          },
          {
            id: 'stk-t1-2',
            key: 'TEST-KEY-SINGLE-002',
            isUsed: false,
            createdAt: '2026-10-14'
          }
        ]
      }
    ],
    tags: ['ทดสอบ', 'ตัวเลือกเดียว']
  },
  {
    id: 'prod-test-2',
    name: 'สินค้าทดสอบ 2 (หลายตัวเลือก)',
    slug: 'test-product-2',
    categoryId: 'cat-test-2',
    categoryName: 'หมวดหมู่ทดสอบ 2',
    subCategoryId: 'sub-test-2',
    subCategoryName: 'สินค้าทดสอบหลายตัวเลือก',
    description: 'สินค้าทดสอบระบบรูปแบบหลายตัวเลือก (Multiple Options) เลือกแพ็กเกจระยะเวลาได้ตามต้องการ มีครบทั้ง 1 วัน, 7 วัน, 30 วัน',
    shortDescription: 'สินค้าทดสอบระบบรูปแบบหลายตัวเลือก (1 วัน / 7 วัน / 30 วัน)',
    image: '/catalog/imported/1659904f5d8658a4d024.webp',
    badge: 'หลายตัวเลือก',
    rating: 5,
    salesCount: 0,
    isPopular: true,
    rank: 2,
    status: 'ready',
    optionType: 'multiple',
    packages: [
      {
        id: 'pkg-t2-1',
        name: 'แพ็กเกจใช้งาน 1 วัน',
        duration: '1 วัน',
        price: 20,
        originalPrice: 30,
        stock: 50,
        inStock: true,
        stockItems: [
          {
            id: 'stk-t2-1',
            key: 'TEST-KEY-1D-001',
            isUsed: false,
            createdAt: '2026-10-14'
          }
        ]
      },
      {
        id: 'pkg-t2-2',
        name: 'แพ็กเกจใช้งาน 7 วัน',
        duration: '7 วัน',
        price: 100,
        originalPrice: 150,
        stock: 30,
        inStock: true,
        stockItems: [
          {
            id: 'stk-t2-2',
            key: 'TEST-KEY-7D-001',
            isUsed: false,
            createdAt: '2026-10-14'
          }
        ]
      },
      {
        id: 'pkg-t2-3',
        name: 'แพ็กเกจใช้งาน 30 วัน',
        duration: '30 วัน',
        price: 300,
        originalPrice: 450,
        stock: 20,
        inStock: true,
        stockItems: [
          {
            id: 'stk-t2-3',
            key: 'TEST-KEY-30D-001',
            isUsed: false,
            createdAt: '2026-10-14'
          }
        ]
      }
    ],
    tags: ['ทดสอบ', 'หลายตัวเลือก']
  },
  {
    id: 'prod-test-3',
    name: 'สินค้าทดสอบ 3 (ตัวเลือกเดียว)',
    slug: 'test-product-3',
    categoryId: 'cat-test-3',
    categoryName: 'หมวดหมู่ทดสอบ 3',
    subCategoryId: 'sub-test-3',
    subCategoryName: 'สินค้าทดสอบตัวเลือกเดียว',
    description: 'สินค้าทดสอบระบบรูปแบบตัวเลือกเดียว สิทธิ์ใช้งานทันที จัดส่งข้อมูลและรหัสคีย์อัตโนมัติ',
    shortDescription: 'สินค้าทดสอบระบบรูปแบบตัวเลือกเดียว สิทธิ์ใช้งานทันที',
    image: '/catalog/imported/104c35788c3f6fca9f4e.webp',
    badge: 'สินค้าเทส',
    rating: 5,
    salesCount: 0,
    isPopular: true,
    rank: 3,
    status: 'ready',
    optionType: 'single',
    packages: [
      {
        id: 'pkg-t3-1',
        name: 'สิทธิ์ใช้งานทันที (1 ชิ้น)',
        duration: 'ถาวร',
        price: 50,
        stock: 80,
        inStock: true,
        stockItems: [
          {
            id: 'stk-t3-1',
            key: 'TEST-KEY-SINGLE-003',
            isUsed: false,
            createdAt: '2026-10-14'
          }
        ]
      }
    ],
    tags: ['ทดสอบ', 'ตัวเลือกเดียว']
  },
  {
    id: 'prod-test-4',
    name: 'สินค้าทดสอบ 4 (หลายตัวเลือก)',
    slug: 'test-product-4',
    categoryId: 'cat-test-4',
    categoryName: 'หมวดหมู่ทดสอบ 4',
    subCategoryId: 'sub-test-4',
    subCategoryName: 'สินค้าทดสอบหลายตัวเลือก',
    description: 'สินค้าทดสอบระบบแบบหลายแพ็กเกจ (รายวัน / รายสัปดาห์ / ตลอดชีพ) รองรับการเลือกแพ็กเกจตามความต้องการ',
    shortDescription: 'สินค้าทดสอบระบบแบบหลายแพ็กเกจ (รายวัน / รายสัปดาห์ / ตลอดชีพ)',
    image: '/catalog/imported/eadd032260d2971fffbb.webp',
    badge: 'ยอดนิยม',
    rating: 5,
    salesCount: 0,
    isPopular: true,
    rank: 4,
    status: 'ready',
    optionType: 'multiple',
    packages: [
      {
        id: 'pkg-t4-1',
        name: 'เช่าใช้งาน 1 วัน',
        duration: '1 วัน',
        price: 35,
        stock: 40,
        inStock: true,
        stockItems: [
          {
            id: 'stk-t4-1',
            key: 'TEST-KEY-1D-004',
            isUsed: false,
            createdAt: '2026-10-14'
          }
        ]
      },
      {
        id: 'pkg-t4-2',
        name: 'เช่าใช้งาน 7 วัน',
        duration: '7 วัน',
        price: 150,
        stock: 25,
        inStock: true,
        stockItems: [
          {
            id: 'stk-t4-2',
            key: 'TEST-KEY-7D-004',
            isUsed: false,
            createdAt: '2026-10-14'
          }
        ]
      },
      {
        id: 'pkg-t4-3',
        name: 'ใช้งานตลอดชีพ (Lifetime)',
        duration: 'ถาวร',
        price: 500,
        stock: 10,
        inStock: true,
        stockItems: [
          {
            id: 'stk-t4-3',
            key: 'TEST-KEY-LIFE-004',
            isUsed: false,
            createdAt: '2026-10-14'
          }
        ]
      }
    ],
    tags: ['ทดสอบ', 'หลายตัวเลือก']
  },
  {
    id: 'prod-test-5',
    name: 'สินค้าทดสอบ 5 (หลายตัวเลือก VVIP)',
    slug: 'test-product-5',
    categoryId: 'cat-test-5',
    categoryName: 'หมวดหมู่ทดสอบ 5',
    subCategoryId: 'sub-test-5',
    subCategoryName: 'สินค้าทดสอบหลายตัวเลือก',
    description: 'สินค้าทดสอบระดับพรีเมียม หลายตัวเลือกแพ็กเกจ (VVIP 1 วัน / VVIP 30 วัน) พร้อมคีย์สต็อกในระบบ',
    shortDescription: 'สินค้าทดสอบ VVIP หลายตัวเลือก ครบทุกระดับแพ็กเกจ',
    image: '/catalog/imported/601957f4b81f88d8b27f.webp',
    badge: 'VVIP',
    rating: 5,
    salesCount: 0,
    isPopular: true,
    rank: 5,
    status: 'ready',
    optionType: 'multiple',
    packages: [
      {
        id: 'pkg-t5-1',
        name: 'VVIP 1 วัน',
        duration: '1 วัน',
        price: 50,
        stock: 30,
        inStock: true,
        stockItems: [
          {
            id: 'stk-t5-1',
            key: 'TEST-KEY-VVIP-1D',
            isUsed: false,
            createdAt: '2026-10-14'
          }
        ]
      },
      {
        id: 'pkg-t5-2',
        name: 'VVIP 30 วัน',
        duration: '30 วัน',
        price: 450,
        stock: 15,
        inStock: true,
        stockItems: [
          {
            id: 'stk-t5-2',
            key: 'TEST-KEY-VVIP-30D',
            isUsed: false,
            createdAt: '2026-10-14'
          }
        ]
      }
    ],
    tags: ['ทดสอบ', 'หลายตัวเลือก', 'VVIP']
  }
];

export const INITIAL_SERVICES_STATUS: ServiceStatusItem[] = [
  {
    id: 'srv-1',
    productId: 'prod-test-1',
    productName: 'สินค้าทดสอบ 1 (ตัวเลือกเดียว)',
    category: 'หมวดหมู่ทดสอบ 1',
    status: 'online',
    version: 'v1.0',
    lastChecked: 'เพิ่งอัปเดต',
    image: '/catalog/imported/46ebc6a271269458ec9b.webp',
    note: 'พร้อมจำหน่าย 24 ชม.'
  },
  {
    id: 'srv-2',
    productId: 'prod-test-2',
    productName: 'สินค้าทดสอบ 2 (หลายตัวเลือก)',
    category: 'หมวดหมู่ทดสอบ 2',
    status: 'online',
    version: 'v1.0',
    lastChecked: 'เพิ่งอัปเดต',
    image: '/catalog/imported/1659904f5d8658a4d024.webp',
    note: 'พร้อมจำหน่าย 24 ชม.'
  },
  {
    id: 'srv-3',
    productId: 'prod-test-3',
    productName: 'สินค้าทดสอบ 3 (ตัวเลือกเดียว)',
    category: 'หมวดหมู่ทดสอบ 3',
    status: 'online',
    version: 'v1.0',
    lastChecked: 'เพิ่งอัปเดต',
    image: '/catalog/imported/104c35788c3f6fca9f4e.webp',
    note: 'พร้อมจำหน่าย 24 ชม.'
  },
  {
    id: 'srv-4',
    productId: 'prod-test-4',
    productName: 'สินค้าทดสอบ 4 (หลายตัวเลือก)',
    category: 'หมวดหมู่ทดสอบ 4',
    status: 'online',
    version: 'v1.0',
    lastChecked: 'เพิ่งอัปเดต',
    image: '/catalog/imported/eadd032260d2971fffbb.webp',
    note: 'พร้อมจำหน่าย 24 ชม.'
  },
  {
    id: 'srv-5',
    productId: 'prod-test-5',
    productName: 'สินค้าทดสอบ 5 (หลายตัวเลือก VVIP)',
    category: 'หมวดหมู่ทดสอบ 5',
    status: 'online',
    version: 'v1.0',
    lastChecked: 'เพิ่งอัปเดต',
    image: '/catalog/imported/601957f4b81f88d8b27f.webp',
    note: 'พร้อมจำหน่าย 24 ชม.'
  }
];

export const INITIAL_SERVICE_STATUSES = INITIAL_SERVICES_STATUS;

export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: '⚡ แจ้งอัปเดตระบบเวอร์ชันใหม่ 2026',
    content: 'ระบบทำงานแบบอัตโนมัติ 24 ชม. เสถียร รวดเร็ว ปลอดภัย 100%',
    type: 'success',
    isActive: true,
    createdAt: '2026-10-14'
  },
  {
    id: 'ann-2',
    title: '🎁 โปรโมชั่นเติมเงินอัตโนมัติ รับโบนัสเครดิตเพิ่ม',
    content: 'รับสิทธิ์ได้ทั้งการเติมผ่าน TrueMoney Wallet อั่งเปา และ Thai QR PromptPay',
    type: 'info',
    isActive: true,
    createdAt: '2026-10-14'
  }
];

export const DEMO_USERS: User[] = [
  {
    id: 'usr-admin-arx',
    username: 'arxstore',
    email: 'admin@arxstore.xyz',
    role: 'admin',
    balance: 999999,
    totalSpent: 125000,
    freeHwidResets: 999,
    accumulatedHwidResets: 0,
    avatar: '/brand/logo.png',
    createdAt: '2026-09-01'
  },
  {
    id: 'usr-demo-1',
    username: 'demouser',
    email: 'user@arxstore.xyz',
    role: 'user',
    balance: 1250,
    totalSpent: 3500,
    freeHwidResets: 0,
    accumulatedHwidResets: 0,
    avatar: '/brand/logo.png',
    createdAt: '2026-09-15'
  }
];
