/**
 * Accurate Client & Server Device Detection Utility
 * Detects Real OS, Browser, Device Model, and Form Factor (Desktop / Mobile / Tablet)
 */

export interface ParsedDeviceInfo {
  os: string;
  browser: string;
  deviceType: 'Desktop' | 'Mobile' | 'Tablet';
  model?: string;
  summary: string;
}

export function parseDeviceFromUserAgent(uaString?: string, clientHintPlatform?: string): ParsedDeviceInfo {
  if (!uaString && !clientHintPlatform) {
    return {
      os: 'ไม่ทราบระบบ',
      browser: 'ไม่ทราบเบราว์เซอร์',
      deviceType: 'Desktop',
      summary: 'อุปกรณ์ไม่ระบุ (Unknown Device)'
    };
  }

  const ua = uaString || '';

  // 1. Device Form Factor
  let deviceType: 'Desktop' | 'Mobile' | 'Tablet' = 'Desktop';
  if (/(ipad|tablet|(android(?!.*mobile))|(windows(?!.*phone)(.*touch))|kindle|playbook|silk)/i.test(ua)) {
    deviceType = 'Tablet';
  } else if (/Android.*Mobile|iPhone|iPod|BlackBerry|IEMobile|Opera Mini|Mobile/i.test(ua)) {
    deviceType = 'Mobile';
  } else {
    deviceType = 'Desktop';
  }

  // 2. Specific Model / Brand
  let model = '';
  if (/iPhone/i.test(ua)) {
    model = 'Apple iPhone';
  } else if (/iPad/i.test(ua)) {
    model = 'Apple iPad';
  } else if (/SM-[A-Za-z0-9]+/i.test(ua)) {
    const sm = ua.match(/(SM-[A-Za-z0-9]+)/i);
    model = sm ? `Samsung (${sm[1]})` : 'Samsung Galaxy';
  } else if (/Pixel\s[0-9a-zA-Z]+/i.test(ua)) {
    const px = ua.match(/(Pixel\s[0-9a-zA-Z]+)/i);
    model = px ? `Google ${px[1]}` : 'Google Pixel';
  } else if (/Xiaomi|Redmi|POCO/i.test(ua)) {
    const mi = ua.match(/(Xiaomi|Redmi[a-zA-Z0-9_\s]+|POCO[a-zA-Z0-9_\s]+)/i);
    model = mi ? mi[1].trim() : 'Xiaomi';
  } else if (/OPPO|CPH[0-9]+/i.test(ua)) {
    model = 'OPPO';
  } else if (/vivo/i.test(ua)) {
    model = 'vivo';
  }

  // 3. Operating System Detection
  let os = 'Unknown OS';
  if (/Windows NT 10.0/i.test(ua)) {
    os = 'Windows 10/11';
  } else if (/Windows NT 6.3/i.test(ua)) {
    os = 'Windows 8.1';
  } else if (/Windows NT 6.2/i.test(ua)) {
    os = 'Windows 8';
  } else if (/Windows NT 6.1/i.test(ua)) {
    os = 'Windows 7';
  } else if (/Windows/i.test(ua)) {
    os = 'Windows';
  } else if (/iPhone/i.test(ua)) {
    const m = ua.match(/OS (\d+[._]\d+)/);
    const ver = m ? m[1].replace(/_/g, '.') : '';
    os = ver ? `iOS ${ver}` : 'iOS';
  } else if (/iPad/i.test(ua)) {
    const m = ua.match(/OS (\d+[._]\d+)/);
    const ver = m ? m[1].replace(/_/g, '.') : '';
    os = ver ? `iPadOS ${ver}` : 'iPadOS';
  } else if (/Macintosh|Mac OS X/i.test(ua)) {
    const m = ua.match(/Mac OS X (\d+[._]\d+)/);
    const ver = m ? m[1].replace(/_/g, '.') : '';
    os = ver ? `macOS ${ver}` : 'macOS';
  } else if (/Android/i.test(ua)) {
    const m = ua.match(/Android\s([0-9\.]+)/);
    const ver = m ? m[1] : '';
    os = ver ? `Android ${ver}` : 'Android';
  } else if (/CrOS/i.test(ua)) {
    os = 'ChromeOS';
  } else if (/Linux/i.test(ua)) {
    os = 'Linux';
  } else if (clientHintPlatform) {
    os = clientHintPlatform;
  }

  // 4. Browser Detection
  let browser = 'Unknown Browser';
  if (/Edg\/([0-9\.]+)/i.test(ua)) {
    const m = ua.match(/Edg\/([0-9]+)/);
    browser = `Edge ${m ? m[1] : ''}`.trim();
  } else if (/SamsungBrowser\/([0-9\.]+)/i.test(ua)) {
    const m = ua.match(/SamsungBrowser\/([0-9]+)/);
    browser = `Samsung Internet ${m ? m[1] : ''}`.trim();
  } else if (/OPR\/([0-9\.]+)/i.test(ua) || /Opera/i.test(ua)) {
    const m = ua.match(/OPR\/([0-9]+)/);
    browser = `Opera ${m ? m[1] : ''}`.trim();
  } else if (/Chrome\/([0-9\.]+)/i.test(ua)) {
    const m = ua.match(/Chrome\/([0-9]+)/);
    browser = `Chrome ${m ? m[1] : ''}`.trim();
  } else if (/Firefox\/([0-9\.]+)/i.test(ua)) {
    const m = ua.match(/Firefox\/([0-9]+)/);
    browser = `Firefox ${m ? m[1] : ''}`.trim();
  } else if (/Safari\/([0-9\.]+)/i.test(ua) && !/Chrome|Android/i.test(ua)) {
    const m = ua.match(/Version\/([0-9]+)/);
    browser = `Safari ${m ? m[1] : ''}`.trim();
  }

  // Construct readable summary
  const prefix = model ? `${model} · ` : '';
  const summary = `${prefix}${os} / ${browser} (${deviceType})`;

  return {
    os,
    browser,
    deviceType,
    model: model || undefined,
    summary
  };
}

/**
 * Get real client device info directly from browser environment
 */
export function getClientDeviceInfo(): string {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') {
    return 'ไม่สามารถระบุอุปกรณ์ได้ (Server)';
  }

  try {
    const ua = navigator.userAgent;
    const uaData = (navigator as any).userAgentData;

    let parsed = parseDeviceFromUserAgent(ua, uaData?.platform);

    // If on Windows NT 10.0, we can refine Windows 11 via platformVersion or hints
    if (parsed.os === 'Windows 10/11' && uaData?.platformVersion) {
      const major = parseInt(uaData.platformVersion.split('.')[0], 10);
      if (major >= 13) {
        parsed.os = 'Windows 11';
      } else {
        parsed.os = 'Windows 10';
      }
      parsed.summary = `${parsed.model ? parsed.model + ' · ' : ''}${parsed.os} / ${parsed.browser} (${parsed.deviceType})`;
    }

    return parsed.summary;
  } catch {
    return 'Windows / Chrome (Desktop)';
  }
}
