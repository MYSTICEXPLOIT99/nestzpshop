'use client';

import { flushSync } from 'react-dom';

/**
 * Executes a smooth circular ripple theme transition radiating from
 * the click position / toggle button, exactly like Dearquiz Store / VitePress.
 */
export function executeThemeTransition(
  event: React.MouseEvent | MouseEvent | undefined,
  toggleCallback: () => void
) {
  if (
    typeof document === 'undefined' ||
    typeof window === 'undefined'
  ) {
    toggleCallback();
    return;
  }

  // Fallback if View Transitions API is unavailable or user prefers reduced motion
  if (
    !('startViewTransition' in document) ||
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
  ) {
    toggleCallback();
    return;
  }

  // 1. Calculate the origin coordinates (x, y) from the button click
  let x = window.innerWidth / 2;
  let y = window.innerHeight / 2;

  if (event) {
    if (typeof event.clientX === 'number' && typeof event.clientY === 'number' && (event.clientX > 0 || event.clientY > 0)) {
      x = event.clientX;
      y = event.clientY;
    } else if (event.currentTarget && 'getBoundingClientRect' in event.currentTarget) {
      const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
      x = rect.left + rect.width / 2;
      y = rect.top + rect.height / 2;
    }
  }

  // 2. Calculate the maximum radius required to cover the entire viewport
  const endRadius = Math.hypot(
    Math.max(x, window.innerWidth - x),
    Math.max(y, window.innerHeight - y)
  );

  try {
    // 3. Start the native View Transition
    const transition = (document as any).startViewTransition(() => {
      flushSync(() => {
        toggleCallback();
      });
    });

    // 4. Animate the circular clipPath on ::view-transition-new(root)
    transition.ready
      .then(() => {
        const clipPath = [
          `circle(0px at ${x}px ${y}px)`,
          `circle(${endRadius}px at ${x}px ${y}px)`
        ];

        document.documentElement.animate(
          {
            clipPath
          },
          {
            duration: 480,
            easing: 'cubic-bezier(0.25, 1, 0.5, 1)',
            pseudoElement: '::view-transition-new(root)'
          }
        );
      })
      .catch(() => {
        // Transition was skipped or aborted; DOM was already updated
      });
  } catch {
    toggleCallback();
  }
}
