/**
 * YouTube utilities for extracting video IDs and building embed links
 */

export function extractYouTubeId(url?: string): string | null {
  if (!url) return null;
  const trimmed = url.trim();
  if (!trimmed) return null;

  // Direct 11-char video ID (e.g., '0k2xPz0y70U')
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }

  // Common YouTube URL formats:
  // - https://www.youtube.com/watch?v=VIDEO_ID
  // - https://youtu.be/VIDEO_ID
  // - https://www.youtube.com/embed/VIDEO_ID
  // - https://www.youtube.com/shorts/VIDEO_ID
  const match = trimmed.match(
    /(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/))([a-zA-Z0-9_-]{11})/
  );

  return match ? match[1] : null;
}

export function getProductYouTubeId(url?: string, categoryId?: string): string {
  const extracted = extractYouTubeId(url);
  if (extracted) return extracted;

  // Default high-performance showcase videos by category if none specified
  if (categoryId === 'cat-cheat' || categoryId === 'cat-customos') {
    return 'QkkoHAzjnUs'; // BoostFPS / Windows Optimization Showcase
  }
  return 'hvoD7ehZPcM'; // FiveM Settings & Scripts Showcase (GTA V Official HD)
}
