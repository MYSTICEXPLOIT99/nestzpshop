import type { NextRequest } from 'next/server';

export interface SecurityLog {
  id: string;
  timestamp: string;
  ip: string;
  method: string;
  path: string;
  threatType: 'SQL_INJECTION' | 'XSS' | 'PATH_TRAVERSAL' | 'COMMAND_INJECTION' | 'MALICIOUS_SCANNER' | 'RATE_LIMIT_EXCEEDED' | 'CSRF_BLOCKED' | 'BRUTE_FORCE' | 'SSRF_BLOCKED' | 'SUSPICIOUS_PAYLOAD';
  action: 'BLOCKED_403' | 'RATE_LIMITED_429' | 'QUARANTINED' | 'FLAGGED';
  riskScore: number;
  details: string;
  userAgent?: string;
}

export interface SecurityMetrics {
  totalAttacksBlocked: number;
  activeRateLimits: number;
  activeQuarantinedIPs: number;
  recentLogs: SecurityLog[];
  threatCounters: Record<string, number>;
  wafUptime: number;
}

// 1. Attack Signatures & Heuristics
const SQL_PATTERNS = [
  /(\b(select|union|insert|update|delete|drop|alter|truncate|exec|execute|information_schema|benchmark|sleep)\b.*?\b(from|into|where|table|database|dual)\b)/i,
  /('|"|%27|%22)?\s*\b(or|and)\b\s*('|"|%27|%22)?[^=\s]+=('|"|%27|%22)?/i,
  /('|"|%27|%22)\s*or\s*('|"|%27|%22)?\d+('|"|%27|%22)?\s*=\s*('|"|%27|%22)?\d+/i,
  /(\b(union\s+all\s+select|union\s+select)\b)/i,
  /;\s*(drop|delete|update|insert)\s+/i,
  /\bwaitfor\s+delay\b/i
];

const XSS_PATTERNS = [
  /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
  /<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi,
  /javascript\s*:/i,
  /vbscript\s*:/i,
  /onload\s*=\s*['"]?[^'"]*['"]?/i,
  /onerror\s*=\s*['"]?[^'"]*['"]?/i,
  /<svg\/onload/i,
  /document\.cookie/i,
  /eval\s*\(/i,
  /alert\s*\(/i
];

const PATH_TRAVERSAL_PATTERNS = [
  /(\.\.[\/\\])/,
  /(\/\.git|\/\.env|\/\.htaccess|\/\.htpasswd)/i,
  /\.(env|git|htaccess|htpasswd|ini|bak|sql|tar|gz|zip|sh|bash)($|\/|\?)/i,
  /(etc\/passwd|windows\/system32|boot\.ini)/i,
  /(wp-admin|wp-login|xmlrpc|phpmyadmin|cgi-bin)/i
];

const COMMAND_INJECTION_PATTERNS = [
  /(;|\||`)\s*(cat|ls|dir|whoami|id|bash|sh|curl|wget|nc|python|perl|ruby)\b/i,
  /(\/bin\/sh|\/bin\/bash)/i
];

const TEMPLATE_INJECTION_PATTERNS = [
  /\$\{[^}]+\}/,
  /\{\{[^}]+\}\}/,
  /<%=[^%]+%>/
];

const OPEN_REDIRECT_PATTERNS = [
  /[?&](redirect|next|url|return_url|callback|goto)=((https?:)?\/\/[^\/&]+)/i
];

const SCANNER_USER_AGENTS = [
  'sqlmap',
  'nikto',
  'masscan',
  'wpscan',
  'zgrab',
  'nmap',
  'acunetix',
  'nessus',
  'dirbuster',
  'gobuster',
  'nuclei',
  'metasploit',
  'havij'
];

interface IpReputation {
  score: number;
  lastSeen: number;
  quarantinedUntil?: number;
}

// Global Singleton State so proxy.ts and API routes share identical state across threads
interface GlobalShieldState {
  startTime: number;
  totalAttacksBlocked: number;
  threatCounters: Record<string, number>;
  securityLogs: SecurityLog[];
  rateLimitMap: Map<string, { count: number; resetAt: number }>;
  ipReputationMap: Map<string, IpReputation>;
  failedLoginMap: Map<string, { count: number; lockedUntil: number }>;
  activeConnections: Map<string, number>;
}

const g = globalThis as unknown as { __ARX_SHIELD_STATE__?: GlobalShieldState };

if (!g.__ARX_SHIELD_STATE__) {
  g.__ARX_SHIELD_STATE__ = {
    startTime: Date.now(),
    totalAttacksBlocked: 0,
    threatCounters: {
      SQL_INJECTION: 0,
      XSS: 0,
      PATH_TRAVERSAL: 0,
      COMMAND_INJECTION: 0,
      MALICIOUS_SCANNER: 0,
      RATE_LIMIT_EXCEEDED: 0,
      CSRF_BLOCKED: 0,
      BRUTE_FORCE: 0,
      SSRF_BLOCKED: 0,
      SUSPICIOUS_PAYLOAD: 0
    },
    securityLogs: [],
    rateLimitMap: new Map(),
    ipReputationMap: new Map(),
    failedLoginMap: new Map(),
    activeConnections: new Map()
  };
}

const shieldState = g.__ARX_SHIELD_STATE__;

// Periodic Cleanup (Every 60 seconds)
let lastCleanup = Date.now();
function runGarbageCollection() {
  const now = Date.now();
  if (now - lastCleanup < 45000 && shieldState.rateLimitMap.size < 5000) return;
  lastCleanup = now;

  // Clean rate limits
  for (const [key, record] of shieldState.rateLimitMap.entries()) {
    if (record.resetAt <= now) {
      shieldState.rateLimitMap.delete(key);
    }
  }

  // Clean IP reputations
  for (const [ip, rep] of shieldState.ipReputationMap.entries()) {
    if (now - rep.lastSeen > 3600000 && (!rep.quarantinedUntil || rep.quarantinedUntil <= now)) {
      shieldState.ipReputationMap.delete(ip);
    }
  }

  // Clean failed logins
  for (const [key, rec] of shieldState.failedLoginMap.entries()) {
    if (rec.lockedUntil <= now) {
      shieldState.failedLoginMap.delete(key);
    }
  }
}

// Helper to log security event
export function recordSecurityEvent(event: Omit<SecurityLog, 'id' | 'timestamp'>) {
  shieldState.totalAttacksBlocked++;
  if (shieldState.threatCounters[event.threatType] !== undefined) {
    shieldState.threatCounters[event.threatType]++;
  }

  const logEntry: SecurityLog = {
    id: 'sec-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
    timestamp: new Date().toLocaleTimeString('th-TH', { hour12: false }) + ' ' + new Date().toLocaleDateString('th-TH'),
    ...event
  };

  shieldState.securityLogs.unshift(logEntry);
  if (shieldState.securityLogs.length > 300) {
    shieldState.securityLogs.pop();
  }
}

// Adjust IP Risk Score
function addRiskScore(ip: string, delta: number, reason: string): number {
  const now = Date.now();
  const current = shieldState.ipReputationMap.get(ip) || { score: 0, lastSeen: now };
  current.score = Math.min(100, Math.max(0, current.score + delta));
  current.lastSeen = now;

  // If score exceeds 75: quarantine IP for 10 minutes
  if (current.score >= 75) {
    current.quarantinedUntil = now + 10 * 60 * 1000;
  }

  shieldState.ipReputationMap.set(ip, current);
  return current.score;
}

export interface SecurityVerdict {
  allowed: boolean;
  status?: number;
  reason?: string;
  threatType?: SecurityLog['threatType'];
  headers?: Record<string, string>;
}

/**
 * Main WAF & Defense Evaluation Function
 * Runs on every incoming HTTP request through Next.js proxy
 */
export function evaluateSecurity(request: NextRequest): SecurityVerdict {
  runGarbageCollection();

  const pathname = request.nextUrl.pathname;
  const search = request.nextUrl.search;
  const fullUri = pathname + search;
  let decodedUri = fullUri;
  try {
    decodedUri = decodeURIComponent(fullUri).replace(/\+/g, ' ');
  } catch {
    decodedUri = fullUri.replace(/\+/g, ' ');
  }
  const method = request.method.toUpperCase();

  const ip = request.headers.get('x-forwarded-for')?.split(',')[0].trim() ||
    request.headers.get('x-real-ip') ||
    '127.0.0.1';
  const userAgent = (request.headers.get('user-agent') || '').toLowerCase();
  const origin = request.headers.get('origin');
  const host = request.headers.get('host') || 'localhost:3000';

  const now = Date.now();

  // 0. Admin security monitoring endpoint is always accessible for real-time inspection
  if (pathname.startsWith('/api/admin/security')) {
    return { allowed: true };
  }

  // 1. Check if IP is currently quarantined
  const rep = shieldState.ipReputationMap.get(ip);
  if (rep && rep.quarantinedUntil && rep.quarantinedUntil > now) {
    const remainingSecs = Math.ceil((rep.quarantinedUntil - now) / 1000);
    return {
      allowed: false,
      status: 403,
      reason: `ARX Shield: IP ของคุณถูกกักกันชั่วคราวเนื่องจากตรวจพบพฤติกรรมผิดปกติ กรุณารอ ${remainingSecs} วินาที`,
      threatType: 'SUSPICIOUS_PAYLOAD'
    };
  }

  // 2. Check Malicious Scanners / Exploit User-Agents
  for (const bot of SCANNER_USER_AGENTS) {
    if (userAgent.includes(bot)) {
      addRiskScore(ip, 80, 'Automated Scanner Detected');
      recordSecurityEvent({
        ip,
        method,
        path: pathname,
        threatType: 'MALICIOUS_SCANNER',
        action: 'BLOCKED_403',
        riskScore: 80,
        details: `Scanner User-Agent: ${bot}`,
        userAgent
      });
      return {
        allowed: false,
        status: 403,
        reason: 'ARX Shield: Automated scanning agent blocked (403 Forbidden)',
        threatType: 'MALICIOUS_SCANNER'
      };
    }
  }

  // 3. Path Traversal & Sensitive File Exposure Check
  for (const pattern of PATH_TRAVERSAL_PATTERNS) {
    if (pattern.test(pathname) || pattern.test(fullUri) || pattern.test(decodedUri)) {
      addRiskScore(ip, 60, 'Path Traversal / LFI Attempt');
      recordSecurityEvent({
        ip,
        method,
        path: pathname,
        threatType: 'PATH_TRAVERSAL',
        action: 'BLOCKED_403',
        riskScore: 60,
        details: `Path Traversal signature match: ${pattern}`,
        userAgent
      });
      return {
        allowed: false,
        status: 403,
        reason: 'ARX Shield: Path traversal / restricted access blocked (403 Forbidden)',
        threatType: 'PATH_TRAVERSAL'
      };
    }
  }

  // 4. SQL Injection in Path or Query String Check
  for (const pattern of SQL_PATTERNS) {
    if (pattern.test(fullUri) || pattern.test(decodedUri)) {
      addRiskScore(ip, 70, 'SQL Injection in URI');
      recordSecurityEvent({
        ip,
        method,
        path: pathname,
        threatType: 'SQL_INJECTION',
        action: 'BLOCKED_403',
        riskScore: 70,
        details: `SQLi query payload match`,
        userAgent
      });
      return {
        allowed: false,
        status: 403,
        reason: 'ARX Shield: Malicious SQL injection signature blocked (403 Forbidden)',
        threatType: 'SQL_INJECTION'
      };
    }
  }

  // 5. Cross-Site Scripting (XSS) in Path or Query String Check
  for (const pattern of XSS_PATTERNS) {
    if (pattern.test(fullUri) || pattern.test(decodedUri)) {
      addRiskScore(ip, 50, 'XSS Payload in URI');
      recordSecurityEvent({
        ip,
        method,
        path: pathname,
        threatType: 'XSS',
        action: 'BLOCKED_403',
        riskScore: 50,
        details: `XSS script injection match`,
        userAgent
      });
      return {
        allowed: false,
        status: 403,
        reason: 'ARX Shield: Malicious Cross-Site Scripting (XSS) blocked (403 Forbidden)',
        threatType: 'XSS'
      };
    }
  }

  // 6. Command Injection in Path or Query
  for (const pattern of COMMAND_INJECTION_PATTERNS) {
    if (pattern.test(fullUri) || pattern.test(decodedUri)) {
      addRiskScore(ip, 85, 'OS Command Injection');
      recordSecurityEvent({
        ip,
        method,
        path: pathname,
        threatType: 'COMMAND_INJECTION',
        action: 'BLOCKED_403',
        riskScore: 85,
        details: `Command execution signature match`,
        userAgent
      });
      return {
        allowed: false,
        status: 403,
        reason: 'ARX Shield: Malicious OS command injection signature blocked (403 Forbidden)',
        threatType: 'COMMAND_INJECTION'
      };
    }
  }

  // 6.1 Server-Side Template Injection (SSTI) Check
  for (const pattern of TEMPLATE_INJECTION_PATTERNS) {
    if (pattern.test(fullUri) || pattern.test(decodedUri)) {
      addRiskScore(ip, 75, 'Server-Side Template Injection');
      recordSecurityEvent({
        ip,
        method,
        path: pathname,
        threatType: 'COMMAND_INJECTION',
        action: 'BLOCKED_403',
        riskScore: 75,
        details: `Template injection signature match: ${pattern}`,
        userAgent
      });
      return {
        allowed: false,
        status: 403,
        reason: 'ARX Shield: Malicious Template Injection (SSTI) blocked (403 Forbidden)',
        threatType: 'COMMAND_INJECTION'
      };
    }
  }

  // 6.2 Open Redirect Abuse Check
  for (const pattern of OPEN_REDIRECT_PATTERNS) {
    if (pattern.test(fullUri) || pattern.test(decodedUri)) {
      addRiskScore(ip, 40, 'Open Redirect Attempt');
      recordSecurityEvent({
        ip,
        method,
        path: pathname,
        threatType: 'SUSPICIOUS_PAYLOAD',
        action: 'BLOCKED_403',
        riskScore: 40,
        details: `Open redirect parameter match`,
        userAgent
      });
      return {
        allowed: false,
        status: 403,
        reason: 'ARX Shield: Unvalidated external redirect blocked (403 Forbidden)',
        threatType: 'SUSPICIOUS_PAYLOAD'
      };
    }
  }

  // 7. CSRF / Origin Validation for State-Changing Requests (POST, PUT, DELETE, PATCH)
  if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(method) && pathname.startsWith('/api/')) {
    if (origin) {
      try {
        const originUrl = new URL(origin);
        // Clean host comparison ignoring port if matched
        const cleanHost = host.split(':')[0];
        const cleanOriginHost = originUrl.hostname;
        if (cleanOriginHost !== cleanHost && cleanOriginHost !== 'localhost' && cleanOriginHost !== '127.0.0.1') {
          recordSecurityEvent({
            ip,
            method,
            path: pathname,
            threatType: 'CSRF_BLOCKED',
            action: 'BLOCKED_403',
            riskScore: 65,
            details: `CSRF Origin mismatch: ${origin} vs host ${host}`,
            userAgent
          });
          return {
            allowed: false,
            status: 403,
            reason: 'ARX Shield: Cross-Origin Request Blocked by CSRF Protection',
            threatType: 'CSRF_BLOCKED'
          };
        }
      } catch {
        // invalid origin url
      }
    }
  }

  // 8. Bypass Rate Limit for Harmless Static Assets (Images, fonts, CSS, Next.js build chunks)
  if (
    pathname.startsWith('/_next/') ||
    /\.(ico|png|jpg|jpeg|svg|webp|gif|css|js|woff|woff2|ttf|eot)$/i.test(pathname)
  ) {
    return { allowed: true };
  }

  // 9. Adaptive Multi-Tier Rate Limiting (กันยิง HTTP Flood / DDoS / API Flood)
  const windowMs = 60000; // 1 minute window
  let maxAllowed = 120; // Default for pages: 120 req/min
  let rateCategory = 'general';

  if (pathname.startsWith('/api/discord-webhook')) {
    maxAllowed = 12; // Sensitive webhook forwarder
    rateCategory = 'webhook';
  } else if (pathname.startsWith('/api/auth')) {
    maxAllowed = 15; // Auth/Register flood protection
    rateCategory = 'auth';
  } else if (pathname.startsWith('/api/topup')) {
    maxAllowed = 20; // Topup payment checks
    rateCategory = 'topup';
  } else if (pathname.startsWith('/api/admin/security')) {
    maxAllowed = 60; // Admin polling
    rateCategory = 'admin';
  } else if (pathname.startsWith('/api/')) {
    maxAllowed = 50; // General API endpoints
    rateCategory = 'api';
  }

  const rateKey = `${ip}:${rateCategory}`;
  const rateRecord = shieldState.rateLimitMap.get(rateKey);

  if (!rateRecord || rateRecord.resetAt <= now) {
    shieldState.rateLimitMap.set(rateKey, { count: 1, resetAt: now + windowMs });
  } else {
    rateRecord.count += 1;
    if (rateRecord.count > maxAllowed) {
      const retryAfter = Math.ceil((rateRecord.resetAt - now) / 1000);
      addRiskScore(ip, 25, 'Rate Limit Exceeded');
      recordSecurityEvent({
        ip,
        method,
        path: pathname,
        threatType: 'RATE_LIMIT_EXCEEDED',
        action: 'RATE_LIMITED_429',
        riskScore: 25,
        details: `Exceeded ${maxAllowed} req/min on [${rateCategory}]`,
        userAgent
      });

      return {
        allowed: false,
        status: 429,
        reason: 'ระบบป้องกันการยิง (Anti-DDoS / Rate Limit): ส่งคำขอถี่เกินกำหนด กรุณารอสักครู่',
        threatType: 'RATE_LIMIT_EXCEEDED',
        headers: {
          'Retry-After': String(retryAfter),
          'X-RateLimit-Limit': String(maxAllowed),
          'X-RateLimit-Remaining': '0',
          'X-RateLimit-Reset': String(Math.ceil(rateRecord.resetAt / 1000))
        }
      };
    }
  }

  return { allowed: true };
}

/**
 * SSRF Guard: Validate outbound URLs strictly
 */
export function validateSsrfUrl(urlStr: string, allowedHosts: string[] = ['discord.com', 'discordapp.com']): { valid: boolean; reason?: string } {
  try {
    const parsed = new URL(urlStr);
    if (parsed.protocol !== 'https:') {
      return { valid: false, reason: 'Only HTTPS protocol is permitted' };
    }

    const hostname = parsed.hostname.toLowerCase();

    // Block loopback and private IP ranges
    const isPrivate =
      hostname === 'localhost' ||
      hostname === '127.0.0.1' ||
      hostname === '::1' ||
      hostname.startsWith('10.') ||
      hostname.startsWith('192.168.') ||
      hostname.startsWith('169.254.') || // Cloud metadata (AWS/GCP/Azure)
      /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(hostname) ||
      hostname.endsWith('.internal') ||
      hostname.endsWith('.local');

    if (isPrivate) {
      return { valid: false, reason: 'SSRF Blocked: Private / internal address access denied' };
    }

    if (allowedHosts.length > 0) {
      const isAllowed = allowedHosts.some(host => hostname === host || hostname.endsWith('.' + host));
      if (!isAllowed) {
        return { valid: false, reason: `SSRF Blocked: Host '${hostname}' is not in the whitelist` };
      }
    }

    return { valid: true };
  } catch {
    return { valid: false, reason: 'Invalid URL format' };
  }
}

/**
 * File Upload Security Guard
 * Validates file size, magic bytes and MIME signature for image uploads
 */
export function validateUploadedImage(dataUrlOrBase64: string, maxBytes = 5 * 1024 * 1024): { valid: boolean; reason?: string; mimeType?: string } {
  if (!dataUrlOrBase64 || typeof dataUrlOrBase64 !== 'string') {
    return { valid: false, reason: 'No file data received' };
  }

  // Validate Data URL Scheme
  const match = dataUrlOrBase64.match(/^data:image\/(png|jpe?g|webp);base64,(.+)$/i);
  if (!match) {
    // Check if it's already a relative safe path (e.g. /images/slip_sample.png)
    if (dataUrlOrBase64.startsWith('/images/') || dataUrlOrBase64.startsWith('/brand/')) {
      return { valid: true, mimeType: 'image/png' };
    }
    return { valid: false, reason: 'Invalid file format. Only JPG, PNG, and WebP images are allowed' };
  }

  const mimeType = 'image/' + match[1].toLowerCase();
  const base64Data = match[2];

  // Calculate approximate file size from base64
  const estimatedSize = (base64Data.length * 3) / 4;
  if (estimatedSize > maxBytes) {
    return { valid: false, reason: `File exceeds maximum allowed size of ${Math.round(maxBytes / (1024 * 1024))}MB` };
  }

  // Check magic bytes signatures in base64 prefix
  const prefix = base64Data.substring(0, 16);
  const isPng = prefix.startsWith('iVBORw0KGgo');
  const isJpg = prefix.startsWith('/9j/');
  const isWebp = prefix.startsWith('UklGR');

  if (!isPng && !isJpg && !isWebp) {
    return { valid: false, reason: 'Corrupted image header or spoofed file extension detected' };
  }

  return { valid: true, mimeType };
}

/**
 * Brute Force Login Protection
 */
export function recordFailedLogin(identifier: string): { locked: boolean; remainingAttempts: number; lockTimeSecs?: number } {
  const now = Date.now();
  const rec = shieldState.failedLoginMap.get(identifier) || { count: 0, lockedUntil: 0 };

  if (rec.lockedUntil > now) {
    return {
      locked: true,
      remainingAttempts: 0,
      lockTimeSecs: Math.ceil((rec.lockedUntil - now) / 1000)
    };
  }

  rec.count += 1;
  const maxAttempts = 5;

  if (rec.count >= maxAttempts) {
    const lockDurationMs = 15 * 60 * 1000; // 15 minutes lockout
    rec.lockedUntil = now + lockDurationMs;
    rec.count = 0;
    shieldState.failedLoginMap.set(identifier, rec);
    return {
      locked: true,
      remainingAttempts: 0,
      lockTimeSecs: Math.ceil(lockDurationMs / 1000)
    };
  }

  shieldState.failedLoginMap.set(identifier, rec);
  return {
    locked: false,
    remainingAttempts: maxAttempts - rec.count
  };
}

export function resetFailedLogin(identifier: string) {
  shieldState.failedLoginMap.delete(identifier);
}

export function isLoginLocked(identifier: string): { locked: boolean; lockTimeSecs?: number } {
  const now = Date.now();
  const rec = shieldState.failedLoginMap.get(identifier);
  if (rec && rec.lockedUntil > now) {
    return {
      locked: true,
      lockTimeSecs: Math.ceil((rec.lockedUntil - now) / 1000)
    };
  }
  return { locked: false };
}

/**
 * Get Security Dashboard Metrics for Admin
 */
export function getSecurityMetrics(): SecurityMetrics {
  const now = Date.now();
  let activeRateLimits = 0;
  for (const r of shieldState.rateLimitMap.values()) {
    if (r.resetAt > now) activeRateLimits++;
  }

  let activeQuarantinedIPs = 0;
  for (const rep of shieldState.ipReputationMap.values()) {
    if (rep.quarantinedUntil && rep.quarantinedUntil > now) activeQuarantinedIPs++;
  }

  return {
    totalAttacksBlocked: shieldState.totalAttacksBlocked,
    activeRateLimits,
    activeQuarantinedIPs,
    recentLogs: shieldState.securityLogs.slice(0, 50),
    threatCounters: { ...shieldState.threatCounters },
    wafUptime: Math.floor((now - shieldState.startTime) / 1000)
  };
}

export function unblockIp(ip: string): boolean {
  return shieldState.ipReputationMap.delete(ip);
}

export function clearAllQuarantines() {
  shieldState.ipReputationMap.clear();
  shieldState.rateLimitMap.clear();
  shieldState.failedLoginMap.clear();
}

export function clearSecurityLogs() {
  shieldState.securityLogs = [];
  shieldState.totalAttacksBlocked = 0;
  for (const k of Object.keys(shieldState.threatCounters)) {
    shieldState.threatCounters[k] = 0;
  }
}
