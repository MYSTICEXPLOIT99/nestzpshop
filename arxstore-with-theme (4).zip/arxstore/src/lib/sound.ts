// Web Audio API Sound Synthesizer for Mechanical Keyboard and Action FX

class SoundEngine {
  private ctx: AudioContext | null = null;
  private enabled: boolean = true;
  private lastClickTime: number = 0;

  constructor() {
    // AudioContext will be initialized on first user interaction
  }

  private initContext() {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public setEnabled(val: boolean) {
    this.enabled = val;
  }

  public isEnabled(): boolean {
    return this.enabled;
  }

  /**
   * Play realistic mechanical keyboard switch click (Crisp tactile actuation)
   */
  public playKeyClick() {
    if (!this.enabled || typeof window === 'undefined') return;
    const now = Date.now();
    if (now - this.lastClickTime < 30) return;
    this.lastClickTime = now;

    try {
      const ctx = this.initContext();
      if (!ctx) return;

      const t = ctx.currentTime;

      // Noise buffer for mechanical tactility
      const bufferSize = ctx.sampleRate * 0.035; // 35ms burst
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.008));
      }

      const noise = ctx.createBufferSource();
      noise.buffer = buffer;

      // Bandpass filter to emulate plastic stem housing resonance
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1800 + Math.random() * 400, t);
      filter.Q.setValueAtTime(3.5, t);

      // Main click oscillator for the metal leaf contact
      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320 + Math.random() * 80, t);
      osc.frequency.exponentialRampToValueAtTime(70, t + 0.03);

      const oscGain = ctx.createGain();
      oscGain.gain.setValueAtTime(0.12, t);
      oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.035);

      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(0.22, t);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.025);

      const master = ctx.createGain();
      master.gain.setValueAtTime(0.4, t);

      noise.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(master);

      osc.connect(oscGain);
      oscGain.connect(master);

      master.connect(ctx.destination);

      noise.start(t);
      osc.start(t);
      osc.stop(t + 0.04);
    } catch {
      // Audio not supported or blocked by browser policy
    }
  }

  /**
   * Play success / purchase coin chime
   */
  public playSuccessChime() {
    if (!this.enabled || typeof window === 'undefined') return;
    try {
      const ctx = this.initContext();
      if (!ctx) return;

      const t = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6

      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t + idx * 0.08);

        gain.gain.setValueAtTime(0.15, t + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.08 + 0.35);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(t + idx * 0.08);
        osc.stop(t + idx * 0.08 + 0.38);
      });
    } catch {
      // Audio error
    }
  }

  /**
   * Play error / warning buzz
   */
  public playErrorBuzz() {
    if (!this.enabled || typeof window === 'undefined') return;
    try {
      const ctx = this.initContext();
      if (!ctx) return;

      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, t);
      osc.frequency.setValueAtTime(110, t + 0.1);

      gain.gain.setValueAtTime(0.15, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(t);
      osc.stop(t + 0.28);
    } catch {
      // Audio error
    }
  }
}

export const sound = new SoundEngine();

export const soundEffects = {
  keyClick: () => sound.playKeyClick(),
  success: () => sound.playSuccessChime(),
  buttonClick: () => sound.playKeyClick(),
  error: () => sound.playErrorBuzz()
};
