'use client';

import React, { useState, useEffect, use } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { Product, ProductPackage, Order } from '@/types';
import {
  ChevronLeft,
  Minus,
  Plus,
  Check,
  CheckCircle2,
  X,
  Copy,
  Download,
  ShoppingBag,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  Zap,
  Clock,
  Play,
  RotateCcw,
  FileText
} from 'lucide-react';
import { getProductYouTubeId } from '@/lib/youtube';

export default function ProductDetailPage() {
  const router = useRouter();
  const routeParams = useParams();
  const rawId = routeParams?.id;
  const resolvedId = (Array.isArray(rawId) ? rawId[0] : (rawId || '')) as string;

  const {
    products,
    user,
    isHydrated,
    openAuthModal,
    purchasePackage,
    playClick,
    playSuccess,
    showToast
  } = useStore();

  const [quantity, setQuantity] = useState<number>(1);
  const [selectedPackageId, setSelectedPackageId] = useState<string>('');
  const [customInputVal, setCustomInputVal] = useState<string>('');
  const [isPurchasing, setIsPurchasing] = useState<boolean>(false);
  const [purchaseResult, setPurchaseResult] = useState<Order | null>(null);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState<boolean>(false);

  // Find product by id or slug
  const product: Product | undefined = products.find((p) => {
    if (!resolvedId) return false;
    const target = decodeURIComponent(resolvedId).toLowerCase();
    return (
      p.id.toLowerCase() === target ||
      p.slug.toLowerCase() === target ||
      p.id.toLowerCase() === `prod-${target}` ||
      target.includes(p.id.toLowerCase()) ||
      p.id.toLowerCase().includes(target)
    );
  }) || (products && products.length > 0 ? products[0] : undefined);

  const packages = product?.packages && Array.isArray(product.packages) ? product.packages : [];

  // Determine whether this product is single-option or multi-option
  const isMultiOption =
    product?.optionType === 'multiple' ||
    (product?.optionType !== 'single' && packages.length > 1);

  // Sync selected package
  useEffect(() => {
    if (packages.length > 0) {
      setSelectedPackageId(packages[0].id);
      setQuantity(1);
    }
  }, [product?.id]);

  if (!isHydrated && products.length === 0) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center">
        <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mb-4 animate-spin">
          <RotateCcw className="w-6 h-6" />
        </div>
        <p className="text-xs text-zinc-400">กำลังโหลดข้อมูลสินค้า...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center">
        <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mb-4">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">ไม่พบสินค้าที่คุณต้องการ</h2>
        <p className="text-xs text-zinc-400 mb-6">สินค้าอาจถูกลบหรือลิงก์ไม่ถูกต้อง</p>
        <Link
          href="/store"
          className="px-5 py-2.5 rounded-full bg-amber-400 text-slate-950 font-bold text-xs transition hover:bg-amber-300"
        >
          กลับสู่หน้าร้านค้า
        </Link>
      </div>
    );
  }

  const selectedPackage: ProductPackage | undefined =
    packages.find((p) => p.id === selectedPackageId) || packages[0];

  const totalStock = packages.reduce((sum, p) => sum + (p.stock || 0), 0);
  const isOutOfStock =
    packages.length === 0 ||
    packages.every((pkg) => !pkg.inStock || pkg.stock <= 0) ||
    totalStock <= 0 ||
    product.status === 'out_of_stock';

  const userBalance = user?.balance ?? 0;
  const currentPrice = selectedPackage?.price ?? 0;
  const totalPrice = currentPrice * quantity;
  const isInsufficientBalance = user ? userBalance < totalPrice : false;

  // Maximum allowed quantity
  const maxQty = selectedPackage?.stock && selectedPackage.stock > 0
    ? Math.min(selectedPackage.stock, 20)
    : 10;

  const handleDecrement = () => {
    playClick();
    if (quantity > 1) {
      setQuantity((q) => q - 1);
    }
  };

  const handleIncrement = () => {
    playClick();
    if (quantity < maxQty) {
      setQuantity((q) => q + 1);
    } else {
      showToast({
        title: 'จำนวนสูงสุด',
        message: `สั่งซื้อได้สูงสุด ${maxQty} ชิ้นต่อคำสั่งซื้อ`,
        type: 'warning'
      });
    }
  };

  const handleBuy = async () => {
    playClick();
    if (!user) {
      openAuthModal('login');
      return;
    }

    if (!selectedPackage) return;

    if (isOutOfStock || selectedPackage.stock <= 0) {
      showToast({
        title: 'สินค้าหมด',
        message: 'แพ็กเกจนี้สินค้าหมดชั่วคราว',
        type: 'warning'
      });
      return;
    }

    if (product.requiresCustomInput && !customInputVal.trim()) {
      showToast({
        title: 'กรุณากรอกข้อมูล',
        message: `กรุณากรอก ${product.customInputLabel || 'UID'} ก่อนทำรายการ`,
        type: 'warning'
      });
      return;
    }

    if (userBalance < totalPrice) {
      showToast({
        title: 'ยอดเงินไม่เพียงพอ',
        message: `ยอดเงินของคุณคงเหลือ ฿${userBalance.toLocaleString()} ต้องการ ฿${totalPrice.toLocaleString()} กรุณาเติมเงิน`,
        type: 'warning'
      });
      router.push('/topup');
      return;
    }

    setIsPurchasing(true);
    let lastOrder: Order | null = null;
    let successCount = 0;

    for (let i = 0; i < quantity; i++) {
      const res = await purchasePackage(product.id, selectedPackage.id);
      if (res.success && res.order) {
        lastOrder = res.order;
        successCount++;
      } else {
        break;
      }
    }

    setIsPurchasing(false);

    if (successCount > 0 && lastOrder) {
      playSuccess();
      setPurchaseResult(lastOrder);
    }
  };

  const handleAddToCart = () => {
    playClick();
    showToast({
      title: 'เพิ่มลงตะกร้าแล้ว',
      message: `${product.name} (${selectedPackage?.name}) จำนวน ${quantity} ชิ้น`,
      type: 'success'
    });
  };

  const copyLicenseKey = () => {
    playClick();
    if (purchaseResult?.licenseKey) {
      navigator.clipboard.writeText(purchaseResult.licenseKey);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  // Details bullet points
  const detailsList: string[] = product.detailsList && product.detailsList.length > 0
    ? product.detailsList
    : product.description
    ? product.description.split('\n').map((l) => l.trim().replace(/^[-•*]\s*/, '')).filter((l) => l.length > 0)
    : [
        'ลงเองได้ มีคลิปสอน หรือให้แอดมินลงให้ก็ได้ ลงได้ทั้ง iOS / Android / PC',
        'มีแพ็คเติบโต',
        'มีบัตรเปลี่ยนชื่อ',
        'ไอดีสะอาดไม่ผ่านโปร',
        'อัดคลิปวิดีโอตอนเชื่อมไก่โค้ด [สำคัญ]',
        'หากมีปัญหาและไม่มีคลิปไม่เคลมทุกกรณี'
      ];

  // Related products
  const relatedProducts = products
    .filter((p) => p.id !== product.id)
    .slice(0, 4);

  return (
    <div className="min-h-screen text-slate-100 py-6 sm:py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1440px] mx-auto space-y-8">

        {/* 1. Breadcrumbs Top Bar */}
        <div className="flex items-center gap-2 text-xs text-zinc-400">
          <button
            type="button"
            onClick={() => {
              playClick();
              router.push('/#products-catalog');
            }}
            className="flex items-center gap-1.5 hover:text-white transition cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>สินค้าทั้งหมด</span>
          </button>
          <span>/</span>
          <span className="text-zinc-500 uppercase">{product.categoryName || 'โค้ดไก่เวล'}</span>
        </div>

        {/* 2. Product Header: Category, Title, Badges */}
        <div className="space-y-2">
          <span className="text-xs text-zinc-500 font-bold uppercase tracking-wider block">
            {product.categoryName || 'โค้ดไก่เวล'}
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-wide">
            {product.name}
          </h1>

          {/* Badges Row */}
          <div className="flex items-center gap-2 flex-wrap pt-1">
            <span className="px-2.5 py-0.5 rounded-full bg-[color:var(--arx-dk-14151a)] border border-white/10 text-zinc-300 text-[11px] font-medium">
              รับประกัน {product.guaranteeDays || 999} วัน
            </span>

            {isMultiOption && (
              <>
                <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-[11px] font-medium">
                  มีไฟล์ให้โหลด
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-[11px] font-medium">
                  มีคลิปสอน
                </span>
              </>
            )}

            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-medium">
              ส่งอัตโนมัติ
            </span>
          </div>
        </div>

        {/* 3. Main 2-Column Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Big Product Image & Details List */}
          <div className="lg:col-span-6 space-y-6">
            {/* Square Product Cover */}
            <div className="relative aspect-square rounded-2xl overflow-hidden bg-black/60 border border-white/10 shadow-2xl">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={product.image}
                alt={product.name}
                className={`w-full h-full object-cover ${isOutOfStock ? 'grayscale contrast-125' : ''}`}
                onError={(e) => {
                  const target = e.currentTarget;
                  if (!target.src.includes('sasuke_cover.webp')) {
                    target.src = '/catalog/imported/sasuke_cover.webp';
                  }
                }}
              />

              {isOutOfStock && (
                <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                  <span className="px-4 py-1.5 rounded-lg bg-red-600 text-white font-black text-sm uppercase">
                    สินค้าหมดชั่วคราว
                  </span>
                </div>
              )}
            </div>

            {/* รายละเอียดสินค้า */}
            <div className="space-y-3 pt-2">
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <span>รายละเอียดสินค้า</span>
              </h3>

              <div className="p-4 rounded-2xl bg-[color:var(--arx-dk-0c0d12)] border border-white/[0.08] space-y-2.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                  <Check className="w-4 h-4 stroke-[2.5]" />
                  <span>รายละเอียด</span>
                </div>

                <div className="space-y-1.5 text-xs text-zinc-300 leading-relaxed font-normal">
                  {detailsList.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <span className="text-zinc-500 select-none">•</span>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Buy Card (Matching Image 3 & Image 4) */}
          <div className="lg:col-span-6">
            <div className="rounded-2xl bg-[color:var(--arx-dk-0c0d12)] border border-white/[0.08] p-5 sm:p-6 space-y-4 shadow-2xl">
              
              {/* Top Price Section */}
              <div>
                <span className="text-xs text-zinc-500 font-medium block">
                  {isMultiOption ? 'เริ่มต้น' : 'ราคา'}
                </span>
                
                <div className="flex items-center gap-2 mt-1">
                  <div className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
                    {currentPrice.toLocaleString()} ฿
                  </div>
                  {isMultiOption && (
                    <span className="px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-zinc-400 text-xs font-medium">
                      {packages.length} ตัวเลือก
                    </span>
                  )}
                </div>

                {/* Balance & Customer Level */}
                <div className="text-xs text-zinc-400 mt-1.5 flex items-center gap-1.5 flex-wrap">
                  <span>เครดิตคงเหลือ <strong className="text-white font-mono">{userBalance.toFixed(2)} ฿</strong></span>
                  <span>·</span>
                  <span>ระดับ <span className="text-cyan-400 font-bold">{user?.role === 'admin' ? 'ผู้ดูแลระบบ' : 'ลูกค้าทั่วไป'}</span></span>
                </div>
              </div>

              {/* Divider */}
              <div className="border-t border-white/[0.08]" />

              {/* Package Selector List (Only for Multi-Option - Matching Image 4) */}
              {isMultiOption && (
                <div className="space-y-2">
                  <label className="text-xs text-zinc-400 font-semibold block">
                    เลือกตัวเลือก
                  </label>

                  <div className="space-y-2">
                    {packages.map((pkg) => {
                      const isSelected = pkg.id === selectedPackageId;

                      return (
                        <div
                          key={pkg.id}
                          onClick={() => {
                            playClick();
                            setSelectedPackageId(pkg.id);
                          }}
                          className={`rounded-xl p-3 border transition-all cursor-pointer flex items-center justify-between ${
                            isSelected
                              ? 'bg-cyan-950/20 border-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.2)]'
                              : 'bg-[color:var(--arx-dk-08090d)] border-white/10 hover:border-white/20'
                          }`}
                        >
                          {/* Left: Radio dot + Package name */}
                          <div className="flex items-center gap-2.5">
                            <div
                              className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                                isSelected
                                  ? 'border-cyan-400 bg-cyan-400'
                                  : 'border-white/30'
                              }`}
                            >
                              {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />}
                            </div>

                            <span className="text-xs sm:text-[13px] font-bold text-white">
                              {pkg.name}
                            </span>
                          </div>

                          {/* Center: Badge & Right: Price */}
                          <div className="flex items-center gap-2">
                            {pkg.badge && pkg.badge !== '✨ สั่งออโต้ API' && (
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-medium hidden sm:inline-block">
                                {pkg.badge}
                              </span>
                            )}

                            {/* Right: Price */}
                            <span className="font-mono font-bold text-xs sm:text-sm text-white">
                              {pkg.price.toFixed(2)} ฿
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="border-t border-white/[0.08] my-3" />
                </div>
              )}

              {/* Quantity Stepper */}
              <div className="flex items-center justify-between">
                <span className="text-xs text-zinc-400 font-medium">
                  จำนวน <span className="text-zinc-500 font-normal">สูงสุด {maxQty}</span>
                </span>

                <div className="flex items-center bg-[color:var(--arx-dk-14151a)] border border-white/10 rounded-xl p-1">
                  <button
                    type="button"
                    onClick={handleDecrement}
                    disabled={quantity <= 1}
                    className="w-8 h-7 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 flex items-center justify-center text-zinc-300 hover:text-white transition cursor-pointer"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>

                  <span className="w-10 text-center font-mono font-bold text-xs text-white">
                    {quantity}
                  </span>

                  <button
                    type="button"
                    onClick={handleIncrement}
                    disabled={quantity >= maxQty || isOutOfStock}
                    className="w-8 h-7 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 flex items-center justify-center text-zinc-300 hover:text-white transition cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Divider */}
              <div className="border-t border-white/[0.08]" />

              {/* Pricing Subtotal Calculation */}
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-zinc-400">
                  <span>{isMultiOption ? (selectedPackage?.name || 'แพ็กเกจ') : 'ราคา'}</span>
                  <span className="font-mono">{totalPrice.toFixed(2)} ฿</span>
                </div>

                <div className="flex items-center justify-between text-sm font-bold text-white pt-1">
                  <span>ยอดชำระ</span>
                  <span className="font-mono text-base font-black text-white">{totalPrice.toFixed(2)} ฿</span>
                </div>
              </div>

              {/* Custom Input Field (If product requires input e.g. UID - Image 4) */}
              {product.requiresCustomInput && (
                <div className="space-y-1.5 pt-1">
                  <label className="text-xs font-bold text-white block">
                    {product.customInputLabel || 'UID ของคุณ'} <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={customInputVal}
                    onChange={(e) => setCustomInputVal(e.target.value)}
                    placeholder={product.customInputPlaceholder || '123456789'}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[color:var(--arx-dk-08090d)] border border-white/15 text-white text-xs font-mono focus:outline-none focus:border-cyan-400 transition"
                  />
                  <p className="text-[11px] text-zinc-500 leading-tight">
                    {product.customInputHelp || `ใส่ UID ของบัญชีที่จะดึงสิทธิ์ให้ — กรอกผิดแล้วสิทธิ์จะไม่เข้าบัญชีตนเอง : ได้ ${selectedPackage?.name || '1 วัน'}`}
                  </p>
                </div>
              )}

              {/* Balance Alert Box */}
              {!user ? (
                <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-xs text-cyan-300 flex items-center justify-between">
                  <span>กรุณาเข้าสู่ระบบก่อนทำการสั่งซื้อ</span>
                  <button
                    type="button"
                    onClick={() => openAuthModal('login')}
                    className="px-3 py-1 rounded-lg bg-cyan-400 text-slate-950 font-bold text-xs"
                  >
                    เข้าสู่ระบบ
                  </button>
                </div>
              ) : isInsufficientBalance ? (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 flex items-center justify-between">
                  <span>เครดิตไม่พอ (มี {userBalance.toFixed(2)} ฿) — </span>
                  <Link
                    href="/topup"
                    className="font-bold underline text-amber-200 hover:text-white"
                  >
                    เติมเงิน
                  </Link>
                </div>
              ) : null}

              {/* Action Buttons */}
              <div className="space-y-2 pt-1">
                {/* Primary Button: ยืนยันสั่งซื้อ */}
                <button
                  type="button"
                  onClick={handleBuy}
                  disabled={isPurchasing || isOutOfStock}
                  className={`w-full py-3.5 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    isOutOfStock
                      ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                      : 'bg-cyan-400 hover:bg-cyan-300 active:scale-[0.98] text-slate-950 shadow-[0_0_20px_rgba(6,182,212,0.35)] hover:shadow-[0_0_28px_rgba(6,182,212,0.5)]'
                  }`}
                >
                  {isPurchasing ? (
                    <span>กำลังดำเนินการ...</span>
                  ) : isOutOfStock ? (
                    <span>สินค้าหมดชั่วคราว</span>
                  ) : (
                    <span>ยืนยันสั่งซื้อ · {totalPrice.toFixed(2)} ฿</span>
                  )}
                </button>

                {/* Secondary Button: ใส่ตะกร้า */}
                <button
                  type="button"
                  onClick={handleAddToCart}
                  disabled={isOutOfStock}
                  className="w-full py-3 rounded-xl bg-[color:var(--arx-dk-14151a)] hover:bg-[color:var(--arx-dk-1c1e26)] border border-white/10 hover:border-white/20 active:scale-[0.98] text-white font-bold text-xs transition-all cursor-pointer"
                >
                  ใส่ตะกร้า
                </button>
              </div>

              {/* Footer Note */}
              <p className="text-[11px] text-zinc-500 text-center font-normal pt-1">
                ระบบจะหักเครดิตแล้วส่งข้อมูลไอดีให้ทันที
              </p>

            </div>
          </div>

        </div>

        {/* 4. สินค้าใกล้เคียง (Matching Image 3 & Image 4 Bottom Section) */}
        {relatedProducts.length > 0 && (
          <div className="space-y-3 pt-6 border-t border-white/[0.08]">
            <div>
              <span className="text-[11px] text-zinc-500 font-bold uppercase tracking-wider block">
                อาจถูกใจ
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight mt-0.5">
                สินค้าใกล้เคียง
              </h2>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
              {relatedProducts.map((p) => {
                const pkgs = p.packages || [];
                const isSinglePkg = pkgs.length <= 1;
                const minP = pkgs.length > 0 ? Math.min(...pkgs.map((x) => x.price)) : 0;
                const totalStk = pkgs.reduce((s, x) => s + (x.stock || 0), 0);
                const isSold = totalStk <= 0 || p.status === 'out_of_stock';

                return (
                  <div
                    key={p.id}
                    onClick={() => {
                      playClick();
                      router.push(`/products/${p.id}`);
                    }}
                    className="rounded-2xl bg-[color:var(--arx-dk-0c0d12)] border border-white/[0.08] hover:border-cyan-500/40 p-3 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 group cursor-pointer"
                  >
                    <div>
                      <div className="relative aspect-square rounded-xl overflow-hidden bg-black/60 mb-2">
                        {p.badge && (
                          <div className="absolute top-2 left-2 z-10">
                            <span className="px-2 py-0.5 rounded-full bg-[color:var(--theme-main)] text-white font-black text-[9px] uppercase">
                              {p.badge}
                            </span>
                          </div>
                        )}
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={p.image}
                          alt={p.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          onError={(e) => {
                            const target = e.currentTarget;
                            if (!target.src.includes('sasuke_cover.webp')) {
                              target.src = '/catalog/imported/sasuke_cover.webp';
                            }
                          }}
                        />
                      </div>
                      <span className="text-zinc-500 text-[10px] font-bold uppercase tracking-wider block mb-0.5">
                        {p.categoryName || 'โค้ดไก่เวล'}
                      </span>
                      <h4 className="text-xs font-bold text-white line-clamp-2 min-h-[32px] group-hover:text-cyan-300 transition-colors">
                        {p.name}
                      </h4>
                    </div>

                    <div className="mt-3 pt-2">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs sm:text-sm font-black text-white font-mono">
                          {!isSinglePkg && <span className="text-[10px] text-zinc-400 font-sans mr-0.5">เริ่ม </span>}
                          {minP.toLocaleString()} ฿
                        </span>
                        <span className="text-[10px] text-zinc-500 font-mono">
                          {isSold ? 'หมด' : `มี ${totalStk}`}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          playClick();
                          router.push(`/products/${p.id}`);
                        }}
                        disabled={isSold}
                        className={`w-full py-2 rounded-xl text-xs font-black transition-all ${
                          isSold
                            ? 'bg-zinc-800 text-zinc-500'
                            : 'bg-cyan-400 hover:bg-cyan-300 text-slate-950'
                        }`}
                      >
                        {isSold ? 'หมดชั่วคราว' : 'ซื้อทันที'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </div>

      {/* Purchase Success Modal */}
      {purchaseResult && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => setPurchaseResult(null)}
        >
          <div
            className="relative w-full max-w-md rounded-2xl bg-[color:var(--arx-dk-0c0e14)] border border-emerald-500/40 p-6 shadow-2xl text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-emerald-500/20">
              <Check className="w-6 h-6 stroke-[2.5]" />
            </div>

            <h3 className="text-lg font-black text-white tracking-wide">
              สั่งซื้อสินค้าสำเร็จ!
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              ระบบจัดส่งข้อมูลไอดีและรหัสผ่านของคุณเรียบร้อยแล้ว
            </p>

            {/* License Box */}
            <div className="mt-4 p-4 rounded-xl bg-black/60 border border-cyan-500/30 text-left space-y-2">
              <div className="flex items-center justify-between text-[11px] text-zinc-400">
                <span>คำสั่งซื้อ: <strong className="text-white font-mono">{purchaseResult.orderNumber}</strong></span>
                <span className="text-emerald-400 font-bold">จัดส่งแล้ว</span>
              </div>

              <div className="p-3 rounded-lg bg-zinc-950 border border-cyan-500/40 flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-cyan-300 select-all tracking-wider">
                  {purchaseResult.licenseKey}
                </span>
                <button
                  type="button"
                  onClick={copyLicenseKey}
                  className="px-2.5 py-1 rounded-md bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-[11px] font-bold flex items-center gap-1 transition"
                >
                  {isCopied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  {isCopied ? 'คัดลอกแล้ว' : 'คัดลอก'}
                </button>
              </div>

              {purchaseResult.credentials && (
                <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs font-mono text-amber-200 break-all select-all whitespace-pre-line">
                  {purchaseResult.credentials}
                </div>
              )}
            </div>

            <div className="mt-5 flex items-center gap-2">
              <Link
                href="/orders"
                onClick={() => setPurchaseResult(null)}
                className="flex-1 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition"
              >
                <ShoppingBag className="w-3.5 h-3.5" /> ดูประวัติคำสั่งซื้อ
              </Link>
              <button
                type="button"
                onClick={() => setPurchaseResult(null)}
                className="px-4 py-2.5 rounded-xl border border-white/10 hover:bg-white/5 text-zinc-300 text-xs font-semibold"
              >
                ปิด
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
