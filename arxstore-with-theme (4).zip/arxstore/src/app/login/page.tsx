'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';

export default function LoginPage() {
  const { openAuthModal } = useStore();
  const router = useRouter();

  useEffect(() => {
    openAuthModal('login');
    router.replace('/');
  }, [openAuthModal, router]);

  return null;
}
