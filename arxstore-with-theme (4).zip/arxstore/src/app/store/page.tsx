'use client';

import React, { useState, useEffect, Suspense } from 'react';
import StoreCatalogView from '@/components/store/StoreCatalogView';

function StorePageContent() {
  const [category, setCategory] = useState<string>('all');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const cat = params.get('category');
      if (cat) {
        setCategory(cat);
      }
    }
  }, []);

  return (
    <main className="store-home min-h-screen">
      <StoreCatalogView initialCategory={category} />
    </main>
  );
}

export default function StorePage() {
  return (
    <Suspense fallback={<div className="min-h-screen" />}>
      <StorePageContent />
    </Suspense>
  );
}
