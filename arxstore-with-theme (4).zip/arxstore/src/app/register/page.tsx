'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';

export default function RegisterPage() {
  const { openAuthModal } = useStore();
  const router = useRouter();

  useEffect(() => {
    openAuthModal('register');
    router.replace('/');
  }, [openAuthModal, router]);

  return null;
}
