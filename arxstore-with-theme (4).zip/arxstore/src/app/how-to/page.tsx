'use client';

import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import {
  ArrowLeft,
  BookOpen,
  UserCheck,
  Wallet,
  ShoppingBag,
  Key,
  ShieldCheck,
  AlertTriangle,
  HelpCircle,
  ExternalLink,
  MessageCircle,
  CheckCircle2,
  Download,
  Flame,
  ArrowRight
} from 'lucide-react';

export default function HowToPage() {
  const router = useRouter();
  const { playClick, siteContent } = useStore();

  const discordUrl = siteContent?.branding?.discordUrl || 'https://discord.gg';

  const steps = [
    {
      step: '01',
      title: 'สมัครสมาชิก & เข้าสู่ระบบ',
      subtitle: 'เริ่มต้นใช้งานเพื่อความปลอดภัยและเก็บประวัติคำสั่งซื้อ',
      icon: UserCheck,
      details: [
        'กดปุ่ม "เข้าสู่ระบบ" ที่แถบด้านบนของเว็บไซต์',
        'หากยังไม่มีบัญชี สามารถกด "สมัครสมาชิกใหม่" กรอกชื่อผู้ใช้และรหัสผ่าน',
        'เมื่อเข้าสู่ระบบแล้ว เครดิตและสินค้าที่คุณสั่งซื้อจะผูกกับบัญชีนี้ตลอดไป',
      ],
      tip: 'แนะนำให้จำชื่อผู้ใช้และรหัสผ่าน หรือจดบันทึกไว้เพื่อความสะดวกในการเข้าสู่ระบบครั้งถัดไป'
    },
    {
      step: '02',
      title: 'เติมเงินเข้ากระเป๋าเครดิต (Wallet)',
      subtitle: 'ระบบเติมเงินออโต้ 24 ชั่วโมง รวดเร็ว ปลอดภัย ยอดเข้าทันที',
      icon: Wallet,
      details: [
        'คลิกที่เมนู "เติมเงิน" จากแถบเมนูด้านบน หรือคลิกจากปุ่มเติมเงิน',
        'เลือกช่องทางการเติมเงินที่คุณสะดวก:',
        '• พร้อมเพย์ (PromptPay QR): สแกนผ่านแอปธนาคาร ยอดเข้าอัตโนมัติทันที',
        '• โอนผ่านบัญชีธนาคาร: โอนตามเลขบัญชีที่ระบุ และอัปโหลดสลิปเพื่อยืนยันยอด',
        '• ซองของขวัญ TrueMoney: คัดลอกลิงก์ซองของขวัญมาวางในระบบ ไม่หักค่าธรรมเนียม',
      ],
      tip: 'ยอดเงินจะอัปเดตบนการ์ดกระเป๋าเงินทันทีหลังทำรายการเสร็จสิ้น'
    },
    {
      step: '03',
      title: 'เลือกสินค้าและสั่งซื้อ',
      subtitle: 'เลือกแพ็กเกจที่ต้องการ ตรวจสอบรายละเอียดและกดสั่งซื้อ',
      icon: ShoppingBag,
      details: [
        'ไปยังหน้า "สินค้า" หรือเลือกจากหมวดหมู่สินค้าในหน้าหลัก',
        'คลิกดูรายละเอียดสินค้า เพื่ออ่านฟังก์ชันการทำงาน และสเปคระบบที่รองรับ',
        'เลือกระยะเวลาการใช้งานที่ต้องการ (เช่น รายวัน, รายสัปดาห์, รายเดือน หรือถาวร)',
        'กดปุ่ม "ซื้อสินค้า" ระบบจะทำการตัดยอดเครดิตจากกระเป๋าเงินของคุณอัตโนมัติ',
      ],
      tip: 'โปรดตรวจสอบสเปคคอมพิวเตอร์และระบบปฏิบัติการที่รองรับก่อนสั่งซื้อสินค้าทุกครั้ง'
    },
    {
      step: '04',
      title: 'รับสินค้าและเริ่มใช้งานโปรแกรม',
      subtitle: 'รับข้อมูล License Key และลิงก์ดาวน์โหลดทันทีหลังสั่งซื้อ',
      icon: Key,
      details: [
        'หลังกดยืนยันสั่งซื้อสำเร็จ หน้าต่างข้อมูลสินค้าจะแสดงขึ้นมาทันที',
        'คุณจะได้รับ License Key, ลิงก์ดาวน์โหลดโปรแกรม และวิธีติดตั้งเฉพาะตัวสินค้า',
        'สามารถเข้ามาตรวจสอบย้อนหลังได้ตลอดเวลาที่หน้า "ประวัติการสั่งซื้อ" (Orders)',
      ],
      tip: 'ข้อควรระวังสำคัญ: ควรปิด Antivirus หรือ Windows Defender ชั่วคราว หรือกดเพิ่ม Exclusion โฟลเดอร์โปรแกรมก่อนเปิดใช้งานเสมอ'
    },
    {
      step: '05',
      title: 'การรับประกันสินค้า & บริการหลังการขาย',
      subtitle: 'อุ่นใจด้วยระบบการรับประกันและทีมงานดูแลตลอด 24 ชม.',
      icon: ShieldCheck,
      details: [
        'สินค้าทุกรายการมีการรับประกันตามเงื่อนไขที่ระบุในหน้ารายละเอียดสินค้า',
        'หากพบปัญหา เช่น คีย์ใช้งานไม่ได้ หรือโปรแกรมมีข้อผิดพลาด สามารถกด "แจ้งเคลม" ได้จากหน้าคำสั่งซื้อ',
        'หากต้องการความช่วยเหลือเพิ่มเติม สามารถติดต่อทีมงานซัพพอร์ตได้โดยตรงผ่าน Discord',
      ],
      tip: 'ทีมงานพร้อมดูแลและแก้ไขปัญหาให้คุณอย่างรวดเร็วตลอด 24 ชั่วโมง'
    }
  ];

  return (
    <div className="min-h-screen text-slate-100 pb-16 selection:bg-[color:var(--theme-main)] selection:text-white">
      {/* Container */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 pt-4 sm:pt-6 space-y-6">
        
        {/* Navigation / Back Button */}
        <div className="flex items-center justify-between">
          <Link
            href="/"
            onClick={() => playClick()}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white text-xs sm:text-sm font-semibold border border-white/5 transition-all group cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-blue-400 group-hover:-translate-x-1 transition-transform" />
            <span>กลับหน้าหลัก</span>
          </Link>

          <Link
            href="/store"
            onClick={() => playClick()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[color:var(--theme-main)] hover:bg-[color:var(--theme-sec)] text-white text-xs sm:text-sm font-extrabold shadow-[0_0_16px_rgba(var(--theme-main-rgb),0.4)] transition-all cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>ไปเลือกซื้อสินค้า</span>
          </Link>
        </div>

        {/* Hero Header */}
        <div className="relative rounded-2xl bg-gradient-to-b from-[var(--arx-dk-0e1222)] via-[var(--arx-dk-090b14)] to-[var(--arx-dk-07080d)] border border-[color:var(--theme-main)]/30 p-6 sm:p-8 overflow-hidden shadow-[0_10px_40px_rgba(var(--theme-main-rgb),0.15)]">
          {/* Ambient Glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-[color:var(--theme-main)]/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-60 h-60 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[color:var(--theme-main)]/20 border border-[color:var(--theme-main)]/50 text-blue-400 text-xs font-bold shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.35)]">
              <BookOpen className="w-3.5 h-3.5" />
              <span>USER GUIDE & TUTORIAL</span>
            </div>

            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight">
              วิธีใช้งานและขั้นตอนการสั่งซื้อ
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              คู่มือสรุปขั้นตอนการใช้งานระบบร้านค้าแบบละเอียด ตั้งแต่การสมัครสมาชิก เติมเงิน สั่งซื้อสินค้า ไปจนถึงการรับสินค้าและการเคลมประกัน
            </p>
          </div>
        </div>

        {/* Steps List */}
        <div className="space-y-4 sm:space-y-5">
          {steps.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="rounded-2xl border border-white/10 hover:border-[color:var(--theme-main)]/50 bg-[color:var(--arx-dk-0c0e17)]/80 backdrop-blur-md p-5 sm:p-6 transition-all duration-300 hover:shadow-[0_8px_30px_rgba(var(--theme-main-rgb),0.12)] space-y-3 sm:space-y-4"
              >
                {/* Step Top Bar */}
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-[color:var(--theme-main)] text-white flex items-center justify-center font-black text-base shadow-[0_0_16px_rgba(var(--theme-main-rgb),0.5)] shrink-0">
                      {item.step}
                    </div>
                    <div>
                      <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                        <span>{item.title}</span>
                      </h2>
                      <p className="text-xs sm:text-sm text-slate-400">
                        {item.subtitle}
                      </p>
                    </div>
                  </div>

                  <div className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-blue-400 shrink-0">
                    <Icon className="w-4 h-4" />
                  </div>
                </div>

                {/* Details List */}
                <div className="bg-black/35 rounded-xl border border-white/5 p-4 space-y-2">
                  {item.details.map((detail, dIdx) => (
                    <div key={dIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-[color:var(--theme-main)] shrink-0 mt-0.5" />
                      <span className="leading-relaxed">{detail}</span>
                    </div>
                  ))}
                </div>

                {/* Tip Callout */}
                <div className="p-3 rounded-xl bg-[color:var(--theme-main)]/10 border border-[color:var(--theme-main)]/25 text-xs flex items-center gap-2.5 text-blue-300">
                  <Flame className="w-4 h-4 text-blue-400 shrink-0" />
                  <span>{item.tip}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Important Warning Notice */}
        <div className="rounded-2xl border border-amber-500/30 bg-amber-950/20 p-5 sm:p-6 space-y-2.5">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-sm sm:text-base">
            <AlertTriangle className="w-5 h-5 shrink-0" />
            <span>คำแนะนำและข้อควรระวังสำคัญสำหรับโปรแกรมช่วยเล่น</span>
          </div>
          <ul className="text-xs sm:text-sm text-amber-200/90 space-y-1.5 pl-6 list-disc leading-relaxed">
            <li>โปรดปิดโปรแกรมป้องกันไวรัส (Antivirus) และ Windows Defender ชั่วคราว หรือกดยกเว้นโฟลเดอร์ก่อนดาวน์โหลดและเปิดโปรแกรม</li>
            <li>รันโปรแกรมด้วยสิทธิ์ผู้ดูแลระบบ (Run as administrator) ทุกครั้ง</li>
            <li>หากโปรแกรมต้องการการตั้งค่าพิเศษ เช่น ปิด Secure Boot หรือเปิดโหมดบางอย่าง สามารถดูได้จากคู่มือเฉพาะตัวสินค้า</li>
            <li>ห้ามแชร์ License Key ให้ผู้อื่น เพราะระบบจะทำการล็อก HWID ทันที</li>
          </ul>
        </div>

        {/* Help & Support CTA */}
        <div className="rounded-2xl bg-[color:var(--arx-dk-0b0e1b)] border border-[color:var(--theme-main)]/30 p-6 text-center space-y-4 shadow-[0_4px_25px_rgba(var(--theme-main-rgb),0.15)]">
          <HelpCircle className="w-10 h-10 text-blue-400 mx-auto" />
          <div className="space-y-1">
            <h3 className="text-lg font-black text-white">
              ต้องการความช่วยเหลือเพิ่มเติม หรือพบปัญหาการใช้งาน?
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 max-w-lg mx-auto">
              หากมีข้อสงสัยหรือติดปัญหาในการใช้งาน สามารถติดต่อแอดมินและทีมงานซัพพอร์ตได้ตลอด 24 ชั่วโมง
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <a
              href={discordUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => playClick()}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#5865F2] hover:bg-[#4752c4] text-white text-xs sm:text-sm font-bold shadow-lg transition-all cursor-pointer"
            >
              <MessageCircle className="w-4 h-4" />
              <span>ติดต่อผ่าน Discord</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-70" />
            </a>

            <Link
              href="/store"
              onClick={() => playClick()}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs sm:text-sm font-bold border border-white/10 transition-all cursor-pointer"
            >
              <span>ไปยังหน้าสินค้า</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
