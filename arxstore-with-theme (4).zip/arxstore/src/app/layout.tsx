import type { Metadata, Viewport } from 'next';
import './globals.css';
import { StoreProvider } from '@/context/StoreContext';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import BuyModal from '@/components/modals/BuyModal';
import AuthModal from '@/components/modals/AuthModal';
import ContactModal from '@/components/modals/ContactModal';
import ArxShield from '@/components/security/ArxShield';
import BackgroundMusicPlayer from '@/components/common/BackgroundMusicPlayer';
import FloatingActionWidgets from '@/components/common/FloatingActionWidgets';
import ToastContainer from '@/components/common/ToastContainer';
import CookieConsent from '@/components/common/CookieConsent';
import TabTitleManager from '@/components/common/TabTitleManager';
import { getSeoSettings, getThemeSettings } from '@/lib/server/db';
import { buildThemeCss } from '@/lib/theme';

export async function generateMetadata(): Promise<Metadata> {
  const seo = getSeoSettings();
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://arxstore.xyz';

  let ogImageUrl = seo.ogImage || '/brand/logo.png';
  if (!ogImageUrl.startsWith('http://') && !ogImageUrl.startsWith('https://')) {
    ogImageUrl = `${baseUrl.replace(/\/+$/, '')}/${ogImageUrl.replace(/^\/+/, '')}`;
  }

  const mainTitle = seo.title || 'Arx Store';

  return {
    metadataBase: new URL(baseUrl),
    title: {
      default: mainTitle,
      template: mainTitle
    },
    description: seo.description,
    keywords: seo.keywords || 'ARX STORE, Setting, BoostFPS, Windows, บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ, ร้านค้าออนไลน์, สินค้าดิจิทัล, FiveM, FiveM Mod, Cheat Game, Spoofer, HWID Reset, Topup TrueMoney, PromptPay',
    icons: {
      icon: [
        { url: '/icon.png', sizes: '512x512', type: 'image/png' },
        { url: '/brand/favicon.png', sizes: '32x32', type: 'image/png' },
        { url: '/favicon.ico', sizes: 'any' }
      ],
      apple: '/brand/apple-touch-icon.png'
    },
    openGraph: {
      title: seo.title,
      description: seo.description,
      url: baseUrl,
      siteName: seo.siteName || 'ARX STORE',
      images: [
        {
          url: ogImageUrl,
          alt: seo.title
        }
      ],
      locale: 'th_TH',
      type: 'website'
    },
    twitter: {
      card: 'summary_large_image',
      title: seo.title,
      description: seo.description,
      images: [ogImageUrl]
    }
  };
}

export async function generateViewport(): Promise<Viewport> {
  const seo = getSeoSettings();
  return {
    themeColor: seo.themeColor || '#00e5ff'
  };
}

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  const seo = getSeoSettings();
  const pageTitle = seo.title || 'Arx Store';
  const themeCss = buildThemeCss(getThemeSettings());

  return (
    <html lang="th" className="dark" suppressHydrationWarning>
      <head>
        {themeCss && <style id="arx-theme" dangerouslySetInnerHTML={{ __html: themeCss }} />}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              try {
                var t = localStorage.getItem('arx_theme');
                if (t === 'light') {
                  document.documentElement.classList.remove('dark');
                  document.documentElement.classList.add('light');
                } else {
                  document.documentElement.classList.remove('light');
                  document.documentElement.classList.add('dark');
                }
              } catch(e) {}
            `
          }}
        />
      </head>
      <body className="min-h-screen flex flex-col antialiased">
        <StoreProvider>
          {/* Enforce browser tab title across all pages */}
          <TabTitleManager title={pageTitle} />

          {/* Main Navigation Bar (Exact DEMOxSHOP Floating Pill) */}
          <Navbar />

          {/* Main Page Body */}
          <div className="flex-1 w-full">
            {children}
          </div>

          {/* Modals, Security, Toast, Cookies & Audio */}
          <BuyModal />
          <AuthModal />
          <ContactModal />
          <ArxShield />
          <BackgroundMusicPlayer />
          <FloatingActionWidgets />
          <ToastContainer />
          <CookieConsent />

          {/* Minimalist Footer */}
          <Footer />
        </StoreProvider>
      </body>
    </html>
  );
}
