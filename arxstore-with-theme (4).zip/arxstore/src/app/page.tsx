'use client';

import React, { useState, useEffect } from 'react';
import ModernHeroSection from '@/components/home/ModernHeroSection';
import HomeWhyChooseUs from '@/components/home/HomeWhyChooseUs';
import OriginalCategoryBanners from '@/components/home/OriginalCategoryBanners';
import HomeLiveFeed from '@/components/home/HomeLiveFeed';
import ModernCatalogSection from '@/components/home/ModernCatalogSection';
import HowToBuySection from '@/components/home/HowToBuySection';
import FaqSection from '@/components/home/FaqSection';

import { useStore } from '@/context/StoreContext';

export default function HomePage() {
  const { recentOrdersFeedEnabled } = useStore();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const cat = params.get('category');
      if (cat) {
        setSelectedCategory(cat);
      }
      if (window.location.hash === '#products-catalog' || (cat && cat !== 'all')) {
        setTimeout(() => {
          const catalogEl = document.getElementById('products-catalog');
          if (catalogEl) {
            const navHeader = document.querySelector('.store-nav-header');
            const navHeight = navHeader ? navHeader.getBoundingClientRect().height : 75;
            const targetY = catalogEl.getBoundingClientRect().top + window.pageYOffset - navHeight - 16;
            window.scrollTo({
              top: Math.max(0, targetY),
              behavior: 'smooth'
            });
          }
        }, 150);
      }
    }
  }, []);

  const handleSelectCategory = (catId: string) => {
    setSelectedCategory(catId);
  };

  return (
    <main className="store-home space-y-4 sm:space-y-6">
      {/* 1. Modern Hero Section & 4 Stat Cards */}
      <ModernHeroSection />

      {/* 2. Why Choose Us Section (ทำไมต้องเลือก...) */}
      <HomeWhyChooseUs />

      {/* 3. Recommended Categories (2x2 Grid) */}
      <OriginalCategoryBanners
        onSelectCategory={handleSelectCategory}
        activeCategory={selectedCategory}
      />

      {/* 3. Live Feed Recent Orders */}
      {recentOrdersFeedEnabled && (
        <div className="pt-0.5">
          <HomeLiveFeed />
        </div>
      )}

      {/* 3. Modern Category Filter Pills & Product Grid (Image 2 Style) */}
      <ModernCatalogSection
        selectedCategory={selectedCategory}
        onSelectCategory={handleSelectCategory}
      />

      {/* 4. How to Buy Steps (Image 1 Style) */}
      <HowToBuySection />

      {/* 5. Frequently Asked Questions (Image 1 Style) */}
      <FaqSection />
    </main>
  );
}

