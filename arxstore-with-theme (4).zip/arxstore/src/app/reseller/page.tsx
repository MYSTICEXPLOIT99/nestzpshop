'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import { ResellerSettings, ResellerTier, ResellerLeaderboardItem } from '@/types';
import {
  Crown,
  Sparkles,
  Zap,
  ArrowRight,
  ChevronDown,
  ChevronUp,
  CreditCard,
  Trophy,
  ShieldCheck,
  CheckCircle2,
  Lock,
  ArrowUpRight
} from 'lucide-react';

export default function ResellerPage() {
  const router = useRouter();
  const { user, topups, playClick, openAuthModal } = useStore();

  const [settings, setSettings] = useState<ResellerSettings | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState<boolean>(true);

  // Fetch reseller settings
  useEffect(() => {
    let isMounted = true;
    async function loadSettings() {
      try {
        const res = await fetch('/api/reseller');
        const json = await res.json();
        if (isMounted && json.success && json.data) {
          setSettings(json.data);
        }
      } catch (err) {
        console.error('Failed to load reseller settings:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadSettings();
    return () => {
      isMounted = false;
    };
  }, []);

  // Compute accumulated topup of logged-in user
  const userAccumulatedTopup = React.useMemo(() => {
    if (!user) return 0;
    // Calculate total approved topups for this user
    const userTopups = (topups || []).filter(
      (t) => (t.userId === user.id || t.username === user.username) && t.status === 'approved'
    );
    const sum = userTopups.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
    // If user has balance greater than topups recorded, use max
    return Math.max(sum, user.totalTopup || 0, user.balance || 0);
  }, [user, topups]);

  // Determine current tier and next tier
  const { currentTier, nextTier, neededAmount, progressPercentage } = React.useMemo(() => {
    const tiers = settings?.tiers || [];
    if (tiers.length === 0) {
      return {
        currentTier: null,
        nextTier: null,
        neededAmount: 0,
        progressPercentage: 0
      };
    }

    // Sort tiers by minTopup ascending
    const sortedTiers = [...tiers].sort((a, b) => a.minTopup - b.minTopup);

    // Find highest tier reached
    let current: ResellerTier = sortedTiers[0];
    let next: ResellerTier | null = sortedTiers[1] || null;

    for (let i = 0; i < sortedTiers.length; i++) {
      if (userAccumulatedTopup >= sortedTiers[i].minTopup) {
        current = sortedTiers[i];
        next = sortedTiers[i + 1] || null;
      } else {
        break;
      }
    }

    let needed = 0;
    let pct = 0;
    if (next) {
      needed = Math.max(0, next.minTopup - userAccumulatedTopup);
      const tierRange = next.minTopup - current.minTopup;
      const userProgress = userAccumulatedTopup - current.minTopup;
      pct = tierRange > 0 ? Math.min(100, Math.max(0, Math.round((userProgress / tierRange) * 100))) : 0;
    } else {
      pct = 100;
    }

    return {
      currentTier: current,
      nextTier: next,
      neededAmount: needed,
      progressPercentage: pct
    };
  }, [settings, userAccumulatedTopup]);

  const handleTopupClick = () => {
    playClick();
    if (!user) {
      openAuthModal('login');
    } else {
      router.push('/topup');
    }
  };

  const scrollToLeaderboard = () => {
    playClick();
    setIsLeaderboardOpen(true);
    const el = document.getElementById('reseller-leaderboard');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  if (loading && !settings) {
    return (
      <main className="store-home min-h-screen py-16 flex items-center justify-center">
        <div className="flex items-center gap-3 text-cyan-400 font-mono text-sm">
          <span className="w-3 h-3 rounded-full bg-cyan-400 animate-ping" />
          <span>กำลังโหลดข้อมูลโปรแกรมตัวแทนจำหน่าย...</span>
        </div>
      </main>
    );
  }

  const {
    title = 'โปรแกรมตัวแทนจำหน่าย',
    subtitle = 'เติมสะสมยิ่งเยอะ ยิ่งลดเยอะทุกออเดอร์ — ระบบเลื่อนระดับให้อัตโนมัติเมื่อยอดเติมสะสมถึงเกณฑ์ ส่วนลดหักให้ทันทีตอนสั่งซื้อ',
    badgeTitle = 'ยศของคุณไม่มีวันหมดอายุ',
    badgeDescription = 'ยศนี้ไม่มีเงื่อนไขยอดรักษายศ — ใช้สิทธิ์ได้ต่อเนื่อง เติมสะสมเพื่อเลื่อนระดับถัดไป',
    allTiersTitle = 'ระดับทั้งหมด',
    allTiersSubtitle = 'เลื่อนอัตโนมัติเมื่อยอดเติมสะสมถึงเกณฑ์',
    leaderboardTitle = 'อันดับตัวแทนจำหน่าย',
    leaderboardSubtitle = 'ตัวแทนที่มียอดเติมสะสมสูงสุดในร้าน',
    tiers = [],
    leaderboard = []
  } = settings || {};

  return (
    <main className="store-home min-h-screen py-6 sm:py-8 space-y-6 sm:space-y-8 select-none">
      
      {/* ========================================================
          1. TOP HEADER (Title, Subtitle & Action Buttons)
         ======================================================== */}
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 pt-1 sm:pt-2">
        <div className="space-y-1.5 max-w-2xl">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
            {title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
            {subtitle}
          </p>
        </div>

        {/* Action Buttons: เติมเงิน & อันดับเติมเงิน (Matching Image 2) */}
        <div className="flex items-center gap-2.5 shrink-0 self-start md:self-auto">
          {/* เติมเงิน Button */}
          <button
            type="button"
            onClick={handleTopupClick}
            className="px-5 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:shadow-[0_0_28px_rgba(6,182,212,0.6)] transition-all cursor-pointer active:scale-95"
          >
            <CreditCard className="w-4 h-4 stroke-[2.5]" />
            <span>เติมเงิน</span>
          </button>

          {/* อันดับเติมเงิน Button */}
          <button
            type="button"
            onClick={scrollToLeaderboard}
            className="px-4 py-2.5 rounded-xl bg-[color:var(--arx-dk-11131a)] hover:bg-[color:var(--arx-dk-191c26)] border border-white/10 hover:border-white/20 text-xs sm:text-sm text-slate-300 hover:text-white font-bold transition cursor-pointer flex items-center gap-2 shadow-sm"
          >
            <Trophy className="w-4 h-4 text-blue-400" />
            <span>อันดับเติมเงิน</span>
          </button>
        </div>
      </div>

      {/* ========================================================
          2. TWO-COLUMN STATUS ROW (Current Tier & Expiry Notice)
         ======================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-6 items-stretch">
        
        {/* Left Card: ยศของคุณตอนนี้ (Matching Image 2 Left Card) */}
        <div className="lg:col-span-6 rounded-2xl sm:rounded-3xl bg-[color:var(--arx-dk-090b12)] border border-cyan-500/30 p-6 sm:p-7 shadow-[0_0_25px_rgba(var(--theme-accent-rgb),0.06)] flex flex-col justify-between relative overflow-hidden">
          {/* Ambient subtle glow at top border */}
          <div className="absolute top-0 inset-x-8 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent pointer-events-none" />

          <div>
            <div className="text-xs text-slate-400 font-semibold mb-2">
              ยศของคุณตอนนี้
            </div>

            {/* Rank Name with Colored Dot + Badge */}
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2.5">
                <span
                  className="w-3 h-3 rounded-full shrink-0 shadow-[0_0_10px_currentColor]"
                  style={{ backgroundColor: currentTier?.color || '#00e5ff', color: currentTier?.color || '#00e5ff' }}
                />
                <span
                  className="text-2xl sm:text-3xl font-black tracking-tight"
                  style={{ color: currentTier?.color || '#00e5ff' }}
                >
                  {currentTier?.name || 'ลูกค้าทั่วไป'}
                </span>
              </div>

              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-white/5 border border-white/10 text-slate-300">
                {currentTier?.badgeText || 'ยังไม่มีส่วนลด'}
              </span>
            </div>
          </div>

          {/* Accumulated Topup Info */}
          <div className="pt-6 sm:pt-8 space-y-3">
            <div>
              <span className="text-xs text-slate-400 font-medium block">
                เติมสะสมแล้ว
              </span>
              <div className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight mt-0.5">
                {userAccumulatedTopup.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ฿
              </div>
            </div>

            {/* Target next tier & Progress Bar */}
            <div className="space-y-1.5 pt-1">
              {nextTier ? (
                <div className="flex items-center justify-between text-xs sm:text-[13px]">
                  <span className="text-slate-300">
                    อีก{' '}
                    <strong className="text-white font-mono font-bold">
                      {neededAmount.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ฿
                    </strong>{' '}
                    จะได้เป็น{' '}
                    <span style={{ color: nextTier.color || '#f97316' }} className="font-bold">
                      {nextTier.name}
                    </span>
                  </span>
                  <span className="text-slate-400 font-mono font-bold text-xs">
                    {progressPercentage}%
                  </span>
                </div>
              ) : (
                <div className="flex items-center justify-between text-xs sm:text-[13px]">
                  <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    คุณอยู่ในระดับตัวแทนจำหน่ายสูงสุดแล้ว!
                  </span>
                  <span className="text-emerald-400 font-mono font-bold text-xs">
                    100%
                  </span>
                </div>
              )}

              {/* Progress bar line */}
              <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-400 to-sky-400 transition-all duration-500 rounded-full"
                  style={{ width: `${progressPercentage}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Card: ยศของคุณไม่มีวันหมดอายุ (Matching Image 2 Right Card) */}
        <div className="lg:col-span-6 rounded-2xl sm:rounded-3xl bg-[color:var(--arx-dk-090b12)] border border-white/[0.08] p-6 sm:p-7 shadow-xl flex flex-col justify-center relative overflow-hidden">
          <div className="space-y-2">
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              {badgeTitle}
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed font-normal">
              {badgeDescription}
            </p>
          </div>
        </div>

      </div>

      {/* ========================================================
          3. ALL TIERS SECTION (ระดับทั้งหมด - Matching Image 2)
         ======================================================== */}
      <div className="space-y-4 pt-2">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            {allTiersTitle}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            {allTiersSubtitle}
          </p>
        </div>

        {/* Tiers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
          {tiers.map((tier) => {
            const isUserCurrent = currentTier?.id === tier.id;

            return (
              <div
                key={tier.id}
                className={`relative rounded-2xl sm:rounded-3xl p-5 sm:p-6 transition-all duration-300 flex flex-col justify-between ${
                  isUserCurrent
                    ? 'bg-[color:var(--arx-dk-080d16)] border-2 border-cyan-400/80 shadow-[0_0_30px_rgba(var(--theme-accent-rgb),0.18)]'
                    : 'bg-[color:var(--arx-dk-090b12)] border border-white/[0.08] hover:border-white/20'
                }`}
              >
                {/* Floating "ระดับของคุณ" Pill on top border if active */}
                {isUserCurrent && (
                  <div className="absolute -top-3.5 left-5 px-3 py-0.5 rounded-full bg-cyan-400 text-slate-950 font-black text-[11px] uppercase tracking-wider shadow-[0_0_12px_rgba(6,182,212,0.6)] flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    <span>ระดับของคุณ</span>
                  </div>
                )}

                <div>
                  {/* Dot + Tier Name */}
                  <div className="flex items-center gap-2 mb-3">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0 shadow-[0_0_8px_currentColor]"
                      style={{ backgroundColor: tier.color, color: tier.color }}
                    />
                    <span
                      className="font-bold text-xs sm:text-sm"
                      style={{ color: tier.color }}
                    >
                      {tier.name}
                    </span>
                  </div>

                  {/* Big Discount Value Display (e.g. —, -20%, -50%) */}
                  <div className="text-3xl sm:text-4xl lg:text-5xl font-black text-white font-mono tracking-tight my-2">
                    {tier.displayDiscount || (tier.discountPercent > 0 ? `-${tier.discountPercent}%` : '—')}
                  </div>

                  {/* Subtext: ยังไม่มีส่วนลด / ลดทุกออเดอร์ */}
                  <div className="text-xs text-slate-400 font-medium">
                    {tier.badgeText || (tier.discountPercent > 0 ? 'ลดทุกออเดอร์' : 'ยังไม่มีส่วนลด')}
                  </div>
                </div>

                {/* Bottom Threshold Box */}
                <div className="pt-5 mt-5 border-t border-white/[0.06] flex items-center justify-between text-xs sm:text-[13px]">
                  <span className="text-slate-400">
                    เติมสะสมตั้งแต่{' '}
                    <strong className="text-white font-mono font-bold">
                      {tier.minTopup.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ฿
                    </strong>
                  </span>

                  {isUserCurrent ? (
                    <span className="text-cyan-400 text-xs font-bold font-mono">ใช้งานอยู่</span>
                  ) : userAccumulatedTopup >= tier.minTopup ? (
                    <span className="text-emerald-400 text-xs font-bold font-mono">ปลดล็อกแล้ว</span>
                  ) : (
                    <span className="text-slate-500 text-xs font-mono flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      ล็อก
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ========================================================
          4. LEADERBOARD SECTION (อันดับตัวแทนจำหน่าย - Matching Image 2)
         ======================================================== */}
      <div id="reseller-leaderboard" className="rounded-2xl sm:rounded-3xl bg-[color:var(--arx-dk-090b12)] border border-white/[0.08] overflow-hidden shadow-xl">
        {/* Leaderboard Header with Collapsible Toggle */}
        <button
          type="button"
          onClick={() => {
            playClick();
            setIsLeaderboardOpen(!isLeaderboardOpen);
          }}
          className="w-full p-5 sm:p-6 flex items-center justify-between text-left hover:bg-white/[0.02] transition cursor-pointer"
        >
          <div>
            <h3 className="text-base sm:text-lg font-black text-white tracking-tight flex items-center gap-2">
              <Trophy className="w-4 h-4 text-blue-400" />
              <span>{leaderboardTitle}</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {leaderboardSubtitle}
            </p>
          </div>

          <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-white transition">
            {isLeaderboardOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </button>

        {/* Leaderboard Items Content */}
        {isLeaderboardOpen && (
          <div className="border-t border-white/[0.06] divide-y sm:divide-y-0 sm:divide-x divide-white/[0.06] grid grid-cols-1 sm:grid-cols-3">
            {leaderboard.map((item, idx) => (
              <div
                key={item.id || idx}
                className="p-4 sm:p-5 flex items-center gap-4 hover:bg-white/[0.015] transition"
              >
                {/* Rank Number */}
                <div className="text-lg sm:text-xl font-mono font-bold text-slate-500 w-5 text-center">
                  {item.rank || idx + 1}
                </div>

                {/* User & Tier Info */}
                <div className="min-w-0 flex-1">
                  <div className="text-sm sm:text-base font-bold text-white font-mono tracking-wide truncate">
                    {item.username}
                  </div>
                  <div
                    className="text-xs font-semibold mt-0.5 truncate"
                    style={{ color: item.color || '#eab308' }}
                  >
                    {item.tierName} · {item.discountLabel}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </main>
  );
}
