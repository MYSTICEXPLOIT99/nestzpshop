'use client';

import React, { useState, useEffect } from 'react';
import { useStore } from '@/context/StoreContext';
import { Product, ProductPackage, ProductStatus, HeroSlide, SiteStats, SlipApiConfig, Category, DiscordWebhookSettings, WebhookLogItem, DigitalStockItem } from '@/types';
import {
  ShieldAlert,
  Package,
  Plus,
  Edit,
  Trash2,
  CheckCircle2,
  XCircle,
  Clock,
  Activity,
  Users,
  ShoppingBag,
  DollarSign,
  TrendingUp,
  RefreshCw,
  Search,
  Sparkles,
  Layers,
  Sliders,
  SlidersHorizontal,
  Flame,
  Tag,
  Key,
  Download,
  CreditCard,
  QrCode,
  Eye,
  EyeOff,
  Save,
  Check,
  Zap,
  ArrowRight,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  ArrowUpDown,
  Info,
  Image as ImageIcon,
  Radio,
  Bell,
  Send,
  CheckCheck,
  Terminal,
  ShieldCheck,
  Menu,
  X,
  LayoutDashboard,
  Music,
  History,
  Share2,
  Type,
  Lock,
  User as UserIcon,
  Gift,
  Globe,
  Award,
  Palette
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import StockManagerModal from '@/components/admin/StockManagerModal';
import { SecurityTab } from '@/components/admin/SecurityTab';
import UserManagerTab from '@/components/admin/UserManagerTab';
import MusicTab from '@/components/admin/MusicTab';
import SeoTab from '@/components/admin/SeoTab';
import ThemeTab from '@/components/admin/ThemeTab';
import SiteContentTab from '@/components/admin/SiteContentTab';
import StoreBrandingTab from '@/components/admin/StoreBrandingTab';
import ResellerSettingsTab from '@/components/admin/ResellerSettingsTab';
import { PromptPayIcon, KPlusIcon, TrueMoneyIcon, BankIcon, THAI_BANKS, getBankInfo } from '@/components/common/PaymentIcons';

export default function AdminPage() {
  const {
    user,
    users,
    isHydrated,
    openAuthModal,
    products,
    categories,
    serviceStatuses,
    orders,
    topups,
    slides,
    heroSliderEnabled,
    toggleHeroSlider,
    recentOrdersFeedEnabled,
    toggleRecentOrdersFeed,
    siteStats,
    displayStats,
    realStats,
    slipConfig,
    updateSlide,
    addSlide,
    deleteSlide,
    moveSlide,
    updateSiteStats,
    updateSlipConfig,
    webhookSettings,
    updateWebhookSettings,
    webhookLogs,
    testDiscordWebhook,
    clearWebhookLogs,
    approveTopup,
    rejectTopup,
    addProduct,
    updateProduct,
    deleteProduct,
    applyGlobalPromotion,
    clearGlobalPromotion,
    updateProductPackages,
    updateProductStatus,
    updateProductStatusNote,
    moveProduct,
    reorderProducts,
    moveCategory,
    reorderCategories,
    updateCategory,
    deleteCategory,
    addCategory,
    restoreDefaultCatalog,
    addStockItem,
    addBulkStockItems,
    playClick,
    playSuccess,
    lang,
    bgmSettings,
    updateBgmSettings,
    welcomeBanner,
    updateWelcomeBanner,
    login,
    playError,
    showToast,
    siteContent
  } = useStore();

  const router = useRouter();

  // Admin Login Portal Gate State (for unauthenticated or non-admin visitors)
  const [adminUsername, setAdminUsername] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminLoginLoading, setAdminLoginLoading] = useState(false);
  const [adminLoginError, setAdminLoginError] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(false);

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminUsername.trim() || !adminPassword) {
      setAdminLoginError('กรุณากรอกชื่อผู้ใช้และรหัสผ่าน');
      playError();
      return;
    }
    setAdminLoginLoading(true);
    setAdminLoginError('');
    try {
      const res = await login(adminUsername.trim(), adminPassword);
      if (!res.success) {
        setAdminLoginError(res.message || 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง');
        playError();
      } else {
        const savedUserStr = typeof window !== 'undefined' ? (localStorage.getItem('arx_current_user') || localStorage.getItem('demox_user')) : null;
        let parsedRole = '';
        if (savedUserStr) {
          try {
            parsedRole = JSON.parse(savedUserStr)?.role;
          } catch {}
        }
        if (parsedRole && parsedRole !== 'admin') {
          setAdminLoginError('บัญชีนี้ไม่ใช่สิทธิ์ผู้ดูแลระบบ (Admin)');
          playError();
        } else {
          playSuccess();
        }
      }
    } catch (err: any) {
      setAdminLoginError(err?.message || 'เกิดข้อผิดพลาดในการเข้าสู่ระบบ');
      playError();
    } finally {
      setAdminLoginLoading(false);
    }
  };

  const [activeTab, setActiveTab] = useState<'products' | 'stock' | 'categories' | 'slides' | 'stats' | 'recent-orders' | 'slip' | 'topups' | 'orders' | 'webhooks' | 'security' | 'users' | 'music' | 'seo' | 'site-content' | 'branding' | 'theme' | 'reseller'>('products');

  // Welcome Banner Form State (จัดการข้อความต้อนรับด้านบนภาพสไลด์)
  const [wbEnabled, setWbEnabled] = useState<boolean>(welcomeBanner?.enabled ?? true);
  const [wbTitlePrefix, setWbTitlePrefix] = useState<string>(welcomeBanner?.titlePrefix || 'ยินดีต้อนรับสู่ร้าน');
  const [wbTitleHighlight, setWbTitleHighlight] = useState<string>(welcomeBanner?.titleHighlight || 'ARXSTORE.XYZ');
  const [wbHighlightColor, setWbHighlightColor] = useState<string>(welcomeBanner?.highlightColor || '#00e5ff');
  const [wbDescription, setWbDescription] = useState<string>(welcomeBanner?.description || '');
  const [wbBtn1Text, setWbBtn1Text] = useState<string>(welcomeBanner?.button1Text || 'ซื้อเลย');
  const [wbBtn1Link, setWbBtn1Link] = useState<string>(welcomeBanner?.button1Link || '#products-catalog');
  const [wbBtn2Text, setWbBtn2Text] = useState<string>(welcomeBanner?.button2Text || 'วิธีใช้งาน');
  const [wbBtn2Link, setWbBtn2Link] = useState<string>(welcomeBanner?.button2Link || '/how-to');
  const [wbSaving, setWbSaving] = useState(false);
  const [wbSavedSuccess, setWbSavedSuccess] = useState(false);

  useEffect(() => {
    if (welcomeBanner) {
      setWbEnabled(welcomeBanner.enabled ?? true);
      setWbTitlePrefix(welcomeBanner.titlePrefix || 'ยินดีต้อนรับสู่ร้าน');
      setWbTitleHighlight(welcomeBanner.titleHighlight || 'ARXSTORE.XYZ');
      setWbHighlightColor(welcomeBanner.highlightColor || '#00e5ff');
      setWbDescription(welcomeBanner.description || '');
      setWbBtn1Text(welcomeBanner.button1Text || 'ซื้อเลย');
      setWbBtn1Link(welcomeBanner.button1Link || '#products-catalog');
      setWbBtn2Text(welcomeBanner.button2Text || 'วิธีใช้งาน');
      setWbBtn2Link(welcomeBanner.button2Link || '/how-to');
    }
  }, [welcomeBanner]);

  const handleSaveWelcomeBanner = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    playClick();
    setWbSaving(true);
    await updateWelcomeBanner({
      enabled: wbEnabled,
      titlePrefix: wbTitlePrefix,
      titleHighlight: wbTitleHighlight,
      highlightColor: wbHighlightColor,
      description: wbDescription,
      button1Text: wbBtn1Text,
      button1Link: wbBtn1Link,
      button2Text: wbBtn2Text,
      button2Link: wbBtn2Link
    });
    playSuccess();
    setWbSaving(false);
    setWbSavedSuccess(true);
    setTimeout(() => setWbSavedSuccess(false), 3000);
  };

  const handleResetWelcomeBanner = () => {
    playClick();
    setWbEnabled(true);
    setWbTitlePrefix('ยินดีต้อนรับสู่ร้าน');
    setWbTitleHighlight('ARXSTORE.XYZ');
    setWbHighlightColor('#00e5ff');
    setWbDescription('ร้านบริการจำหน่ายโปรแกรมช่วยเล่น Fivem / ปลดแบนFivem ราคาถูกและปลอดภัยต่อผู้ใช้ ตอบโจทย์ทุกการใช้งาน ต่างๆ ไม่ว่าจะเป็นโปรแกรม External / Unban / Internal / CMD');
    setWbBtn1Text('ซื้อเลย');
    setWbBtn1Link('#products-catalog');
    setWbBtn2Text('เติมเงิน');
    setWbBtn2Link('/topup');
  };

  // Mobile State for Persistent Sidebar (สถานะเปิดบนมือถือ)
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Search & Filter for Products (จัดการสินค้า)
  const [productSearch, setProductSearch] = useState('');
  const [selectedCatFilter, setSelectedCatFilter] = useState('all');

  // Search & Filter for Stock Management (จัดการสต็อก)
  const [stockSearch, setStockSearch] = useState('');
  const [stockCatFilter, setStockCatFilter] = useState('all');
  const [stockStatusFilter, setStockStatusFilter] = useState<'all' | 'in_stock' | 'out_of_stock'>('all');

  // Modals state
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editModalTab, setEditModalTab] = useState<'info' | 'packages' | 'all'>('info');
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [showBulkPromoModal, setShowBulkPromoModal] = useState(false);
  const [showAddSlideModal, setShowAddSlideModal] = useState(false);
  const [newSlideImage, setNewSlideImage] = useState('/catalog/imported/banner_fivem.webp');
  const [newSlideAction, setNewSlideAction] = useState('all');

  // Digital Stock Manager state (จัดการคลังสต็อก: คีย์, ลิงก์, ไฟล์)
  const [managingStockProduct, setManagingStockProduct] = useState<Product | null>(null);
  const [managingStockPackageId, setManagingStockPackageId] = useState<string>('');

  const openStockManager = (prod: Product, pkgId?: string) => {
    playClick();
    setManagingStockProduct(prod);
    setManagingStockPackageId(pkgId || prod.packages[0]?.id || '');
  };

  // Close modals smoothly on Escape key press (กดปุ่ม Esc เพื่อปิดหน้าต่างโมดอล)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'Esc') {
        if (managingStockProduct) {
          e.preventDefault();
          playClick();
          setManagingStockProduct(null);
        } else if (editingProduct) {
          e.preventDefault();
          playClick();
          setEditingProduct(null);
        } else if (showAddProductModal) {
          e.preventDefault();
          playClick();
          setShowAddProductModal(false);
        } else if (showBulkPromoModal) {
          e.preventDefault();
          playClick();
          setShowBulkPromoModal(false);
        } else if (showAddSlideModal) {
          e.preventDefault();
          playClick();
          setShowAddSlideModal(false);
        } else if (editingCategory) {
          e.preventDefault();
          playClick();
          setEditingCategory(null);
        } else if (mobileSidebarOpen) {
          e.preventDefault();
          setMobileSidebarOpen(false);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    managingStockProduct,
    editingProduct,
    showAddProductModal,
    showBulkPromoModal,
    showAddSlideModal,
    editingCategory,
    mobileSidebarOpen,
    playClick
  ]);

  // New Product form state
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState(categories[0]?.id || 'cat-fivem');
  const [newProdImage, setNewProdImage] = useState('/catalog/imported/46ebc6a271269458ec9b.webp');
  const [newProdDesc, setNewProdDesc] = useState('');
  const [newProdInstructions, setNewProdInstructions] = useState('');
  const [newProdYoutubeUrl, setNewProdYoutubeUrl] = useState('');
  const [newProdStatus, setNewProdStatus] = useState<ProductStatus>('ready');
  const [newProdStatusNote, setNewProdStatusNote] = useState('');
  const [newProdPackages, setNewProdPackages] = useState<ProductPackage[]>([
    { id: 'pkg-1d', name: 'ใช้งาน 1 วัน', duration: '1 วัน', price: 50, stock: 10, inStock: true },
    { id: 'pkg-7d', name: 'ใช้งาน 7 วัน', duration: '7 วัน', price: 150, stock: 10, inStock: true },
    { id: 'pkg-30d', name: 'ใช้งาน 30 วัน', duration: '30 วัน', price: 350, stock: 5, inStock: true }
  ]);

  // Bulk Promo state
  const [bulkDiscount, setBulkDiscount] = useState<number>(20);
  const [bulkBadge, setBulkBadge] = useState<string>('SALE');
  const [bulkCategoryScope, setBulkCategoryScope] = useState<string>('all');

  // Site Stats local form state
  const [statsForm, setStatsForm] = useState<SiteStats>({
    users: siteStats?.users ?? 0,
    topup: siteStats?.topup ?? 0,
    stock: siteStats?.stock ?? 0,
    sales: siteStats?.sales ?? 0,
    isCustom: siteStats?.isCustom ?? false,
    mode: siteStats?.mode ?? 'direct'
  });
  const [statsSavedNotice, setStatsSavedNotice] = useState<string | null>(null);

  // Keep statsForm in sync when siteStats updates from context
  useEffect(() => {
    if (siteStats) {
      setStatsForm(prev => ({
        ...prev,
        users: typeof siteStats.users === 'number' ? siteStats.users : prev.users,
        topup: typeof siteStats.topup === 'number' ? siteStats.topup : prev.topup,
        stock: typeof siteStats.stock === 'number' ? siteStats.stock : prev.stock,
        sales: typeof siteStats.sales === 'number' ? siteStats.sales : prev.sales,
        isCustom: typeof siteStats.isCustom === 'boolean' ? siteStats.isCustom : prev.isCustom,
        mode: siteStats.mode ?? prev.mode ?? 'direct'
      }));
    }
  }, [siteStats]);

  // Instant Auto-Save handler: saves to state, localStorage, and StoreContext on every keystroke/change
  const handleStatsFieldChange = (field: keyof SiteStats, value: any) => {
    const next: SiteStats = { ...statsForm, [field]: value };
    setStatsForm(next);
    updateSiteStats(next, true);
    setStatsSavedNotice('✓ บันทึกอัตโนมัติแล้ว (อัปเดตหน้าเว็บ Real-time ทันที)');
  };

  const handleSaveStatsForm = () => {
    playClick();
    updateSiteStats(statsForm, false);
    setStatsSavedNotice('✓ บันทึกตัวเลขสถิติเรียบร้อยแล้ว (อัปเดตหน้าเว็บทันทีแบบ Real-time)');
  };

  // Slip API form state
  const [slipForm, setSlipForm] = useState<SlipApiConfig>({
    provider: slipConfig?.provider ?? 'slipok',
    apiKey: slipConfig?.apiKey ?? '',
    branchId: slipConfig?.branchId ?? '',
    promptPayNumber: slipConfig?.promptPayNumber ?? '5160906053',
    accountName: slipConfig?.accountName ?? 'ณัฐพงศ์ แซ่หลู่',
    bankName: slipConfig?.bankName ?? 'กสิกรไทย (KBANK / K+)',
    trueMoneyPhone: slipConfig?.trueMoneyPhone ?? '098-XXX-XXXX',
    autoApprove: slipConfig?.autoApprove ?? true,
    channelPromptPayEnabled: slipConfig?.channelPromptPayEnabled ?? true,
    channelBankTransferEnabled: slipConfig?.channelBankTransferEnabled ?? true,
    channelAngpaoEnabled: slipConfig?.channelAngpaoEnabled ?? true,
    channelTrueMoneyWalletEnabled: slipConfig?.channelTrueMoneyWalletEnabled ?? true,
    angpaoFeePercent: slipConfig?.angpaoFeePercent ?? 2.9
  });
  const [showApiKey, setShowApiKey] = useState(false);

  useEffect(() => {
    if (slipConfig) {
      setSlipForm({
        provider: slipConfig.provider ?? 'slipok',
        apiKey: slipConfig.apiKey ?? '',
        branchId: slipConfig.branchId ?? '',
        promptPayNumber: slipConfig.promptPayNumber ?? '5160906053',
        accountName: slipConfig.accountName ?? 'ณัฐพงศ์ แซ่หลู่',
        bankName: slipConfig.bankName ?? 'กสิกรไทย (KBANK / K+)',
        trueMoneyPhone: slipConfig.trueMoneyPhone ?? '098-XXX-XXXX',
        autoApprove: slipConfig.autoApprove ?? true,
        channelPromptPayEnabled: slipConfig.channelPromptPayEnabled ?? true,
        channelBankTransferEnabled: slipConfig.channelBankTransferEnabled ?? true,
        channelAngpaoEnabled: slipConfig.channelAngpaoEnabled ?? true,
        channelTrueMoneyWalletEnabled: slipConfig.channelTrueMoneyWalletEnabled ?? true,
        angpaoFeePercent: slipConfig.angpaoFeePercent ?? 2.9
      });
    }
  }, [slipConfig]);

  // BYShop Connection Test State
  const [isTestingByshop, setIsTestingByshop] = useState(false);
  const [byshopTestResult, setByshopTestResult] = useState('');

  const handleTestByshopConnection = async () => {
    if (!slipForm.apiKey.trim()) {
      showToast({ title: 'แจ้งเตือน', message: 'กรุณากรอก API Key ของ BYShop ก่อนกดทดสอบ', type: 'error' });
      playError();
      return;
    }
    playClick();
    setIsTestingByshop(true);
    setByshopTestResult('');
    try {
      const token = typeof window !== 'undefined' ? (localStorage.getItem('arx_session_token') || localStorage.getItem('arx_admin_token')) : null;
      const res = await fetch('/api/admin/byshop/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}`, 'x-session-token': token } : {})
        },
        body: JSON.stringify({
          apiKey: slipForm.apiKey.trim(),
          merchantId: slipForm.branchId.trim()
        })
      });
      const data = await res.json();
      if (data.success) {
        playSuccess();
        setByshopTestResult(`เชื่อมต่อสำเร็จ (${data.latency})`);
        showToast({
          title: 'เชื่อมต่อ BYShop สำเร็จ!',
          message: data.message,
          type: 'success'
        });
      } else {
        throw new Error(data.message || 'การเชื่อมต่อไม่สำเร็จ');
      }
    } catch (err: any) {
      playError();
      setByshopTestResult(`ล้มเหลว: ${err.message}`);
      showToast({ title: 'เชื่อมต่อไม่สำเร็จ', message: err.message, type: 'error' });
    } finally {
      setIsTestingByshop(false);
    }
  };

  // Status Note editing state for Real-time status tab
  const [editingNotes, setEditingNotes] = useState<Record<string, string>>({});

  // Discord Webhook local form state
  const [webhookForm, setWebhookForm] = useState<DiscordWebhookSettings>(() => {
    const DEFAULT_AVATAR = 'https://files.catbox.moe/haszlm.png';
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('arx_webhook_settings');
        if (saved) {
          const parsed = JSON.parse(saved);
          let avatar = parsed.botAvatarUrl || DEFAULT_AVATAR;
          if (avatar.includes('83pZpGj.png')) avatar = DEFAULT_AVATAR;
          return {
            registerEnabled: parsed.registerEnabled ?? true,
            registerUrl: parsed.registerUrl || '',
            topupEnabled: parsed.topupEnabled ?? true,
            topupUrl: parsed.topupUrl || '',
            orderEnabled: parsed.orderEnabled ?? true,
            orderUrl: parsed.orderUrl || '',
            stockEnabled: parsed.stockEnabled ?? true,
            stockUrl: parsed.stockUrl || '',
            botName: parsed.botName || 'ARX STORE BOT',
            botAvatarUrl: avatar
          };
        }
      } catch {
        // ignore
      }
    }
    const fallbackAv = webhookSettings?.botAvatarUrl && !webhookSettings.botAvatarUrl.includes('83pZpGj.png')
      ? webhookSettings.botAvatarUrl
      : DEFAULT_AVATAR;
    return {
      registerEnabled: webhookSettings?.registerEnabled ?? true,
      registerUrl: webhookSettings?.registerUrl ?? '',
      topupEnabled: webhookSettings?.topupEnabled ?? true,
      topupUrl: webhookSettings?.topupUrl ?? '',
      orderEnabled: webhookSettings?.orderEnabled ?? true,
      orderUrl: webhookSettings?.orderUrl ?? '',
      stockEnabled: webhookSettings?.stockEnabled ?? true,
      stockUrl: webhookSettings?.stockUrl ?? '',
      botName: webhookSettings?.botName ?? 'ARX STORE BOT',
      botAvatarUrl: fallbackAv
    };
  });
  const [testingWebhookType, setTestingType] = useState<string | null>(null);

  // Directly hydrate from localStorage on mount so links are never lost on refresh
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('arx_webhook_settings');
        if (saved) {
          const parsed = JSON.parse(saved);
          let avatar = parsed.botAvatarUrl || 'https://files.catbox.moe/haszlm.png';
          if (avatar.includes('83pZpGj.png')) avatar = 'https://files.catbox.moe/haszlm.png';
          setWebhookForm(prev => ({
            ...prev,
            ...parsed,
            registerUrl: parsed.registerUrl ?? prev.registerUrl,
            topupUrl: parsed.topupUrl ?? prev.topupUrl,
            orderUrl: parsed.orderUrl ?? prev.orderUrl,
            stockUrl: parsed.stockUrl ?? prev.stockUrl,
            botAvatarUrl: avatar
          }));
        }
      } catch {
        // ignore
      }
    }
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const tab = params.get('tab');
      if (tab && ['products', 'stock', 'categories', 'slides', 'stats', 'status', 'slip', 'topups', 'orders', 'webhooks', 'security', 'users'].includes(tab)) {
        setActiveTab(tab as any);
      }
    }
  }, []);

  useEffect(() => {
    if (webhookSettings) {
      setWebhookForm(prev => {
        // Guard: do not wipe existing URLs with empty strings from unhydrated default state
        const registerUrl = webhookSettings.registerUrl || prev.registerUrl || '';
        const topupUrl = webhookSettings.topupUrl || prev.topupUrl || '';
        const orderUrl = webhookSettings.orderUrl || prev.orderUrl || '';
        const stockUrl = webhookSettings.stockUrl || prev.stockUrl || '';
        let botAvatarUrl = webhookSettings.botAvatarUrl || prev.botAvatarUrl || 'https://files.catbox.moe/haszlm.png';
        if (botAvatarUrl.includes('83pZpGj.png')) botAvatarUrl = 'https://files.catbox.moe/haszlm.png';

        return {
          ...prev,
          ...webhookSettings,
          registerUrl,
          topupUrl,
          orderUrl,
          stockUrl,
          botAvatarUrl
        };
      });
    }
  }, [webhookSettings]);

  const [webhookSavedNotice, setWebhookSavedNotice] = useState<string | null>(null);

  // Instant Auto-Save handler: saves to state, localStorage, and StoreContext on every change
  const handleWebhookFieldChange = (field: keyof DiscordWebhookSettings, value: any) => {
    const next = { ...webhookForm, [field]: value };
    setWebhookForm(next);
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('arx_webhook_settings', JSON.stringify(next));
      } catch (e) {
        console.error('Failed to save webhook settings to localStorage:', e);
      }
    }
    updateWebhookSettings(next, true);
  };

  const handleSaveWebhookSettings = () => {
    playClick();
    if (typeof window !== 'undefined') {
      localStorage.setItem('arx_webhook_settings', JSON.stringify(webhookForm));
    }
    updateWebhookSettings(webhookForm);
    setWebhookSavedNotice('✓ บันทึกการตั้งค่า Discord Webhook ทั้งหมดเรียบร้อยแล้ว!');
    setTimeout(() => setWebhookSavedNotice(null), 3500);
  };

  const handleTestWebhook = async (type: 'register' | 'topup_bank' | 'topup_truemoney' | 'order' | 'stock') => {
    playClick();
    // Auto-save form before testing so the link is 100% saved
    if (typeof window !== 'undefined') {
      localStorage.setItem('arx_webhook_settings', JSON.stringify(webhookForm));
    }
    updateWebhookSettings(webhookForm, true);

    setTestingType(type);
    let targetUrl = '';
    if (type === 'register') targetUrl = webhookForm.registerUrl;
    else if (type === 'topup_bank' || type === 'topup_truemoney') targetUrl = webhookForm.topupUrl;
    else if (type === 'order') targetUrl = webhookForm.orderUrl;
    else if (type === 'stock') targetUrl = webhookForm.stockUrl;

    const res = await testDiscordWebhook(type, targetUrl);
    setTestingType(null);
    if (res.success) {
      const typeLabels: Record<string, string> = {
        register: 'สมัครสมาชิกใหม่',
        topup_bank: 'เติมเงินสลิปธนาคาร',
        topup_truemoney: 'เติมเงิน TrueMoney ซองอั่งเปา',
        order: 'สั่งซื้อสินค้า & License Key',
        stock: 'แจ้งเตือนเติมสต็อคสินค้า'
      };
      setWebhookSavedNotice(`✓ ส่งข้อความจำลองเหตุการณ์จริง (${typeLabels[type] || type}) พร้อมรายละเอียดครบถ้วนเข้า Discord เรียบร้อยแล้ว!`);
    } else {
      setWebhookSavedNotice(`การส่งทดสอบล้มเหลว: ${res.message || 'โปรดตรวจสอบ Webhook URL'}`);
    }
    setTimeout(() => setWebhookSavedNotice(null), 4500);
  };

  // ARX SHIELD state & toggle
  const [shieldActive, setShieldActive] = useState<boolean>(true);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const saved = localStorage.getItem('arx_shield_enabled');
      if (saved !== null) {
        setShieldActive(saved === 'true');
      }
    } catch {
      // ignore
    }
  }, []);

  const toggleShield = () => {
    playClick();
    const nextVal = !shieldActive;
    setShieldActive(nextVal);
    if (typeof window !== 'undefined') {
      localStorage.setItem('arx_shield_enabled', String(nextVal));
      window.dispatchEvent(new CustomEvent('arx:shield:change', { detail: nextVal }));
    }
  };

  // Analytics calculations
  const totalRevenue = orders.reduce((sum, o) => sum + o.price, 0);
  const pendingTopups = topups.filter(t => t.status === 'pending');

  // Stock Analytics calculations (สำหรับแท็บจัดการสต็อก)
  const totalAvailStockCount = products.reduce((acc, p) => {
    return acc + p.packages.reduce((pAcc, pkg) => {
      const avail = pkg.stockItems ? pkg.stockItems.filter(s => !s.isUsed).length : pkg.stock;
      return pAcc + (avail > 0 ? avail : 0);
    }, 0);
  }, 0);

  const totalSoldStockCount = products.reduce((acc, p) => {
    return acc + p.packages.reduce((pAcc, pkg) => {
      const sold = pkg.stockItems ? pkg.stockItems.filter(s => s.isUsed).length : 0;
      return pAcc + sold;
    }, 0);
  }, 0);

  const outOfStockPackagesCount = products.reduce((acc, p) => {
    return acc + p.packages.filter(pkg => {
      const avail = pkg.stockItems ? pkg.stockItems.filter(s => !s.isUsed).length : pkg.stock;
      return avail <= 0 || !pkg.inStock;
    }).length;
  }, 0);

  // Filtered products for Stock Tab
  const filteredStockProducts = products.filter(p => {
    if (stockCatFilter !== 'all' && p.categoryId !== stockCatFilter) return false;
    if (stockSearch) {
      const q = stockSearch.toLowerCase();
      const matchName = p.name.toLowerCase().includes(q);
      const matchCat = (p.categoryName || '').toLowerCase().includes(q);
      const matchKey = p.packages.some(pkg => pkg.stockItems?.some(s => s.key.toLowerCase().includes(q)));
      if (!matchName && !matchCat && !matchKey) return false;
    }
    if (stockStatusFilter === 'in_stock') {
      const anyInStock = p.packages.some(pkg => {
        const avail = pkg.stockItems ? pkg.stockItems.filter(s => !s.isUsed).length : pkg.stock;
        return avail > 0 && pkg.inStock;
      });
      if (!anyInStock) return false;
    }
    if (stockStatusFilter === 'out_of_stock') {
      const allOut = p.packages.every(pkg => {
        const avail = pkg.stockItems ? pkg.stockItems.filter(s => !s.isUsed).length : pkg.stock;
        return avail <= 0 || !pkg.inStock;
      });
      if (!allOut) return false;
    }
    return true;
  });

  // Preset Image List for quick selection
  const PRESET_IMAGES = [
    { label: 'FiveM เต็มระบบ', path: '/catalog/imported/46ebc6a271269458ec9b.webp' },
    { label: 'โปรล็อค FiveM', path: '/catalog/imported/1659904f5d8658a4d024.webp' },
    { label: 'ปลดแบน FiveM', path: '/catalog/imported/104c35788c3f6fca9f4e.webp' },
    { label: 'ปลดแบน Valorant', path: '/catalog/imported/601957f4b81f88d8b27f.webp' },
    { label: 'มาโคร คุมดีด', path: '/catalog/imported/eadd032260d2971fffbb.webp' },
    { label: 'แบนเนอร์ FiveM', path: '/catalog/imported/banner_fivem.webp' },
    { label: 'แบนเนอร์ Cheat', path: '/catalog/imported/banner_cheat.webp' },
    { label: 'โลโก้ร้าน ARX', path: '/brand/logo.png' }
  ];

  // Auth Protection Check: If not hydrated, show minimal loader
  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-[color:var(--arx-dk-050811)] text-white flex flex-col items-center justify-center p-4">
        <div className="w-10 h-10 border-2 border-cyan-500/20 border-t-cyan-400 rounded-full animate-spin mb-4" />
        <p className="text-xs text-slate-400 font-mono tracking-wider">กำลังตรวจสอบสิทธิ์การเข้าถึง...</p>
      </div>
    );
  }

  // If visitor is not logged in or not admin, show dedicated Cyberpunk Admin Login Gate
  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-[color:var(--arx-dk-04060d)] text-white flex items-center justify-center p-4 relative overflow-hidden select-none">
        {/* Ambient Backlight Glows */}
        <div className="absolute top-1/4 left-1/3 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-cyan-500/10 blur-[140px] pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/3 translate-x-1/2 translate-y-1/2 w-[500px] h-[500px] rounded-full bg-blue-600/10 blur-[140px] pointer-events-none" />
        
        {/* Subtle grid background pattern */}
        <div 
          className="absolute inset-0 opacity-[0.03] pointer-events-none"
          style={{
            backgroundImage: 'linear-gradient(rgba(var(--theme-accent-rgb), 0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(var(--theme-accent-rgb), 0.4) 1px, transparent 1px)',
            backgroundSize: '40px 40px'
          }}
        />

        <div className="w-full max-w-md relative z-10 animate-in fade-in zoom-in-95 duration-200">
          <div className="rounded-3xl p-6 sm:p-8 bg-[color:var(--arx-dk-080d1a)]/95 border border-cyan-500/30 shadow-[0_20px_70px_rgba(0,0,0,0.95),0_0_40px_rgba(var(--theme-accent-rgb),0.18)] backdrop-blur-2xl">
            {/* Header Badge & Icon */}
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-cyan-950/70 border border-cyan-400/50 shadow-[0_0_20px_rgba(var(--theme-accent-rgb),0.4)] text-cyan-300 mb-3.5">
                <ShieldCheck className="w-7 h-7 stroke-[2.2]" />
              </div>
              <div>
                <span className="inline-block px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-[10px] font-black text-cyan-300 tracking-wider uppercase mb-2">
                  ARX CYBERSHIELD • ADMIN PORTAL
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-wide">
                เข้าสู่ระบบผู้ดูแลระบบ
              </h1>
              <p className="text-xs text-slate-400 mt-1">
                กรุณาเข้าสู่ระบบด้วยบัญชี Admin เพื่อจัดการร้านค้า ARX STORE
              </p>
            </div>

            {/* If currently logged in as a normal user */}
            {user && user.role !== 'admin' && (
              <div className="mb-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2.5">
                <span className="shrink-0 text-base leading-none">⚠️</span>
                <div>
                  <p className="font-bold">เข้าสู่ระบบในชื่อ @{user.username} (ผู้ใช้ทั่วไป)</p>
                  <p className="text-[11px] text-amber-200/80 mt-0.5">
                    บัญชีนี้ไม่มีสิทธิ์เข้าถึง Admin Panel กรุณาลงชื่อเข้าใช้ด้วยบัญชีแอดมิน
                  </p>
                </div>
              </div>
            )}

            {/* Error Message */}
            {adminLoginError && (
              <div className="mb-4 p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs flex items-center gap-2 animate-in fade-in">
                <span className="shrink-0">⚠️</span>
                <span>{adminLoginError}</span>
              </div>
            )}

            {/* Login Form */}
            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  ชื่อผู้ใช้ (Username)
                </label>
                <div className="relative rounded-xl bg-black/60 border border-white/10 hover:border-white/20 focus-within:border-cyan-400 focus-within:shadow-[0_0_15px_rgba(var(--theme-accent-rgb),0.25)] transition-all">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500 pointer-events-none">
                    <UserIcon className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    required
                    value={adminUsername}
                    onChange={(e) => setAdminUsername(e.target.value)}
                    placeholder="arxstore"
                    autoFocus
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-xl bg-transparent text-white placeholder-slate-600 text-xs focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  รหัสผ่าน (Password)
                </label>
                <div className="relative rounded-xl bg-black/60 border border-white/10 hover:border-white/20 focus-within:border-cyan-400 focus-within:shadow-[0_0_15px_rgba(var(--theme-accent-rgb),0.25)] transition-all">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500 pointer-events-none">
                    <Lock className="w-4 h-4" />
                  </span>
                  <input
                    type={showAdminPassword ? 'text' : 'password'}
                    required
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-10 py-2.5 rounded-xl bg-transparent text-white placeholder-slate-600 text-xs focus:outline-none font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowAdminPassword(!showAdminPassword)}
                    className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                  >
                    {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={adminLoginLoading}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 via-cyan-300 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(var(--theme-accent-rgb),0.45)] hover:shadow-[0_0_30px_rgba(var(--theme-accent-rgb),0.65)] transition-all cursor-pointer active:scale-95 disabled:opacity-60"
              >
                {adminLoginLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                    <span>กำลังตรวจสอบสิทธิ์...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 stroke-[2.5]" />
                    <span>เข้าสู่ระบบแอดมิน</span>
                  </>
                )}
              </button>
            </form>

            {/* Back to Homepage Button */}
            <div className="mt-5 pt-4 border-t border-white/5 flex items-center justify-between text-xs text-slate-400">
              <Link
                href="/"
                className="hover:text-cyan-300 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <span>← กลับสู่หน้าร้านค้า</span>
              </Link>
              <span className="text-[11px] text-slate-500 font-mono">
                ARX STORE OS
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Handle Create Product
  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim()) return;

    const catObj = categories.find(c => c.id === newProdCategory);

    addProduct({
      name: newProdName,
      slug: newProdName.toLowerCase().replace(/\s+/g, '-'),
      categoryId: newProdCategory,
      categoryName: catObj ? catObj.name : 'สินค้าทั่วไป',
      shortDescription: newProdDesc || 'รายละเอียดสินค้าดิจิทัลและโปรเจกต์',
      description: newProdDesc || 'รายละเอียดสินค้าดิจิทัลและโปรเจกต์แบบเต็ม',
      image: newProdImage || '/catalog/imported/46ebc6a271269458ec9b.webp',
      rating: 5.0,
      salesCount: 0,
      status: newProdStatus,
      statusNote: newProdStatusNote.trim() || undefined,
      packages: newProdPackages,
      tags: ['New', 'Digital'],
      instructions: newProdInstructions || '1. โหลด Loader\n2. กรอก License Key\n3. เข้าใช้งานได้ทันที',
      youtubeUrl: newProdYoutubeUrl.trim() || undefined
    });

    setShowAddProductModal(false);
    setNewProdName('');
    setNewProdDesc('');
    setNewProdInstructions('');
    setNewProdYoutubeUrl('');
    setNewProdStatus('ready');
    setNewProdStatusNote('');
  };

  // Handle Edit Product Submit
  const handleUpdateProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    updateProduct(editingProduct.id, {
      name: editingProduct.name,
      image: editingProduct.image,
      categoryId: editingProduct.categoryId,
      categoryName: categories.find(c => c.id === editingProduct.categoryId)?.name || editingProduct.categoryName,
      shortDescription: editingProduct.shortDescription,
      description: editingProduct.description,
      badge: editingProduct.badge,
      discountBadge: editingProduct.discountBadge,
      status: editingProduct.status,
      statusNote: editingProduct.statusNote,
      packages: editingProduct.packages,
      instructions: editingProduct.instructions,
      youtubeUrl: editingProduct.youtubeUrl,
      optionType: editingProduct.optionType,
      requiresCustomInput: editingProduct.requiresCustomInput,
      customInputLabel: editingProduct.customInputLabel,
      customInputPlaceholder: editingProduct.customInputPlaceholder,
      customInputHelp: editingProduct.customInputHelp,
      guaranteeDays: editingProduct.guaranteeDays,
      features: editingProduct.features,
      detailsList: editingProduct.detailsList
    });

    setEditingProduct(null);
  };

  // Quick Package Presets Helper
  const applyPackagePreset = (type: '1d_only' | '7d_only' | '14d_only' | 'lifetime_only' | 'standard_3' | 'all_5', target: 'new' | 'edit') => {
    playClick();
    let pkgs: ProductPackage[] = [];

    if (type === '1d_only') {
      pkgs = [{ id: 'pkg-' + Date.now() + '-1d', name: 'ใช้งาน 1 วัน', duration: '1 วัน', price: 50, stock: 10, inStock: true }];
    } else if (type === '7d_only') {
      pkgs = [{ id: 'pkg-' + Date.now() + '-7d', name: 'ใช้งาน 7 วัน', duration: '7 วัน', price: 150, stock: 10, inStock: true }];
    } else if (type === '14d_only') {
      pkgs = [{ id: 'pkg-' + Date.now() + '-14d', name: 'ใช้งาน 14 วัน', duration: '14 วัน', price: 250, stock: 10, inStock: true }];
    } else if (type === 'lifetime_only') {
      pkgs = [{ id: 'pkg-' + Date.now() + '-lt', name: 'ถาวร (Lifetime)', duration: 'ถาวร', price: 990, stock: 10, inStock: true }];
    } else if (type === 'standard_3') {
      pkgs = [
        { id: 'pkg-' + Date.now() + '-1d', name: 'เช่าใช้งาน 1 วัน', duration: '1 วัน', price: 50, stock: 10, inStock: true },
        { id: 'pkg-' + Date.now() + '-7d', name: 'เช่าใช้งาน 7 วัน', duration: '7 วัน', price: 150, stock: 10, inStock: true },
        { id: 'pkg-' + Date.now() + '-30d', name: 'เช่าใช้งาน 30 วัน', duration: '30 วัน', price: 350, stock: 5, inStock: true }
      ];
    } else if (type === 'all_5') {
      pkgs = [
        { id: 'pkg-' + Date.now() + '-1d', name: 'ใช้งาน 1 วัน', duration: '1 วัน', price: 50, stock: 10, inStock: true },
        { id: 'pkg-' + Date.now() + '-7d', name: 'ใช้งาน 7 วัน', duration: '7 วัน', price: 150, stock: 10, inStock: true },
        { id: 'pkg-' + Date.now() + '-14d', name: 'ใช้งาน 14 วัน', duration: '14 วัน', price: 250, stock: 10, inStock: true },
        { id: 'pkg-' + Date.now() + '-30d', name: 'ใช้งาน 30 วัน', duration: '30 วัน', price: 350, stock: 5, inStock: true },
        { id: 'pkg-' + Date.now() + '-lt', name: 'ถาวร (Lifetime)', duration: 'ถาวร', price: 1200, stock: 5, inStock: true }
      ];
    }

    if (target === 'new') {
      setNewProdPackages(pkgs);
    } else if (editingProduct) {
      setEditingProduct({ ...editingProduct, packages: pkgs });
    }
  };

  // หมวดหมู่ที่ใช้แสดงผล = หมวดจริง + หมวด "กำพร้า" ของสินค้าที่หมวดถูกลบ/ไม่มี
  // (ถ้าไม่ทำแบบนี้ สินค้าที่หมวดหายจะไม่โผล่ในตารางจัดการสินค้า/สต็อกเลย)
  const viewCategories: (Category & { isOrphan?: boolean })[] = (() => {
    const known = new Set(categories.map(c => c.id));
    const orphans = new Map<string, Category & { isOrphan?: boolean }>();
    products.forEach(p => {
      const cid = p.categoryId || '';
      if (known.has(cid) || orphans.has(cid)) return;
      orphans.set(cid, {
        id: cid,
        name: p.categoryName ? `${p.categoryName} (หมวดถูกลบ)` : 'ไม่มีหมวดหมู่',
        slug: '',
        iconName: '',
        description: '',
        itemCount: 0,
        badge: '!',
        isOrphan: true
      });
    });
    return [...categories, ...Array.from(orphans.values())];
  })();

  // Filtered Products & Displayed Categories
  const displayedCategories = selectedCatFilter === 'all'
    ? viewCategories
    : viewCategories.filter(c => c.id === selectedCatFilter);

  const filteredProducts = products.filter(p => {
    const matchCat = selectedCatFilter === 'all' || p.categoryId === selectedCatFilter;
    const matchSearch = !productSearch || p.name.toLowerCase().includes(productSearch.toLowerCase()) || p.categoryName.toLowerCase().includes(productSearch.toLowerCase());
    return matchCat && matchSearch;
  });

  type AdminTab = 'products' | 'stock' | 'categories' | 'stats' | 'recent-orders' | 'slip' | 'topups' | 'orders' | 'webhooks' | 'security' | 'users' | 'music' | 'seo' | 'site-content' | 'branding' | 'reseller' | 'theme';

  interface AdminNavItem {
    id: AdminTab;
    label: string;
    icon: React.ElementType;
    badge?: number | string;
    badgeColor?: string;
    desc?: string;
    isAlert?: boolean;
    isLive?: boolean;
  }

  interface AdminNavSection {
    group: string;
    items: AdminNavItem[];
  }

  // Grouped Navigation definition for Persistent Modern Sidebar
  const navSections: AdminNavSection[] = [
    {
      group: 'สินค้า & ร้านค้า',
      items: [
        {
          id: 'products',
          label: 'จัดการสินค้า',
          icon: Package,
          badge: products.length,
          badgeColor: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30',
          desc: 'รายชื่อ, ราคา, แพ็กเกจ'
        },
        {
          id: 'stock',
          label: 'จัดการสต็อก',
          icon: Key,
          badge: totalAvailStockCount,
          badgeColor: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
          desc: 'คีย์, ลิงก์, ไฟล์สินค้า'
        },
        {
          id: 'categories',
          label: 'จัดหมวดหมู่',
          icon: Layers,
          badge: categories.length,
          badgeColor: 'bg-slate-800 text-slate-400 border-white/5',
          desc: 'ลำดับหมวดหมู่ & แบนเนอร์'
        },
        {
          id: 'recent-orders',
          label: 'จัดการประวัติการซื้อล่าสุด',
          icon: History,
          badge: recentOrdersFeedEnabled ? 'เปิดอยู่' : 'ปิดอยู่',
          badgeColor: recentOrdersFeedEnabled
            ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
            : 'bg-rose-500/15 text-rose-300 border-rose-500/30',
          desc: 'เปิด/ปิดประวัติการซื้อหน้าเว็บ'
        },
        {
          id: 'site-content',
          label: 'เนื้อหาเว็บ & ติดต่อ',
          icon: Layers,
          badge: 'ข้อมูลเว็บ',
          badgeColor: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30',
          desc: 'ชื่อร้าน, โลโก้, ซื้อยังไง, FAQ, ช่องทางติดต่อ'
        }
      ]
    },
    {
      group: 'การเงิน & สมาชิก',
      items: [
        {
          id: 'orders',
          label: 'คำสั่งซื้อ',
          icon: ShoppingBag,
          badge: orders.length,
          badgeColor: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
          desc: 'ประวัติการสั่งซื้อ'
        },
        {
          id: 'topups',
          label: 'รายการเติมเงิน',
          icon: CreditCard,
          badge: pendingTopups.length > 0 ? pendingTopups.length : topups.length,
          badgeColor: pendingTopups.length > 0 ? 'bg-rose-500 text-white font-bold animate-pulse' : 'bg-slate-800 text-slate-400 border-white/5',
          isAlert: pendingTopups.length > 0,
          desc: pendingTopups.length > 0 ? 'มีสลิปรอตรวจ!' : 'ประวัติสลิป'
        },
        {
          id: 'slip',
          label: 'ระบบ Slip API',
          icon: QrCode,
          desc: 'ตรวจสลิปอัตโนมัติ 24 ชม.'
        },
        {
          id: 'users',
          label: 'จัดการ User',
          icon: Users,
          badge: users.length,
          badgeColor: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30',
          desc: 'แก้ไขเงิน, สินค้า, โปรไฟล์'
        },
        {
          id: 'reseller',
          label: 'ตัวแทนจำหน่าย (Reseller)',
          icon: Award,
          badge: 'สิทธิ์ตัวแทน',
          badgeColor: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
          desc: 'เกณฑ์ยอดเติม & ส่วนลด'
        }
      ]
    },
    {
      group: 'ระบบ & เพลง',
      items: [
        {
          id: 'music',
          label: 'เพลงพื้นหลัง BGM',
          icon: Music,
          badge: bgmSettings?.enabled ? 'เปิด' : 'ปิด',
          badgeColor: bgmSettings?.enabled ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' : 'bg-slate-800 text-slate-400 border-white/5',
          desc: 'ตั้งค่าเพลง & เสียง'
        },
        {
          id: 'theme',
          label: 'ปรับสีเว็บ',
          icon: Palette,
          badge: 'ธีม',
          badgeColor: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30',
          desc: 'สีหลัก, พื้นหลัง, การ์ด, ตัวอักษร'
        },
        {
          id: 'stats',
          label: 'สถิติปลอมยอด',
          icon: TrendingUp,
          desc: 'ปรับตัวเลขหน้าแรก'
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col lg:flex-row">
      {/* Mobile Top Header with toggle */}
      <div className="lg:hidden bg-slate-950/95 border-b border-white/10 p-3 flex items-center justify-between sticky top-0 z-40 backdrop-blur-md">
        <div className="flex items-center gap-2.5">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={siteContent?.branding?.logoUrl || "/brand/logo.png"}
            alt={siteContent?.branding?.siteName || "ARX Logo"}
            className="w-7 h-7 object-contain"
            onError={(e) => {
              const target = e.currentTarget;
              if (!target.src.includes('arx-default-logo.png')) {
                target.src = '/brand/arx-default-logo.png';
              }
            }}
          />
          <div>
            <span className="font-black text-white text-xs block">{siteContent?.branding?.siteName || 'ARX ADMIN'}</span>
            <span className="text-[10px] text-cyan-400 font-mono">
              {navSections.flatMap((s: AdminNavSection) => s.items).find((i: AdminNavItem) => i.id === activeTab)?.label}
            </span>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
          className="p-2 rounded-xl bg-slate-900 border border-white/10 text-slate-300 hover:text-white cursor-pointer"
        >
          {mobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* ======================================================== */}
      {/* 🖥️ LEFT SIDEBAR (Expanded & Highly Readable) */}
      {/* ======================================================== */}
      <aside className={`w-full lg:w-64 xl:w-72 shrink-0 bg-slate-950 border-b lg:border-b-0 lg:border-r border-white/10 lg:sticky lg:top-0 lg:h-screen flex flex-col justify-start overflow-hidden z-30 ${
        mobileSidebarOpen ? 'block' : 'hidden lg:flex'
      }`}>
        {/* Top: Fixed Brand Identity */}
        <div className="shrink-0">
          <div className="px-3.5 py-3 border-b border-white/10 flex items-center justify-between gap-2 bg-slate-950">
            <div className="flex items-center gap-2.5 min-w-0">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={siteContent?.branding?.logoUrl || "/brand/logo.png"}
                alt={siteContent?.branding?.siteName || "ARX Logo"}
                className="w-8 h-8 object-contain shrink-0 drop-shadow-[0_0_8px_rgba(var(--theme-accent-rgb),0.7)]"
                onError={(e) => {
                  const target = e.currentTarget;
                  if (!target.src.includes('arx-default-logo.png')) {
                    target.src = '/brand/arx-default-logo.png';
                  }
                }}
              />
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-black text-white text-sm tracking-wide truncate">{siteContent?.branding?.siteName || 'ARX STORE'}</span>
                  <span className="text-[9.5px] font-mono font-black px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">ADMIN</span>
                </div>
                <p className="text-[10.5px] text-slate-400 truncate mt-0.5">Master Control Hub</p>
              </div>
            </div>
            <Link
              href="/"
              target="_blank"
              className="p-1.5 rounded-lg bg-slate-900 border border-white/10 text-slate-400 hover:text-cyan-300 hover:bg-cyan-500/10 transition shrink-0"
              title="เปิดดูหน้าร้าน (Storefront)"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        {/* Middle: Category Menu List */}
        <div className="flex-1 min-h-0 overflow-y-auto px-2 py-2 space-y-1.5 sidebar-custom-scroll">
          {navSections.map(sec => (
            <div key={sec.group} className="space-y-1">
              <div className="px-2.5 pt-2 pb-1 text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono flex items-center justify-between">
                <span>{sec.group}</span>
                <span className="text-[9px] text-slate-500">{sec.items.length}</span>
              </div>

              {sec.items.map(it => {
                const Icon = it.icon;
                const isActive = activeTab === it.id;
                return (
                  <button
                    key={it.id}
                    type="button"
                    onClick={() => {
                      playClick();
                      setActiveTab(it.id);
                      setMobileSidebarOpen(false);
                    }}
                    title={it.desc}
                    className={`w-full px-2.5 py-1.5 rounded-xl text-xs sm:text-[12.5px] font-semibold flex items-center gap-2.5 transition-all cursor-pointer text-left group ${
                      isActive
                        ? it.id === 'stock'
                          ? 'bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-sm shadow-amber-500/10'
                          : it.id === 'security'
                          ? 'bg-rose-500/15 text-rose-300 border border-rose-500/40 shadow-sm shadow-rose-500/10'
                          : it.id === 'orders' || it.id === 'topups' || it.id === 'slip'
                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-500/10'
                          : it.id === 'webhooks' || it.id === 'stats'
                          ? 'bg-purple-500/15 text-purple-300 border border-purple-500/40 shadow-sm shadow-purple-500/10'
                          : 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/10'
                        : 'text-slate-400 hover:text-white hover:bg-white/[0.04] border border-transparent'
                    }`}
                  >
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                      isActive
                        ? 'bg-white/10 text-white'
                        : 'bg-slate-900/80 text-slate-400 group-hover:text-cyan-300 group-hover:bg-slate-800'
                    }`}>
                      <Icon className="w-4 h-4" />
                    </div>

                    <span className="flex-1 truncate text-xs sm:text-[12.5px] font-medium">{it.label}</span>

                    {it.isLive && (
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                    )}

                    {it.badge !== undefined && (
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold shrink-0 border ${
                        it.isAlert
                          ? 'bg-rose-500 text-white border-rose-400 animate-pulse font-black'
                          : isActive
                          ? 'bg-white/10 text-white border-white/20'
                          : it.badgeColor || 'bg-slate-900 text-slate-400 border-white/5'
                      }`}>
                        {it.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}

          {/* Bottom Status */}
          <div className="pt-2 px-1 border-t border-white/10 mt-1.5 flex items-center justify-center gap-1.5 text-[10px] text-slate-500 font-mono py-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Online · 24/7</span>
          </div>
        </div>
      </aside>

      {/* ======================================================== */}
      {/* 🚀 MAIN CONTENT DASHBOARD AREA (Compact & High-density) */}
      {/* ======================================================== */}
      <main className="flex-1 min-w-0 p-3 sm:p-4 lg:p-5 space-y-3.5">
        {/* 🚀 QUICK KPI DASHBOARD */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-2.5">
          {/* KPI 1: สินค้า */}
          <button
            type="button"
            onClick={() => { playClick(); setActiveTab('products'); }}
            className={`p-3 sm:p-3.5 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden group min-h-[58px] ${
              activeTab === 'products'
                ? 'bg-cyan-950/40 border-cyan-400 shadow-sm shadow-cyan-500/10 ring-1 ring-cyan-400/50'
                : 'bg-slate-950/60 border-white/10 hover:border-cyan-500/40 hover:bg-slate-900/60'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10.5px] font-bold text-slate-400 uppercase tracking-wider">สินค้าทั้งหมด</span>
              <div className="w-6 h-6 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition-transform">
                <Package className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-base sm:text-lg font-bold text-white font-mono leading-none">{products.length} <span className="text-xs font-normal text-slate-400">รายการ</span></div>
            <div className="text-[11px] text-cyan-400 flex items-center gap-1 mt-1">
              <span>{products.reduce((acc, p) => acc + p.packages.filter(x => x.inStock).length, 0)} พร้อมขาย</span>
              <ArrowRight className="w-3 h-3 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          </button>

          {/* KPI 2: คำสั่งซื้อ */}
          <button
            type="button"
            onClick={() => { playClick(); setActiveTab('orders'); }}
            className={`p-3 sm:p-3.5 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden group min-h-[58px] ${
              activeTab === 'orders'
                ? 'bg-emerald-950/40 border-emerald-400 shadow-sm shadow-emerald-500/10 ring-1 ring-emerald-400/50'
                : 'bg-slate-950/60 border-white/10 hover:border-emerald-500/40 hover:bg-slate-900/60'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10.5px] font-bold text-slate-400 uppercase tracking-wider">คำสั่งซื้อ</span>
              <div className="w-6 h-6 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform">
                <ShoppingBag className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-base sm:text-lg font-bold text-white font-mono leading-none">{orders.length} <span className="text-xs font-normal text-slate-400">ออเดอร์</span></div>
            <div className="text-[11px] text-emerald-400 flex items-center gap-1 mt-1">
              <span>฿{orders.reduce((acc, o) => acc + (o.price || 0), 0).toLocaleString()}</span>
              <ArrowRight className="w-3 h-3 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          </button>

          {/* KPI 3: สลิปรอตรวจ */}
          <button
            type="button"
            onClick={() => { playClick(); setActiveTab('topups'); }}
            className={`p-3 sm:p-3.5 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden group min-h-[58px] ${
              pendingTopups.length > 0
                ? 'bg-rose-950/40 border-rose-500/80 shadow-sm shadow-rose-500/20'
                : activeTab === 'topups'
                ? 'bg-emerald-950/40 border-emerald-400 ring-1 ring-emerald-400/50'
                : 'bg-slate-950/60 border-white/10 hover:border-emerald-500/40 hover:bg-slate-900/60'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10.5px] font-bold text-slate-400 uppercase tracking-wider">สลิปรออนุมัติ</span>
              <div className={`w-6 h-6 rounded-lg flex items-center justify-center transition-transform group-hover:scale-105 ${
                pendingTopups.length > 0
                  ? 'bg-rose-500/20 border border-rose-500/50 text-rose-400 animate-bounce'
                  : 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400'
              }`}>
                <CreditCard className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-base sm:text-lg font-bold text-white font-mono leading-none flex items-center gap-1.5">
              {pendingTopups.length}
              {pendingTopups.length > 0 && (
                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-rose-500 text-white font-bold animate-pulse">
                  ด่วน
                </span>
              )}
            </div>
            <div className={`text-[11px] flex items-center gap-1 mt-1 ${pendingTopups.length > 0 ? 'text-rose-300 font-bold' : 'text-slate-400'}`}>
              <span>{pendingTopups.length > 0 ? 'ตรวจสลิปทันที' : 'ไม่มีสลิปค้าง'}</span>
              <ArrowRight className="w-3 h-3 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          </button>

          {/* KPI 4: จัดการ User */}
          <button
            type="button"
            onClick={() => { playClick(); setActiveTab('users'); }}
            className={`p-3 sm:p-3.5 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden group min-h-[58px] ${
              activeTab === 'users'
                ? 'bg-cyan-950/40 border-cyan-400 shadow-sm shadow-cyan-500/10 ring-1 ring-cyan-400/50'
                : 'bg-slate-950/60 border-white/10 hover:border-cyan-500/40 hover:bg-slate-900/60'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10.5px] font-bold text-slate-400 uppercase tracking-wider">สมาชิกทั้งหมด</span>
              <div className="w-6 h-6 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition-transform">
                <Users className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-base sm:text-lg font-bold text-white font-mono leading-none">{users.length} <span className="text-xs font-normal text-slate-400">คน</span></div>
            <div className="text-[11px] text-cyan-300 flex items-center gap-1.5 mt-1">
              <span>จัดการข้อมูลสมาชิก</span>
              <ArrowRight className="w-3 h-3 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          </button>
        </div>

        {/* Tab Contents Area */}
        <div className="min-h-[600px]">
        {/* ======================================================== */}
        {/* TAB 1: PRODUCTS & PACKAGES & PROMOTIONS MANAGEMENT */}
        {/* ======================================================== */}
        {activeTab === 'products' && (
        <div className="space-y-3 sm:space-y-4">
          {/* Controls bar: search & category pills */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-950/80 p-2 sm:p-3 rounded-2xl border border-white/10 shadow-md">
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none">
              <button
                type="button"
                onClick={() => setSelectedCatFilter('all')}
                className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-[13px] font-bold transition cursor-pointer whitespace-nowrap ${
                  selectedCatFilter === 'all'
                    ? 'bg-[color:var(--theme-accent)] text-slate-950 font-black shadow-md shadow-cyan-500/20'
                    : 'bg-slate-900/90 text-slate-300 hover:text-white border border-white/10 hover:border-cyan-500/30'
                }`}
              >
                ทั้งหมด ({products.length})
              </button>
              {viewCategories.map(c => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setSelectedCatFilter(c.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-[13px] font-bold transition cursor-pointer whitespace-nowrap ${
                    selectedCatFilter === c.id
                      ? 'bg-[color:var(--theme-accent)] text-slate-950 font-black shadow-md shadow-cyan-500/20'
                      : 'bg-slate-900/90 text-slate-300 hover:text-white border border-white/10 hover:border-cyan-500/30'
                  }`}
                >
                  {c.name} ({products.filter(p => p.categoryId === c.id).length})
                </button>
              ))}

              <button
                type="button"
                onClick={() => { playClick(); setActiveTab('categories'); }}
                className="w-8 h-8 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 flex items-center justify-center transition cursor-pointer whitespace-nowrap shrink-0 ml-1 shadow-sm"
                title="จัดลำดับหมวดหมู่สินค้า"
              >
                <ArrowUpDown className="w-4 h-4 text-cyan-400" />
              </button>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <div className="relative w-full sm:w-60">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="ค้นหาสินค้า..."
                  value={productSearch}
                  onChange={e => setProductSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900/90 border border-white/10 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                />
              </div>
              <button
                type="button"
                onClick={() => { playClick(); setShowAddProductModal(true); }}
                className="px-3.5 py-2 rounded-xl bg-[color:var(--theme-accent)] hover:bg-cyan-300 text-slate-950 font-black text-xs sm:text-[13px] flex items-center gap-1.5 transition shadow-md shadow-cyan-500/30 cursor-pointer whitespace-nowrap shrink-0"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>เพิ่มสินค้า</span>
              </button>
            </div>
          </div>

          {/* Quick Info & Action Bar */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs px-1 text-slate-400 gap-1.5">
            <div className="flex items-center gap-1.5">
              <span className="text-amber-400 text-sm">💡</span>
              <span className="text-xs sm:text-[13px] text-slate-300">
                <strong className="text-white">คลิกที่รูปภาพ หรือชื่อสินค้า</strong> เพื่อแก้ไขข้อมูล หรือกดปุ่ม <span className="text-cyan-400 font-bold bg-cyan-500/10 px-1.5 py-0.5 rounded border border-cyan-500/30 text-xs">[แก้ไข]</span> ทางด้านขวา
              </span>
            </div>
            <div className="text-xs text-slate-400">
              เปลี่ยนสถานะและหมวดหมู่ได้โดยตรงจากตาราง
            </div>
          </div>

          {/* Products Table */}
          <div className="overflow-x-auto rounded-2xl border border-white/10 bg-slate-950/80 shadow-lg">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-900/90 text-slate-300 uppercase tracking-wider text-xs font-bold border-b border-white/10">
                <tr>
                  <th className="py-3 px-3 text-center w-14 whitespace-nowrap">ลำดับ</th>
                  <th className="py-3 px-3.5 text-left min-w-[240px]">รูปภาพ & สินค้า</th>
                  <th className="py-3 px-3 text-center w-36 whitespace-nowrap">หมวดหมู่</th>
                  <th className="py-3 px-3 text-center w-36 whitespace-nowrap">สถานะ</th>
                  <th className="py-3 px-3 text-center w-32 whitespace-nowrap">โปรโมชั่น</th>
                  <th className="py-3 px-3 text-left min-w-[120px]">แพ็ก</th>
                  <th className="py-3 px-3 text-center w-32 whitespace-nowrap">
                    จัดการ
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {displayedCategories.map((cat, catIdx) => {
                  const catProducts = products
                    .filter(p => p.categoryId === cat.id)
                    .filter(p => {
                      if (!productSearch) return true;
                      const q = productSearch.toLowerCase();
                      return (
                        p.name.toLowerCase().includes(q) ||
                        p.shortDescription?.toLowerCase().includes(q) ||
                        p.categoryName?.toLowerCase().includes(q) ||
                        p.tags?.some(t => t.toLowerCase().includes(q))
                      );
                    });

                  if (catProducts.length === 0 && productSearch) {
                    return null;
                  }

                  return (
                    <React.Fragment key={cat.id}>
                      {/* --- CATEGORY DIVIDER HEADER --- */}
                      <tr className="bg-gradient-to-r from-cyan-950/60 via-slate-900 to-slate-950 border-y border-cyan-500/25">
                        <td colSpan={7} className="py-2.5 px-3.5">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-xs font-black text-cyan-400 bg-cyan-500/20 border border-cyan-500/40 rounded-lg px-2 py-0.5 shadow-sm">
                                {cat.badge || (catIdx + 1 < 10 ? `0${catIdx + 1}` : `${catIdx + 1}`)}
                              </span>
                              <span className="text-cyan-400/40 font-mono text-xs font-bold">───</span>
                              <h4 className="text-sm font-black text-white tracking-wide uppercase flex items-center gap-2">
                                {cat.image && (
                                  <div className="w-5 h-5 rounded-full overflow-hidden border border-cyan-400/50 shadow-sm shrink-0">
                                    {/* eslint-disable-next-line @next/next/no-img-element */}
                                    <img src={cat.image} alt={cat.name} className="w-full h-full object-cover rounded-full" />
                                  </div>
                                )}
                                <span>{cat.name}</span>
                              </h4>
                              <span className="text-cyan-400/40 font-mono text-xs font-bold">───</span>
                            </div>

                            <div className="flex items-center gap-2">
                              {!cat.isOrphan && (
                              <button
                                type="button"
                                onClick={() => {
                                  playClick();
                                  setNewProdCategory(cat.id);
                                  setShowAddProductModal(true);
                                }}
                                className="text-xs text-cyan-300 hover:text-white transition cursor-pointer flex items-center gap-1 bg-cyan-500/10 hover:bg-cyan-500/20 px-2.5 py-1 rounded-lg border border-cyan-500/30"
                                title={`เพิ่มสินค้าใหม่ในหมวดหมู่ ${cat.name}`}
                              >
                                <Plus className="w-3.5 h-3.5" />
                                <span className="hidden sm:inline">เพิ่มสินค้าในหมวด</span>
                              </button>
                              )}

                              <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/25 text-cyan-300 font-mono text-xs font-bold">
                                {catProducts.length} รายการ
                              </span>

                              {selectedCatFilter === 'all' ? (
                                <button
                                  type="button"
                                  onClick={() => setSelectedCatFilter(cat.id)}
                                  className="text-xs text-slate-400 hover:text-cyan-300 transition cursor-pointer underline underline-offset-2"
                                >
                                  กรองหมวดนี้
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => setSelectedCatFilter('all')}
                                  className="text-xs text-slate-400 hover:text-cyan-300 transition cursor-pointer underline underline-offset-2"
                                >
                                  ดูทั้งหมด
                                </button>
                              )}
                            </div>
                          </div>
                        </td>
                      </tr>

                      {/* Products in this category */}
                      {catProducts.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-4 text-center text-xs sm:text-sm text-slate-500 italic">
                            ยังไม่มีสินค้าในหมวดหมู่ {cat.name}
                          </td>
                        </tr>
                      ) : (
                        catProducts.map((p, pIdx) => {
                          const totalStock = p.packages.reduce((sum, pkg) => sum + pkg.stock, 0);
                          const minPrice = Math.min(...p.packages.map(pkg => pkg.price));
                          const maxPrice = Math.max(...p.packages.map(pkg => pkg.price));

                          return (
                            <tr key={p.id} className="hover:bg-white/[0.04] transition group/row">
                              {/* 1. ลำดับ */}
                              <td className="py-3 px-3 text-center">
                                <div className="flex items-center justify-center gap-1">
                                  <span className="font-mono text-xs sm:text-[13px] font-black text-cyan-400 bg-cyan-500/10 border border-cyan-500/25 rounded-md px-1.5 py-0.5 min-w-[28px] shadow-sm">
                                    #{pIdx + 1}
                                  </span>
                                  <div className="flex flex-col gap-0.5">
                                    <button
                                      type="button"
                                      onClick={() => moveProduct(p.id, 'up', cat.id)}
                                      disabled={pIdx === 0}
                                      className="p-1 rounded bg-slate-900 border border-white/5 hover:border-cyan-500/50 hover:bg-cyan-500/20 text-slate-400 hover:text-cyan-300 transition cursor-pointer disabled:opacity-20 disabled:cursor-not-allowed"
                                      title="ขยับขึ้น"
                                    >
                                      <ChevronUp className="w-3 h-3" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => moveProduct(p.id, 'down', cat.id)}
                                      disabled={pIdx === catProducts.length - 1}
                                      className="p-1 rounded bg-slate-900 border border-white/5 hover:border-cyan-500/50 hover:bg-cyan-500/20 text-slate-400 hover:text-cyan-300 transition cursor-pointer disabled:opacity-20 disabled:cursor-not-allowed"
                                      title="ขยับลง"
                                    >
                                      <ChevronDown className="w-3 h-3" />
                                    </button>
                                  </div>
                                </div>
                              </td>

                              {/* 2. รูปภาพ & สินค้า (Clickable to Edit) */}
                              <td className="py-3 px-3.5">
                                <div
                                  onClick={() => {
                                    playClick();
                                    setEditModalTab('info');
                                    setEditingProduct(JSON.parse(JSON.stringify(p)));
                                  }}
                                  className="flex items-center gap-3 cursor-pointer group/item select-none"
                                  title="คลิกเพื่อแก้ไขสินค้าและแพ็กเกจ"
                                >
                                  <div className="relative shrink-0">
                                    {/* eslint-disable-next-line @next/next/no-img-element */}
                                    <img
                                      src={p.image}
                                      alt={p.name}
                                      className="w-11 h-11 sm:w-12 sm:h-12 object-cover rounded-xl border border-white/10 group-hover/item:border-cyan-400 group-hover/item:scale-105 transition-all shadow-md"
                                      onError={(e) => {
                                        const target = e.currentTarget;
                                        if (!target.src.includes('46ebc6a271269458ec9b.webp')) {
                                          target.src = '/catalog/imported/46ebc6a271269458ec9b.webp';
                                        }
                                      }}
                                    />
                                    <div className="absolute inset-0 bg-cyan-500/30 rounded-xl opacity-0 group-hover/item:opacity-100 flex items-center justify-center transition-opacity">
                                      <Edit className="w-3.5 h-3.5 text-white drop-shadow" />
                                    </div>
                                  </div>
                                  <div className="min-w-0">
                                    <div className="flex items-center gap-1">
                                      <span className="font-bold text-white text-xs sm:text-[13.5px] group-hover/item:text-cyan-300 transition truncate block max-w-[220px] sm:max-w-[280px]">
                                        {p.name}
                                      </span>
                                    </div>
                                    <span className="text-[11px] sm:text-xs text-slate-400 truncate max-w-[220px] sm:max-w-[280px] block mt-0.5">
                                      {p.shortDescription || 'คลิกเพื่อแก้ไขคำอธิบาย'}
                                    </span>
                                  </div>
                                </div>
                              </td>

                              {/* 3. หมวดหมู่ (Inline Change) */}
                              <td className="py-3 px-3 text-center">
                                <div className="flex items-center justify-center">
                                  <select
                                    value={p.categoryId}
                                    onChange={(e) => {
                                      playClick();
                                      const newCatId = e.target.value;
                                      const catObj = categories.find(c => c.id === newCatId);
                                      updateProduct(p.id, { categoryId: newCatId, categoryName: catObj?.name || p.categoryName });
                                    }}
                                    className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-slate-300 text-xs cursor-pointer hover:border-cyan-500/40 focus:outline-none focus:border-cyan-400 transition"
                                    title="คลิกเพื่อเปลี่ยนหมวดหมู่สินค้านี้ทันที"
                                  >
                                    {categories.map(c => (
                                      <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                                        {c.name}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                              </td>

                              {/* 4. สถานะ (Inline 1-Click Status Dropdown) */}
                              <td className="py-3 px-3 text-center">
                                <div className="flex items-center justify-center">
                                  <select
                                    value={p.status}
                                    onChange={(e) => {
                                      playClick();
                                      updateProductStatus(p.id, e.target.value as any);
                                    }}
                                    className={`px-2.5 py-1.5 rounded-xl text-xs font-bold uppercase border cursor-pointer transition focus:outline-none focus:ring-1 focus:ring-cyan-400 ${
                                      p.status === 'ready'
                                        ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/25'
                                        : p.status === 'updating'
                                        ? 'bg-amber-500/15 text-amber-400 border-amber-500/30 hover:bg-amber-500/25'
                                        : 'bg-rose-500/15 text-rose-400 border-rose-500/30 hover:bg-rose-500/25'
                                    }`}
                                    title="คลิกเพื่อเปลี่ยนสถานะสินค้าทันที"
                                  >
                                    <option value="ready" className="bg-slate-900 text-emerald-400">🟢 พร้อมใช้งาน</option>
                                    <option value="updating" className="bg-slate-900 text-amber-400">🟡 กำลังอัพเดท</option>
                                    <option value="out_of_stock" className="bg-slate-900 text-rose-400">🔴 ปิดใช้งาน</option>
                                  </select>
                                </div>
                              </td>

                              {/* 5. โปรโมชั่น (Clickable Badge) */}
                              <td className="py-3 px-3 text-center">
                                <div className="flex items-center justify-center">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      playClick();
                                      setEditModalTab('info');
                                      setEditingProduct(JSON.parse(JSON.stringify(p)));
                                    }}
                                    className="cursor-pointer group/badge"
                                    title="คลิกเพื่อแก้ไขป้ายโปรโมชั่น"
                                  >
                                    {p.badge ? (
                                      <span className="px-2 py-0.5 rounded-md font-bold text-[11px] inline-flex items-center justify-center gap-1 bg-rose-500/20 text-rose-300 border border-rose-500/30 whitespace-nowrap group-hover/badge:border-rose-400 transition">
                                        <Flame className="w-3 h-3 text-rose-400" />
                                        {p.badge === 'สินค้าหมด' ? 'OUT OF STOCK' : p.badge}
                                      </span>
                                    ) : (
                                      <span className="text-slate-500 text-xs group-hover/badge:text-cyan-400 transition hover:underline">
                                        - ปกติ -
                                      </span>
                                    )}
                                  </button>
                                </div>
                              </td>

                              {/* 6. แพ็กเกจ & ราคา */}
                              <td className="py-3 px-3">
                                <div
                                  onClick={() => {
                                    playClick();
                                    setEditModalTab('packages');
                                    setEditingProduct(JSON.parse(JSON.stringify(p)));
                                  }}
                                  className="cursor-pointer group/pkg"
                                  title="คลิกเพื่อแก้ไขแพ็กเกจและราคา"
                                >
                                  <div className="font-mono font-bold text-cyan-400 text-xs sm:text-[13px] flex items-center gap-1 group-hover/pkg:text-cyan-300">
                                    <span>{minPrice === maxPrice ? `฿${minPrice}` : `฿${minPrice} - ฿${maxPrice}`}</span>
                                  </div>
                                  <div className="flex items-center gap-1 mt-0.5">
                                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                                      p.optionType === 'multiple' || p.packages.length > 1
                                        ? 'bg-purple-500/15 text-purple-300 border border-purple-500/30'
                                        : 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                                    }`}>
                                      {p.optionType === 'multiple' || p.packages.length > 1 ? `${p.packages.length} ตัวเลือก` : 'ตัวเลือกเดียว'}
                                    </span>
                                  </div>
                                </div>
                              </td>

                              {/* 7. จัดการ */}
                              <td className="py-3 px-3 text-center whitespace-nowrap w-32">
                                <div className="flex items-center justify-center gap-1.5 whitespace-nowrap">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      playClick();
                                      setEditModalTab('info');
                                      setEditingProduct(JSON.parse(JSON.stringify(p)));
                                    }}
                                    className="px-2.5 py-1 rounded-lg bg-cyan-500/15 hover:bg-cyan-500 text-cyan-300 hover:text-slate-950 border border-cyan-500/40 hover:border-cyan-300 transition-all font-bold text-xs flex items-center justify-center gap-1 shadow-sm cursor-pointer group"
                                    title="แก้ไขสินค้าและแพ็กเกจ"
                                  >
                                    <Edit className="w-3 h-3 group-hover:scale-110 transition-transform" />
                                    <span>แก้ไข</span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => {
                                      playClick();
                                      deleteProduct(p.id);
                                    }}
                                    className="p-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/30 hover:border-rose-400 transition cursor-pointer flex items-center justify-center shadow-sm"
                                    title="ลบสินค้าทันที"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 1.1: DIGITAL STOCK MANAGEMENT (จัดการสต็อก: คีย์, ลิงก์, ไฟล์) */}
      {/* ======================================================== */}
      {activeTab === 'stock' && (
        <div className="space-y-2.5">
          {/* 1. Quick Stock Summary KPI Cards (Comfortable 4 Cards) */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
            <div className="p-3 sm:p-3.5 rounded-xl bg-slate-950/60 border border-emerald-500/30 flex items-center justify-between shadow-sm min-h-[64px]">
              <div>
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">พร้อมส่งทั้งหมด</div>
                <div className="text-base sm:text-lg font-bold text-emerald-400 font-mono mt-0.5">{totalAvailStockCount} <span className="text-xs text-slate-400 font-normal">ชิ้น</span></div>
                <div className="text-[11px] text-emerald-400/80 mt-0.5">ส่งมอบทันทีเมื่อซื้อ</div>
              </div>
              <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>

            <div className="p-3 sm:p-3.5 rounded-xl bg-slate-950/60 border border-rose-500/30 flex items-center justify-between shadow-sm min-h-[64px]">
              <div>
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">ส่งมอบแล้ว (ขายแล้ว)</div>
                <div className="text-base sm:text-lg font-bold text-rose-400 font-mono mt-0.5">{totalSoldStockCount} <span className="text-xs text-slate-400 font-normal">ชิ้น</span></div>
                <div className="text-[11px] text-rose-400/80 mt-0.5">ถูกนำไปใช้งานเรียบร้อย</div>
              </div>
              <div className="w-7 h-7 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <XCircle className="w-4 h-4" />
              </div>
            </div>

            <div className={`p-3 sm:p-3.5 rounded-xl bg-slate-950/60 border flex items-center justify-between shadow-sm min-h-[64px] ${
              outOfStockPackagesCount > 0 ? 'border-amber-500/60 bg-amber-950/10' : 'border-white/10'
            }`}>
              <div>
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">แพ็กเกจที่สต็อกหมด</div>
                <div className="text-base sm:text-lg font-bold text-amber-400 font-mono flex items-center gap-1.5 mt-0.5">
                  {outOfStockPackagesCount} <span className="text-xs text-slate-400 font-normal">แพ็ก</span>
                  {outOfStockPackagesCount > 0 && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-400 font-bold border border-rose-500/30 animate-pulse">
                      ด่วน
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">ไม่มีของพร้อมส่ง</div>
              </div>
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <ShieldAlert className="w-4 h-4" />
              </div>
            </div>

            <div className="p-3 sm:p-3.5 rounded-xl bg-slate-950/60 border border-cyan-500/30 flex items-center justify-between shadow-sm min-h-[64px]">
              <div>
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">สินค้าทั้งหมด</div>
                <div className="text-base sm:text-lg font-bold text-cyan-400 font-mono mt-0.5">{products.length} <span className="text-xs text-slate-400 font-normal">รายการ</span></div>
                <div className="text-[11px] text-cyan-400/80 mt-0.5">รวมทุกหมวดหมู่</div>
              </div>
              <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Package className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* 2. Search & Category / Status Filters (Comfortable Bar) */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-950/80 p-2 sm:p-3 rounded-2xl border border-white/10 shadow-md">
            {/* Category Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none">
              <button
                type="button"
                onClick={() => setStockCatFilter('all')}
                className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-[13px] font-bold transition cursor-pointer whitespace-nowrap ${
                  stockCatFilter === 'all'
                    ? 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/20'
                    : 'bg-slate-900/90 text-slate-300 hover:text-white border border-white/10 hover:border-amber-500/30'
                }`}
              >
                ทุกหมวดหมู่ ({products.length})
              </button>
              {viewCategories.map(c => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setStockCatFilter(c.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-[13px] font-bold transition cursor-pointer whitespace-nowrap ${
                    stockCatFilter === c.id
                      ? 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/20'
                      : 'bg-slate-900/90 text-slate-300 hover:text-white border border-white/10 hover:border-amber-500/30'
                  }`}
                >
                  {c.name} ({products.filter(p => p.categoryId === c.id).length})
                </button>
              ))}
            </div>

            {/* Status Switcher & Search */}
            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              {/* Status Filter */}
              <div className="flex items-center bg-slate-900 border border-white/10 rounded-xl p-1 text-xs">
                <button
                  type="button"
                  onClick={() => setStockStatusFilter('all')}
                  className={`px-3 py-1 rounded-lg transition font-bold cursor-pointer ${
                    stockStatusFilter === 'all' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  ทั้งหมด
                </button>
                <button
                  type="button"
                  onClick={() => setStockStatusFilter('in_stock')}
                  className={`px-3 py-1 rounded-lg transition font-bold cursor-pointer ${
                    stockStatusFilter === 'in_stock' ? 'bg-emerald-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  พร้อมส่ง
                </button>
                <button
                  type="button"
                  onClick={() => setStockStatusFilter('out_of_stock')}
                  className={`px-3 py-1 rounded-lg transition font-bold cursor-pointer ${
                    stockStatusFilter === 'out_of_stock' ? 'bg-rose-500 text-white font-black' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  ของหมด
                </button>
              </div>

              {/* Search Input */}
              <div className="relative w-full sm:w-56">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="ค้นหาในคลัง..."
                  value={stockSearch}
                  onChange={e => setStockSearch(e.target.value)}
                  className="w-full pl-9 pr-7 py-2 bg-slate-900/90 border border-white/10 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
                {stockSearch && (
                  <button
                    type="button"
                    onClick={() => setStockSearch('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs cursor-pointer"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* 3. Product Stock Inventory Cards (Compact Density) */}
          <div className="space-y-3">
            {filteredStockProducts.length === 0 ? (
              <div className="p-8 text-center bg-slate-950/60 rounded-xl border border-white/5">
                <Package className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <h4 className="text-white font-bold text-xs mb-0.5">ไม่พบสินค้าตามเงื่อนไขที่เลือก</h4>
                <p className="text-[10px] text-slate-400 mb-3">ลองปรับตัวกรองหมวดหมู่ หรือคำค้นหาใหม่</p>
                <button
                  type="button"
                  onClick={() => {
                    setStockSearch('');
                    setStockCatFilter('all');
                    setStockStatusFilter('all');
                  }}
                  className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold cursor-pointer"
                >
                  ล้างการค้นหา
                </button>
              </div>
            ) : (
              viewCategories.map(cat => {
                const catProducts = filteredStockProducts.filter(p => p.categoryId === cat.id);
                if (catProducts.length === 0) return null;

                const totalCatAvail = catProducts.reduce((sum, p) => {
                  return sum + p.packages.reduce((acc, pkg) => {
                    const avail = pkg.stockItems ? pkg.stockItems.filter(s => !s.isUsed).length : pkg.stock;
                    return acc + (avail > 0 ? avail : 0);
                  }, 0);
                }, 0);

                return (
                  <div key={cat.id} className="space-y-2.5 bg-slate-950/60 p-3 sm:p-3.5 rounded-2xl border border-white/10 shadow-sm">
                    {/* Category Header Bar */}
                    <div className="flex items-center justify-between px-1 pb-1.5 border-b border-white/5">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_8px_#f59e0b]" />
                        <h3 className="text-xs sm:text-sm font-black text-white tracking-wide uppercase flex items-center gap-2">
                          <span>{cat.name}</span>
                          <span className="text-[10px] text-amber-300 font-bold font-mono bg-amber-500/15 px-2 py-0.5 rounded-full border border-amber-500/30">
                            {catProducts.length} สินค้า
                          </span>
                        </h3>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">
                        พร้อมส่งในหมวดหมู่นี้: <strong className="text-emerald-400 font-bold">{totalCatAvail} ชิ้น</strong>
                      </span>
                    </div>

                    {/* 2 Products per row (1 แถบ มี 2 สินค้า) */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                      {catProducts.map(prod => {
                        const prodAvail = prod.packages.reduce((acc, pkg) => {
                          const avail = pkg.stockItems ? pkg.stockItems.filter(s => !s.isUsed).length : pkg.stock;
                          return acc + (avail > 0 ? avail : 0);
                        }, 0);
                        const prodSold = prod.packages.reduce((acc, pkg) => {
                          const sold = pkg.stockItems ? pkg.stockItems.filter(s => s.isUsed).length : 0;
                          return acc + sold;
                        }, 0);
                        const hasOutOfStock = prod.packages.some(pkg => {
                          const avail = pkg.stockItems ? pkg.stockItems.filter(s => !s.isUsed).length : pkg.stock;
                          return avail <= 0 || !pkg.inStock;
                        });

                        return (
                          <div
                            key={prod.id}
                            className="bg-slate-900/80 border border-white/10 hover:border-amber-500/40 rounded-xl p-2.5 sm:p-3 transition shadow-md flex flex-col justify-between space-y-2.5"
                          >
                            {/* Product Header Row */}
                            <div className="flex items-center justify-between gap-2 pb-2 border-b border-white/5">
                              <div className="flex items-center gap-2.5 min-w-0">
                                <div className="w-9 h-9 rounded-lg overflow-hidden bg-slate-950 border border-white/10 shrink-0">
                                  {/* eslint-disable-next-line @next/next/no-img-element */}
                                  <img
                                    src={prod.image}
                                    alt={prod.name}
                                    className="w-full h-full object-cover"
                                    onError={(e) => {
                                      const target = e.currentTarget;
                                      if (!target.src.includes('46ebc6a271269458ec9b.webp')) {
                                        target.src = '/catalog/imported/46ebc6a271269458ec9b.webp';
                                      }
                                    }}
                                  />
                                </div>
                                <div className="min-w-0">
                                  <div className="flex items-center gap-1.5 flex-wrap">
                                    <span className="text-[9px] px-1.5 py-0.2 rounded-full font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 truncate max-w-[120px]">
                                      {cat.name}
                                    </span>
                                    {prodAvail > 0 ? (
                                      hasOutOfStock ? (
                                        <span className="text-[9px] px-1.5 py-0.2 rounded-full font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                                          บางแพ็กหมด
                                        </span>
                                      ) : (
                                        <span className="text-[9px] px-1.5 py-0.2 rounded-full font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                                          พร้อมส่ง
                                        </span>
                                      )
                                    ) : (
                                      <span className="text-[9px] px-1.5 py-0.2 rounded-full font-bold bg-rose-500/20 text-rose-400 border border-rose-500/40 animate-pulse">
                                        สต็อกหมด
                                      </span>
                                    )}
                                  </div>
                                  <h4 className="text-xs font-black text-white mt-0.5 truncate">{prod.name}</h4>
                                  <div className="text-[10px] text-slate-400 font-mono">
                                    {prod.packages.length} แพ็ก · พร้อมส่ง <strong className={prodAvail > 0 ? 'text-emerald-400' : 'text-rose-400'}>{prodAvail} ชิ้น</strong> · ขาย {prodSold} ชิ้น
                                  </div>
                                </div>
                              </div>

                              {/* Direct Stock Action & Delete Buttons */}
                              <div className="flex items-center gap-1.5 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => openStockManager(prod)}
                                  className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[10.5px] flex items-center gap-1 transition shadow-sm shadow-amber-500/20 cursor-pointer"
                                >
                                  <Key className="w-3 h-3" />
                                  <span>จัดการคลังสินค้านี้</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    playClick();
                                    deleteProduct(prod.id);
                                  }}
                                  className="p-1 rounded-lg bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white border border-rose-500/25 hover:border-rose-400 transition cursor-pointer"
                                  title="ลบสินค้านี้ทันที (ไม่ต้องถาม)"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </div>

                            {/* Packages Stock Breakdown Grid */}
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                              {prod.packages.map(pkg => {
                                const stockItems = pkg.stockItems || [];
                                const availItems = stockItems.filter(s => !s.isUsed);
                                const soldItems = stockItems.filter(s => s.isUsed);
                                const availCount = stockItems.length > 0 ? availItems.length : pkg.stock;
                                const hasDownloadUrl = !!(prod.downloadUrl || (stockItems.some(s => s.downloadUrl)));

                                return (
                                  <div
                                    key={pkg.id}
                                    className={`p-2 rounded-lg border transition flex flex-col justify-between ${
                                      availCount <= 0 || !pkg.inStock
                                        ? 'bg-rose-950/20 border-rose-500/30'
                                        : 'bg-slate-950/70 border-white/5 hover:border-cyan-500/30'
                                    }`}
                                  >
                                    <div>
                                      <div className="flex items-center justify-between">
                                        <span className="font-bold text-white text-[11px] truncate">{pkg.duration}</span>
                                        <span className="font-mono text-cyan-400 text-[11px] font-bold">฿{pkg.price}</span>
                                      </div>

                                      <div className="mt-0.5 flex items-baseline justify-between">
                                        <div className="text-[8.5px] text-slate-400">สถานะสต็อก:</div>
                                        <div className={`font-mono text-[11px] font-black ${
                                          availCount > 0 ? 'text-emerald-400' : 'text-rose-400'
                                        }`}>
                                          {availCount > 0 ? `${availCount} ชิ้น` : 'ของหมด (0)'}
                                        </div>
                                      </div>

                                      {/* Items Breakdown */}
                                      <div className="mt-1 pt-1 border-t border-white/5 space-y-0.5 text-[9px] text-slate-400">
                                        <div className="flex items-center justify-between">
                                          <span className="flex items-center gap-1">
                                            <Key className="w-2.5 h-2.5 text-amber-400" />
                                            <span>คีย์</span>
                                          </span>
                                          <span className="font-mono text-slate-300 font-bold">
                                            {stockItems.length > 0
                                              ? `${stockItems.length} (ขาย ${soldItems.length})`
                                              : `${pkg.stock} พร้อมส่ง`}
                                          </span>
                                        </div>

                                        <div className="flex items-center justify-between">
                                          <span className="flex items-center gap-1">
                                            <Download className="w-2.5 h-2.5 text-cyan-400" />
                                            <span>ลิงก์โหลด</span>
                                          </span>
                                          <span className={`font-mono ${hasDownloadUrl ? 'text-emerald-400' : 'text-slate-500'}`}>
                                            {hasDownloadUrl ? 'มีลิงก์' : 'ค่าเริ่มต้น'}
                                          </span>
                                        </div>
                                      </div>
                                    </div>

                                    {/* Button group for this package */}
                                    <div className="mt-1.5 pt-1 border-t border-white/5 flex items-center gap-1">
                                      <button
                                        type="button"
                                        onClick={() => openStockManager(prod, pkg.id)}
                                        className="flex-1 py-1 px-1.5 rounded bg-amber-500/15 hover:bg-amber-500 text-amber-300 hover:text-slate-950 border border-amber-500/30 text-[9.5px] font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                                        title={`จัดการคลังสต็อกของ ${pkg.name}`}
                                      >
                                        <Key className="w-2.5 h-2.5" />
                                        <span>คลัง ({availCount})</span>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          playClick();
                                          const randKey = 'ARX-' + Math.random().toString(36).substring(2, 6).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase();
                                          addStockItem(prod.id, pkg.id, {
                                            key: randKey,
                                            downloadUrl: prod.downloadUrl,
                                            fileName: prod.name.replace(/\s+/g, '_') + '.zip',
                                            note: 'สุ่มเพิ่มด่วน'
                                          });
                                          playSuccess();
                                        }}
                                        className="py-1 px-1.5 rounded bg-emerald-500/15 hover:bg-emerald-500 text-emerald-300 hover:text-slate-950 border border-emerald-500/30 text-[9.5px] font-bold transition flex items-center gap-0.5 cursor-pointer shrink-0"
                                        title="กดเพื่อสุ่มสร้างและเติม 1 คีย์เข้าสต็อกทันที"
                                      >
                                        <Zap className="w-2.5 h-2.5" />
                                        <span>+1</span>
                                      </button>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* 4. Automatic System Notice (Compact) */}
          <div className="p-2 sm:p-2.5 rounded-xl bg-cyan-950/20 border border-cyan-500/20 flex items-start gap-2 text-[10.5px] text-slate-300">
            <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <p className="font-bold text-cyan-300">
                ระบบเบิกจ่ายคลังสต็อกอัตโนมัติ 24 ชั่วโมง:
              </p>
              <p className="text-slate-400 leading-relaxed text-[10px]">
                เมื่อมีลูกค้าทำการสั่งซื้อสินค้าและตัดยอดเงินสำเร็จ ระบบจะค้นหาและดึงไอเทมในคลังที่ยังไม่ถูกใช้งาน (`!isUsed`) ออกมา 1 ชิ้น พร้อมส่งมอบ License Key, ลิงก์ดาวน์โหลด และรหัสผ่าน/บันทึก ให้กับลูกค้าโดยอัตโนมัติทันที
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 1.5: CATEGORIES MANAGEMENT & REORDERING */}
      {/* ======================================================== */}
      {activeTab === 'categories' && (
        <div className="space-y-2.5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-950/80 p-2 sm:p-2.5 rounded-xl border border-white/10 shadow-sm">
            <div>
              <div className="flex items-center gap-1.5 mb-0.5">
                <span className="px-1.5 py-0.2 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-mono text-[9px] font-bold uppercase tracking-wider">
                  REAL-TIME CATEGORY REORDERING
                </span>
                <span className="flex items-center gap-1 text-[10px] text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  บันทึกอัตโนมัติ
                </span>
              </div>
              <h2 className="text-xs font-black text-white tracking-tight flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                <span>จัดการและจัดลำดับหมวดหมู่สินค้า</span>
              </h2>
              <p className="text-[10.5px] text-slate-400 mt-0.5 leading-relaxed">
                คลิกปุ่ม <strong className="text-cyan-300">ขึ้น / ลง</strong> เพื่อสลับลำดับหมวดหมู่ โดยจะแสดงผลเป็น Grid บนหน้าแรกแบบสด
              </p>
            </div>

            <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
              <button
                type="button"
                onClick={() => {
                  playClick();
                  const nextNum = categories.length + 1;
                  setEditingCategory({
                    id: `cat-${Date.now()}`,
                    name: 'หมวดหมู่ใหม่',
                    slug: `category-${Date.now()}`,
                    description: '',
                    image: '/catalog/imported/banner_fivem.webp',
                    linkUrl: '',
                    badge: (nextNum < 10 ? '0' : '') + nextNum
                  });
                }}
                className="px-2.5 py-1 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold flex items-center gap-1 transition cursor-pointer shadow-sm"
                title="สร้างหมวดหมู่สินค้าใหม่"
              >
                <Plus className="w-3 h-3" />
                <span>เพิ่มหมวดหมู่</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  playClick();
                  if (confirm('ต้องการรีเซ็ตสินค้าและหมวดหมู่กลับสู่ค่าเริ่มต้นทั้งหมดหรือไม่?')) {
                    restoreDefaultCatalog();
                  }
                }}
                className="px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-bold flex items-center gap-1 transition cursor-pointer"
                title="รีเซ็ตสินค้าและหมวดหมู่กลับสู่ค่าตั้งต้น"
              >
                <RefreshCw className="w-3 h-3" />
                <span>คืนค่าเริ่มต้น</span>
              </button>

              <Link
                href="/#categories"
                target="_blank"
                className="px-2.5 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[11px] font-bold flex items-center gap-1 transition cursor-pointer"
              >
                <ExternalLink className="w-3 h-3" />
                <span>ดูหน้าแรกแบบสด</span>
              </Link>
            </div>
          </div>

          {/* Live Preview Scheme Banner */}
          <div className="rounded-xl p-2.5 border border-cyan-500/20 bg-slate-950/60">
            <div className="flex items-center justify-between text-[10.5px] text-slate-400 mb-2 font-mono font-bold">
              <span className="flex items-center gap-1 text-cyan-400">
                <Sparkles className="w-3 h-3" />
                ผังจำลองการแสดงผลบนหน้าแรก (Homepage Banner Layout Preview)
              </span>
              <span>{categories.length} หมวดหมู่ที่ใช้งาน</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {categories.map((cat, idx) => (
                <div
                  key={cat.id}
                  className={`rounded-lg border p-2 flex items-center justify-between relative overflow-hidden ${
                    idx === 0
                      ? 'border-cyan-500/30 bg-cyan-950/20'
                      : idx === 1
                      ? 'border-blue-500/30 bg-blue-950/20'
                      : 'border-indigo-500/30 bg-indigo-950/20'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-black text-cyan-400 px-1.5 py-0.2 rounded bg-cyan-500/10 border border-cyan-500/20">
                      {cat.badge || (idx + 1 < 10 ? `0${idx + 1}` : `${idx + 1}`)}
                    </span>
                    <div>
                      <span className="text-[9px] text-cyan-400/80 font-bold block uppercase">
                        {idx === 0
                          ? 'แถวบนซ้าย (Top Left)'
                          : idx === 1
                          ? 'แถวบนขวา (Top Right)'
                          : idx === 2
                          ? 'แถวล่างซ้าย (Setting Product)'
                          : `ตำแหน่งที่ ${idx + 1}`}
                      </span>
                      <span className="text-xs font-bold text-white">{cat.name}</span>
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {products.filter(p => p.categoryId === cat.id).length} สินค้า
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Categories Reorder Table / List (Compact) */}
          <div className="overflow-x-auto rounded-xl border border-white/10 bg-slate-950/80 shadow-md">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/90 text-slate-400 uppercase tracking-wider text-[10px] border-b border-white/10">
                <tr>
                  <th className="py-2 px-2 text-center w-20 whitespace-nowrap">ลำดับ</th>
                  <th className="py-2 px-2.5">ชื่อหมวดหมู่ & รายละเอียด</th>
                  <th className="py-2 px-2 text-center whitespace-nowrap">ตำแหน่งหน้าแรก</th>
                  <th className="py-2 px-2 text-center whitespace-nowrap">จำนวนสินค้า</th>
                  <th className="py-2 px-2 text-center w-28 whitespace-nowrap">ขยับตำแหน่ง</th>
                  <th className="py-2 px-2 text-right whitespace-nowrap">แก้ไข</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {categories.map((cat, cIdx) => {
                  const catProducts = products.filter(p => p.categoryId === cat.id);
                  const isTopLeft = cIdx === 0;
                  const isTopRight = cIdx === 1;

                  return (
                    <tr key={cat.id} className="hover:bg-white/[0.02] transition">
                      <td className="py-1.5 px-2 text-center">
                        <div className="flex items-center justify-center">
                          <span className="font-mono text-xs font-black text-cyan-400 bg-cyan-500/15 border border-cyan-500/30 rounded px-1.5 py-0.5 min-w-[26px] shadow-sm">
                            {cat.badge || (cIdx + 1 < 10 ? `0${cIdx + 1}` : `${cIdx + 1}`)}
                          </span>
                        </div>
                      </td>

                      <td className="py-1.5 px-2.5">
                        <div className="flex items-center gap-2">
                          {/* Category Image Thumbnail as Circle (Matching Image 1 & 2) */}
                          <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-900 border border-cyan-500/40 shrink-0 relative shadow-md ring-1 ring-cyan-500/20 flex items-center justify-center">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img
                              src={
                                cat.image ||
                                (cat.id === 'cat-fivem'
                                  ? '/catalog/imported/banner_fivem.webp'
                                  : cat.id === 'cat-cheat'
                                  ? '/catalog/imported/banner_cheat.webp'
                                  : '/catalog/imported/banner_customos.webp')
                              }
                              alt={cat.name}
                              className="w-full h-full object-cover rounded-full"
                              onError={(e) => {
                                const target = e.currentTarget;
                                if (!target.src.includes('banner_fivem.webp')) {
                                  target.src = '/catalog/imported/banner_fivem.webp';
                                }
                              }}
                            />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-white text-xs">{cat.name}</span>
                              <span className="text-[9px] font-mono text-slate-500">ID: {cat.id}</span>
                            </div>
                            <p className="text-[10px] text-slate-400 line-clamp-1">
                              {cat.description || 'ไม่มีคำอธิบายเพิ่มเติม'}
                            </p>
                          </div>
                        </div>
                      </td>

                      <td className="py-1.5 px-2 text-center whitespace-nowrap">
                        <span className={`px-2 py-0.2 rounded-full text-[9px] font-bold border ${
                          isTopLeft
                            ? 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30'
                            : isTopRight
                            ? 'bg-blue-500/10 text-blue-300 border-blue-500/30'
                            : 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30'
                        }`}>
                          {isTopLeft
                            ? 'บนซ้าย (01)'
                            : isTopRight
                            ? 'บนขวา (02)'
                            : cIdx === 2
                            ? 'ล่างซ้าย (03)'
                            : `ตำแหน่งที่ ${cIdx + 1}`}
                        </span>
                      </td>

                      <td className="py-1.5 px-2 text-center whitespace-nowrap">
                        <span className="font-mono font-bold text-white bg-slate-900 px-2 py-0.5 rounded text-[11px] border border-white/5">
                          {catProducts.length} รายการ
                        </span>
                      </td>

                      <td className="py-1.5 px-2 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            type="button"
                            onClick={() => moveCategory(cat.id, 'up')}
                            disabled={cIdx === 0}
                            className="px-2 py-0.5 rounded bg-slate-900 border border-white/10 hover:border-cyan-400 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-300 font-bold text-[10px] flex items-center gap-0.5 transition cursor-pointer disabled:opacity-20 disabled:cursor-not-allowed shadow-sm"
                            title="เลื่อนหมวดหมู่นี้ขึ้น"
                          >
                            <ChevronUp className="w-3 h-3" />
                            <span>ขึ้น</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => moveCategory(cat.id, 'down')}
                            disabled={cIdx === categories.length - 1}
                            className="px-2 py-0.5 rounded bg-slate-900 border border-white/10 hover:border-cyan-400 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-300 font-bold text-[10px] flex items-center gap-0.5 transition cursor-pointer disabled:opacity-20 disabled:cursor-not-allowed shadow-sm"
                            title="เลื่อนหมวดหมู่นี้ลง"
                          >
                            <ChevronDown className="w-3 h-3" />
                            <span>ลง</span>
                          </button>
                        </div>
                      </td>

                      <td className="py-1.5 px-2 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              playClick();
                              const fallbackImg =
                                cat.image ||
                                (cat.id === 'cat-fivem'
                                  ? '/catalog/imported/banner_fivem.webp'
                                  : cat.id === 'cat-cheat'
                                  ? '/catalog/imported/banner_cheat.webp'
                                  : '/catalog/imported/banner_customos.webp');
                              const fallbackLink = cat.linkUrl || `/store?category=${cat.id}#products-catalog`;
                              setEditingCategory({
                                ...cat,
                                image: fallbackImg,
                                linkUrl: fallbackLink
                              });
                            }}
                            className="px-2.5 py-0.5 rounded-md bg-cyan-500/15 hover:bg-cyan-500 text-cyan-300 hover:text-slate-950 text-[10.5px] font-bold transition flex items-center gap-1 cursor-pointer"
                          >
                            <Edit className="w-2.5 h-2.5" />
                            <span>แก้ไข</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              playClick();
                              if (confirm(`คุณต้องการลบหมวดหมู่ "${cat.name}" หรือไม่? (รายการจะถูกลบถาวรและไม่กลับมาเมื่อรีเฟรช)`)) {
                                deleteCategory(cat.id);
                              }
                            }}
                            className="p-1 rounded-md bg-rose-500/15 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/30 hover:border-rose-400 transition cursor-pointer flex items-center justify-center shadow-sm"
                            title="ลบหมวดหมู่นี้"
                          >
                            <Trash2 className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 3: SITE STATS CONTROLLER (ปลอมยอด / กำหนดสถิติ) */}
      {/* ======================================================== */}
      {activeTab === 'stats' && (
        <div className="max-w-3xl space-y-2.5">
          <div className="bg-slate-950/80 p-3 sm:p-3.5 rounded-xl border border-cyan-500/25 space-y-2.5 shadow-md">
            <div>
              <span className="text-[9.5px] font-mono font-bold text-cyan-400 tracking-wider uppercase flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-cyan-400" />
                SITE STATISTICS & METRICS CONTROLLER
              </span>
              <h2 className="text-xs font-black text-white mt-0.5">
                กำหนดตัวเลขสถิติหน้าเว็บ (ระบบปลอมยอด / ตั้งค่ายอดอิสระ)
              </h2>
              <p className="text-[10px] text-slate-400 mt-0.5">
                ระบุตัวเลขสถิติได้ตามต้องการ จะไปแสดงผลบนแผงสถิติ 4 ช่องในหน้าหลักทันทีแบบ Real-time
              </p>
            </div>

            {/* Mode Selector (Compact) */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2 rounded-xl bg-slate-900/90 border border-cyan-500/30 shadow-sm">
              <div className="space-y-0.5">
                <div className="text-[11px] font-black text-white flex items-center gap-1">
                  <Sliders className="w-3 h-3 text-cyan-400" />
                  <span>โหมดสถิติ:</span>
                </div>
                <p className="text-[9.5px] text-slate-400">
                  {statsForm.mode === 'boost'
                    ? 'โหมดบวกเพิ่ม (+ Boost): ยอดจริง + ตัวเลขที่กรอก'
                    : 'โหมดกำหนดตัวเลขตรงๆ (Direct): แสดงผลตามเลขที่กรอก 100%'}
                </p>
              </div>

              <div className="flex items-center gap-1 p-0.5 bg-black/60 rounded-lg border border-white/10 shrink-0">
                <button
                  type="button"
                  onClick={() => handleStatsFieldChange('mode', 'direct')}
                  className={`px-2.5 py-1 rounded-md text-[10.5px] font-bold transition flex items-center gap-1 cursor-pointer ${
                    statsForm.mode !== 'boost'
                      ? 'bg-cyan-500 text-slate-950 shadow-sm font-black'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-2.5 h-2.5" />
                  <span>กำหนดตรงๆ (แนะนำ)</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleStatsFieldChange('mode', 'boost')}
                  className={`px-2.5 py-1 rounded-md text-[10.5px] font-bold transition flex items-center gap-1 cursor-pointer ${
                    statsForm.mode === 'boost'
                      ? 'bg-amber-400 text-slate-950 shadow-sm font-black'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span>+ บวกเพิ่ม</span>
                </button>
              </div>
            </div>

            {/* Auto-Save Notice Banner */}
            {statsSavedNotice && (
              <div className="p-2 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-[10.5px] font-bold flex items-center justify-between gap-1.5">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>{statsSavedNotice}</span>
                </span>
                <span className="text-[9px] text-emerald-400/80 font-mono bg-emerald-900/50 px-1.5 py-0.2 rounded border border-emerald-500/30">
                  ⚡ ซิงค์เรียลไทม์
                </span>
              </div>
            )}

            {/* Quick Presets */}
            <div className="flex flex-wrap items-center gap-1.5 p-2 bg-white/[0.02] rounded-xl border border-white/5 text-[10px]">
              <span className="text-slate-400 font-bold">ทางลัด:</span>
              <button
                type="button"
                onClick={() => {
                  playClick();
                  const zeroStats: SiteStats = {
                    users: 0,
                    topup: 0,
                    stock: 0,
                    sales: 0,
                    isCustom: false,
                    mode: 'direct'
                  };
                  setStatsForm(zeroStats);
                  updateSiteStats(zeroStats);
                  setStatsSavedNotice('✓ รีเซ็ตสถิติแสดงเฉพาะยอดจริง 100% เรียบร้อย');
                }}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-bold transition cursor-pointer"
              >
                🔄 ยอดจริง 100%
              </button>

              <button
                type="button"
                onClick={() => {
                  playClick();
                  const demoStats: SiteStats = {
                    users: statsForm.mode === 'boost' ? 631 : 634,
                    topup: statsForm.mode === 'boost' ? 56291.86 : 56291.86,
                    stock: statsForm.mode === 'boost' ? 162 : 172,
                    sales: statsForm.mode === 'boost' ? 368 : 369,
                    isCustom: true,
                    mode: statsForm.mode
                  };
                  setStatsForm(demoStats);
                  updateSiteStats(demoStats);
                  setStatsSavedNotice('✓ ตั้งค่าเป็นสถิติเริ่มต้นร้านค้าแล้ว');
                }}
                className="px-2 py-0.5 rounded bg-cyan-500/20 hover:bg-cyan-500 text-cyan-200 hover:text-slate-950 text-[10px] font-bold transition cursor-pointer"
              >
                ✨ สถิติเริ่มต้น (634, 56.2K, 172, 369)
              </button>

              <button
                type="button"
                onClick={() => {
                  playClick();
                  const highStats: SiteStats = {
                    users: 1000,
                    topup: 100000,
                    stock: 500,
                    sales: 1000,
                    isCustom: true,
                    mode: statsForm.mode
                  };
                  setStatsForm(highStats);
                  updateSiteStats(highStats);
                  setStatsSavedNotice('✓ ตั้งค่าเป็นสถิติหลักพันแล้ว');
                }}
                className="px-2 py-0.5 rounded bg-amber-500/20 hover:bg-amber-500 text-amber-200 hover:text-slate-950 text-[10px] font-bold transition cursor-pointer"
              >
                🚀 สถิติหลักพัน (1K, 100K, 500, 1K)
              </button>
            </div>

            {/* Inputs Grid (Compact) */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSaveStatsForm();
              }}
              className="space-y-2.5"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {/* 1. Users Count */}
                <div className="p-3 rounded-xl bg-slate-900 border border-white/10 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-200">
                    <span className="flex items-center gap-1.5"><Users className="w-4 h-4 text-cyan-400" /> 1. ผู้ใช้งาน (Users)</span>
                    <span className="text-slate-400 text-xs">คน</span>
                  </div>

                  {/* Real vs Display Badges */}
                  <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950/80 border border-white/5 text-xs">
                    <span className="text-slate-400">
                      จริง: <strong className="text-white font-mono">{realStats.users.toLocaleString()}</strong>
                    </span>
                    <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                      <span>โชว์:</span>
                      <strong className="font-mono text-sm font-black bg-emerald-950/70 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/40 shadow-sm">
                        {(statsForm.mode === 'boost' ? (realStats.users + (statsForm.users || 0)) : (statsForm.users || 0)).toLocaleString()} คน
                      </strong>
                    </span>
                  </div>

                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      value={statsForm.users}
                      onChange={e => handleStatsFieldChange('users', parseInt(e.target.value) || 0)}
                      onBlur={() => handleStatsFieldChange('users', statsForm.users)}
                      className="w-full px-3 py-2 rounded-lg bg-black/60 border border-slate-700 text-amber-300 font-mono text-base font-black focus:outline-none focus:border-cyan-400 pl-8"
                      placeholder="0"
                    />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-cyan-400 font-mono font-bold text-sm">
                      {statsForm.mode === 'boost' ? '+' : '#'}
                    </span>
                  </div>
                </div>

                {/* 2. Total Topup */}
                <div className="p-3 rounded-xl bg-slate-900 border border-white/10 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-200">
                    <span className="flex items-center gap-1.5"><DollarSign className="w-4 h-4 text-blue-400" /> 2. ยอดเติม (Total Topup)</span>
                    <span className="text-slate-400 text-xs">บาท</span>
                  </div>

                  {/* Real vs Display Badges */}
                  <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950/80 border border-white/5 text-xs">
                    <span className="text-slate-400">
                      จริง: <strong className="text-white font-mono">฿{realStats.topup.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                    </span>
                    <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                      <span>โชว์:</span>
                      <strong className="font-mono text-sm font-black bg-emerald-950/70 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/40 shadow-sm">
                        ฿{(statsForm.mode === 'boost' ? (realStats.topup + (statsForm.topup || 0)) : (statsForm.topup || 0)).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </strong>
                    </span>
                  </div>

                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={statsForm.topup}
                      onChange={e => handleStatsFieldChange('topup', parseFloat(e.target.value) || 0)}
                      onBlur={() => handleStatsFieldChange('topup', statsForm.topup)}
                      className="w-full px-3 py-2 rounded-lg bg-black/60 border border-slate-700 text-amber-300 font-mono text-base font-black focus:outline-none focus:border-cyan-400 pl-8"
                      placeholder="0"
                    />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-cyan-400 font-mono font-bold text-sm">
                      {statsForm.mode === 'boost' ? '+' : '฿'}
                    </span>
                  </div>
                </div>

                {/* 3. Total Stock */}
                <div className="p-3 rounded-xl bg-slate-900 border border-white/10 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-200">
                    <span className="flex items-center gap-1.5"><Package className="w-4 h-4 text-indigo-400" /> 3. สต็อก (Stock)</span>
                    <span className="text-slate-400 text-xs">ชิ้น</span>
                  </div>

                  {/* Real vs Display Badges */}
                  <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950/80 border border-white/5 text-xs">
                    <span className="text-slate-400">
                      จริง: <strong className="text-white font-mono">{realStats.stock.toLocaleString()} ชิ้น</strong>
                    </span>
                    <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                      <span>โชว์:</span>
                      <strong className="font-mono text-sm font-black bg-emerald-950/70 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/40 shadow-sm">
                        {(statsForm.mode === 'boost' ? (realStats.stock + (statsForm.stock || 0)) : (statsForm.stock || 0)).toLocaleString()} ชิ้น
                      </strong>
                    </span>
                  </div>

                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      value={statsForm.stock}
                      onChange={e => handleStatsFieldChange('stock', parseInt(e.target.value) || 0)}
                      onBlur={() => handleStatsFieldChange('stock', statsForm.stock)}
                      className="w-full px-3 py-2 rounded-lg bg-black/60 border border-slate-700 text-amber-300 font-mono text-base font-black focus:outline-none focus:border-cyan-400 pl-8"
                      placeholder="0"
                    />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-cyan-400 font-mono font-bold text-sm">
                      {statsForm.mode === 'boost' ? '+' : '#'}
                    </span>
                  </div>
                </div>

                {/* 4. Total Sales */}
                <div className="p-3 rounded-xl bg-slate-900 border border-white/10 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-200">
                    <span className="flex items-center gap-1.5"><ShoppingBag className="w-4 h-4 text-emerald-400" /> 4. ยอดขาย (Total Sales)</span>
                    <span className="text-slate-400 text-xs">ครั้ง</span>
                  </div>

                  {/* Real vs Display Badges */}
                  <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950/80 border border-white/5 text-xs">
                    <span className="text-slate-400">
                      จริง: <strong className="text-white font-mono">{realStats.sales.toLocaleString()} ครั้ง</strong>
                    </span>
                    <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                      <span>โชว์:</span>
                      <strong className="font-mono text-sm font-black bg-emerald-950/70 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/40 shadow-sm">
                        {(statsForm.mode === 'boost' ? (realStats.sales + (statsForm.sales || 0)) : (statsForm.sales || 0)).toLocaleString()} ครั้ง
                      </strong>
                    </span>
                  </div>

                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      value={statsForm.sales}
                      onChange={e => handleStatsFieldChange('sales', parseInt(e.target.value) || 0)}
                      onBlur={() => handleStatsFieldChange('sales', statsForm.sales)}
                      className="w-full px-3 py-2 rounded-lg bg-black/60 border border-slate-700 text-amber-300 font-mono text-base font-black focus:outline-none focus:border-cyan-400 pl-8"
                      placeholder="0"
                    />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-cyan-400 font-mono font-bold text-sm">
                      {statsForm.mode === 'boost' ? '+' : '#'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Submit Save Button */}
              <button
                type="submit"
                className="w-full py-2.5 rounded-lg bg-[color:var(--theme-accent)] hover:bg-cyan-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-cyan-500/20 cursor-pointer transition-all"
              >
                <Save className="w-4 h-4" />
                <span>บันทึกตัวเลขสถิติ (อัปเดต Real-time ทันที)</span>
              </button>
            </form>
          </div>

          {/* Real Registered Users Card & Auto-Save Status */}
          <div className="rounded-xl p-3 bg-slate-950/80 border border-cyan-500/20 shadow-sm space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-white/5">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/20">
                  <Users className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>รายชื่อบัญชีผู้ใช้งานจริงในระบบ</span>
                    <span className="px-1.5 py-0.2 rounded-full text-[9px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold">
                      {users.length} บัญชี
                    </span>
                  </h3>
                </div>
              </div>

              <div className="flex items-center gap-1 text-[9px] text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-2 py-0.5 rounded">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block" />
                <span className="font-semibold">Auto-Save Persistent</span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-[11px]">
                <thead>
                  <tr className="border-b border-white/10 text-slate-400 text-[10px]">
                    <th className="pb-1.5 font-semibold">ชื่อผู้ใช้</th>
                    <th className="pb-1.5 font-semibold">ระดับ</th>
                    <th className="pb-1.5 font-semibold text-right">ยอดคงเหลือ</th>
                    <th className="pb-1.5 font-semibold text-right">ยอดใช้จ่ายรวม</th>
                    <th className="pb-1.5 font-semibold text-right">วันที่สมัคร</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-300">
                  {users.map((u) => {
                    const isAdmin = u.role === 'admin';
                    const isCurrent = user?.id === u.id || user?.username.toLowerCase() === u.username.toLowerCase();

                    return (
                      <tr key={u.id} className={`hover:bg-white/[0.02] transition ${isCurrent ? 'bg-cyan-500/[0.04]' : ''}`}>
                        <td className="py-1.5">
                          <div className="flex items-center gap-1.5">
                            <div className={`w-5 h-5 rounded flex items-center justify-center text-[10px] font-bold ${
                              isAdmin 
                                ? 'bg-gradient-to-tr from-amber-500 to-orange-600 text-slate-950' 
                                : 'bg-gradient-to-tr from-cyan-500 to-blue-600 text-slate-950'
                            }`}>
                              {u.username.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div className="flex items-center gap-1 font-semibold text-white text-[11px]">
                                <span>{u.username}</span>
                                {isCurrent && (
                                   <span className="text-[8.5px] px-1 py-0.2 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                                     คุณ
                                   </span>
                                )}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="py-1.5">
                          {isAdmin ? (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                              Admin
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-medium bg-slate-800 text-slate-300 border border-white/5">
                              Member
                            </span>
                          )}
                        </td>
                        <td className="py-1.5 text-right font-mono font-bold text-cyan-300">
                          ฿{Number(u.balance || 0).toLocaleString()}
                        </td>
                        <td className="py-1.5 text-right font-mono text-slate-400">
                          ฿{Number(u.totalSpent || 0).toLocaleString()}
                        </td>
                        <td className="py-1.5 text-right text-slate-400 font-mono text-[10px]">
                          {u.memberSince || u.createdAt || '-'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB: RECENT ORDERS FEED MANAGEMENT (จัดการประวัติการซื้อล่าสุด) */}
      {/* ======================================================== */}
      {activeTab === 'recent-orders' && (
        <div className="space-y-3">
          {/* Main Control Card */}
          <div className="rounded-xl border border-cyan-500/25 bg-slate-950/85 p-3.5 sm:p-4 shadow-lg backdrop-blur-md relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-32 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
              <div className="flex items-start sm:items-center gap-3">
                <div
                  className={`w-11 h-11 rounded-xl flex items-center justify-center border transition-all shrink-0 ${
                    recentOrdersFeedEnabled
                      ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.25)]'
                      : 'bg-rose-500/15 border-rose-500/40 text-rose-400 shadow-[0_0_15px_rgba(244,63,94,0.15)]'
                  }`}
                >
                  <History className={`w-6 h-6 ${recentOrdersFeedEnabled ? 'animate-pulse' : ''}`} />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-sm sm:text-base font-black text-white">
                      จัดการประวัติการซื้อล่าสุด (Recent Purchases Feed)
                    </h2>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold border flex items-center gap-1.5 font-mono ${
                        recentOrdersFeedEnabled
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm'
                          : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      }`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${recentOrdersFeedEnabled ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`} />
                      <span>{recentOrdersFeedEnabled ? 'เปิดใช้งานบนหน้าเว็บ (ON)' : 'ปิดการแสดงผล (OFF)'}</span>
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 leading-relaxed max-w-2xl">
                    ควบคุมการเปิดหรือปิดการแสดงผลแถบประวัติการสั่งซื้อล่าสุด (Live Purchases Ticker) ที่หน้าแรกของเว็บไซต์ ระบบจะซิงค์การทำงานแบบ Real-time ทันทีโดยไม่ต้องรีเฟรชหน้าเว็บ
                  </p>
                </div>
              </div>

              {/* Master Action Toggle Switch */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    toggleRecentOrdersFeed();
                  }}
                  className={`px-4 py-2 rounded-xl border font-black text-xs flex items-center gap-2 transition-all cursor-pointer shadow-md ${
                    recentOrdersFeedEnabled
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 border-emerald-400 shadow-emerald-500/25 active:scale-95'
                      : 'bg-slate-900 hover:bg-slate-800 text-rose-300 border-rose-500/30 hover:border-rose-400/50 active:scale-95'
                  }`}
                >
                  {recentOrdersFeedEnabled ? (
                    <>
                      <Eye className="w-4 h-4 stroke-[2.5]" />
                      <span>คลิกเพื่อปิดการแสดงผล (Turn OFF)</span>
                    </>
                  ) : (
                    <>
                      <EyeOff className="w-4 h-4 stroke-[2.5] text-rose-400" />
                      <span className="text-white">คลิกเพื่อเปิดใช้งาน (Turn ON)</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Status notification banner if OFF */}
            {!recentOrdersFeedEnabled ? (
              <div className="mt-3 p-2.5 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-200 text-xs flex items-center gap-2.5">
                <span className="text-base shrink-0">⚠️</span>
                <div className="flex-1">
                  <strong className="block text-rose-300 font-bold">แถบประวัติการสั่งซื้อล่าสุดถูกปิดซ่อนไว้</strong>
                  <span className="text-rose-200/80 text-[11px]">ลูกค้าและผู้เข้าชมเว็บไซต์จะไม่เห็นแถบประวัติการซื้อล่าสุดบนหน้าหลัก จนกว่าจะกดเปิดใช้งานอีกครั้ง</span>
                </div>
              </div>
            ) : (
              <div className="mt-3 p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2.5">
                <span className="text-base shrink-0">✅</span>
                <div className="flex-1">
                  <strong className="block text-emerald-300 font-bold">แถบประวัติการสั่งซื้อล่าสุดกำลังเปิดแสดงผลปกติ</strong>
                  <span className="text-emerald-200/80 text-[11px]">ผู้เข้าชมเว็บไซต์สามารถดูรายการซื้อแบบเรียลไทม์ พร้อมการเลื่อนรายการอัตโนมัติบนหน้าแรก</span>
                </div>
              </div>
            )}
          </div>

          {/* 3 Quick Status Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-2.5">
            <div className="p-3 rounded-xl border border-white/10 bg-slate-950/70">
              <div className="flex items-center justify-between text-slate-400 mb-1">
                <span className="text-[10px] font-mono uppercase tracking-wider">สถานะการแสดงผล</span>
                <Radio className={`w-3.5 h-3.5 ${recentOrdersFeedEnabled ? 'text-emerald-400 animate-pulse' : 'text-rose-400'}`} />
              </div>
              <div className="text-sm sm:text-base font-black text-white">
                {recentOrdersFeedEnabled ? (
                  <span className="text-emerald-400">เปิดใช้งาน (ONLINE)</span>
                ) : (
                  <span className="text-rose-400">ปิดการแสดงผล (HIDDEN)</span>
                )}
              </div>
              <p className="text-[10px] text-slate-500 mt-0.5">สถานะหน้าแรกของเว็บไซต์</p>
            </div>

            <div className="p-3 rounded-xl border border-white/10 bg-slate-950/70">
              <div className="flex items-center justify-between text-slate-400 mb-1">
                <span className="text-[10px] font-mono uppercase tracking-wider">ประวัติในระบบ</span>
                <ShoppingBag className="w-3.5 h-3.5 text-cyan-400" />
              </div>
              <div className="text-sm sm:text-base font-black text-white font-mono">
                {orders.length} <span className="text-xs font-normal text-slate-400">รายการคำสั่งซื้อ</span>
              </div>
              <p className="text-[10px] text-slate-500 mt-0.5">รวมประวัติการสั่งซื้อทั้งหมด</p>
            </div>

            <div className="p-3 rounded-xl border border-white/10 bg-slate-950/70">
              <div className="flex items-center justify-between text-slate-400 mb-1">
                <span className="text-[10px] font-mono uppercase tracking-wider">ตำแหน่งบนหน้าเว็บ</span>
                <ExternalLink className="w-3.5 h-3.5 text-purple-400" />
              </div>
              <div className="text-sm sm:text-base font-black text-white truncate">
                {orders.length > 0 ? (recentOrdersFeedEnabled ? 'แสดงผลบนหน้าแรก' : 'ปิดการแสดงผล') : 'ซ่อนอัตโนมัติ (ยังไม่มีคำสั่งซื้อ)'}
              </div>
              <p className="text-[10px] text-slate-500 mt-0.5">
                {orders.length > 0 ? 'แสดงคำสั่งซื้อจริงแบบเรียลไทม์' : 'จะเริ่มแสดงเมื่อมีคำสั่งซื้อจริงเกิดขึ้น'}
              </p>
            </div>
          </div>

          {/* Live Storefront Preview Box */}
          <div className="rounded-xl border border-white/10 bg-slate-950/80 p-3 sm:p-3.5 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <h3 className="text-xs sm:text-sm font-bold text-white">
                  ตัวอย่างการแสดงผลบนหน้าแรก (Live Storefront Preview)
                </h3>
              </div>
              <Link
                href="/"
                target="_blank"
                className="px-2.5 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[10.5px] font-bold flex items-center gap-1.5 transition cursor-pointer"
              >
                <span>เปิดดูหน้าเว็บจริง</span>
                <ExternalLink className="w-3 h-3" />
              </Link>
            </div>

            {/* Preview Frame */}
            <div className={`p-3 rounded-xl border transition-all ${
              recentOrdersFeedEnabled
                ? 'border-cyan-500/30 bg-[color:var(--arx-dk-070b16)]'
                : 'border-rose-500/30 bg-[color:var(--arx-dk-070b16)]/50 opacity-60'
            }`}>
              {!recentOrdersFeedEnabled && (
                <div className="mb-2 text-center py-1.5 px-3 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-semibold">
                  ⚠️ แถบนี้ถูกปิดใช้งานอยู่ — ลูกค้าจะไม่เห็นแถบนี้บนหน้าหลัก
                </div>
              )}
              <div className="pointer-events-none select-none">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                    <span className="text-[11px] font-black uppercase text-cyan-400 tracking-wider">
                      RECENT PURCHASES • ประวัติการซื้อล่าสุด
                    </span>
                  </div>
                  <span className="text-[9.5px] text-slate-400 font-mono">Live Update</span>
                </div>
                {/* Horizontal scroll cards or empty state */}
                <div className="py-1">
                  {orders.length > 0 ? (
                    <div className="flex items-center gap-2 overflow-x-auto py-1">
                      {orders.slice(0, 8).map((item: any, idx: number) => (
                        <div
                          key={item.id || idx}
                          className="shrink-0 w-52 sm:w-60 p-2 rounded-lg bg-slate-900/90 border border-white/10 flex items-center gap-2 shadow-sm"
                        >
                          <div className="w-7 h-7 rounded-md bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 font-black text-xs">
                            {item.username?.[0]?.toUpperCase() || 'U'}
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-bold text-white truncate max-w-[100px]">{item.username}</span>
                              <span className="text-[9px] font-bold text-cyan-400 font-mono">฿{item.price}</span>
                            </div>
                            <p className="text-[9px] text-slate-400 truncate">{item.productName}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-6 px-4 text-center rounded-lg bg-slate-900/40 border border-dashed border-white/10 flex flex-col items-center justify-center gap-1.5 text-slate-400">
                      <ShoppingBag className="w-5 h-5 text-slate-600 mb-0.5" />
                      <span className="text-xs font-bold text-slate-300">ยังไม่มีรายการคำสั่งซื้อในระบบ (0 รายการ)</span>
                      <span className="text-[10.5px] text-slate-500 max-w-md">
                        ระบบจะไม่แสดงรายการจำลองบนหน้าหลัก และจะซ่อนแถบประวัติซื้อล่าสุดโดยอัตโนมัติ จนกว่าจะมีลูกค้าสั่งซื้อสินค้าจริง
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Recent Orders Table (Summary) */}
          <div className="rounded-xl border border-white/10 bg-slate-950/80 p-3 sm:p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-cyan-400" />
                <span>รายการคำสั่งซื้อล่าสุด ({Math.min(orders.length, 10)} รายการแรก)</span>
              </h3>
              <button
                type="button"
                onClick={() => { playClick(); setActiveTab('orders'); }}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1 transition cursor-pointer"
              >
                <span>ดูประวัติทั้งหมด ({orders.length})</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {orders.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-xs">
                ยังไม่มีรายการคำสั่งซื้อในระบบ
              </div>
            ) : (
              <div className="overflow-x-auto rounded-lg border border-white/5">
                <table className="w-full text-left text-[11px]">
                  <thead className="bg-slate-900/80 text-slate-400 uppercase text-[9px] font-mono border-b border-white/5">
                    <tr>
                      <th className="py-2 px-3">ผู้สั่งซื้อ</th>
                      <th className="py-2 px-3">สินค้า</th>
                      <th className="py-2 px-3 text-right">ราคา</th>
                      <th className="py-2 px-3 text-center">วันที่ทำรายการ</th>
                      <th className="py-2 px-3 text-center">สถานะ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 font-sans">
                    {orders.slice(0, 10).map((ord) => (
                      <tr key={ord.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="py-2 px-3 text-white font-medium">
                          {ord.username}
                        </td>
                        <td className="py-2 px-3 text-slate-300 truncate max-w-[200px]">
                          {ord.productName}
                        </td>
                        <td className="py-2 px-3 text-right font-mono text-cyan-400 font-bold">
                          ฿{ord.price?.toLocaleString()}
                        </td>
                        <td className="py-2 px-3 text-center font-mono text-slate-400 text-[10px]">
                          {ord.createdAt || '-'}
                        </td>
                        <td className="py-2 px-3 text-center">
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                            สำเร็จ
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 5: SLIP VERIFICATION & PAYMENT CHANNELS SETTINGS     */}
      {/* ======================================================== */}
      {activeTab === 'slip' && (
        <div className="max-w-3xl mx-auto space-y-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              updateSlipConfig(slipForm);
            }}
            className="space-y-4"
          >
            {/* 1. PAYMENT CHANNELS TOGGLE SECTION (เปิด/ปิด ช่องทางการโอน) */}
            <div className="bg-slate-950/80 p-4 sm:p-5 rounded-2xl border border-cyan-500/30 space-y-3.5 shadow-xl">
              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <div>
                  <span className="text-[10px] font-mono font-bold text-cyan-400 tracking-wider uppercase flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-cyan-400" />
                    PAYMENT CHANNELS MANAGEMENT
                  </span>
                  <h2 className="text-base sm:text-lg font-black text-white mt-0.5">
                    เปิด / ปิด ช่องทางการเติมเงินหน้าร้าน
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    เลือกเปิดหรือปิดช่องทางการชำระเงินที่ต้องการแสดงผลในหน้า /topup ได้อย่างอิสระ
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Channel 1: PromptPay QR */}
                <div className={`p-3.5 rounded-xl border transition-all ${
                  slipForm.channelPromptPayEnabled !== false
                    ? 'bg-cyan-950/20 border-cyan-500/40 shadow-sm'
                    : 'bg-slate-900/40 border-slate-800 opacity-60'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-white p-1 flex items-center justify-center shrink-0">
                        <PromptPayIcon className="w-full h-full" />
                      </div>
                      <div>
                        <strong className="text-xs font-bold text-white block">PromptPay QR Code</strong>
                        <span className="text-[10.5px] text-slate-400">สแกนจ่ายผ่านแอปธนาคาร</span>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={slipForm.channelPromptPayEnabled !== false}
                        onChange={e => setSlipForm({ ...slipForm, channelPromptPayEnabled: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500"></div>
                    </label>
                  </div>
                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-white/5">
                    <span className="text-slate-400">สถานะหน้าร้าน:</span>
                    <span className={`font-bold ${slipForm.channelPromptPayEnabled !== false ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {slipForm.channelPromptPayEnabled !== false ? '● เปิดใช้งาน (เปิดบริการ)' : '○ ปิดให้บริการชั่วคราว'}
                    </span>
                  </div>
                </div>

                {/* Channel 2: Bank Transfer (K+) */}
                <div className={`p-3.5 rounded-xl border transition-all ${
                  slipForm.channelBankTransferEnabled !== false
                    ? 'bg-emerald-950/20 border-emerald-500/40 shadow-sm'
                    : 'bg-slate-900/40 border-slate-800 opacity-60'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg overflow-hidden shrink-0 shadow-sm">
                        <BankIcon bankName={slipForm.bankName} className="w-full h-full" />
                      </div>
                      <div>
                        <strong className="text-xs font-bold text-white block">โอนผ่านธนาคาร / แนบสลิป</strong>
                        <span className="text-[10.5px] text-slate-400">{slipForm.bankName || 'โอนเงินเข้าบัญชีร้านค้า'}</span>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={slipForm.channelBankTransferEnabled !== false}
                        onChange={e => setSlipForm({ ...slipForm, channelBankTransferEnabled: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
                    </label>
                  </div>
                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-white/5">
                    <span className="text-slate-400">สถานะหน้าร้าน:</span>
                    <span className={`font-bold ${slipForm.channelBankTransferEnabled !== false ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {slipForm.channelBankTransferEnabled !== false ? '● เปิดใช้งาน (เปิดบริการ)' : '○ ปิดให้บริการชั่วคราว'}
                    </span>
                  </div>
                </div>

                {/* Channel 3: TrueMoney Angpao */}
                <div className={`p-3.5 rounded-xl border transition-all ${
                  slipForm.channelAngpaoEnabled !== false
                    ? 'bg-orange-950/20 border-orange-500/40 shadow-sm'
                    : 'bg-slate-900/40 border-slate-800 opacity-60'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-white p-0.5 flex items-center justify-center shrink-0">
                        <TrueMoneyIcon className="w-6 h-6" />
                      </div>
                      <div>
                        <strong className="text-xs font-bold text-white block">ซองของขวัญ TrueMoney</strong>
                        <span className="text-[10.5px] text-slate-400">วางลิงก์ซองอั่งเปาอัตโนมัติ</span>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={slipForm.channelAngpaoEnabled !== false}
                        onChange={e => setSlipForm({ ...slipForm, channelAngpaoEnabled: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-orange-500"></div>
                    </label>
                  </div>
                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-white/5">
                    <span className="text-slate-400">สถานะหน้าร้าน:</span>
                    <span className={`font-bold ${slipForm.channelAngpaoEnabled !== false ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {slipForm.channelAngpaoEnabled !== false ? '● เปิดใช้งาน (เปิดบริการ)' : '○ ปิดให้บริการชั่วคราว'}
                    </span>
                  </div>
                </div>

                {/* Channel 4: TrueMoney Wallet Phone Transfer */}
                <div className={`p-3.5 rounded-xl border transition-all ${
                  slipForm.channelTrueMoneyWalletEnabled !== false
                    ? 'bg-amber-950/20 border-amber-500/40 shadow-sm'
                    : 'bg-slate-900/40 border-slate-800 opacity-60'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-300 shrink-0 font-bold text-xs">
                        TM
                      </div>
                      <div>
                        <strong className="text-xs font-bold text-white block">เบอร์ TrueMoney โอนตรง</strong>
                        <span className="text-[10.5px] text-slate-400">แสดงเบอร์วอลเล็ทของร้าน</span>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={slipForm.channelTrueMoneyWalletEnabled !== false}
                        onChange={e => setSlipForm({ ...slipForm, channelTrueMoneyWalletEnabled: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                    </label>
                  </div>
                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-white/5">
                    <span className="text-slate-400">สถานะหน้าร้าน:</span>
                    <span className={`font-bold ${slipForm.channelTrueMoneyWalletEnabled !== false ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {slipForm.channelTrueMoneyWalletEnabled !== false ? '● เปิดใช้งาน (เปิดบริการ)' : '○ ปิดให้บริการชั่วคราว'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* 2. TRUEMONEY ANGPAO FEE PERCENTAGE DEDUCTION SETTINGS */}
            <div className="bg-slate-950/80 p-4 sm:p-5 rounded-2xl border border-orange-500/30 space-y-3.5 shadow-xl">
              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <div>
                  <span className="text-[10px] font-mono font-bold text-orange-400 tracking-wider uppercase flex items-center gap-1.5">
                    🧧 TRUEMONEY VOUCHER FEE CONFIGURATION
                  </span>
                  <h2 className="text-base sm:text-lg font-black text-white mt-0.5">
                    ระบบซองของขวัญ: กำหนดอัตราหักค่าธรรมเนียม (%)
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    กำหนดเปอร์เซ็นต์ค่าธรรมเนียมที่จะหักออกจากยอดซองอั่งเปาก่อนเติมเครดิตเข้ากระเป๋าลูกค้า
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                {/* Input & Presets (7 cols) */}
                <div className="md:col-span-7 space-y-2.5">
                  <label className="block text-xs font-bold text-slate-200">
                    อัตราค่าธรรมเนียมที่หัก (%):
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      value={slipForm.angpaoFeePercent ?? 2.9}
                      onChange={e => {
                        const val = parseFloat(e.target.value);
                        setSlipForm({ ...slipForm, angpaoFeePercent: isNaN(val) ? 0 : Math.max(0, Math.min(100, val)) });
                      }}
                      className="w-full px-3 py-2.5 rounded-xl bg-black/60 border border-orange-500/40 text-amber-300 font-mono text-lg font-black focus:outline-none focus:border-orange-400 pr-10"
                      placeholder="2.9"
                    />
                    <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-orange-400 font-bold text-base">
                      %
                    </span>
                  </div>

                  {/* Preset Buttons */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    <span className="text-[11px] text-slate-400 font-medium">ตัวเลือกด่วน:</span>
                    {[
                      { label: '0% (ไม่หัก/ฟรี)', val: 0 },
                      { label: '2.5%', val: 2.5 },
                      { label: '2.9% (มาตรฐาน)', val: 2.9 },
                      { label: '5%', val: 5 },
                      { label: '10%', val: 10 }
                    ].map(p => (
                      <button
                        key={p.val}
                        type="button"
                        onClick={() => {
                          playClick();
                          setSlipForm({ ...slipForm, angpaoFeePercent: p.val });
                        }}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                          (slipForm.angpaoFeePercent ?? 2.9) === p.val
                            ? 'bg-orange-500 text-black font-bold shadow-md'
                            : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/5'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Calculation Preview (5 cols) */}
                <div className="md:col-span-5 p-3.5 rounded-xl bg-black/50 border border-orange-500/20 space-y-2 text-xs">
                  <div className="font-bold text-orange-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-orange-400" />
                    <span>ตัวอย่างการคำนวณจริง</span>
                  </div>
                  <div className="space-y-1 text-slate-300 text-[11.5px]">
                    <div className="flex justify-between">
                      <span className="text-slate-400">ลูกค้าเติมซอง:</span>
                      <span className="font-mono text-white font-bold">100.00 ฿</span>
                    </div>
                    <div className="flex justify-between text-rose-300">
                      <span>หักค่าธรรมเนียม ({(slipForm.angpaoFeePercent ?? 2.9)}%):</span>
                      <span className="font-mono font-bold">-{(100 * ((slipForm.angpaoFeePercent ?? 2.9) / 100)).toFixed(2)} ฿</span>
                    </div>
                    <div className="h-px bg-white/10 my-1" />
                    <div className="flex justify-between text-emerald-300 font-bold">
                      <span>เครดิตที่ลูกค้าได้รับ:</span>
                      <span className="font-mono text-sm text-emerald-400">
                        {Math.max(0, 100 - (100 * ((slipForm.angpaoFeePercent ?? 2.9) / 100))).toFixed(2)} ฿
                      </span>
                    </div>
                  </div>
                  <p className="text-[10px] text-slate-500 pt-1 leading-tight">
                    * ระบบจะหักค่าธรรมเนียมตาม % นี้อัตโนมัติก่อนเติมเครดิตเข้าบัญชี
                  </p>
                </div>
              </div>
            </div>

            {/* 3. BANK ACCOUNT & WALLET INFO */}
            <div className="bg-slate-950/80 p-4 sm:p-5 rounded-2xl border border-cyan-500/30 space-y-3 shadow-xl">
              <span className="text-[10px] font-mono font-bold text-cyan-400 tracking-wider uppercase block">
                ข้อมูลบัญชีรับโอนเงิน (แสดงในหน้าเติมเงิน)
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-300 mb-1 font-semibold">
                    เบอร์พร้อมเพย์ / เลขบัญชีธนาคาร:
                  </label>
                  <input
                    type="text"
                    value={slipForm.promptPayNumber}
                    onChange={e => setSlipForm({ ...slipForm, promptPayNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                    placeholder="เช่น 5160906053 หรือ 098-XXX-XXXX"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-300 mb-1 font-semibold">
                    ชื่อบัญชีรับเงิน (Account Name):
                  </label>
                  <input
                    type="text"
                    value={slipForm.accountName}
                    onChange={e => setSlipForm({ ...slipForm, accountName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                    placeholder="เช่น ณัฐพงศ์ แซ่หลู่"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-300 mb-1 font-semibold flex items-center justify-between">
                    <span>ธนาคาร (Bank Name):</span>
                    <span className="text-[10.5px] text-cyan-400 font-normal">เปลี่ยนไอคอน & ข้อมูลหน้าร้านอัตโนมัติ</span>
                  </label>
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0 shadow-md border border-white/10 bg-black/40 p-0.5">
                      <BankIcon bankName={slipForm.bankName} className="w-full h-full" />
                    </div>
                    <select
                      value={THAI_BANKS.some(b => b.name === slipForm.bankName) ? slipForm.bankName : (slipForm.bankName ? 'custom' : THAI_BANKS[0].name)}
                      onChange={e => {
                        playClick();
                        if (e.target.value !== 'custom') {
                          setSlipForm({ ...slipForm, bankName: e.target.value });
                        }
                      }}
                      className="flex-1 px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400 cursor-pointer font-medium"
                    >
                      {THAI_BANKS.map(b => (
                        <option key={b.code} value={b.name} className="bg-slate-900 text-white">
                          {b.name}
                        </option>
                      ))}
                      <option value="custom" className="bg-slate-900 text-cyan-300">
                        ✍️ กำหนดชื่อธนาคารเอง (Custom...)
                      </option>
                    </select>
                  </div>
                  {(!THAI_BANKS.some(b => b.name === slipForm.bankName) || slipForm.bankName === '') && (
                    <input
                      type="text"
                      value={slipForm.bankName}
                      onChange={e => setSlipForm({ ...slipForm, bankName: e.target.value })}
                      className="w-full mt-2 px-3 py-2 rounded-xl bg-slate-900 border border-cyan-500/40 text-xs text-cyan-300 focus:outline-none focus:border-cyan-400 placeholder:text-slate-500"
                      placeholder="พิมพ์ชื่อธนาคารที่ต้องการ เช่น กสิกรไทย (KBANK)"
                    />
                  )}
                </div>
                <div>
                  <label className="block text-xs text-slate-300 mb-1 font-semibold">
                    เบอร์ TrueMoney Wallet ของร้าน (สำหรับโอนตรง):
                  </label>
                  <input
                    type="text"
                    placeholder="เช่น 098-XXX-XXXX"
                    value={slipForm.trueMoneyPhone || ''}
                    onChange={e => setSlipForm({ ...slipForm, trueMoneyPhone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-orange-500/30 text-xs text-white font-mono focus:outline-none focus:border-orange-400"
                  />
                </div>
              </div>
            </div>

            {/* 4. AUTOMATED SLIP VERIFICATION API INTEGRATION */}
            <div className="bg-slate-950/80 p-4 sm:p-5 rounded-2xl border border-cyan-500/30 space-y-3 shadow-xl">
              <div>
                <span className="text-[10px] font-mono font-bold text-cyan-400 tracking-wider uppercase flex items-center gap-1.5">
                  <QrCode className="w-3.5 h-3.5 text-cyan-400" />
                  AUTOMATED SLIP VERIFICATION API
                </span>
                <h3 className="text-sm sm:text-base font-black text-white mt-0.5">
                  เชื่อมต่อระบบตรวจสลิปอัตโนมัติ (Slip API)
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  เชื่อมต่อกับ SlipOK, BYShop หรือระบบตรวจสลิปเพื่อตัดยอดอัตโนมัติ
                </p>
              </div>

              {/* API Provider */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  เลือกผู้ให้บริการ API (Service Provider):
                </label>
                <select
                  value={slipForm.provider}
                  onChange={e => setSlipForm({ ...slipForm, provider: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                >
                  <option value="slipok">SlipOK API (ตรวจสอบยอด สลิปไม่ซ้ำ เติมอัตโนมัติ)</option>
                  <option value="easyslip">EasySlip API</option>
                  <option value="byshop">BYShop API (byshop.me - ระบบตรวจสลิป & API อัตโนมัติ)</option>
                  <option value="openslip">OpenSlipVerify API</option>
                  <option value="custom">Custom Webhook / Internal Engine</option>
                </select>
              </div>

              {/* API Key */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  API Key / Secret Token:
                </label>
                <div className="relative">
                  <input
                    type={showApiKey ? 'text' : 'password'}
                    placeholder={slipForm.provider === 'byshop' ? "เช่น byshop_key_xxxxxxxx หรือ Token จาก byshop.me" : "เช่น slipok_live_xxxxxxxxxxxxxxxx"}
                    value={slipForm.apiKey}
                    onChange={e => setSlipForm({ ...slipForm, apiKey: e.target.value })}
                    className="w-full px-3 pr-10 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="button"
                    onClick={() => setShowApiKey(!showApiKey)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Branch ID */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Branch ID / Merchant ID (หากมี):
                </label>
                <input
                  type="text"
                  placeholder={slipForm.provider === 'byshop' ? "เช่น byshop_partner_id หรือ Merchant ID จาก byshop.me" : "เช่น branch_01"}
                  value={slipForm.branchId}
                  onChange={e => setSlipForm({ ...slipForm, branchId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>

              {/* BYShop Guide & Test Box */}
              {slipForm.provider === 'byshop' && (
                <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/40 via-cyan-950/30 to-slate-900 border border-emerald-500/30 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-emerald-400" />
                      BYShop.me API Integration
                    </span>
                    <a
                      href="https://byshop.me"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1 font-mono"
                    >
                      <span>ไปยังเว็บไซต์ byshop.me</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    ระบบรองรับการเชื่อมต่อกับ <strong className="text-white">BYShop.me</strong> สำหรับการตรวจสอบสลิปโอนเงินและการตัดยอดอัตโนมัติ โดยนำ API Key ที่ได้รับจากทีมงาน BYShop มาวางในช่องด้านบน
                  </p>
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleTestByshopConnection}
                      disabled={isTestingByshop}
                      className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                    >
                      {isTestingByshop ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>กำลังตรวจสอบสถานะ...</span>
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          <span>ทดสอบการเชื่อมต่อ BYShop API</span>
                        </>
                      )}
                    </button>
                    {byshopTestResult && (
                      <span className="text-xs font-mono text-emerald-300 flex items-center gap-1 bg-black/40 px-2.5 py-1 rounded-md border border-emerald-500/20">
                        {byshopTestResult}
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* Auto Approve Toggle */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/25">
                <div>
                  <strong className="text-xs font-bold text-white block">อนุมัติและปรับยอดเครดิตอัตโนมัติ 24 ชม.</strong>
                  <span className="text-[11px] text-slate-400">เมื่อสลิปถูกต้อง ยอดเงินตรง และไม่เคยใช้งานมาก่อน เครดิตจะเข้ากระเป๋าลูกค้าทันที</span>
                </div>
                <input
                  type="checkbox"
                  checked={slipForm.autoApprove}
                  onChange={e => setSlipForm({ ...slipForm, autoApprove: e.target.checked })}
                  className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
                />
              </div>
            </div>

            {/* SUBMIT BUTTON */}
            <button
              type="submit"
              className="w-full py-3 rounded-xl cyber-btn-primary font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 cursor-pointer transition-all active:scale-[0.99]"
            >
              <Save className="w-4 h-4" />
              <span>บันทึกการตั้งค่าช่องทางชำระเงิน & ค่าธรรมเนียมทั้งหมด</span>
            </button>
          </form>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 6: TOPUPS LIST */}
      {/* ======================================================== */}
      {activeTab === 'topups' && (
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm sm:text-base font-bold text-white">ประวัติและรายการเติมเงินทั้งหมด ({topups.length})</h2>
          </div>
          <div className="overflow-x-auto rounded-xl border border-white/10 bg-slate-950/80">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px] border-b border-white/10">
                <tr>
                  <th className="py-2 px-2.5 font-bold">รหัสรายการ</th>
                  <th className="py-2 px-2.5 font-bold">ผู้ใช้งาน</th>
                  <th className="py-2 px-2.5 font-bold">ช่องทาง</th>
                  <th className="py-2 px-2.5 font-bold">จำนวนเงิน</th>
                  <th className="py-2 px-2.5 font-bold">สถานะ</th>
                  <th className="py-2 px-2.5 font-bold">วันที่ทำรายการ</th>
                  <th className="py-2 px-2.5 font-bold text-right">ดำเนินการ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {topups.map(t => (
                  <tr key={t.id} className="hover:bg-white/[0.02]">
                    <td className="py-2 px-2.5 font-mono text-cyan-300 font-bold text-[11px]">{t.transactionNo}</td>
                    <td className="py-2 px-2.5 font-medium text-white text-[11px]">{t.username}</td>
                    <td className="py-2 px-2.5 uppercase text-[9.5px] font-mono text-slate-300">{t.method}</td>
                    <td className="py-2 px-2.5 font-mono font-bold text-emerald-400 text-[11px]">฿{t.amount.toLocaleString()}</td>
                    <td className="py-2 px-2.5">
                      <span className={`px-2 py-0.2 rounded-full text-[9px] font-bold uppercase ${
                        t.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                      }`}>
                        {t.status === 'approved' ? 'อนุมัติแล้ว' : 'รอดำเนินการ'}
                      </span>
                    </td>
                    <td className="py-2 px-2.5 text-slate-400 font-mono text-[9.5px]">{t.createdAt}</td>
                    <td className="py-2 px-2.5 text-right">
                      {t.status === 'pending' && (
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => approveTopup(t.id)}
                            className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500 hover:text-slate-950 font-bold transition cursor-pointer text-[10px]"
                          >
                            อนุมัติ
                          </button>
                          <button
                            type="button"
                            onClick={() => rejectTopup(t.id)}
                            className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 hover:bg-rose-500 hover:text-white font-bold transition cursor-pointer text-[10px]"
                          >
                            ปฏิเสธ
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 7: ORDERS LIST */}
      {/* ======================================================== */}
      {activeTab === 'orders' && (
        <div className="space-y-3">
          {/* Master Control Card: เปิด/ปิด ประวัติการสั่งซื้อล่าสุด (Recent Purchases Feed บนหน้าหลัก) */}
          <div className="rounded-xl border border-white/10 bg-slate-950/80 p-2.5 sm:p-3 shadow-md backdrop-blur-md relative overflow-hidden">
            <div className="absolute top-0 right-0 w-48 h-24 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none" />

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 relative z-10">
              <div className="flex items-center gap-2.5">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center border transition-all shrink-0 ${
                  recentOrdersFeedEnabled
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.2)]'
                    : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                }`}>
                  <Radio className={`w-4 h-4 ${recentOrdersFeedEnabled ? 'animate-pulse' : ''}`} />
                </div>
                <div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h2 className="text-xs sm:text-sm font-bold text-white">
                      ประวัติการสั่งซื้อล่าสุด (Recent Purchases Feed)
                    </h2>
                    <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-bold border flex items-center gap-1 font-mono ${
                      recentOrdersFeedEnabled
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm'
                        : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    }`}>
                      <span className={`w-1 h-1 rounded-full ${recentOrdersFeedEnabled ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`} />
                      <span>{recentOrdersFeedEnabled ? 'กำลังแสดงผล (ON)' : 'ซ่อนอยู่ (OFF)'}</span>
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5 leading-tight">
                    ควบคุมการเปิดหรือปิดการแสดงผลแถบประวัติการสั่งซื้อล่าสุด (Live Orders Feed / Marquee) ที่หน้าหลักของร้านค้า
                  </p>
                </div>
              </div>

              {/* Master Switch Button */}
              <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
                <button
                  type="button"
                  onClick={() => toggleRecentOrdersFeed()}
                  className={`px-3 py-1 rounded-lg border font-bold text-[11px] flex items-center gap-1.5 transition-all cursor-pointer shadow-sm ${
                    recentOrdersFeedEnabled
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 border-emerald-400 shadow-emerald-500/30 font-black'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-white/10'
                  }`}
                >
                  {recentOrdersFeedEnabled ? (
                    <>
                      <Eye className="w-3 h-3" />
                      <span>เปิดอยู่ (คลิกเพื่อปิด)</span>
                    </>
                  ) : (
                    <>
                      <EyeOff className="w-3 h-3 text-rose-400" />
                      <span className="text-white">ปิดอยู่ (คลิกเพื่อเปิด)</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Alert banner if disabled */}
            {!recentOrdersFeedEnabled && (
              <div className="mt-2 p-2 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-200 text-[10.5px] flex items-center gap-2">
                <span className="text-sm">⚠️</span>
                <div>
                  <strong className="block text-rose-300 font-bold">แถบประวัติการซื้อล่าสุดถูกปิดซ่อนไว้</strong>
                  <span className="text-rose-200/80 text-[10px]">ผู้เข้าชมเว็บไซต์จะไม่เห็นแถบประวัติการซื้อล่าสุดบนหน้าหลัก จนกว่าจะกดเปิดใช้งานอีกครั้ง</span>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between pt-1">
            <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-cyan-400" />
              <span>รายการคำสั่งซื้อทั้งหมด ({orders.length})</span>
            </h2>
          </div>
          <div className="overflow-x-auto rounded-xl border border-white/10 bg-slate-950/80">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px] border-b border-white/10">
                <tr>
                  <th className="py-2 px-2.5 font-bold">เลขออเดอร์</th>
                  <th className="py-2 px-2.5 font-bold">ผู้ซื้อ</th>
                  <th className="py-2 px-2.5 font-bold">สินค้า & แพ็กเกจ</th>
                  <th className="py-2 px-2.5 font-bold">ราคา</th>
                  <th className="py-2 px-2.5 font-bold">License Key</th>
                  <th className="py-2 px-2.5 font-bold">วันที่ซื้อ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {orders.map(o => (
                  <tr key={o.id} className="hover:bg-white/[0.02]">
                    <td className="py-2 px-2.5 font-mono text-cyan-300 font-bold text-[11px]">{o.orderNumber}</td>
                    <td className="py-2 px-2.5 text-white font-medium text-[11px]">{o.username}</td>
                    <td className="py-2 px-2.5">
                      <span className="font-bold text-white block text-[11px]">{o.productName}</span>
                      <span className="text-[9.5px] text-slate-400">{o.packageName}</span>
                    </td>
                    <td className="py-2 px-2.5 font-mono font-bold text-emerald-400 text-[11px]">฿{o.price.toLocaleString()}</td>
                    <td className="py-2 px-2.5 font-mono text-slate-300 select-all text-[10.5px]">{o.licenseKey}</td>
                    <td className="py-2 px-2.5 text-slate-400 font-mono text-[9.5px]">{o.createdAt}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 8: DISCORD WEBHOOK LOGGING */}
      {/* ======================================================== */}
      {activeTab === 'webhooks' && (
        <div className="space-y-3">
          {/* Header & Quick Save Notice */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 p-3.5 sm:p-4 rounded-2xl bg-slate-950/80 border border-cyan-500/20 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
            <div className="relative z-10 space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                  <Radio className="w-4 h-4 animate-pulse" />
                </span>
                <h2 className="text-base sm:text-lg font-black text-white tracking-wide">
                  ระบบ Discord Webhook Notification & Real-time Logs
                </h2>
              </div>
              <p className="text-[11px] text-slate-400 max-w-2xl leading-relaxed">
                ใส่ Discord Webhook URL เพื่อรับการแจ้งเตือนแบบทันทีเมื่อเกิดเหตุการณ์สำคัญในร้านค้า รองรับ Rich Embeds แยกสีตามหมวดหมู่ พร้อมซ่อนคีย์สินค้าด้วย Spoiler Tag เพื่อความปลอดภัย
              </p>
            </div>

            <div className="relative z-10 flex flex-wrap items-center gap-2.5">
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Auto-Save อัตโนมัติ</span>
              </div>
              <button
                type="button"
                onClick={handleSaveWebhookSettings}
                className="px-3.5 py-1.5 rounded-lg bg-[color:var(--theme-accent)] text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20 hover:scale-[1.02] active:scale-[0.98] transition cursor-pointer whitespace-nowrap"
              >
                <Save className="w-3.5 h-3.5" />
                <span>บันทึกการตั้งค่า Webhook</span>
              </button>
            </div>
          </div>

          {/* Webhook Notice Toast */}
          {webhookSavedNotice && (
            <div className="p-2.5 rounded-xl bg-cyan-500/15 border border-cyan-400/30 flex items-center justify-between gap-2.5 text-[11px] text-cyan-200 animate-in fade-in slide-in-from-top-2 duration-200">
              <div className="flex items-center gap-2">
                <CheckCheck className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                <span className="font-semibold">{webhookSavedNotice}</span>
              </div>
              <button
                type="button"
                onClick={() => setWebhookSavedNotice(null)}
                className="text-cyan-400/60 hover:text-cyan-200 text-xs cursor-pointer font-bold"
              >
                ปิด
              </button>
            </div>
          )}

          {/* Bot Profile Configuration */}
          <div className="cyber-card p-3.5 sm:p-4 rounded-2xl bg-slate-950/60 border border-white/10 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-white/5">
              <div className="flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                <h3 className="text-xs sm:text-sm font-bold text-white">โปรไฟล์ของ Discord Bot (Webhook Identity)</h3>
              </div>
              <span className="text-[10px] text-slate-400">กำหนดชื่อและรูปอวาตาร์ของบอทที่ส่งข้อความ (Auto-Saved)</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  ชื่อบอทแสดงผล (Bot Display Name)
                </label>
                <input
                  type="text"
                  value={webhookForm.botName}
                  onChange={e => handleWebhookFieldChange('botName', e.target.value)}
                  placeholder="เช่น ARX STORE NOTIFICATIONS"
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-semibold text-slate-300 flex items-center gap-1.5">
                    <span>ลิงก์รูปโปรไฟล์บอท (Bot Avatar URL)</span>
                    <span className="text-[9px] text-cyan-400 font-mono bg-cyan-500/10 px-1.5 py-0.2 rounded-full border border-cyan-500/30">
                      🔒 ล็อครูปหลัก
                    </span>
                  </label>
                  <span className="text-[9.5px] text-emerald-400 font-mono bg-emerald-500/10 px-1.5 py-0.2 rounded-full border border-emerald-500/20">
                    ✓ ล็อคสมบูรณ์
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      value={webhookForm.botAvatarUrl || 'https://files.catbox.moe/haszlm.png'}
                      onChange={e => handleWebhookFieldChange('botAvatarUrl', e.target.value)}
                      onBlur={e => {
                        let val = e.target.value.trim();
                        if (val.startsWith('//')) val = 'https:' + val;
                        else if (val && !val.startsWith('http://') && !val.startsWith('https://')) val = 'https://' + val;
                        handleWebhookFieldChange('botAvatarUrl', val || 'https://files.catbox.moe/haszlm.png');
                      }}
                      placeholder="https://files.catbox.moe/haszlm.png"
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                  <div className="w-8 h-8 rounded-lg bg-slate-900 border border-cyan-500/40 overflow-hidden flex items-center justify-center flex-shrink-0 relative group shadow-sm" title="พรีวิวรูปโปรไฟล์บอท ARX STORE">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={webhookForm.botAvatarUrl || '/brand/logo.png'}
                      alt="ARX STORE Bot Avatar"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                      crossOrigin="anonymous"
                      onError={e => {
                        const target = e.target as HTMLImageElement;
                        if (!target.src.includes('logo.png')) {
                          target.src = '/brand/logo.png';
                        }
                      }}
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between mt-1">
                  <p className="text-[9.5px] text-slate-400 flex items-center gap-1">
                    <span className="w-1 h-1 rounded-full bg-cyan-400 animate-pulse"></span>
                    ล็อครูปโปรไฟล์บอท Discord เป็นโลโก้หลัก ARX STORE อัตโนมัติ
                  </p>
                  {webhookForm.botAvatarUrl !== 'https://files.catbox.moe/haszlm.png' && (
                    <button
                      type="button"
                      onClick={() => handleWebhookFieldChange('botAvatarUrl', 'https://files.catbox.moe/haszlm.png')}
                      className="text-[9.5px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer font-medium"
                    >
                      รีเซ็ตกลับเป็นรูปหลัก
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* 4 Main Webhook Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
            {/* 1. Log สมัครสมาชิก */}
            <div className="cyber-card p-3 sm:p-3.5 rounded-xl bg-slate-950/70 border border-cyan-500/30 flex flex-col justify-between space-y-2.5 hover:border-cyan-400/50 transition group">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between pb-2 border-b border-white/5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                      <Users className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white group-hover:text-cyan-300 transition">
                        1. Log สมัครสมาชิก
                      </h4>
                      <p className="text-[9px] text-slate-400">New Registration</p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={webhookForm.registerEnabled}
                      onChange={e => handleWebhookFieldChange('registerEnabled', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-8 h-4 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-cyan-500"></div>
                  </label>
                </div>

                <p className="text-[11px] text-slate-300 leading-relaxed">
                  ส่งข้อความ Rich Embed สีฟ้า Cyan เข้า Discord ทันทีที่มีสมาชิกใหม่สร้างบัญชีในเว็บไซต์
                </p>

                <div className="space-y-1">
                  <label className="text-[10px] font-semibold text-slate-400 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <span>Discord Webhook URL</span>
                      <span className="text-[8.5px] px-1 py-0.2 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-mono">Auto-saved</span>
                    </span>
                    <span className="text-[9.5px] text-cyan-400 font-mono">
                      {webhookForm.registerUrl ? '✓ บันทึกแล้ว' : 'ยังไม่ได้ใส่'}
                    </span>
                  </label>
                  <textarea
                    rows={2}
                    value={webhookForm.registerUrl}
                    onChange={e => handleWebhookFieldChange('registerUrl', e.target.value)}
                    onBlur={() => handleWebhookFieldChange('registerUrl', webhookForm.registerUrl.trim())}
                    placeholder="https://discord.com/api/webhooks/..."
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-[11px] font-mono focus:outline-none focus:border-cyan-500 resize-none"
                  />
                </div>

                <div className="p-2 rounded-lg bg-cyan-950/30 border border-cyan-500/20 text-[10px] text-slate-300 space-y-0.5">
                  <div className="font-bold text-cyan-300 flex items-center gap-1">
                    <Info className="w-3 h-3" />
                    <span>ข้อมูลใน Discord Embed:</span>
                  </div>
                  <ul className="list-disc list-inside text-slate-400 pl-1">
                    <li>Username, สิทธิ์, วันเวลาลงทะเบียน</li>
                  </ul>
                </div>
              </div>

              <div className="pt-1">
                <button
                  type="button"
                  disabled={testingWebhookType === 'register' || !webhookForm.registerUrl}
                  onClick={() => handleTestWebhook('register')}
                  className="w-full py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 font-bold text-[10.5px] flex items-center justify-center gap-1.5 transition disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                >
                  {testingWebhookType === 'register' ? (
                    <>
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      <span>กำลังทดสอบ...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3 h-3" />
                      <span>ทดสอบส่ง Webhook สมัครสมาชิก</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* 2. Log เติมเงิน ธนาคาร & TrueMoney */}
            <div className="cyber-card p-3 sm:p-3.5 rounded-xl bg-slate-950/70 border border-emerald-500/30 flex flex-col justify-between space-y-2.5 hover:border-emerald-400/50 transition group">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between pb-2 border-b border-white/5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                      <CreditCard className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white group-hover:text-emerald-300 transition">
                        2. Log เติมเงิน ธนาคาร/วอเลท
                      </h4>
                      <p className="text-[9px] text-slate-400">Bank Slip & Angpao Topup</p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={webhookForm.topupEnabled}
                      onChange={e => handleWebhookFieldChange('topupEnabled', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-8 h-4 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                </div>

                <p className="text-[11px] text-slate-300 leading-relaxed">
                  ส่งข้อความแจ้งเตือนยอดเงินเข้า Embed เขียว (ธนาคาร/สลิป) และ Embed ส้ม (ซองทรูมันนี่)
                </p>

                <div className="space-y-1">
                  <label className="text-[10px] font-semibold text-slate-400 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <span>Discord Webhook URL</span>
                      <span className="text-[8.5px] px-1 py-0.2 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">Auto-saved</span>
                    </span>
                    <span className="text-[9.5px] text-emerald-400 font-mono">
                      {webhookForm.topupUrl ? '✓ บันทึกแล้ว' : 'ยังไม่ได้ใส่'}
                    </span>
                  </label>
                  <textarea
                    rows={2}
                    value={webhookForm.topupUrl}
                    onChange={e => handleWebhookFieldChange('topupUrl', e.target.value)}
                    onBlur={() => handleWebhookFieldChange('topupUrl', webhookForm.topupUrl.trim())}
                    placeholder="https://discord.com/api/webhooks/..."
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-[11px] font-mono focus:outline-none focus:border-emerald-500 resize-none"
                  />
                </div>

                <div className="p-2 rounded-lg bg-emerald-950/30 border border-emerald-500/20 text-[10px] text-slate-300 space-y-0.5">
                  <div className="font-bold text-emerald-300 flex items-center gap-1">
                    <Info className="w-3 h-3" />
                    <span>ข้อมูลใน Discord Embed:</span>
                  </div>
                  <ul className="list-disc list-inside text-slate-400 pl-1">
                    <li>ยอดเงิน (฿), ช่องทาง, ผู้ใช้, TX No.</li>
                  </ul>
                </div>
              </div>

              <div className="pt-1 grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  disabled={testingWebhookType === 'topup_bank' || !webhookForm.topupUrl}
                  onClick={() => handleTestWebhook('topup_bank')}
                  className="py-1.5 px-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-bold text-[10px] flex items-center justify-center gap-1 transition disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                >
                  {testingWebhookType === 'topup_bank' ? (
                    <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                  ) : (
                    <Send className="w-2.5 h-2.5" />
                  )}
                  <span>สลิปธนาคาร</span>
                </button>

                <button
                  type="button"
                  disabled={testingWebhookType === 'topup_truemoney' || !webhookForm.topupUrl}
                  onClick={() => handleTestWebhook('topup_truemoney')}
                  className="py-1.5 px-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 font-bold text-[10px] flex items-center justify-center gap-1 transition disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                >
                  {testingWebhookType === 'topup_truemoney' ? (
                    <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                  ) : (
                    <Send className="w-2.5 h-2.5" />
                  )}
                  <span>TrueMoney</span>
                </button>
              </div>
            </div>

            {/* 3. Log ซื้อของ ซื้อสินค้า */}
            <div className="cyber-card p-3 sm:p-3.5 rounded-xl bg-slate-950/70 border border-purple-500/30 flex flex-col justify-between space-y-2.5 hover:border-purple-400/50 transition group">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between pb-2 border-b border-white/5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                      <ShoppingBag className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white group-hover:text-purple-300 transition">
                        3. Log ซื้อของ / สั่งซื้อ
                      </h4>
                      <p className="text-[9px] text-slate-400">Product & License Orders</p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={webhookForm.orderEnabled}
                      onChange={e => handleWebhookFieldChange('orderEnabled', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-8 h-4 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-purple-500"></div>
                  </label>
                </div>

                <p className="text-[11px] text-slate-300 leading-relaxed">
                  ส่งข้อความแจ้งเตือนคำสั่งซื้อใหม่ Rich Embed สีม่วง พร้อมซ่อน License Key ด้วยแท็ก Spoiler
                </p>

                <div className="space-y-1">
                  <label className="text-[10px] font-semibold text-slate-400 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <span>Discord Webhook URL</span>
                      <span className="text-[8.5px] px-1 py-0.2 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20 font-mono">Auto-saved</span>
                    </span>
                    <span className="text-[9.5px] text-purple-400 font-mono">
                      {webhookForm.orderUrl ? '✓ บันทึกแล้ว' : 'ยังไม่ได้ใส่'}
                    </span>
                  </label>
                  <textarea
                    rows={2}
                    value={webhookForm.orderUrl}
                    onChange={e => handleWebhookFieldChange('orderUrl', e.target.value)}
                    onBlur={() => handleWebhookFieldChange('orderUrl', webhookForm.orderUrl.trim())}
                    placeholder="https://discord.com/api/webhooks/..."
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-[11px] font-mono focus:outline-none focus:border-purple-500 resize-none"
                  />
                </div>

                <div className="p-2 rounded-lg bg-purple-950/30 border border-purple-500/20 text-[10px] text-slate-300 space-y-0.5">
                  <div className="font-bold text-purple-300 flex items-center gap-1">
                    <Info className="w-3 h-3" />
                    <span>ข้อมูลใน Discord Embed:</span>
                  </div>
                  <ul className="list-disc list-inside text-slate-400 pl-1">
                    <li>เลขออเดอร์, สินค้า, ยอด, ||คีย์สินค้า||</li>
                  </ul>
                </div>
              </div>

              <div className="pt-1">
                <button
                  type="button"
                  disabled={testingWebhookType === 'order' || !webhookForm.orderUrl}
                  onClick={() => handleTestWebhook('order')}
                  className="w-full py-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-purple-300 font-bold text-[10.5px] flex items-center justify-center gap-1.5 transition disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                >
                  {testingWebhookType === 'order' ? (
                    <>
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      <span>กำลังทดสอบ...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3 h-3" />
                      <span>ทดสอบส่ง Webhook ซื้อสินค้า</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* 4. แจ้งเตือนเติมสต็อคสินค้า */}
            <div className="cyber-card p-3 sm:p-3.5 rounded-xl bg-slate-950/70 border border-emerald-500/30 flex flex-col justify-between space-y-2.5 hover:border-emerald-400/50 transition group">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between pb-2 border-b border-white/5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                      <Key className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white group-hover:text-emerald-300 transition">
                        4. แจ้งเตือนเติมสต็อค
                      </h4>
                      <p className="text-[9px] text-slate-400">Stock Refill Notification</p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={webhookForm.stockEnabled}
                      onChange={e => handleWebhookFieldChange('stockEnabled', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-8 h-4 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                </div>

                <p className="text-[11px] text-slate-300 leading-relaxed">
                  ส่งข้อความแจ้งเตือน Rich Embed แถบสีเขียวสด (#00E676) พร้อมรูปภาพ Thumbnail, จำนวนที่เติม, หมวดหมู่ และวันเวลาภาษาไทย
                </p>

                <div className="space-y-1">
                  <label className="text-[10px] font-semibold text-slate-400 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <span>Discord Webhook URL</span>
                      <span className="text-[8.5px] px-1 py-0.2 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">Auto-saved</span>
                    </span>
                    <span className="text-[9.5px] text-emerald-400 font-mono">
                      {webhookForm.stockUrl ? '✓ บันทึกแล้ว' : 'ยังไม่ได้ใส่'}
                    </span>
                  </label>
                  <textarea
                    rows={2}
                    value={webhookForm.stockUrl}
                    onChange={e => handleWebhookFieldChange('stockUrl', e.target.value)}
                    onBlur={() => handleWebhookFieldChange('stockUrl', webhookForm.stockUrl.trim())}
                    placeholder="https://discord.com/api/webhooks/..."
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-[11px] font-mono focus:outline-none focus:border-emerald-500 resize-none"
                  />
                </div>

                <div className="p-2 rounded-lg bg-emerald-950/30 border border-emerald-500/20 text-[10px] text-slate-300 space-y-0.5">
                  <div className="font-bold text-emerald-400 flex items-center gap-1">
                    <Info className="w-3 h-3" />
                    <span>ข้อมูลใน Discord Embed:</span>
                  </div>
                  <ul className="list-disc list-inside text-slate-400 pl-1">
                    <li>📦 ชื่อสินค้า, 🔢 จำนวน, 📁 หมวดหมู่, 🖼️ รูปภาพ</li>
                  </ul>
                </div>
              </div>

              <div className="pt-1">
                <button
                  type="button"
                  disabled={testingWebhookType === 'stock' || !webhookForm.stockUrl}
                  onClick={() => handleTestWebhook('stock')}
                  className="w-full py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-bold text-[10.5px] flex items-center justify-center gap-1.5 transition disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                >
                  {testingWebhookType === 'stock' ? (
                    <>
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      <span>กำลังทดสอบ...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3 h-3" />
                      <span>ทดสอบส่ง Webhook แจ้งเตือนสต็อค</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Audit Logs Table: ประวัติการส่ง Webhook ล่าสุด */}
          <div className="cyber-card p-3.5 sm:p-4 rounded-2xl bg-slate-950/80 border border-white/10 space-y-3">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5 pb-2.5 border-b border-white/10">
              <div>
                <div className="flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-cyan-400" />
                  <h3 className="text-xs sm:text-sm font-bold text-white">
                    ประวัติการส่ง Webhook ล่าสุด ({webhookLogs.length})
                  </h3>
                </div>
                <p className="text-[10px] text-slate-400">
                  เก็บบันทึกประวัติการยิง Webhook ทั้งสำเร็จและล้มเหลวแบบเรียลไทม์
                </p>
              </div>

              {webhookLogs.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    clearWebhookLogs();
                  }}
                  className="px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-[10.5px] font-bold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>ล้างประวัติ Log</span>
                </button>
              )}
            </div>

            {webhookLogs.length === 0 ? (
              <div className="text-center py-8 text-slate-500 space-y-1.5">
                <Bell className="w-6 h-6 mx-auto text-slate-600 opacity-50" />
                <p className="text-xs">ยังไม่มีประวัติการส่ง Webhook</p>
                <p className="text-[10px] text-slate-600">
                  ระบบจะบันทึกประวัติอัตโนมัติเมื่อมีสมาชิกสมัครใหม่, เติมเงิน, ซื้อสินค้า, หรือเมื่อคุณกดปุ่มทดสอบ
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto rounded-xl border border-white/5">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900/90 text-slate-400 uppercase text-[9.5px] border-b border-white/10 font-bold">
                    <tr>
                      <th className="py-2 px-2.5">วันและเวลา</th>
                      <th className="py-2 px-2.5">ประเภทเหตุการณ์</th>
                      <th className="py-2 px-2.5">หัวข้อ / ข้อมูล</th>
                      <th className="py-2 px-2.5">สถานะส่ง</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {webhookLogs.map(log => {
                      let typeBadge = (
                        <span className="px-1.5 py-0.2 rounded text-[9.5px] font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                          สมัครสมาชิก
                        </span>
                      );
                      if (log.type === 'topup_bank') {
                        typeBadge = (
                          <span className="px-1.5 py-0.2 rounded text-[9.5px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                            เติมเงิน ธนาคาร
                          </span>
                        );
                      } else if (log.type === 'topup_truemoney') {
                        typeBadge = (
                          <span className="px-1.5 py-0.2 rounded text-[9.5px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                            เติมเงิน TrueMoney
                          </span>
                        );
                      } else if (log.type === 'order') {
                        typeBadge = (
                          <span className="px-1.5 py-0.2 rounded text-[9.5px] font-bold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                            คำสั่งซื้อสินค้า
                          </span>
                        );
                      } else if (log.type === 'stock') {
                        typeBadge = (
                          <span className="px-1.5 py-0.2 rounded text-[9.5px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                            แจ้งเตือนเติมสต็อค
                          </span>
                        );
                      } else if (log.type === 'test') {
                        typeBadge = (
                          <span className="px-1.5 py-0.2 rounded text-[9.5px] font-bold bg-blue-500/15 text-blue-300 border border-blue-500/30">
                            ทดสอบระบบ
                          </span>
                        );
                      }

                      return (
                        <tr key={log.id} className="hover:bg-white/[0.02] transition">
                          <td className="py-2 px-2.5 font-mono text-[10px] text-slate-400 whitespace-nowrap">
                            {log.timestamp}
                          </td>
                          <td className="py-2 px-2.5 whitespace-nowrap">{typeBadge}</td>
                          <td className="py-2 px-2.5">
                            <span className="font-bold text-white block text-[11px]">{log.title}</span>
                            <span className="font-mono text-[9.5px] text-slate-400 block truncate max-w-md">
                              {log.details}
                            </span>
                            {log.error && (
                              <span className="text-[9.5px] text-rose-400 block mt-0.5">
                                สาเหตุ: {log.error}
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-2.5 whitespace-nowrap">
                            {log.status === 'success' ? (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[9.5px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                                <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
                                <span>สำเร็จ (204)</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[9.5px] font-bold bg-rose-500/15 text-rose-300 border border-rose-500/30">
                                <XCircle className="w-2.5 h-2.5 text-rose-400" />
                                <span>ล้มเหลว</span>
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 11. Security WAF & Anti-DDoS Center */}
      {activeTab === 'security' && (
        <SecurityTab />
      )}

      {/* 12. User Management System (จัดการผู้ใช้งาน: ชื่อ, รูป, ยอดเงิน, สินค้า) */}
      {activeTab === 'users' && (
        <UserManagerTab />
      )}

      {/* 13. Background Music BGM Management (ระบบเพลงพื้นหลัง & แก้ลิงก์เพลง) */}
      {activeTab === 'music' && (
        <MusicTab />
      )}

      {/* 14. SEO & Discord Embed Management (รูปโปรโมท & แดชบอร์ด SEO) */}
      {activeTab === 'seo' && (
        <SeoTab />
      )}

      {/* 15. Store Branding & Site Content Management (ตั้งค่าร้าน & ข้อมูลเว็บ) */}
      {(activeTab === 'site-content' || (activeTab as string) === 'branding') && (
        <SiteContentTab />
      )}

      {/* 16. Theme Color Manager (ระบบปรับสีเว็บ) */}
      {activeTab === 'theme' && (
        <ThemeTab />
      )}

      {/* 17. Reseller Program & Tiers Management (ตั้งค่าตัวแทนจำหน่าย) */}
      {activeTab === 'reseller' && (
        <ResellerSettingsTab />
      )}
      </div>
    </main>

      {/* ======================================================== */}
      {/* MODAL: EDIT PRODUCT & PACKAGES & PROMO (Requirement 1 & 5) */}
      {/* ======================================================== */}
      {editingProduct && (
        <div
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              playClick();
              setEditingProduct(null);
            }
          }}
          className="fixed inset-0 z-[9999] flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto cursor-pointer"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-lg md:max-w-xl max-h-[90vh] flex flex-col cyber-card rounded-2xl bg-slate-950 border border-cyan-500/40 shadow-2xl overflow-hidden my-auto cursor-default"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-3.5 py-2.5 sm:px-4 sm:py-3 border-b border-white/10 bg-slate-900/90 shrink-0">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
                  <Package className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h3 className="text-xs sm:text-sm font-bold text-white truncate">แก้ไขสินค้า & แพ็กเกจ</h3>
                    <span className="text-[9px] px-1.5 py-0.2 rounded font-mono bg-cyan-950/80 text-cyan-400 border border-cyan-800/40">
                      ID: {editingProduct.id}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="hidden sm:inline-block text-[9.5px] font-mono font-bold text-slate-400 bg-white/5 border border-white/10 px-1.5 py-0.5 rounded">
                  ESC
                </span>
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setEditingProduct(null);
                  }}
                  title="ปิดหน้าต่าง (กด Esc)"
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition shrink-0 cursor-pointer"
                >
                  <XCircle className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="flex items-center border-b border-white/10 bg-black/40 px-2 pt-1 gap-1 shrink-0">
              <button
                type="button"
                onClick={() => setEditModalTab('info')}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold rounded-t-lg transition border-b-2 cursor-pointer ${
                  editModalTab === 'info'
                    ? 'text-cyan-400 border-cyan-400 bg-cyan-950/40'
                    : 'text-slate-400 border-transparent hover:text-slate-200'
                }`}
              >
                <Tag className="w-3 h-3" />
                <span>ข้อมูลสินค้า</span>
              </button>
              <button
                type="button"
                onClick={() => setEditModalTab('packages')}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold rounded-t-lg transition border-b-2 cursor-pointer ${
                  editModalTab === 'packages'
                    ? 'text-cyan-400 border-cyan-400 bg-cyan-950/40'
                    : 'text-slate-400 border-transparent hover:text-slate-200'
                }`}
              >
                <Layers className="w-3 h-3" />
                <span>แพ็กเกจ & คลัง</span>
                <span className="text-[9.5px] px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 font-mono">
                  {editingProduct.packages.length}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setEditModalTab('all')}
                className={`flex items-center gap-1 px-2.5 py-1.5 text-[10.5px] font-medium rounded-t-lg transition border-b-2 cursor-pointer ml-auto ${
                  editModalTab === 'all'
                    ? 'text-cyan-400 border-cyan-400 bg-cyan-950/40 font-bold'
                    : 'text-slate-500 border-transparent hover:text-slate-300'
                }`}
              >
                <span>แสดงทั้งหมด</span>
              </button>
            </div>

            <form onSubmit={handleUpdateProductSubmit} className="flex-1 flex flex-col min-h-0 overflow-hidden">
              <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3">
                {/* 1. GENERAL INFO SECTION */}
                {(editModalTab === 'info' || editModalTab === 'all') && (
                  <div className="space-y-2.5">
                    {/* Product Name */}
                    <div>
                      <label className="block text-[10.5px] font-bold text-slate-300 mb-1">ชื่อสินค้า:</label>
                      <input
                        type="text"
                        required
                        value={editingProduct.name}
                        onChange={e => setEditingProduct({ ...editingProduct, name: e.target.value })}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400"
                      />
                    </div>

                    {/* Category & Status */}
                    <div className="grid grid-cols-2 gap-2 min-w-0">
                      <div className="min-w-0">
                        <label className="block text-[10.5px] font-bold text-slate-300 mb-1 truncate">หมวดหมู่:</label>
                        <select
                          value={editingProduct.categoryId}
                          onChange={e => setEditingProduct({ ...editingProduct, categoryId: e.target.value })}
                          className="w-full px-2 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400 truncate cursor-pointer"
                        >
                          {categories.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>

                      <div className="min-w-0">
                        <label className="block text-[10.5px] font-bold text-slate-300 mb-1 truncate">สถานะสินค้า:</label>
                        <select
                          value={editingProduct.status}
                          onChange={e => setEditingProduct({ ...editingProduct, status: e.target.value as any })}
                          className="w-full px-2 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400 truncate cursor-pointer"
                        >
                          <option value="ready">พร้อมใช้งาน (Online)</option>
                          <option value="updating">กำลังอัพเดท (Updating)</option>
                          <option value="out_of_stock">ปิดปรับปรุง / สินค้าหมด</option>
                        </select>
                      </div>
                    </div>

                    {/* Image URL & Thumbnail Preview */}
                    <div>
                      <label className="block text-[10.5px] font-bold text-slate-300 mb-1">รูปภาพสินค้า:</label>
                      <div className="flex items-center gap-2">
                        <div className="w-10 h-10 rounded-lg border border-white/10 bg-black overflow-hidden shrink-0 flex items-center justify-center">
                          {editingProduct.image ? (
                            <img
                              src={editingProduct.image}
                              alt=""
                              className="w-full h-full object-cover"
                              onError={e => { (e.currentTarget as HTMLElement).style.display = 'none'; }}
                            />
                          ) : (
                            <ImageIcon className="w-4 h-4 text-slate-500" />
                          )}
                        </div>
                        <input
                          type="text"
                          required
                          value={editingProduct.image}
                          onChange={e => setEditingProduct({ ...editingProduct, image: e.target.value })}
                          className="flex-1 min-w-0 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white font-mono focus:outline-none focus:border-cyan-400 truncate"
                        />
                      </div>
                      {/* Compact Image Presets with horizontal scroll */}
                      <div className="flex items-center gap-1 mt-1.5 overflow-x-auto py-0.5 scrollbar-none">
                        <span className="text-[9.5px] text-slate-500 shrink-0">เลือกด่วน:</span>
                        {PRESET_IMAGES.map((img, i) => (
                          <button
                            key={i}
                            type="button"
                            onClick={() => setEditingProduct({ ...editingProduct, image: img.path })}
                            className={`px-1.5 py-0.5 rounded text-[9.5px] shrink-0 border transition cursor-pointer ${
                              editingProduct.image === img.path
                                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 font-bold'
                                : 'bg-slate-900 hover:bg-slate-800 text-slate-400 border-white/5'
                            }`}
                          >
                            {img.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Promo Badge & YouTube */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 min-w-0">
                      <div className="min-w-0">
                        <label className="block text-[10.5px] font-bold text-slate-300 mb-1 truncate">ป้ายโปรโมชั่น (Promo Badge):</label>
                        <div className="flex gap-1.5">
                          <input
                            type="text"
                            placeholder="เช่น NEW, SALE, HOT"
                            value={editingProduct.badge || ''}
                            onChange={e => setEditingProduct({ ...editingProduct, badge: e.target.value || undefined })}
                            className="flex-1 min-w-0 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400"
                          />
                          {editingProduct.badge && (
                            <button
                              type="button"
                              onClick={() => setEditingProduct({ ...editingProduct, badge: undefined })}
                              className="px-2 py-1 rounded-lg bg-rose-500/20 text-rose-300 text-[10px] font-bold shrink-0 hover:bg-rose-500 hover:text-white transition cursor-pointer"
                            >
                              ลบ
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="min-w-0">
                        <label className="block text-[10.5px] font-bold text-slate-300 mb-1 truncate">ลิงก์คลิปรีวิว YouTube:</label>
                        <input
                          type="text"
                          placeholder="https://www.youtube.com/watch?v=..."
                          value={editingProduct.youtubeUrl || ''}
                          onChange={e => setEditingProduct({ ...editingProduct, youtubeUrl: e.target.value })}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono truncate"
                        />
                      </div>
                    </div>

                    {/* Product Full Description */}
                    <div>
                      <label className="block text-[10.5px] font-bold text-slate-300 mb-1">คำอธิบายสินค้า (Description):</label>
                      <textarea
                        rows={2.5}
                        placeholder="รายละเอียดสินค้า คุณสมบัติ ฟังก์ชันการทำงานต่างๆ..."
                        value={editingProduct.description || ''}
                        onChange={e => setEditingProduct({ ...editingProduct, description: e.target.value })}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400 font-sans leading-relaxed"
                      />
                    </div>
                  </div>
                )}

                {/* 2. PACKAGES MANAGEMENT SECTION */}
                {(editModalTab === 'packages' || editModalTab === 'all') && (
                  <div className={`space-y-2.5 ${editModalTab === 'all' ? 'pt-3 border-t border-slate-800' : ''}`}>
                    {/* Option Type Selector (ตัวเลือกเดียว หรือ หลายตัวเลือก) */}
                    <div className="p-3 rounded-xl bg-slate-900 border border-cyan-500/20 space-y-2">
                      <label className="block text-[10.5px] font-bold text-slate-300">
                        รูปแบบตัวเลือกสินค้า (Product Type):
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            playClick();
                            const firstPkg = editingProduct.packages[0] || {
                              id: 'pkg-1',
                              name: 'สินค้า',
                              duration: 'ถาวร',
                              price: 100,
                              stock: 10,
                              inStock: true
                            };
                            setEditingProduct({
                              ...editingProduct,
                              optionType: 'single',
                              packages: [firstPkg]
                            });
                          }}
                          className={`px-3 py-2 rounded-lg border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                            editingProduct.optionType === 'single' || editingProduct.packages.length <= 1
                              ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-sm'
                              : 'bg-black/40 border-white/10 text-slate-400 hover:text-white'
                          }`}
                        >
                          <span>ตัวเลือกเดียว (Single Option)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            playClick();
                            let pkgs = editingProduct.packages;
                            if (pkgs.length <= 1) {
                              pkgs = [
                                { id: 'pkg-' + Date.now() + '-1', name: 'แพ็กเกจ 1 วัน', duration: '1 วัน', price: 20, stock: 50, inStock: true },
                                { id: 'pkg-' + Date.now() + '-7', name: 'แพ็กเกจ 7 วัน', duration: '7 วัน', price: 80, stock: 30, inStock: true },
                                { id: 'pkg-' + Date.now() + '-30', name: 'แพ็กเกจ 30 วัน', duration: '30 วัน', price: 200, stock: 20, inStock: true }
                              ];
                            }
                            setEditingProduct({
                              ...editingProduct,
                              optionType: 'multiple',
                              packages: pkgs
                            });
                          }}
                          className={`px-3 py-2 rounded-lg border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                            editingProduct.optionType === 'multiple' || editingProduct.packages.length > 1
                              ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-sm'
                              : 'bg-black/40 border-white/10 text-slate-400 hover:text-white'
                          }`}
                        >
                          <span>หลายตัวเลือก (Multi / Packages)</span>
                        </button>
                      </div>

                      {/* Custom UID / Input Settings */}
                      <div className="pt-2 border-t border-white/5 space-y-2">
                        <label className="flex items-center gap-2 text-xs font-bold text-white cursor-pointer select-none">
                          <input
                            type="checkbox"
                            checked={Boolean(editingProduct.requiresCustomInput)}
                            onChange={(e) => setEditingProduct({ ...editingProduct, requiresCustomInput: e.target.checked })}
                            className="w-4 h-4 accent-cyan-400 cursor-pointer"
                          />
                          <span>ต้องการให้ลูกค้าระบุข้อมูลเพิ่มเติม (เช่น UID / ชื่อในเกม)</span>
                        </label>

                        {editingProduct.requiresCustomInput && (
                          <div className="grid grid-cols-2 gap-2 pt-1">
                            <div>
                              <label className="block text-[10px] text-slate-400 mb-0.5">ชื่อหัวข้อฟิลด์:</label>
                              <input
                                type="text"
                                placeholder="เช่น UID ของคุณ"
                                value={editingProduct.customInputLabel || ''}
                                onChange={(e) => setEditingProduct({ ...editingProduct, customInputLabel: e.target.value })}
                                className="w-full px-2 py-1 rounded bg-black/60 border border-slate-700 text-xs text-white"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-slate-400 mb-0.5">ข้อความตัวอย่าง (Placeholder):</label>
                              <input
                                type="text"
                                placeholder="เช่น 123456789"
                                value={editingProduct.customInputPlaceholder || ''}
                                onChange={(e) => setEditingProduct({ ...editingProduct, customInputPlaceholder: e.target.value })}
                                className="w-full px-2 py-1 rounded bg-black/60 border border-slate-700 text-xs text-white"
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Discount Badge & Guarantee */}
                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/5">
                        <div>
                          <label className="block text-[10px] text-slate-400 mb-0.5">ป้ายลดราคา (Discount Badge):</label>
                          <input
                            type="text"
                            placeholder="เช่น -40% หรือ -60%"
                            value={editingProduct.discountBadge || ''}
                            onChange={(e) => setEditingProduct({ ...editingProduct, discountBadge: e.target.value || undefined })}
                            className="w-full px-2 py-1 rounded bg-black/60 border border-slate-700 text-xs text-white font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-400 mb-0.5">วันรับประกัน (วัน):</label>
                          <input
                            type="number"
                            placeholder="999"
                            value={editingProduct.guaranteeDays || 999}
                            onChange={(e) => setEditingProduct({ ...editingProduct, guaranteeDays: parseInt(e.target.value) || 999 })}
                            className="w-full px-2 py-1 rounded bg-black/60 border border-slate-700 text-xs text-white font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Header + Presets */}
                    <div className="flex items-center justify-between gap-1 flex-wrap bg-black/40 p-2 rounded-lg border border-white/5">
                      <span className="text-[10px] text-slate-400 font-medium">ทางลัดจัดเซ็ต:</span>
                      <div className="flex flex-wrap gap-1">
                        <button
                          type="button"
                          onClick={() => applyPackagePreset('1d_only', 'edit')}
                          className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-slate-300 font-bold transition cursor-pointer"
                        >
                          1 วัน
                        </button>
                        <button
                          type="button"
                          onClick={() => applyPackagePreset('7d_only', 'edit')}
                          className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-slate-300 font-bold transition cursor-pointer"
                        >
                          7 วัน
                        </button>
                        <button
                          type="button"
                          onClick={() => applyPackagePreset('14d_only', 'edit')}
                          className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-slate-300 font-bold transition cursor-pointer"
                        >
                          14 วัน
                        </button>
                        <button
                          type="button"
                          onClick={() => applyPackagePreset('lifetime_only', 'edit')}
                          className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-slate-300 font-bold transition cursor-pointer"
                        >
                          ถาวร
                        </button>
                        <button
                          type="button"
                          onClick={() => applyPackagePreset('all_5', 'edit')}
                          className="px-2 py-0.5 rounded text-[10px] bg-cyan-500/20 hover:bg-cyan-500 hover:text-slate-950 text-cyan-300 font-bold transition border border-cyan-500/30 cursor-pointer"
                        >
                          รวมทุกแพ็ก
                        </button>
                      </div>
                    </div>

                    {/* Packages Editor List */}
                    <div className="space-y-2">
                      {editingProduct.packages.map((pkg, pIdx) => (
                        <div key={pkg.id || pIdx} className="p-2.5 rounded-xl bg-slate-900/90 border border-white/5 hover:border-cyan-500/20 transition space-y-2">
                          {/* Row 1: Duration input + inStock toggle + delete */}
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-1.5 flex-1 min-w-0">
                              <span className="text-[10px] text-slate-400 shrink-0 font-medium">ชื่อแพ็ก:</span>
                              <input
                                type="text"
                                placeholder="เช่น 1 วัน, ถาวร"
                                value={pkg.duration}
                                onChange={e => {
                                  const updated = [...editingProduct.packages];
                                  updated[pIdx].duration = e.target.value;
                                  updated[pIdx].name = `ใช้งาน ${e.target.value}`;
                                  setEditingProduct({ ...editingProduct, packages: updated });
                                }}
                                className="flex-1 min-w-0 px-2 py-1 rounded bg-black/60 border border-slate-700 text-xs text-white focus:border-cyan-400"
                              />
                            </div>
                            
                            <label className="flex items-center gap-1 text-[10px] text-slate-300 cursor-pointer shrink-0 select-none bg-black/40 px-2 py-1 rounded border border-white/5">
                              <input
                                type="checkbox"
                                checked={pkg.inStock}
                                onChange={e => {
                                  const updated = [...editingProduct.packages];
                                  updated[pIdx].inStock = e.target.checked;
                                  setEditingProduct({ ...editingProduct, packages: updated });
                                }}
                                className="w-3.5 h-3.5 accent-cyan-400 cursor-pointer"
                              />
                              <span>เปิดขาย</span>
                            </label>

                            {editingProduct.packages.length > 1 && (
                              <button
                                type="button"
                                onClick={() => {
                                  const updated = editingProduct.packages.filter((_, idx) => idx !== pIdx);
                                  setEditingProduct({ ...editingProduct, packages: updated });
                                }}
                                className="p-1 rounded text-rose-400 hover:text-white hover:bg-rose-500/20 transition shrink-0 cursor-pointer"
                                title="ลบแพ็กเกจนี้"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>

                          {/* Row 2: Price + Stock + Manage Keys */}
                          <div className="flex items-center gap-2 pt-1 border-t border-white/5">
                            <div className="flex items-center gap-1 flex-1 min-w-0">
                              <span className="text-[10px] text-slate-400 shrink-0">ราคา:</span>
                              <div className="relative flex-1 min-w-0">
                                <span className="absolute left-1.5 top-1/2 -translate-y-1/2 text-[10px] text-slate-500 font-bold">฿</span>
                                <input
                                  type="number"
                                  placeholder="0"
                                  value={pkg.price}
                                  onChange={e => {
                                    const updated = [...editingProduct.packages];
                                    updated[pIdx].price = parseFloat(e.target.value) || 0;
                                    setEditingProduct({ ...editingProduct, packages: updated });
                                  }}
                                  className="w-full pl-4 pr-1 py-1 rounded bg-black/60 border border-slate-700 text-xs text-cyan-400 font-mono font-bold focus:border-cyan-400"
                                />
                              </div>
                            </div>

                            <div className="flex items-center gap-1 flex-1 min-w-0">
                              <span className="text-[10px] text-slate-400 shrink-0">สต็อก:</span>
                              <input
                                type="number"
                                placeholder="0"
                                value={pkg.stock}
                                onChange={e => {
                                  const updated = [...editingProduct.packages];
                                  const s = parseInt(e.target.value) || 0;
                                  updated[pIdx].stock = s;
                                  updated[pIdx].inStock = s > 0;
                                  setEditingProduct({ ...editingProduct, packages: updated });
                                }}
                                className="w-full px-1.5 py-1 rounded bg-black/60 border border-slate-700 text-xs text-white font-mono focus:border-cyan-400"
                              />
                            </div>

                            <button
                              type="button"
                              onClick={() => openStockManager(editingProduct, pkg.id)}
                              className="px-2 py-1 rounded bg-amber-500/15 hover:bg-amber-500 text-amber-300 hover:text-slate-950 text-[10px] font-bold transition flex items-center gap-1 shrink-0 border border-amber-500/30 cursor-pointer shadow-sm"
                              title="จัดการคลังคีย์และไฟล์"
                            >
                              <Key className="w-3 h-3" />
                              <span>คลัง ({pkg.stockItems ? pkg.stockItems.filter(s => !s.isUsed).length : pkg.stock})</span>
                            </button>
                          </div>
                        </div>
                      ))}

                      <button
                        type="button"
                        onClick={() => {
                          const newP: ProductPackage = {
                            id: 'pkg-' + Date.now(),
                            name: 'แพ็กเกจใหม่',
                            duration: '7 วัน',
                            price: 100,
                            stock: 10,
                            inStock: true
                          };
                          setEditingProduct({ ...editingProduct, packages: [...editingProduct.packages, newP] });
                        }}
                        className="w-full py-1.5 rounded-lg border border-dashed border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/10 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>เพิ่มแพ็กเกจใหม่</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Sticky Footer */}
              <div className="px-3.5 py-2.5 sm:px-4 sm:py-3 border-t border-slate-800 bg-slate-950/95 flex items-center justify-between gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    deleteProduct(editingProduct.id);
                    setEditingProduct(null);
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/30 text-xs font-bold transition flex items-center gap-1 cursor-pointer shadow-sm"
                  title="ลบสินค้านี้"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">ลบสินค้านี้</span>
                  <span className="sm:hidden">ลบ</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      playClick();
                      setEditingProduct(null);
                    }}
                    title="ยกเลิกและปิดหน้าต่าง (กด Esc)"
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer transition flex items-center gap-1"
                  >
                    <span>ยกเลิก</span>
                    <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">(Esc)</span>
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg cyber-btn-primary font-bold text-xs shadow-md shadow-cyan-500/30 flex items-center gap-1.5 cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>บันทึก</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: BULK STORE PROMOTION (Requirement 1) */}
      {/* ======================================================== */}
      {showBulkPromoModal && (
        <div
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              playClick();
              setShowBulkPromoModal(false);
            }
          }}
          className="fixed inset-0 z-[9999] flex items-center justify-center p-3 bg-black/80 backdrop-blur-md cursor-pointer"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-md cyber-card rounded-2xl p-4 sm:p-5 bg-slate-950 border border-amber-500/40 shadow-2xl space-y-3 cursor-default"
          >
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-1.5 text-amber-400">
                <Flame className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm sm:text-base font-black text-white">ระบบจัดโปรโมชั่นรวมทั้งร้าน</h3>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[9.5px] font-mono font-bold text-slate-400 bg-white/5 border border-white/10 px-1.5 py-0.5 rounded">
                  ESC
                </span>
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setShowBulkPromoModal(false);
                  }}
                  title="ปิดหน้าต่าง (กด Esc)"
                  className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
                >
                  <XCircle className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="space-y-2.5">
              <p className="text-[11px] text-slate-300">
                ระบบจะคำนวณปรับลดราคาสินค้าทุกชิ้นโดยอิงจากราคาเดิม พร้อมติดป้ายโปรโมชั่นหน้าร้านให้อัตโนมัติในคลิกเดียว
              </p>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  ขอบเขตที่ต้องการจัดโปรโมชั่น:
                </label>
                <select
                  value={bulkCategoryScope}
                  onChange={e => setBulkCategoryScope(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="all">สินค้าทุกชิ้นในร้าน (ทั้งเว็บไซต์)</option>
                  {categories.map(c => (
                    <option key={c.id} value={c.id}>เฉพาะหมวดหมู่ {c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  เปอร์เซ็นต์ส่วนลด: <strong className="text-amber-400 font-mono text-sm">{bulkDiscount}%</strong>
                </label>
                <div className="flex items-center gap-1.5 mb-1.5">
                  {[10, 15, 20, 30, 50].map(pct => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => setBulkDiscount(pct)}
                      className={`px-2.5 py-0.5 rounded text-xs font-bold transition ${
                        bulkDiscount === pct
                          ? 'bg-amber-500 text-slate-950 font-black'
                          : 'bg-slate-800 text-slate-300 hover:text-white'
                      }`}
                    >
                      {pct}%
                    </button>
                  ))}
                </div>
                <input
                  type="range"
                  min="5"
                  max="80"
                  step="5"
                  value={bulkDiscount}
                  onChange={e => setBulkDiscount(parseInt(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  ข้อความบนป้ายโปรโมชั่น:
                </label>
                <input
                  type="text"
                  value={bulkBadge}
                  onChange={e => setBulkBadge(e.target.value)}
                  placeholder="เช่น SALE 20%, HOT DEAL"
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="pt-2.5 border-t border-slate-800 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('ต้องการยกเลิกโปรโมชั่นและคืนราคาเดิมใช่หรือไม่?')) {
                      clearGlobalPromotion(bulkCategoryScope);
                      setShowBulkPromoModal(false);
                    }
                  }}
                  className="px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-white text-xs font-bold transition"
                >
                  คืนราคาเดิม
                </button>

                <button
                  type="button"
                  onClick={() => {
                    applyGlobalPromotion(bulkDiscount, bulkBadge, bulkCategoryScope);
                    setShowBulkPromoModal(false);
                  }}
                  className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-slate-950 font-black text-xs shadow-md transition"
                >
                  🚀 ใช้งานโปรโมชั่นทันที
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: ADD NEW PRODUCT */}
      {/* ======================================================== */}
      {showAddProductModal && (
        <div
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              playClick();
              setShowAddProductModal(false);
            }
          }}
          className="fixed inset-0 z-[9999] flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto cursor-pointer"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-lg max-h-[90vh] flex flex-col cyber-card rounded-2xl bg-slate-950 border border-cyan-500/40 shadow-2xl overflow-hidden my-auto cursor-default"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-3.5 py-2.5 sm:px-4 sm:py-3 border-b border-white/10 bg-slate-900/90 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
                  <Plus className="w-4 h-4" />
                </div>
                <h3 className="text-xs sm:text-sm font-bold text-white">เพิ่มสินค้าใหม่ลงในร้าน</h3>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="hidden sm:inline-block text-[9.5px] font-mono font-bold text-slate-400 bg-white/5 border border-white/10 px-1.5 py-0.5 rounded">
                  ESC
                </span>
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setShowAddProductModal(false);
                  }}
                  title="ปิดหน้าต่าง (กด Esc)"
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition shrink-0 cursor-pointer"
                >
                  <XCircle className="w-4 h-4" />
                </button>
              </div>
            </div>

            <form onSubmit={handleCreateProduct} className="flex-1 flex flex-col min-h-0 overflow-hidden">
              <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3">
                {/* Product Name */}
                <div>
                  <label className="block text-[10.5px] font-bold text-slate-300 mb-1">ชื่อสินค้า:</label>
                  <input
                    type="text"
                    required
                    placeholder="เช่น โปร FiveM Aimbot V3"
                    value={newProdName}
                    onChange={e => setNewProdName(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                {/* Category & Image in 2 cols */}
                <div className="grid grid-cols-2 gap-2 min-w-0">
                  <div className="min-w-0">
                    <label className="block text-[10.5px] font-bold text-slate-300 mb-1 truncate">หมวดหมู่:</label>
                    <select
                      value={newProdCategory}
                      onChange={e => setNewProdCategory(e.target.value)}
                      className="w-full px-2 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400 truncate cursor-pointer"
                    >
                      {categories.map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="min-w-0">
                    <label className="block text-[10.5px] font-bold text-slate-300 mb-1 truncate">รูปภาพสินค้า:</label>
                    <input
                      type="text"
                      value={newProdImage}
                      onChange={e => setNewProdImage(e.target.value)}
                      className="w-full px-2 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white font-mono truncate focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-[10.5px] font-bold text-slate-300 mb-1">คำอธิบายย่อ:</label>
                  <textarea
                    rows={2}
                    placeholder="ฟังก์ชันและจุดเด่นของสินค้า..."
                    value={newProdDesc}
                    onChange={e => setNewProdDesc(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                {/* YouTube Review */}
                <div>
                  <label className="block text-[10.5px] font-bold text-slate-300 mb-1">ลิงก์คลิปรีวิว YouTube:</label>
                  <input
                    type="text"
                    placeholder="https://www.youtube.com/watch?v=... หรือ Video ID"
                    value={newProdYoutubeUrl}
                    onChange={e => setNewProdYoutubeUrl(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                  />
                </div>

                {/* Quick Presets for New Product Packages */}
                <div className="pt-2 border-t border-slate-800 space-y-1.5">
                  <span className="text-[10.5px] font-bold text-cyan-400">เลือกแพ็กเกจระยะเวลาเริ่มต้น:</span>
                  <div className="flex flex-wrap gap-1">
                    <button
                      type="button"
                      onClick={() => applyPackagePreset('1d_only', 'new')}
                      className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-slate-300 font-bold transition cursor-pointer"
                    >
                      1 วัน
                    </button>
                    <button
                      type="button"
                      onClick={() => applyPackagePreset('7d_only', 'new')}
                      className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-slate-300 font-bold transition cursor-pointer"
                    >
                      7 วัน
                    </button>
                    <button
                      type="button"
                      onClick={() => applyPackagePreset('lifetime_only', 'new')}
                      className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-slate-300 font-bold transition cursor-pointer"
                    >
                      ถาวร
                    </button>
                    <button
                      type="button"
                      onClick={() => applyPackagePreset('all_5', 'new')}
                      className="px-2 py-0.5 rounded text-[10px] bg-cyan-500/20 hover:bg-cyan-500 hover:text-slate-950 text-cyan-300 font-bold transition border border-cyan-500/30 cursor-pointer"
                    >
                      รวมทุกแพ็ก
                    </button>
                  </div>
                </div>
              </div>

              {/* Sticky Footer */}
              <div className="px-3.5 py-2.5 sm:px-4 sm:py-3 border-t border-slate-800 bg-slate-950/95 flex items-center justify-end gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setShowAddProductModal(false);
                  }}
                  title="ยกเลิกและปิดหน้าต่าง (กด Esc)"
                  className="px-3.5 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700 transition cursor-pointer flex items-center gap-1"
                >
                  <span>ยกเลิก</span>
                  <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">(Esc)</span>
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg cyber-btn-primary font-bold text-xs shadow-md shadow-cyan-500/30 cursor-pointer"
                >
                  เพิ่มสินค้า
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: ADD NEW IMAGE SLIDE (มีแค่ช่องใส่ลิงก์รูป + ปลายทาง) */}
      {/* ======================================================== */}
      {showAddSlideModal && (
        <div
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              playClick();
              setShowAddSlideModal(false);
            }
          }}
          className="fixed inset-0 z-[9999] flex items-center justify-center p-3 bg-black/80 backdrop-blur-md cursor-pointer"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-md cyber-card rounded-2xl p-4 sm:p-5 bg-slate-950 border border-cyan-500/40 shadow-2xl space-y-3 cursor-default"
          >
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-cyan-400" />
                <span>เพิ่มรูปสไลด์ใหม่หน้าหลัก</span>
              </h3>
              <div className="flex items-center gap-1.5">
                <span className="text-[9.5px] font-mono font-bold text-slate-400 bg-white/5 border border-white/10 px-1.5 py-0.5 rounded">
                  ESC
                </span>
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setShowAddSlideModal(false);
                  }}
                  title="ปิดหน้าต่าง (กด Esc)"
                  className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
                >
                  <XCircle className="w-4 h-4" />
                </button>
              </div>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                addSlide({
                  image: newSlideImage || '/catalog/imported/banner_fivem.webp',
                  ctaAction: newSlideAction || 'all',
                  title: 'รูปสไลด์ #' + (slides.length + 1),
                  badge: 'PROMO',
                  badgeColor: 'border-cyan-500/40 text-cyan-400 bg-cyan-500/10',
                  subtitle: [],
                  description: '',
                  ctaText: 'SHOP CLICK',
                  accentColor: '#00e5ff',
                  theme: 'arx-brand',
                  isActive: true
                });
                setShowAddSlideModal(false);
              }}
              className="space-y-2.5"
            >
              {/* Image Preview in Modal */}
              <div className="relative aspect-[21/9] max-h-36 rounded-xl overflow-hidden bg-slate-900 border border-white/10 flex items-center justify-center">
                {newSlideImage ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={newSlideImage}
                    alt="Preview"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.currentTarget;
                      if (!target.src.includes('banner_fivem.webp')) {
                        target.src = '/catalog/imported/banner_fivem.webp';
                      }
                    }}
                  />
                ) : (
                  <div className="text-center p-3">
                    <ImageIcon className="w-6 h-6 text-slate-600 mx-auto mb-1" />
                    <span className="text-[11px] text-slate-500">กรุณาใส่ลิงก์รูปภาพด้านล่าง</span>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  ช่องใส่ลิงก์รูปภาพ (Image Link):
                </label>
                <input
                  type="text"
                  required
                  value={newSlideImage}
                  onChange={e => setNewSlideImage(e.target.value)}
                  placeholder="https://... หรือ /catalog/imported/banner_fivem.webp"
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-cyan-400"
                />

                {/* Preset suggestions */}
                <div className="flex flex-wrap gap-1 mt-1.5">
                  <button
                    type="button"
                    onClick={() => setNewSlideImage('/catalog/imported/banner_fivem.webp')}
                    className="text-[9.5px] px-1.5 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-white/10 cursor-pointer"
                  >
                    FiveM
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewSlideImage('/catalog/imported/banner_cheat.webp')}
                    className="text-[9.5px] px-1.5 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-white/10 cursor-pointer"
                  >
                    Cheat
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewSlideImage('/catalog/imported/5a29b53cb71e055f96b8.webp')}
                    className="text-[9.5px] px-1.5 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-white/10 cursor-pointer"
                  >
                    CustomOS
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  ปลายทางเมื่อคลิกรูปนี้:
                </label>
                <select
                  value={newSlideAction}
                  onChange={e => setNewSlideAction(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400 cursor-pointer"
                >
                  <option value="all">สินค้าทั้งหมด (All Categories)</option>
                  {categories.map(c => (
                    <option key={c.id} value={c.id}>หมวดหมู่: {c.name}</option>
                  ))}
                </select>
              </div>

              <div className="pt-2.5 border-t border-slate-800 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setShowAddSlideModal(false);
                  }}
                  title="ยกเลิกและปิดหน้าต่าง (กด Esc)"
                  className="px-3.5 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700 transition cursor-pointer flex items-center gap-1"
                >
                  <span>ยกเลิก</span>
                  <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">(Esc)</span>
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg cyber-btn-primary font-bold text-xs shadow-md shadow-cyan-500/30 flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> เพิ่มรูปสไลด์
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* EDIT CATEGORY MODAL */}
      {/* ======================================================== */}
      {editingCategory && (
        <div
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              playClick();
              setEditingCategory(null);
            }
          }}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 cursor-pointer"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-slate-950 border border-cyan-500/30 rounded-2xl max-w-md w-full max-h-[92vh] overflow-y-auto p-4 sm:p-5 shadow-2xl relative space-y-3 cursor-default"
          >
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-1.5">
                <Edit className="w-4 h-4 text-cyan-400" />
                <span>แก้ไขหมวดหมู่ (รูปภาพ & ลิงก์)</span>
              </h3>
              <div className="flex items-center gap-1.5">
                <span className="text-[9.5px] font-mono font-bold text-slate-400 bg-white/5 border border-white/10 px-1.5 py-0.5 rounded">
                  ESC
                </span>
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setEditingCategory(null);
                  }}
                  title="ปิดหน้าต่าง (กด Esc)"
                  className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
                >
                  <XCircle className="w-4 h-4" />
                </button>
              </div>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!editingCategory) return;
                const existing = categories.find(c => c.id === editingCategory.id);
                if (existing) {
                  updateCategory(editingCategory.id, {
                    name: editingCategory.name,
                    description: editingCategory.description,
                    image: editingCategory.image,
                    linkUrl: editingCategory.linkUrl
                  });
                } else {
                  addCategory(editingCategory);
                }
                setEditingCategory(null);
              }}
              className="space-y-3 text-xs"
            >
              {/* Image Preview: Circular Icon & Banner */}
              <div className="space-y-2">
                <label className="block font-bold text-slate-300 text-[11px] flex items-center justify-between">
                  <span>ตัวอย่างรูปหมวดหมู่ (วงกลม & แบนเนอร์):</span>
                  <span className="text-[9.5px] text-cyan-400 font-mono">Circle & Banner Preview</span>
                </label>
                
                <div className="flex items-center gap-3.5 p-3 rounded-xl bg-slate-900/80 border border-white/10 shadow-inner">
                  {/* Circular Avatar Preview */}
                  <div className="flex flex-col items-center gap-1 shrink-0">
                    <div className="w-14 h-14 rounded-full overflow-hidden bg-slate-950 border-2 border-cyan-400 shadow-[0_0_15px_rgba(var(--theme-accent-rgb),0.25)] flex items-center justify-center">
                      {editingCategory.image ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={editingCategory.image}
                          alt={editingCategory.name}
                          className="w-full h-full object-cover rounded-full"
                          onError={(e) => {
                            const target = e.currentTarget;
                            if (!target.src.includes('banner_fivem.webp')) {
                              target.src = '/catalog/imported/banner_fivem.webp';
                            }
                          }}
                        />
                      ) : (
                        <ImageIcon className="w-5 h-5 text-slate-600" />
                      )}
                    </div>
                    <span className="text-[9.5px] text-cyan-300 font-bold">ไอคอนวงกลม</span>
                  </div>

                  {/* Wide Banner Preview */}
                  <div className="flex-1 relative aspect-[21/9] max-h-24 rounded-lg overflow-hidden bg-slate-950 border border-white/10 flex items-center justify-center group shadow-sm">
                    {editingCategory.image ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={editingCategory.image}
                        alt={editingCategory.name}
                        className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-300"
                        onError={(e) => {
                          const target = e.currentTarget;
                          if (!target.src.includes('banner_fivem.webp')) {
                            target.src = '/catalog/imported/banner_fivem.webp';
                          }
                        }}
                      />
                    ) : (
                      <span className="text-[10px] text-slate-500">กรุณาใส่ลิงก์รูปภาพ</span>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2 pointer-events-none">
                      <span className="text-white font-bold text-xs truncate drop-shadow-md">
                        {editingCategory.name || 'ชื่อหมวดหมู่'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Image Input & Presets */}
              <div>
                <label className="block font-bold text-slate-300 mb-1 text-[11px]">
                  ลิงก์รูปภาพหมวดหมู่ (Image URL):
                </label>
                <input
                  type="text"
                  required
                  value={editingCategory.image || ''}
                  onChange={e => setEditingCategory({ ...editingCategory, image: e.target.value })}
                  placeholder="https://... หรือ /catalog/imported/banner_fivem.webp"
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white font-mono focus:outline-none focus:border-cyan-400"
                />
                <div className="flex flex-wrap gap-1 mt-1.5">
                  <span className="text-[9.5px] text-slate-400 self-center">รูปสำเร็จ:</span>
                  <button
                    type="button"
                    onClick={() => setEditingCategory({ ...editingCategory, image: '/catalog/imported/banner_fivem.webp' })}
                    className="text-[9.5px] px-1.5 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-white/10 cursor-pointer"
                  >
                    FiveM
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingCategory({ ...editingCategory, image: '/catalog/imported/banner_cheat.webp' })}
                    className="text-[9.5px] px-1.5 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-white/10 cursor-pointer"
                  >
                    Cheat
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingCategory({ ...editingCategory, image: '/catalog/imported/banner_customos.webp' })}
                    className="text-[9.5px] px-1.5 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-white/10 cursor-pointer"
                  >
                    CustomOS
                  </button>
                </div>
              </div>

              {/* Link URL Input & Presets */}
              <div>
                <label className="block font-bold text-slate-300 mb-1 text-[11px]">
                  ลิงก์ปลายทางเมื่อคลิกหมวดหมู่ (Link URL):
                </label>
                <input
                  type="text"
                  required
                  value={editingCategory.linkUrl || ''}
                  onChange={e => setEditingCategory({ ...editingCategory, linkUrl: e.target.value })}
                  placeholder={`/store?category=${editingCategory.id}#products-catalog`}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white font-mono focus:outline-none focus:border-cyan-400"
                />
                <div className="flex flex-wrap gap-1 mt-1.5">
                  <span className="text-[9.5px] text-slate-400 self-center">ทางลัด:</span>
                  <button
                    type="button"
                    onClick={() => setEditingCategory({ ...editingCategory, linkUrl: `/store?category=${editingCategory.id}#products-catalog` })}
                    className="text-[9.5px] px-1.5 py-0.5 rounded bg-cyan-950/40 hover:bg-cyan-900/50 text-cyan-300 border border-cyan-500/30 cursor-pointer"
                  >
                    กรองหมวดหมู่
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingCategory({ ...editingCategory, linkUrl: '/store' })}
                    className="text-[9.5px] px-1.5 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-white/10 cursor-pointer"
                  >
                    หน้าร้านค้า
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingCategory({ ...editingCategory, linkUrl: '/topup' })}
                    className="text-[9.5px] px-1.5 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-white/10 cursor-pointer"
                  >
                    หน้าเติมเงิน
                  </button>
                </div>
              </div>

              {/* Name & ID Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div className="sm:col-span-1">
                  <label className="block font-bold text-slate-300 mb-1 text-[11px]">รหัส (ID):</label>
                  <input
                    type="text"
                    disabled
                    value={editingCategory.id}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-500 font-mono text-xs"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block font-bold text-slate-300 mb-1 text-[11px]">ชื่อหมวดหมู่:</label>
                  <input
                    type="text"
                    required
                    value={editingCategory.name}
                    onChange={e => setEditingCategory({ ...editingCategory, name: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-cyan-400 font-bold text-xs"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block font-bold text-slate-300 mb-1 text-[11px]">คำอธิบายย่อ:</label>
                <textarea
                  rows={2}
                  value={editingCategory.description || ''}
                  onChange={e => setEditingCategory({ ...editingCategory, description: e.target.value })}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-cyan-400 text-xs"
                  placeholder="คำอธิบายสั้นๆ ของหมวดหมู่"
                />
              </div>

              <div className="pt-2.5 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setEditingCategory(null);
                  }}
                  title="ยกเลิกและปิดหน้าต่าง (กด Esc)"
                  className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold cursor-pointer text-xs flex items-center gap-1"
                >
                  <span>ยกเลิก</span>
                  <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">(Esc)</span>
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg cyber-btn-primary font-bold shadow-md shadow-cyan-500/25 cursor-pointer flex items-center gap-1.5 text-xs"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>บันทึกการแก้ไข</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Digital Stock Manager Modal (จัดการคลังสต็อก: คีย์, ลิงก์ดาวน์โหลด, ไฟล์) */}
      <StockManagerModal
        product={managingStockProduct}
        initialPackageId={managingStockPackageId}
        isOpen={!!managingStockProduct}
        onClose={() => setManagingStockProduct(null)}
      />

    </div>
  );
}
