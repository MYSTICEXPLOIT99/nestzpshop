import { NextResponse } from 'next/server';
import {
  getOrders,
  getOrdersByUserId,
  createOrder,
  getUserById,
  adjustUserBalance,
  getSessionFromRequest,
  validateCouponCode,
  recordCouponUsage
} from '@/lib/server/db';
import { dispatchDiscordNotification } from '@/lib/server/discord';

const recentOrderSignatures = new Map<string, number>();

export async function GET(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    const { searchParams } = new URL(request.url);
    const queryUserId = searchParams.get('userId');

    // Admin can see all or specific user's orders
    if (session?.role === 'admin') {
      if (queryUserId) {
        return NextResponse.json({ success: true, data: getOrdersByUserId(queryUserId) });
      }
      return NextResponse.json({ success: true, data: getOrders() });
    }

    // Authenticated user can see their own orders
    if (session) {
      const userOrders = getOrdersByUserId(session.userId);
      return NextResponse.json({ success: true, data: userOrders });
    }

    // IDOR Protection: Anonymous requests cannot query arbitrary user orders
    if (queryUserId) {
      return NextResponse.json(
        { success: false, error: 'กรุณาเข้าสู่ระบบเพื่อดูประวัติคำสั่งซื้อ' },
        { status: 401 }
      );
    }

    return NextResponse.json({
      success: true,
      data: [],
      message: 'Authentication required'
    });
  } catch (err) {
    return NextResponse.json({ success: false, error: 'Failed to fetch orders' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    const body = await request.json();
    const {
      productId,
      productName,
      packageId,
      packageName,
      price,
      couponCode,
      downloadUrl,
      instructions,
      idempotencyKey
    } = body;

    // Must be logged in to buy
    if (!session) {
      return NextResponse.json(
        { success: false, message: 'กรุณาเข้าสู่ระบบก่อนทำการสั่งซื้อสินค้า' },
        { status: 401 }
      );
    }

    const user = getUserById(session.userId);
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'ไม่พบข้อมูลผู้ใช้งานในระบบ' },
        { status: 404 }
      );
    }

    const basePrice = Math.max(0, Number(price) || 0);

    // Validate Coupon on Server
    let finalPrice = basePrice;
    if (couponCode && typeof couponCode === 'string') {
      const couponRes = validateCouponCode(couponCode, basePrice);
      if (couponRes.valid && couponRes.discountAmount) {
        finalPrice = Math.max(0, basePrice - couponRes.discountAmount);
        recordCouponUsage(couponCode);
      }
    }

    // Server-Side Balance Check
    if (user.balance < finalPrice) {
      return NextResponse.json(
        {
          success: false,
          message: `ยอดเงินคงเหลือไม่เพียงพอ (ยอดเงินในบัญชี: ฿${user.balance.toLocaleString()} | ราคาสินค้า: ฿${finalPrice.toLocaleString()})`
        },
        { status: 400 }
      );
    }

    // Replay / Rapid Click Prevention
    const now = Date.now();
    const sig = `${user.id}:${productId}:${packageId}:${idempotencyKey || ''}`;
    const lastTime = recentOrderSignatures.get(sig);
    if (lastTime && now - lastTime < 3000) {
      return NextResponse.json(
        { success: false, message: 'ระบบป้องกันคำสั่งซื้อซ้ำซ้อน กรุณารอสักครู่' },
        { status: 409 }
      );
    }
    recentOrderSignatures.set(sig, now);

    // Deduct balance atomically in Central DB
    const deductRes = adjustUserBalance(user.id, -finalPrice);
    if (!deductRes.success) {
      return NextResponse.json(
        { success: false, message: deductRes.error || 'ไม่สามารถหักยอดเงินได้' },
        { status: 400 }
      );
    }

    // Generate Key
    const randChunk = () => Math.random().toString(36).substring(2, 6).toUpperCase();
    const generatedKey = `ARX-${randChunk()}-${randChunk()}-${randChunk()}`;

    // Create Order in Central DB
    const orderNumber = 'ARX' + Math.floor(100000 + Math.random() * 900000);
    const newOrder = createOrder({
      orderNumber,
      userId: user.id,
      username: user.username,
      productId: String(productId || ''),
      productName: String(productName || 'สินค้า ARX STORE'),
      packageId: String(packageId || ''),
      packageName: String(packageName || 'แพ็กเกจมาตรฐาน'),
      price: finalPrice,
      originalPrice: basePrice !== finalPrice ? basePrice : undefined,
      status: 'delivered',
      licenseKey: generatedKey,
      downloadUrl: downloadUrl || 'https://arxstore.xyz/download/loader.exe',
      instructions: instructions || 'เปิดโปรแกรมแล้วใส่ License Key เพื่อเปิดใช้งาน'
    });

    // Server-Side Discord Notification
    dispatchDiscordNotification('order', {
      title: '🛒 ออเดอร์การสั่งซื้อใหม่ (New Order Delivered)',
      description: `มีคำสั่งซื้อสินค้าสำเร็จและส่งมอบ License Key เรียบร้อยแล้ว`,
      fields: [
        { name: 'เลขออเดอร์', value: `\`#${orderNumber}\``, inline: true },
        { name: 'ผู้ซื้อ', value: `\`${user.username}\``, inline: true },
        { name: 'สินค้า', value: `${productName} (${packageName})`, inline: true },
        { name: 'ราคาที่ชำระ', value: `฿${finalPrice.toLocaleString()} บาท`, inline: true },
        { name: 'License Key', value: `\`${generatedKey}\``, inline: true }
      ]
    });

    return NextResponse.json({
      success: true,
      message: 'สั่งซื้อสำเร็จ!',
      order: newOrder,
      newBalance: deductRes.newBalance
    }, { status: 201 });
  } catch (err: any) {
    console.error('Order creation error:', err);
    return NextResponse.json({ success: false, message: 'เกิดข้อผิดพลาดในการประมวลผลคำสั่งซื้อ' }, { status: 500 });
  }
}
