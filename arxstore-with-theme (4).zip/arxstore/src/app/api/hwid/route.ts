import { NextResponse } from 'next/server';

let hwidLogs: any[] = [];

export async function GET() {
  return NextResponse.json({
    success: true,
    data: hwidLogs
  });
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { userId, username, productId, productName, licenseKey, wasFree, cost } = body;

    const record = {
      id: 'hwid-' + Date.now(),
      userId: String(userId || '').slice(0, 30),
      username: String(username || '').slice(0, 30),
      productId: String(productId || '').slice(0, 30),
      productName: String(productName || '').slice(0, 100),
      licenseKey: String(licenseKey || '').slice(0, 100),
      status: 'completed',
      cost: wasFree ? 0 : Math.max(0, Number(cost || 50)),
      wasFree: Boolean(wasFree),
      createdAt: new Date().toISOString()
    };

    hwidLogs.unshift(record);
    // Anti-DoS memory cap
    if (hwidLogs.length > 200) {
      hwidLogs = hwidLogs.slice(0, 200);
    }

    return NextResponse.json({
      success: true,
      message: 'HWID reset executed successfully',
      data: record
    }, { status: 201 });
  } catch {
    return NextResponse.json({
      success: false,
      message: 'Failed to process HWID reset'
    }, { status: 400 });
  }
}
