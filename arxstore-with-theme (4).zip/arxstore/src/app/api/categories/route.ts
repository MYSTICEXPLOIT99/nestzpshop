import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { INITIAL_CATEGORIES } from '@/lib/data';
import { Category } from '@/types';

const DATA_DIR = path.join(process.cwd(), 'src', 'data');
const CATEGORIES_FILE = path.join(DATA_DIR, 'categories.json');

interface CategoriesStoreData {
  categories: Category[];
  deletedCategoryIds: string[];
}

function readCategoriesStore(): CategoriesStoreData {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(CATEGORIES_FILE)) {
      const raw = fs.readFileSync(CATEGORIES_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return {
          categories: parsed,
          deletedCategoryIds: []
        };
      }
      if (parsed && typeof parsed === 'object') {
        const categories = Array.isArray(parsed.categories) ? parsed.categories : [];
        const deletedCategoryIds = Array.isArray(parsed.deletedCategoryIds) ? parsed.deletedCategoryIds : [];
        return { categories, deletedCategoryIds };
      }
    }
  } catch (err) {
    console.error('Error reading categories.json:', err);
  }

  return {
    categories: INITIAL_CATEGORIES,
    deletedCategoryIds: []
  };
}

function writeCategoriesStore(categories: Category[], deletedCategoryIds: string[] = []) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(
      CATEGORIES_FILE,
      JSON.stringify({ categories, deletedCategoryIds }, null, 2),
      'utf-8'
    );
  } catch (err) {
    console.error('Error writing categories.json:', err);
  }
}

export async function GET() {
  try {
    const store = readCategoriesStore();
    const valid = store.categories.filter(c => !store.deletedCategoryIds.includes(c.id));
    return NextResponse.json({
      success: true,
      data: valid,
      deletedCategoryIds: store.deletedCategoryIds
    });
  } catch (err) {
    console.error('Error in categories GET:', err);
    return NextResponse.json({
      success: true,
      data: INITIAL_CATEGORIES,
      deletedCategoryIds: []
    });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const current = readCategoriesStore();

    if (body.action === 'restore_defaults') {
      writeCategoriesStore(INITIAL_CATEGORIES, []);
      return NextResponse.json({ success: true, data: INITIAL_CATEGORIES, deletedCategoryIds: [] });
    }

    if (body.action === 'delete' && typeof body.id === 'string') {
      const deletedId = body.id;
      const updatedCategories = current.categories.filter(c => c.id !== deletedId);
      const updatedDeletedIds = Array.from(new Set([...current.deletedCategoryIds, deletedId]));
      writeCategoriesStore(updatedCategories, updatedDeletedIds);
      return NextResponse.json({
        success: true,
        data: updatedCategories,
        deletedCategoryIds: updatedDeletedIds
      });
    }

    if (Array.isArray(body.categories)) {
      const incomingDeleted = Array.isArray(body.deletedCategoryIds) ? body.deletedCategoryIds : [];
      const mergedDeleted = Array.from(new Set([...current.deletedCategoryIds, ...incomingDeleted]));
      const valid = body.categories.filter((c: Category) => !mergedDeleted.includes(c.id));
      writeCategoriesStore(valid, mergedDeleted);
      return NextResponse.json({
        success: true,
        data: valid,
        deletedCategoryIds: mergedDeleted
      });
    }

    return NextResponse.json({ success: false, message: 'Invalid categories payload' }, { status: 400 });
  } catch (err) {
    console.error('Error in categories POST:', err);
    return NextResponse.json({ success: false, message: 'Internal server error' }, { status: 500 });
  }
}
