import { NextResponse } from 'next/server';
import { getResellerSettings } from '@/lib/server/db';

export async function GET() {
  try {
    const settings = getResellerSettings();
    return NextResponse.json({
      success: true,
      data: settings
    });
  } catch (error) {
    console.error('Error fetching reseller settings:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to fetch reseller settings' },
      { status: 500 }
    );
  }
}
