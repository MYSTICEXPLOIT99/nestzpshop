import { NextResponse } from 'next/server';
import { getRandomBoxesData, getSessionFromRequest } from '@/lib/server/db';

export async function GET(request: Request) {
  try {
    const data = getRandomBoxesData();
    const session = getSessionFromRequest(request);

    // Sanitize boxes for public view: hide raw account credentials
    const safeBoxes = (data.boxes || [])
      .filter(b => b.isActive)
      .map(b => ({
        ...b,
        items: b.items.map(it => ({
          id: it.id,
          name: it.name,
          tier: it.tier,
          chance: it.chance,
          image: it.image,
          inStockCount: (it.accounts || []).length
        }))
      }));

    const myHistory = session
      ? (data.history || [])
          .filter(h => h.userId === session.userId)
          .slice(0, 50)
      : [];

    return NextResponse.json({
      success: true,
      boxes: safeBoxes,
      myHistory,
      recentHistory: (data.history || []).slice(0, 20).map(h => ({
        id: h.id,
        boxName: h.boxName,
        username: h.username.length > 3 ? h.username.substring(0, 2) + '***' : h.username,
        itemName: h.itemName,
        tier: h.tier,
        createdAt: h.createdAt
      }))
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
