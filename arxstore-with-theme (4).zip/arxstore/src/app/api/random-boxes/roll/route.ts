import { NextResponse } from 'next/server';
import { getSessionFromRequest, rollRandomBox } from '@/lib/server/db';

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (!session) {
      return NextResponse.json({ success: false, error: 'กรุณาเข้าสู่ระบบก่อนทำการสุ่ม' }, { status: 401 });
    }

    const body = await request.json();
    const { boxId, quantity } = body;
    if (!boxId) {
      return NextResponse.json({ success: false, error: 'ไม่พบรหัสกล่องสุ่ม' }, { status: 400 });
    }

    const qty = Math.max(1, Math.min(20, Math.floor(Number(quantity) || 1)));
    const rollResult = rollRandomBox(boxId, session.userId, qty);
    if (!rollResult.success) {
      return NextResponse.json({ success: false, error: rollResult.error }, { status: 400 });
    }

    return NextResponse.json({
      success: true,
      result: rollResult.result,
      results: rollResult.results,
      newBalance: rollResult.newBalance,
      message: `สั่งซื้อสำเร็จ! คุณได้รับ ${rollResult.result?.itemName}${qty > 1 ? ` จำนวน ${qty} รายการ` : ''}`
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
