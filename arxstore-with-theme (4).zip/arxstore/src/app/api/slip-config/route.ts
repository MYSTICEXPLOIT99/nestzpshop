import { NextResponse } from 'next/server';
import { getSlipConfigServer, updateSlipConfigServer, getSessionFromRequest } from '@/lib/server/db';
import { SlipApiConfig } from '@/types';

export async function GET() {
  try {
    const config = getSlipConfigServer();
    return NextResponse.json({ success: true, data: config });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (!session || session.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized: เฉพาะผู้ดูแลระบบเท่านั้น' }, { status: 401 });
    }

    const body: Partial<SlipApiConfig> = await request.json();
    const updated = updateSlipConfigServer(body);

    return NextResponse.json({
      success: true,
      message: 'บันทึกการตั้งค่าระบบการชำระเงินเรียบร้อย',
      data: updated
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
