import { NextResponse } from 'next/server';
import { validateSsrfUrl } from '@/lib/waf/shield';
import { getSessionFromRequest, getServerSettings, updateServerSettings } from '@/lib/server/db';

export async function GET(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 403 });
    }
    const settings = getServerSettings();
    return NextResponse.json({
      success: true,
      settings: {
        hasWebhook: Boolean(settings.discordWebhookUrl),
        notifyOrder: settings.notifyOrder ?? true,
        notifyTopup: settings.notifyTopup ?? true,
        notifyRegister: settings.notifyRegister ?? true,
        notifyStock: settings.notifyStock ?? true
      }
    });
  } catch {
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    // Webhook dispatching / testing requires ADMIN authorization
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json(
        {
          success: false,
          error: 'การเข้าถึงถูกปฏิเสธ: ระบบป้องกันการสแปมและปลอมแปลง Webhook อนุญาตเฉพาะผู้ดูแลระบบ (Admin) เท่านั้น'
        },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { action, webhookUrl, settings, type, data, botName, botAvatarUrl } = body;

    // 1. Update Webhook Settings (Admin only)
    if (action === 'save_settings' || action === 'update') {
      if (webhookUrl) {
        const ssrfCheck = validateSsrfUrl(webhookUrl, ['discord.com', 'discordapp.com']);
        if (!ssrfCheck.valid || !webhookUrl.includes('/api/webhooks/')) {
          return NextResponse.json(
            { success: false, error: 'URL ของ Discord Webhook ไม่ถูกต้องหรือถูกบล็อกโดยระบบ SSRF' },
            { status: 400 }
          );
        }
        updateServerSettings({ discordWebhookUrl: webhookUrl, ...settings });
      } else if (settings) {
        updateServerSettings(settings);
      }
      return NextResponse.json({ success: true, message: 'บันทึกการตั้งค่า Discord Webhook เรียบร้อยแล้ว' });
    }

    // 2. Dispatch / Test Webhook Notification (Supports type: register, topup_bank, topup_truemoney, order, stock, test)
    if (type || action === 'test' || action === 'send' || action === 'dispatch') {
      const targetUrl = (webhookUrl || data?.customUrl || getServerSettings().discordWebhookUrl || '').trim();
      if (!targetUrl) {
        return NextResponse.json(
          { success: false, error: 'กรุณาระบุ Discord Webhook URL ก่อนดำเนินการ' },
          { status: 400 }
        );
      }

      const ssrfCheck = validateSsrfUrl(targetUrl, ['discord.com', 'discordapp.com']);
      if (!ssrfCheck.valid || !targetUrl.includes('/api/webhooks/')) {
        return NextResponse.json(
          { success: false, error: 'Discord Webhook URL ไม่ถูกต้อง (ต้องเป็น https://discord.com/api/webhooks/...)' },
          { status: 400 }
        );
      }

      const effectiveType = type || (action === 'test' ? 'test' : 'order');
      const nowStr = new Date().toLocaleString('th-TH', { timeZone: 'Asia/Bangkok' });
      const avatar = botAvatarUrl || 'https://files.catbox.moe/haszlm.png';
      const name = botName || 'ARX STORE BOT';

      let embed: any = {};

      if (effectiveType === 'register') {
        embed = {
          title: '👤 สมาชิกใหม่ลงทะเบียน (New Member Registered)',
          description: 'มีผู้ใช้ใหม่ลงทะเบียนเข้าสู่ระบบ **ARX STORE** เรียบร้อยแล้ว',
          color: 0x00E5FF, // Cyan
          fields: [
            { name: '👤 ชื่อผู้ใช้ (Username)', value: data?.username || 'user', inline: true },
            { name: '🆔 รหัสสมาชิก (User ID)', value: `\`${data?.userId || 'USR-ARX'}\``, inline: true },
            { name: '💰 ยอดเงินเริ่มต้น', value: `฿${(data?.balance ?? 0).toLocaleString()} บาท`, inline: true },
            { name: '🖥️ อุปกรณ์ / เบราว์เซอร์', value: data?.device || 'Web Browser', inline: true },
            { name: '⏰ วันที่และเวลา', value: nowStr, inline: true }
          ],
          footer: { text: 'ARX STORE · Registration Alert', icon_url: avatar },
          timestamp: new Date().toISOString()
        };
      } else if (effectiveType === 'topup_bank') {
        embed = {
          title: '💳 แจ้งเตือนการเติมเงินสำเร็จ (Bank Slip Topup)',
          description: 'ผู้ใช้ทำการสแกนสลิปธนาคารและได้รับยอดเงินเข้าสู่ระบบแล้ว',
          color: 0x10B981, // Emerald Green
          fields: [
            { name: '👤 ผู้ใช้งาน', value: data?.username || '-', inline: true },
            { name: '💵 ยอดเงินที่เติม', value: `+฿${Number(data?.amount || 0).toLocaleString()} บาท`, inline: true },
            { name: '💰 ยอดเงินคงเหลือใหม่', value: `฿${Number(data?.newBalance || data?.amount || 0).toLocaleString()} บาท`, inline: true },
            { name: '🏦 ช่องทาง', value: data?.bank || 'สลิปธนาคาร / QR พร้อมเพย์', inline: true },
            { name: '🧾 รหัสอ้างอิงสลิป', value: `\`${data?.refCode || data?.txNo || '-'}\``, inline: true },
            { name: '⏰ วันที่และเวลา', value: nowStr, inline: true }
          ],
          footer: { text: 'ARX STORE · Bank Topup Alert', icon_url: avatar },
          timestamp: new Date().toISOString()
        };
      } else if (effectiveType === 'topup_truemoney') {
        embed = {
          title: '🎁 แจ้งเตือนการเติมเงินสำเร็จ (TrueMoney Angpao)',
          description: 'ผู้ใช้ทำการเติมเงินผ่านซองของขวัญ TrueMoney Wallet',
          color: 0xF97316, // Orange
          fields: [
            { name: '👤 ผู้ใช้งาน', value: data?.username || '-', inline: true },
            { name: '💵 ยอดเงินที่เติม', value: `+฿${Number(data?.amount || 0).toLocaleString()} บาท`, inline: true },
            { name: '🎉 โบนัสเงินคืน', value: `+฿${Number(data?.bonusAmount || (data?.amount ? data.amount * 0.05 : 0)).toLocaleString()} บาท (5%)`, inline: true },
            { name: '💰 ยอดเงินคงเหลือใหม่', value: `฿${Number(data?.newBalance || data?.amount || 0).toLocaleString()} บาท`, inline: true },
            { name: '🎫 รหัสซอง / TX', value: `\`${data?.txNo || '-'}\``, inline: true },
            { name: '⏰ วันที่และเวลา', value: nowStr, inline: true }
          ],
          footer: { text: 'ARX STORE · TrueMoney Topup Alert', icon_url: avatar },
          timestamp: new Date().toISOString()
        };
      } else if (effectiveType === 'order') {
        embed = {
          title: '🛒 มีคำสั่งซื้อใหม่ (New Order Completed)',
          description: 'ลูกค้าได้ทำการสั่งซื้อสินค้าและได้รับข้อมูลเรียบร้อยแล้ว',
          color: 0xA855F7, // Purple
          fields: [
            { name: '📦 รายการสินค้า', value: `**${data?.productName || 'สินค้าดิจิทัล'}**`, inline: true },
            { name: '🏷️ แพ็กเกจ / ระยะเวลา', value: data?.packageName || '30 วัน', inline: true },
            { name: '👤 ผู้ซื้อ', value: data?.username || '-', inline: true },
            { name: '💵 ยอดชำระ', value: `฿${Number(data?.price || 0).toLocaleString()} บาท`, inline: true },
            { name: '🧾 เลขที่คำสั่งซื้อ', value: `\`${data?.orderNumber || 'ARX-ORD-001'}\``, inline: true },
            { name: '🔑 ข้อมูลสินค้า / License Key', value: `||${data?.licenseKey || 'KEY-XXXX-XXXX'}||`, inline: false },
            { name: '⏰ วันที่และเวลา', value: nowStr, inline: true }
          ],
          footer: { text: 'ARX STORE · Order Alert', icon_url: avatar },
          timestamp: new Date().toISOString()
        };
      } else if (effectiveType === 'stock') {
        embed = {
          title: '📦 แจ้งเตือนการเติมสต็อกสินค้า (Stock Refill)',
          description: 'แอดมินได้ทำการเพิ่มสต็อกสินค้าลงในระบบร้านค้าเรียบร้อยแล้ว',
          color: 0x00E676, // Vibrant Emerald
          thumbnail: { url: data?.productImage || 'https://files.catbox.moe/haszlm.png' },
          fields: [
            { name: '📦 สินค้า', value: `**${data?.productName || 'สินค้า'}**`, inline: true },
            { name: '🏷️ แพ็กเกจ', value: data?.packageName || '-', inline: true },
            { name: '📁 หมวดหมู่', value: data?.categoryName || '-', inline: true },
            { name: '➕ จำนวนที่เติม', value: `+${data?.addedCount || 1} ชิ้น`, inline: true },
            { name: '📊 สต็อกคงเหลือทั้งหมด', value: `${data?.currentStock || 0} ชิ้น`, inline: true },
            { name: '👤 ผู้ดำเนินการ', value: data?.operator || 'Admin', inline: true },
            { name: '⏰ วันที่และเวลา', value: nowStr, inline: true }
          ],
          footer: { text: 'ARX STORE · Stock Refill Alert', icon_url: avatar },
          timestamp: new Date().toISOString()
        };
      } else {
        // Generic Test
        embed = {
          title: '🔔 ทดสอบการเชื่อมต่อ Discord Webhook สำเร็จ (Connection Test)',
          description: `ระบบส่งการแจ้งเตือนจากหลังบ้าน **ARX STORE** เรียบร้อยแล้ว`,
          color: 0x00E5FF,
          fields: [
            { name: '📡 สถานะ', value: '🟢 ปกติ (Connected & Verified)', inline: true },
            { name: '👤 ผู้ทดสอบ', value: `\`${session.userId}\``, inline: true },
            { name: '⏰ เวลาที่ส่ง', value: nowStr, inline: true }
          ],
          footer: { text: 'ARX STORE · System Test', icon_url: avatar },
          timestamp: new Date().toISOString()
        };
      }

      const discordPayload = {
        username: name,
        avatar_url: avatar,
        embeds: [embed]
      };

      const discordRes = await fetch(targetUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(discordPayload)
      });

      if (!discordRes.ok) {
        const errText = await discordRes.text().catch(() => '');
        return NextResponse.json(
          {
            success: false,
            error: `Discord ปฏิเสธการส่ง (HTTP ${discordRes.status}): ${errText || 'ตรวจสอบสิทธิ์ของ Webhook'}`
          },
          { status: discordRes.status || 400 }
        );
      }

      return NextResponse.json({ success: true, message: 'ส่งข้อความเข้า Discord สำเร็จเรียบร้อย' });
    }

    return NextResponse.json({ success: false, error: 'คำสั่งไม่ถูกต้อง' }, { status: 400 });
  } catch (err: any) {
    console.error('Webhook route error:', err);
    return NextResponse.json({ success: false, error: err?.message || 'Internal server error' }, { status: 500 });
  }
}
