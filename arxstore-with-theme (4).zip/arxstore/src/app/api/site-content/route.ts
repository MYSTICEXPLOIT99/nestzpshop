import { NextResponse } from 'next/server';
import { getSiteContent, saveSiteContent, getSessionFromRequest, updateSeoSettings, getUsers, updateUser } from '@/lib/server/db';
import { SiteContent } from '@/types';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const content = getSiteContent();
    return NextResponse.json(
      { success: true, data: content },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      }
    );
  } catch (err: any) {
    console.error('Error fetching site content:', err);
    return NextResponse.json(
      { success: false, message: 'Failed to retrieve site content' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json(
        { success: false, message: 'สิทธิ์ถูกปฏิเสธ: เฉพาะผู้ดูแลระบบเท่านั้นที่สามารถแก้ไขเนื้อหาเว็บไซต์ได้' },
        { status: 403 }
      );
    }

    const body = (await request.json().catch(() => null)) as Partial<SiteContent> | null;
    if (!body) {
      return NextResponse.json(
        { success: false, message: 'ข้อมูลไม่ถูกต้อง' },
        { status: 400 }
      );
    }

    const current = getSiteContent();
    const updated: SiteContent = {
      branding: body.branding ? { ...(current.branding || {}), ...body.branding } : current.branding,
      stepsSection: body.stepsSection || current.stepsSection,
      faqSection: body.faqSection || current.faqSection,
      contactModal: body.contactModal || current.contactModal,
      footer: body.footer || current.footer
    };

    saveSiteContent(updated);

    // Sync logo to admin users so profile avatar always follows store logo
    if (updated.branding?.logoUrl) {
      try {
        const users = getUsers();
        users.forEach(u => {
          if (u.role === 'admin' || !u.avatar || u.avatar === '/brand/logo.png' || u.avatar === '/brand/arx-default-logo.png') {
            updateUser(u.id, { avatar: updated.branding!.logoUrl });
          }
        });
      } catch (userErr) {
        console.error('Failed to sync logo to admin user:', userErr);
      }
    }

    // Sync to SEO settings as well
    if (updated.branding) {
      try {
        updateSeoSettings({
          siteName: updated.branding.siteName,
          title: updated.branding.siteTitle || updated.branding.siteName,
          description: updated.branding.slogan || current.branding?.slogan,
          ogImage: updated.branding.logoUrl
        });
      } catch (seoErr) {
        console.error('Failed to sync SEO settings:', seoErr);
      }
    }

    return NextResponse.json(
      {
        success: true,
        message: 'บันทึกเนื้อหาเว็บไซต์และข้อมูลแบรนด์เรียบร้อยแล้ว!',
        data: updated
      },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate'
        }
      }
    );
  } catch (err: any) {
    console.error('Error saving site content:', err);
    return NextResponse.json(
      { success: false, message: 'เกิดข้อผิดพลาดในการบันทึกเนื้อหาเว็บไซต์' },
      { status: 500 }
    );
  }
}
