import { NextResponse } from 'next/server';
import { INITIAL_SERVICE_STATUSES } from '@/lib/data';
import { getSessionFromRequest } from '@/lib/server/db';

let statuses = [...INITIAL_SERVICE_STATUSES];

export async function GET() {
  return NextResponse.json({
    success: true,
    data: statuses,
    summary: {
      total: statuses.length,
      online: statuses.filter(s => s.status === 'online').length,
      updating: statuses.filter(s => s.status === 'updating').length,
      maintenance: statuses.filter(s => s.status === 'maintenance').length,
      operationalRate: Math.round((statuses.filter(s => s.status === 'online').length / statuses.length) * 100)
    }
  });
}

export async function PUT(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json(
        { success: false, message: 'Unauthorized: เฉพาะผู้ดูแลระบบเท่านั้นที่สามารถแก้ไขสถานะบริการได้' },
        { status: 403 }
      );
    }

    const { id, status } = await request.json();
    const validStatuses = ['online', 'updating', 'maintenance'];
    if (!validStatuses.includes(status)) {
      return NextResponse.json({ success: false, message: 'Invalid status value' }, { status: 400 });
    }

    statuses = statuses.map(s => s.id === id ? { ...s, status, lastChecked: 'เมื่อสักครู่' } : s);
    return NextResponse.json({
      success: true,
      message: 'Status updated'
    });
  } catch {
    return NextResponse.json({ success: false, message: 'Invalid payload' }, { status: 400 });
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json(
        { success: false, message: 'Unauthorized: เฉพาะผู้ดูแลระบบเท่านั้นที่สามารถเพิ่มสถานะบริการได้' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const name = String(body.name || '').trim().slice(0, 100);
    const category = String(body.category || 'General').trim().slice(0, 50);
    const status = ['online', 'updating', 'maintenance'].includes(body.status) ? body.status : 'online';

    if (!name) {
      return NextResponse.json({ success: false, message: 'Service name is required' }, { status: 400 });
    }

    const newService = {
      id: 'stat-' + Date.now(),
      productId: 'prod-' + Date.now(),
      name,
      category,
      status,
      lastChecked: 'เมื่อสักครู่',
      version: 'v1.0.0'
    };

    statuses.push(newService);
    return NextResponse.json({ success: true, data: newService }, { status: 201 });
  } catch {
    return NextResponse.json({ success: false, message: 'Invalid payload' }, { status: 400 });
  }
}
