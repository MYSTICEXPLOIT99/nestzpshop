import { NextResponse } from 'next/server';
import {
  getUserByUsername,
  getUserById,
  createUser,
  verifyPassword,
  createSession,
  revokeSession,
  getSessionFromRequest,
  sanitizeUser,
  updateUser,
  getSession
} from '@/lib/server/db';
import { dispatchDiscordNotification } from '@/lib/server/discord';
import { isLoginLocked, recordFailedLogin, resetFailedLogin } from '@/lib/waf/shield';

const regIpAttempts = new Map<string, { count: number; resetAt: number }>();

export async function GET(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (!session) {
      return NextResponse.json({ authenticated: false, user: null });
    }

    const user = getUserById(session.userId);
    if (!user) {
      return NextResponse.json({ authenticated: false, user: null });
    }

    return NextResponse.json({
      authenticated: true,
      user: sanitizeUser(user)
    });
  } catch (err) {
    return NextResponse.json({ authenticated: false, user: null }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const ip = request.headers.get('x-forwarded-for')?.split(',')[0].trim() ||
      request.headers.get('x-real-ip') ||
      '127.0.0.1';

    const body = await request.json();
    const { action, username, password, email, hp_trap, honeypot, hp_security_check, token, avatar, userId } = body;
    const botTrap = hp_trap || honeypot || hp_security_check;

    if (action === 'logout') {
      const sessionToken = token || request.headers.get('x-session-token');
      if (sessionToken) {
        revokeSession(sessionToken);
      }
      return NextResponse.json(
        { success: true, message: 'ออกจากระบบแล้ว' },
        {
          headers: {
            'Set-Cookie': 'arx_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0'
          }
        }
      );
    }

    // Update Profile Action (เปลี่ยนรูปโปรไฟล์, เปลี่ยนชื่อผู้ใช้)
    if (action === 'update_profile') {
      const session = getSessionFromRequest(request);
      const sessionToken = token || request.headers.get('x-session-token');
      let targetUserId = session?.userId;
      if (!targetUserId && sessionToken) {
        const sess = getSession(sessionToken);
        if (sess) targetUserId = sess.userId;
      }
      if (!targetUserId && userId) {
        targetUserId = userId;
      }

      if (!targetUserId) {
        return NextResponse.json({ success: false, message: 'กรุณาเข้าสู่ระบบก่อนทำรายการ' }, { status: 401 });
      }

      const currentUser = getUserById(targetUserId);
      if (!currentUser) {
        return NextResponse.json({ success: false, message: 'ไม่พบข้อมูลผู้ใช้ในระบบ' }, { status: 404 });
      }

      const updates: { username?: string; avatar?: string } = {};

      if (username !== undefined && typeof username === 'string') {
        const newUsername = username.trim();
        if (newUsername.length < 3 || newUsername.length > 25) {
          return NextResponse.json({ success: false, message: 'ชื่อผู้ใช้ต้องมีความยาว 3-25 ตัวอักษร' }, { status: 400 });
        }
        const existing = getUserByUsername(newUsername);
        if (existing && existing.id !== currentUser.id) {
          return NextResponse.json({ success: false, message: 'ชื่อผู้ใช้นี้มีคนใช้แล้ว กรุณาเลือกชื่ออื่น' }, { status: 400 });
        }
        updates.username = newUsername;
      }

      if (avatar !== undefined && typeof avatar === 'string') {
        updates.avatar = avatar.trim();
      }

      const updated = updateUser(currentUser.id, updates);
      if (!updated) {
        return NextResponse.json({ success: false, message: 'ไม่สามารถบันทึกข้อมูลโปรไฟล์ได้' }, { status: 500 });
      }

      return NextResponse.json({
        success: true,
        message: 'บันทึกข้อมูลโปรไฟล์สำเร็จ',
        user: sanitizeUser(updated)
      });
    }

    // 1. Invisible Honeypot Trap Check: Bots fill all fields automatically
    if (botTrap && typeof botTrap === 'string' && botTrap.trim().length > 0) {
      return NextResponse.json(
        { success: false, message: 'ระบบตรวจพบบอทอัตโนมัติ (Automated bot spam rejected)' },
        { status: 400 }
      );
    }

    const cleanUser = (username || '').trim();
    const cleanPass = (password || '').trim();

    if (action === 'register') {
      // 2. IP Rate Limit: Max 5 registrations per 10 minutes per IP
      const now = Date.now();
      const ipRecord = regIpAttempts.get(ip);
      if (ipRecord && ipRecord.resetAt > now) {
        if (ipRecord.count >= 5) {
          const waitSecs = Math.ceil((ipRecord.resetAt - now) / 1000);
          return NextResponse.json(
            { success: false, message: `ระบบป้องกันสแปม: IP ของคุณสมัครสมาชิกบ่อยเกินไป กรุณารอ ${waitSecs} วินาที` },
            { status: 429 }
          );
        }
        ipRecord.count += 1;
      } else {
        regIpAttempts.set(ip, { count: 1, resetAt: now + 600000 });
      }

      // 3. Strict Username Validation
      const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
      if (!usernameRegex.test(cleanUser)) {
        return NextResponse.json(
          { success: false, message: 'ชื่อผู้ใช้ต้องเป็นตัวอักษรภาษาอังกฤษ ตัวเลข หรือขีดล่าง (_) ความยาว 3-20 ตัวอักษรเท่านั้น' },
          { status: 400 }
        );
      }

      // 4. Block Reserved Usernames
      const blockedNames = ['arxstore', 'admin', 'administrator', 'root', 'bot', 'system', 'null', 'undefined', 'anonymous', 'moderator'];
      if (blockedNames.includes(cleanUser.toLowerCase())) {
        return NextResponse.json(
          { success: false, message: 'ชื่อผู้ใช้นี้สงวนไว้หรือไม่อนุญาตให้ใช้งาน' },
          { status: 400 }
        );
      }

      // 5. Password Length Check
      if (cleanPass.length < 4) {
        return NextResponse.json(
          { success: false, message: 'รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร' },
          { status: 400 }
        );
      }

      // 6. Check Duplicate Username against Central DB
      const existing = getUserByUsername(cleanUser);
      if (existing) {
        return NextResponse.json(
          { success: false, message: 'ชื่อผู้ใช้นี้มีอยู่ในระบบแล้ว กรุณาใช้ชื่ออื่น' },
          { status: 400 }
        );
      }

      // 7. Create User with Hashed Password in Central DB
      const newUser = createUser({
        username: cleanUser,
        password: cleanPass,
        email: email && typeof email === 'string' && email.trim() ? email.trim() : undefined,
        role: 'user'
      });

      const session = createSession(newUser.id, newUser.role);

      // Trigger Discord Webhook from server
      dispatchDiscordNotification('register', {
        title: '👤 สมาชิกใหม่ลงทะเบียน (New Member)',
        description: `มีผู้ใช้งานใหม่สมัครสมาชิกเข้าสู่ระบบ ARX STORE`,
        fields: [
          { name: 'ชื่อผู้ใช้', value: `\`${newUser.username}\``, inline: true },
          { name: 'รหัสสมาชิก', value: `\`${newUser.id}\``, inline: true },
          { name: 'วันที่สมัคร', value: newUser.memberSince || 'วันนี้', inline: true }
        ]
      });

      return NextResponse.json(
        {
          success: true,
          user: sanitizeUser(newUser),
          token: session.token
        },
        {
          headers: {
            'Set-Cookie': `arx_session=${session.token}; Path=/; SameSite=Lax; Max-Age=2592000`
          }
        }
      );
    }

    // ----------------------------------------------------
    // Login Flow
    // ----------------------------------------------------
    const loginLockKey = `${ip}:${cleanUser.toLowerCase()}`;
    const lockStatus = isLoginLocked(loginLockKey);
    if (lockStatus.locked) {
      return NextResponse.json(
        {
          success: false,
          message: `ระบบป้องกัน Brute Force: บัญชีหรือ IP นี้ถูกระงับชั่วคราวเนื่องจากรหัสผ่านผิดเกินกำหนด กรุณารออีก ${lockStatus.lockTimeSecs} วินาที`
        },
        { status: 429 }
      );
    }

    if (!cleanUser || !cleanPass) {
      return NextResponse.json(
        { success: false, message: 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน' },
        { status: 400 }
      );
    }

    const matchedUser = getUserByUsername(cleanUser);
    if (!matchedUser) {
      const failResult = recordFailedLogin(loginLockKey);
      return NextResponse.json(
        { success: false, message: `ไม่พบบัญชีผู้ใช้นี้ หรือรหัสผ่านไม่ถูกต้อง (เหลือโอกาสลองอีก ${failResult.remainingAttempts} ครั้ง)` },
        { status: 401 }
      );
    }

    // Verify cryptographic PBKDF2 hash
    const isValidPassword = verifyPassword(cleanPass, matchedUser.passwordHash);
    if (!isValidPassword) {
      const failResult = recordFailedLogin(loginLockKey);
      if (failResult.locked) {
        return NextResponse.json(
          { success: false, message: `ระบบความปลอดภัย: รหัสผ่านผิดเกินกำหนด บัญชีถูกระงับชั่วคราว ${failResult.lockTimeSecs} วินาที` },
          { status: 429 }
        );
      }
      return NextResponse.json(
        { success: false, message: `รหัสผ่านไม่ถูกต้อง (เหลือโอกาสลองอีก ${failResult.remainingAttempts} ครั้ง)` },
        { status: 401 }
      );
    }

    resetFailedLogin(loginLockKey);

    // Create secure server session
    const session = createSession(matchedUser.id, matchedUser.role);

    return NextResponse.json(
      {
        success: true,
        user: sanitizeUser(matchedUser),
        token: session.token,
        message: 'เข้าสู่ระบบสำเร็จ'
      },
      {
        headers: {
          'Set-Cookie': `arx_session=${session.token}; Path=/; SameSite=Lax; Max-Age=2592000`
        }
      }
    );
  } catch (err: any) {
    console.error('Auth error:', err);
    return NextResponse.json({ success: false, message: 'Authentication error' }, { status: 400 });
  }
}
