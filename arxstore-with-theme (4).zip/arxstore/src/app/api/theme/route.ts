import { NextResponse } from 'next/server';
import { getThemeSettings } from '@/lib/server/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  return NextResponse.json({ success: true, data: getThemeSettings() });
}
