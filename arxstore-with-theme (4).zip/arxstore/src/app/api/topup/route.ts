import { NextResponse } from 'next/server';
import {
  getTopups,
  getTopupsByUserId,
  createTopup,
  updateTopupStatus,
  getSessionFromRequest,
  getUserById,
  getSlipConfigServer
} from '@/lib/server/db';
import { dispatchDiscordNotification } from '@/lib/server/discord';
import { validateUploadedImage } from '@/lib/waf/shield';

const usedRefCodes = new Set<string>();

export async function GET(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    const { searchParams } = new URL(request.url);
    const queryUserId = searchParams.get('userId');

    // Admin can see all topup records
    if (session?.role === 'admin') {
      if (queryUserId) {
        return NextResponse.json({ success: true, data: getTopupsByUserId(queryUserId) });
      }
      return NextResponse.json({ success: true, data: getTopups() });
    }

    // User can see their own topup records
    if (session) {
      return NextResponse.json({ success: true, data: getTopupsByUserId(session.userId) });
    }

    if (queryUserId) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    return NextResponse.json({ success: true, data: [] });
  } catch (err) {
    return NextResponse.json({ success: false, error: 'Failed to fetch topups' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (!session) {
      return NextResponse.json(
        { success: false, message: 'กรุณาเข้าสู่ระบบก่อนทำรายการเติมเงิน' },
        { status: 401 }
      );
    }

    const user = getUserById(session.userId);
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'ไม่พบข้อมูลผู้ใช้งาน' },
        { status: 404 }
      );
    }

    const body = await request.json();
    const { method, amount, refCode, slipUrl, senderName, bankName } = body;

    const numAmount = Number(amount);
    if (isNaN(numAmount) || numAmount <= 0 || numAmount > 1000000) {
      return NextResponse.json(
        { success: false, message: 'จำนวนเงินไม่ถูกต้อง (ต้องอยู่ระหว่าง 1 - 1,000,000 บาท)' },
        { status: 400 }
      );
    }

    // 1. Replay Attack & Duplicate Transaction Check
    const cleanRef = String(refCode || '').trim();
    if (cleanRef) {
      if (usedRefCodes.has(cleanRef) || getTopups().some(r => r.refCode === cleanRef)) {
        return NextResponse.json(
          { success: false, message: 'รหัสอ้างอิงหรือสลิปนี้ถูกใช้งานไปแล้วในระบบ' },
          { status: 400 }
        );
      }
      usedRefCodes.add(cleanRef);
      if (usedRefCodes.size > 1000) {
        const [first] = usedRefCodes;
        usedRefCodes.delete(first);
      }
    }

    // 2. Validate uploaded slip image strictly (MIME, Magic Bytes, File Size)
    const rawSlip = slipUrl || body.image || body.slip;
    if (rawSlip && typeof rawSlip === 'string' && rawSlip.startsWith('data:image')) {
      const fileCheck = validateUploadedImage(rawSlip, 5 * 1024 * 1024);
      if (!fileCheck.valid) {
        return NextResponse.json(
          { success: false, message: `ไฟล์สลิปไม่ถูกต้อง: ${fileCheck.reason}` },
          { status: 400 }
        );
      }
    }

    const slipConfig = getSlipConfigServer();

    // Validate channel enabled status
    if (method === 'angpao') {
      if (slipConfig.channelAngpaoEnabled === false) {
        return NextResponse.json(
          { success: false, message: 'ช่องทางซองของขวัญ TrueMoney Wallet ปิดให้บริการชั่วคราว' },
          { status: 400 }
        );
      }
    } else if (method === 'promptpay') {
      if (slipConfig.channelPromptPayEnabled === false) {
        return NextResponse.json(
          { success: false, message: 'ช่องทาง PromptPay QR ปิดให้บริการชั่วคราว' },
          { status: 400 }
        );
      }
    } else {
      if (slipConfig.channelBankTransferEnabled === false) {
        return NextResponse.json(
          { success: false, message: 'ช่องทางโอนผ่านธนาคารปิดให้บริการชั่วคราว' },
          { status: 400 }
        );
      }
    }

    // Calculate Angpao fee deduction if applicable
    let finalCreditAmount = numAmount;
    let feeDeducted = 0;
    const angpaoFeePercent = typeof slipConfig.angpaoFeePercent === 'number' ? slipConfig.angpaoFeePercent : 2.9;

    if (method === 'angpao') {
      if (angpaoFeePercent > 0) {
        feeDeducted = Math.round(numAmount * (angpaoFeePercent / 100) * 100) / 100;
        finalCreditAmount = Math.max(0, Math.round((numAmount - feeDeducted) * 100) / 100);
      }
    }

    const transactionNo = (method === 'angpao' ? 'TM' : 'BNK') + Math.floor(100000 + Math.random() * 900000);

    // Save Topup Record in Central DB with 'pending' status
    // Client CANNOT grant money instantly!
    const newTopup = createTopup({
      transactionNo,
      userId: user.id,
      username: user.username,
      method: method === 'angpao' ? 'angpao' : 'bank_transfer',
      amount: finalCreditAmount,
      status: 'pending',
      refCode: cleanRef || ('REF-' + Date.now()),
      slipUrl: rawSlip || '/images/slip_sample.png',
      senderName: senderName || user.username,
      bankName: bankName || (method === 'angpao' ? `TrueMoney Angpao (หัก ${angpaoFeePercent}%)` : 'ธนาคารไทย / พร้อมเพย์')
    });

    // Dispatch Server Discord Notification
    dispatchDiscordNotification('topup', {
      title: '💳 แจ้งเตือนการเติมเงินใหม่ (Pending Verification)',
      description: `มีคำขอแจ้งเติมเงินเข้ามาใหม่ กรุณาตรวจสอบยอดเงินและสลิปในหลังบ้าน`,
      fields: [
        { name: 'รหัสธุรกรรม', value: `\`#${transactionNo}\``, inline: true },
        { name: 'ผู้เติมเงิน', value: `\`${user.username}\``, inline: true },
        {
          name: 'ยอดเงิน',
          value: method === 'angpao' && feeDeducted > 0
            ? `฿${numAmount.toLocaleString()} (หัก ${angpaoFeePercent}%: -฿${feeDeducted}) -> เครดิตสุทธิ ฿${finalCreditAmount.toLocaleString()} บาท`
            : `฿${numAmount.toLocaleString()} บาท`,
          inline: true
        },
        { name: 'ช่องทาง', value: newTopup.bankName || 'ธนาคาร', inline: true },
        { name: 'สถานะ', value: '⏳ รอตรวจสอบ (Pending)', inline: true }
      ]
    });

    return NextResponse.json({
      success: true,
      message: 'ส่งข้อมูลแจ้งโอนเงินสำเร็จ! รายการอยู่ระหว่างรอเจ้าหน้าที่ตรวจสอบยอดเงิน',
      data: newTopup
    }, { status: 201 });
  } catch (err: any) {
    console.error('Topup error:', err);
    return NextResponse.json({ success: false, message: 'เกิดข้อผิดพลาดในการแจ้งเติมเงิน' }, { status: 500 });
  }
}

// Admin Review / Approval Endpoint
export async function PATCH(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json(
        { success: false, message: 'สิทธิ์การเข้าถึงถูกปฏิเสธ: เฉพาะผู้ดูแลระบบเท่านั้น' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { topupId, status } = body;

    if (!topupId || (status !== 'approved' && status !== 'rejected')) {
      return NextResponse.json(
        { success: false, message: 'ข้อมูลคำขอไม่ถูกต้อง' },
        { status: 400 }
      );
    }

    const result = updateTopupStatus(topupId, status, session.userId);
    if (!result.success) {
      return NextResponse.json({ success: false, message: result.error }, { status: 400 });
    }

    // Trigger Discord notification
    if (status === 'approved' && result.topup) {
      dispatchDiscordNotification('topup', {
        title: '✅ อนุมัติการเติมเงินสำเร็จ (Topup Approved)',
        description: `แอดมินตรวจสอบยอดเงินและเติมเครดิตเข้ากระเป๋าเรียบร้อยแล้ว`,
        fields: [
          { name: 'รหัสธุรกรรม', value: `\`#${result.topup.transactionNo}\``, inline: true },
          { name: 'ผู้ใช้งาน', value: `\`${result.topup.username}\``, inline: true },
          { name: 'จำนวนเงินที่เพิ่ม', value: `+฿${result.topup.amount.toLocaleString()} บาท`, inline: true },
          { name: 'สถานะ', value: 'อนุมัติเรียบร้อย', inline: true }
        ],
        color: 0x00FF9D
      });
    }

    return NextResponse.json({
      success: true,
      message: status === 'approved' ? 'อนุมัติยอดเงินและเพิ่มเข้ากระเป๋าผู้ใช้แล้ว' : 'ปฏิเสธรายการเติมเงินแล้ว',
      data: result.topup
    });
  } catch (err) {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}
