import { NextResponse } from 'next/server';
import { getAntiDevtoolSettingsServer } from '@/lib/server/db';

export async function GET() {
  try {
    const settings = getAntiDevtoolSettingsServer();
    return NextResponse.json({
      success: true,
      data: settings
    });
  } catch {
    return NextResponse.json({
      success: false,
      message: 'Failed to retrieve security settings'
    }, { status: 500 });
  }
}
