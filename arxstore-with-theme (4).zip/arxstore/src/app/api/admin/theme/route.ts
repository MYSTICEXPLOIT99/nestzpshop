import { NextResponse } from 'next/server';
import { getSessionFromRequest, getThemeSettings, updateThemeSettings, resetThemeSettings } from '@/lib/server/db';
import { normalizeHex } from '@/lib/theme';

export const dynamic = 'force-dynamic';

const COLOR_KEYS = ['main', 'secondary', 'accent', 'background', 'card', 'text', 'textMuted', 'border'] as const;

function forbidden() {
  return NextResponse.json(
    { success: false, message: 'สิทธิ์ถูกปฏิเสธ: เฉพาะผู้ดูแลระบบเท่านั้นที่ปรับสีเว็บได้' },
    { status: 403 }
  );
}

export async function GET() {
  try {
    return NextResponse.json({ success: true, data: getThemeSettings() });
  } catch {
    return NextResponse.json({ success: false, message: 'อ่านค่าสีไม่สำเร็จ' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') return forbidden();

    const body = await request.json();
    const updates: Record<string, string | boolean> = {};

    for (const key of COLOR_KEYS) {
      if (body[key] === undefined) continue;
      const hex = normalizeHex(body[key]);
      if (!hex) {
        return NextResponse.json(
          { success: false, message: `รหัสสีของ "${key}" ไม่ถูกต้อง (ต้องเป็นรูปแบบ #RRGGBB)` },
          { status: 400 }
        );
      }
      updates[key] = hex;
    }
    if (typeof body.enabled === 'boolean') updates.enabled = body.enabled;

    const data = updateThemeSettings(updates);
    return NextResponse.json({ success: true, message: 'บันทึกสีเว็บสำเร็จ!', data });
  } catch (err) {
    console.error('Error updating theme:', err);
    return NextResponse.json({ success: false, message: 'เกิดข้อผิดพลาดในการบันทึกสีเว็บ' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') return forbidden();
    return NextResponse.json({ success: true, message: 'คืนค่าสีเดิมเรียบร้อย', data: resetThemeSettings() });
  } catch {
    return NextResponse.json({ success: false, message: 'คืนค่าสีไม่สำเร็จ' }, { status: 500 });
  }
}
