import { NextResponse } from 'next/server';
import { getSeoSettings, updateSeoSettings, getSessionFromRequest } from '@/lib/server/db';

export async function GET() {
  try {
    const seo = getSeoSettings();
    return NextResponse.json({ success: true, data: seo });
  } catch (err: any) {
    return NextResponse.json({ success: false, message: 'Failed to get SEO settings' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json(
        { success: false, message: 'สิทธิ์ถูกปฏิเสธ: เฉพาะผู้ดูแลระบบเท่านั้นที่สามารถแก้ไขการตั้งค่า SEO & Discord Embed ได้' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { title, description, ogImage, themeColor, siteName, keywords } = body;

    const updated = updateSeoSettings({
      ...(title !== undefined ? { title: String(title).trim() } : {}),
      ...(description !== undefined ? { description: String(description).trim() } : {}),
      ...(ogImage !== undefined ? { ogImage: String(ogImage).trim() } : {}),
      ...(themeColor !== undefined ? { themeColor: String(themeColor).trim() } : {}),
      ...(siteName !== undefined ? { siteName: String(siteName).trim() } : {}),
      ...(keywords !== undefined ? { keywords: String(keywords).trim() } : {})
    });

    return NextResponse.json({
      success: true,
      message: 'บันทึกการตั้งค่ารูปแชร์และ Discord Embed สำเร็จ!',
      data: updated
    });
  } catch (err: any) {
    console.error('Error updating SEO settings:', err);
    return NextResponse.json(
      { success: false, message: 'เกิดข้อผิดพลาดในการบันทึกการตั้งค่า SEO' },
      { status: 500 }
    );
  }
}
