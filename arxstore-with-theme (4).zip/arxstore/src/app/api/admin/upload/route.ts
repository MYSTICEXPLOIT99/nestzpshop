import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { getSessionFromRequest } from '@/lib/server/db';

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads', 'seo');

function ensureUploadDir() {
  if (!fs.existsSync(UPLOAD_DIR)) {
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json(
        { success: false, message: 'สิทธิ์ถูกปฏิเสธ: เฉพาะผู้ดูแลระบบเท่านั้น' },
        { status: 403 }
      );
    }

    ensureUploadDir();

    const contentType = request.headers.get('content-type') || '';

    if (contentType.includes('multipart/form-data')) {
      const formData = await request.formData();
      const file = formData.get('file') as File | null;

      if (!file) {
        return NextResponse.json({ success: false, message: 'ไม่พบไฟล์รูปภาพ' }, { status: 400 });
      }

      // Check max size 10MB
      if (file.size > 10 * 1024 * 1024) {
        return NextResponse.json({ success: false, message: 'ขนาดไฟล์เกิน 10MB' }, { status: 400 });
      }

      const bytes = await file.arrayBuffer();
      const buffer = Buffer.from(bytes);

      // Determine extension
      let ext = 'png';
      const type = file.type.toLowerCase();
      if (type.includes('jpeg') || type.includes('jpg')) ext = 'jpg';
      else if (type.includes('webp')) ext = 'webp';
      else if (type.includes('gif')) ext = 'gif';

      const fileName = `og-image-${Date.now()}.${ext}`;
      const filePath = path.join(UPLOAD_DIR, fileName);

      fs.writeFileSync(filePath, buffer);

      const publicUrl = `/uploads/seo/${fileName}`;
      return NextResponse.json({
        success: true,
        message: 'อัปโหลดรูปภาพสำเร็จ!',
        url: publicUrl
      });
    }

    // Support base64 payload
    const body = await request.json();
    const { imageBase64, extension = 'png' } = body;

    if (!imageBase64 || typeof imageBase64 !== 'string') {
      return NextResponse.json({ success: false, message: 'ข้อมูลรูปภาพไม่ถูกต้อง' }, { status: 400 });
    }

    const matches = imageBase64.match(/^data:image\/([a-zA-Z0-9+]+);base64,(.+)$/);
    let rawBase64 = imageBase64;
    let ext = extension;

    if (matches) {
      ext = matches[1] === 'jpeg' ? 'jpg' : matches[1];
      rawBase64 = matches[2];
    }

    const buffer = Buffer.from(rawBase64, 'base64');
    const fileName = `og-image-${Date.now()}.${ext}`;
    const filePath = path.join(UPLOAD_DIR, fileName);

    fs.writeFileSync(filePath, buffer);

    const publicUrl = `/uploads/seo/${fileName}`;
    return NextResponse.json({
      success: true,
      message: 'อัปโหลดรูปภาพสำเร็จ!',
      url: publicUrl
    });
  } catch (err: any) {
    console.error('Error uploading SEO image:', err);
    return NextResponse.json(
      { success: false, message: 'เกิดข้อผิดพลาดในการอัปโหลดรูปภาพ' },
      { status: 500 }
    );
  }
}
