import { NextResponse } from 'next/server';
import { getSessionFromRequest, getRandomBoxesData, saveRandomBoxesData, RandomBox } from '@/lib/server/db';

export async function GET(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (!session || session.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 403 });
    }

    const data = getRandomBoxesData();
    return NextResponse.json({
      success: true,
      boxes: data.boxes || [],
      history: data.history || []
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (!session || session.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 403 });
    }

    const body = await request.json();
    const { action, box, boxId } = body;
    const data = getRandomBoxesData();
    data.boxes = data.boxes || [];

    if (action === 'save') {
      if (!box || !box.name || !box.price) {
        return NextResponse.json({ success: false, error: 'กรุณากรอกข้อมูลกล่องสุ่มให้ครบถ้วน' }, { status: 400 });
      }

      if (box.id) {
        // Edit existing box
        const index = data.boxes.findIndex(b => b.id === box.id);
        if (index !== -1) {
          data.boxes[index] = { ...data.boxes[index], ...box };
        } else {
          data.boxes.push(box);
        }
      } else {
        // New box
        const newBox: RandomBox = {
          ...box,
          id: 'box-' + Date.now(),
          totalSpins: 0,
          isActive: box.isActive ?? true,
          items: box.items || []
        };
        data.boxes.push(newBox);
      }

      saveRandomBoxesData(data);
      return NextResponse.json({ success: true, message: 'บันทึกกล่องสุ่มสำเร็จ', boxes: data.boxes });
    }

    if (action === 'delete') {
      if (!boxId) {
        return NextResponse.json({ success: false, error: 'ไม่พบ ID กล่องที่ต้องการลบ' }, { status: 400 });
      }
      data.boxes = data.boxes.filter(b => b.id !== boxId);
      saveRandomBoxesData(data);
      return NextResponse.json({ success: true, message: 'ลบกล่องสุ่มเรียบร้อยแล้ว', boxes: data.boxes });
    }

    if (action === 'toggle_active') {
      const target = data.boxes.find(b => b.id === boxId);
      if (target) {
        target.isActive = !target.isActive;
        saveRandomBoxesData(data);
      }
      return NextResponse.json({ success: true, boxes: data.boxes });
    }

    return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
