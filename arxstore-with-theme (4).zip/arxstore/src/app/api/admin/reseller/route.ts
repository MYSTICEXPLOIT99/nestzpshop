import { NextResponse } from 'next/server';
import { getResellerSettings, updateResellerSettings, getSessionFromRequest } from '@/lib/server/db';

export async function GET(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json(
        { success: false, message: 'สิทธิ์ถูกปฏิเสธ: เฉพาะผู้ดูแลระบบเท่านั้น' },
        { status: 403 }
      );
    }

    const settings = getResellerSettings();
    return NextResponse.json({
      success: true,
      data: settings
    });
  } catch (error) {
    console.error('Error getting admin reseller settings:', error);
    return NextResponse.json(
      { success: false, message: 'เกิดข้อผิดพลาดในการโหลดข้อมูลตัวแทนจำหน่าย' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json(
        { success: false, message: 'สิทธิ์ถูกปฏิเสธ: เฉพาะผู้ดูแลระบบเท่านั้น' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const updated = updateResellerSettings(body);

    return NextResponse.json({
      success: true,
      message: 'บันทึกการตั้งค่าตัวแทนจำหน่ายเรียบร้อยแล้ว',
      data: updated
    });
  } catch (error) {
    console.error('Error saving reseller settings:', error);
    return NextResponse.json(
      { success: false, message: 'เกิดข้อผิดพลาดในการบันทึกข้อมูลตัวแทนจำหน่าย' },
      { status: 500 }
    );
  }
}
