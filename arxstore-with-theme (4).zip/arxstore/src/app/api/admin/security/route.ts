import { NextRequest, NextResponse } from 'next/server';
import { getSecurityMetrics, clearAllQuarantines, clearSecurityLogs, unblockIp } from '@/lib/waf/shield';
import {
  getSessionFromRequest,
  getAntiDevtoolSettingsServer,
  updateAntiDevtoolSettingsServer
} from '@/lib/server/db';

export async function GET(req: NextRequest) {
  try {
    const session = getSessionFromRequest(req);
    if (session?.role !== 'admin') {
      return NextResponse.json({ success: false, message: 'Forbidden' }, { status: 403 });
    }

    const metrics = getSecurityMetrics();
    const securitySettings = getAntiDevtoolSettingsServer();

    return NextResponse.json({
      success: true,
      shieldStatus: 'ARMED_AND_PROTECTING',
      version: 'ARX-CyberShield-v2.5-Enterprise',
      metrics,
      securitySettings
    });
  } catch {
    return NextResponse.json({
      success: false,
      message: 'Failed to retrieve security metrics'
    }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = getSessionFromRequest(req);
    if (session?.role !== 'admin') {
      return NextResponse.json({ success: false, message: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const { action, ip, settings } = body;

    if (action === 'update_settings' && settings && typeof settings === 'object') {
      const updated = updateAntiDevtoolSettingsServer(settings);
      return NextResponse.json({
        success: true,
        message: 'บันทึกการตั้งค่าระบบ Anti-Devtools เรียบร้อยแล้ว',
        data: updated
      });
    }

    if (action === 'unblock_all') {
      clearAllQuarantines();
      return NextResponse.json({ success: true, message: 'ปลดบล็อก IP และรีเซ็ต Rate Limit ทั้งหมดเรียบร้อยแล้ว' });
    }

    if (action === 'unblock_ip' && ip) {
      unblockIp(ip);
      return NextResponse.json({ success: true, message: `ปลดบล็อก IP ${ip} เรียบร้อยแล้ว` });
    }

    if (action === 'clear_logs') {
      clearSecurityLogs();
      return NextResponse.json({ success: true, message: 'ล้างบันทึกการโจมตีทั้งหมดเรียบร้อยแล้ว' });
    }

    return NextResponse.json({ success: false, message: 'Unknown action' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ success: false, message: err?.message || 'Error executing action' }, { status: 500 });
  }
}
