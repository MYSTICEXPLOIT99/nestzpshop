import { NextResponse } from 'next/server';
import {
  getUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser,
  adjustUserBalance,
  getSessionFromRequest,
  sanitizeUser
} from '@/lib/server/db';

export async function GET(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json({ success: false, message: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const users = getUsers();
    return NextResponse.json({
      success: true,
      data: users.map(sanitizeUser)
    });
  } catch (err) {
    return NextResponse.json({ success: false, message: 'Failed to fetch users' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json({ success: false, message: 'Forbidden' }, { status: 403 });
    }

    const body = await request.json();
    const { username, password, role, email, avatar, balance } = body;

    if (!username || !password) {
      return NextResponse.json({ success: false, message: 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน' }, { status: 400 });
    }

    const newUser = createUser({
      username,
      password,
      role: role || 'user',
      email,
      avatar
    });

    if (typeof balance === 'number' && balance > 0) {
      updateUser(newUser.id, { balance });
      newUser.balance = balance;
    }

    return NextResponse.json({
      success: true,
      message: 'สร้างบัญชีผู้ใช้ใหม่สำเร็จ',
      data: sanitizeUser(newUser)
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ success: false, message: err?.message || 'Error creating user' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json({ success: false, message: 'Forbidden' }, { status: 403 });
    }

    const body = await request.json();
    const { id, balanceDelta, newPassword, role, email, balance, username, avatar } = body;

    if (!id) {
      return NextResponse.json({ success: false, message: 'User ID is required' }, { status: 400 });
    }

    if (typeof balanceDelta === 'number') {
      adjustUserBalance(id, balanceDelta);
    }

    const updates: any = {};
    if (newPassword) updates.newPassword = newPassword;
    if (role) updates.role = role;
    if (email) updates.email = email;
    if (typeof balance === 'number') updates.balance = Math.max(0, balance);
    if (username && typeof username === 'string') updates.username = username.trim();
    if (avatar && typeof avatar === 'string') updates.avatar = avatar.trim();

    const updated = updateUser(id, updates);
    if (!updated) {
      return NextResponse.json({ success: false, message: 'User not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      message: 'อัปเดตข้อมูลผู้ใช้เรียบร้อยแล้ว',
      data: sanitizeUser(updated)
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, message: err?.message || 'Error updating user' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json({ success: false, message: 'Forbidden' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) {
      return NextResponse.json({ success: false, message: 'User ID is required' }, { status: 400 });
    }

    if (session.userId === id) {
      return NextResponse.json({ success: false, message: 'ไม่สามารถลบบัญชีตัวเองได้' }, { status: 400 });
    }

    const deleted = deleteUser(id);
    if (!deleted) {
      return NextResponse.json({ success: false, message: 'User not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, message: 'ลบผู้ใช้เรียบร้อยแล้ว' });
  } catch (err: any) {
    return NextResponse.json({ success: false, message: err?.message || 'Error deleting user' }, { status: 500 });
  }
}
