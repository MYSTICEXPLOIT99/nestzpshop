import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const url = body.url?.trim();
    return handleDetect(url);
  } catch (err) {
    return NextResponse.json({ success: false, message: 'Invalid JSON body' }, { status: 400 });
  }
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const url = searchParams.get('url')?.trim() || searchParams.get('link')?.trim();
  return handleDetect(url);
}

async function handleDetect(url?: string) {
  try {
    if (!url) {
      return NextResponse.json(
        { success: false, message: 'URL is required' },
        { status: 400 }
      );
    }

    // 1. Check YouTube oEmbed (Official & Fast, no API key needed)
    try {
      const ytOembedUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`;
      const oembedRes = await fetch(ytOembedUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        next: { revalidate: 3600 }
      });

      if (oembedRes.ok) {
        const data = await oembedRes.json();
        if (data.title) {
          return NextResponse.json({
            success: true,
            title: data.title,
            author: data.author_name || 'YouTube',
            thumbnail: data.thumbnail_url || null,
            provider: 'youtube'
          });
        }
      }
    } catch (e) {
      // Continue to next provider
    }

    // 2. Check noembed.com (Supports YouTube, Vimeo, SoundCloud, etc.)
    try {
      const noembedUrl = `https://noembed.com/embed?url=${encodeURIComponent(url)}`;
      const noembedRes = await fetch(noembedUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        next: { revalidate: 3600 }
      });

      if (noembedRes.ok) {
        const data = await noembedRes.json();
        if (data.title) {
          return NextResponse.json({
            success: true,
            title: data.title,
            author: data.author_name || data.provider_name || 'Music',
            thumbnail: data.thumbnail_url || null,
            provider: data.provider_name || 'oembed'
          });
        }
      }
    } catch (e) {
      // Continue to next provider
    }

    // 3. Check Direct Audio File (.mp3, .wav, .ogg, .m4a, .aac, .flac)
    try {
      const parsed = new URL(url);
      const pathname = decodeURIComponent(parsed.pathname);
      const filename = pathname.split('/').pop() || '';
      if (filename.match(/\.(mp3|wav|ogg|m4a|aac|flac)$/i)) {
        const cleanName = filename
          .replace(/\.(mp3|wav|ogg|m4a|aac|flac)$/i, '')
          .replace(/[_-]+/g, ' ')
          .trim();

        if (cleanName) {
          return NextResponse.json({
            success: true,
            title: cleanName,
            author: 'เพลงพื้นหลัง',
            provider: 'audio-file'
          });
        }
      }
    } catch (e) {
      // Continue
    }

    // 4. If YouTube URL but oEmbed was unavailable, extract title from video ID pattern
    const ytMatch = url.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/))([\w-]{11})/);
    if (ytMatch) {
      return NextResponse.json({
        success: true,
        title: `YouTube Audio (${ytMatch[1]})`,
        author: 'เพลงพื้นหลัง',
        provider: 'youtube-id'
      });
    }

    return NextResponse.json({
      success: false,
      message: 'ไม่พบชื่อเพลงจากลิงก์นี้ กรุณากรอกชื่อเพลงด้วยตนเอง'
    }, { status: 404 });

  } catch (err: any) {
    console.error('Error detecting music title:', err);
    return NextResponse.json(
      { success: false, message: 'เกิดข้อผิดพลาดในการดึงข้อมูลเพลง' },
      { status: 500 }
    );
  }
}
