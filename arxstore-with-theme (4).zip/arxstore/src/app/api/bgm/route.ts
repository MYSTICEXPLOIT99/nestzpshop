import { NextResponse } from 'next/server';
import { getBgmSettingsServer, updateBgmSettingsServer, getSessionFromRequest } from '@/lib/server/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const settings = getBgmSettingsServer();
    return NextResponse.json(
      { success: true, data: settings },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      }
    );
  } catch (err: any) {
    return NextResponse.json(
      { success: false, message: 'Failed to retrieve BGM settings' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json(
        { success: false, message: 'สิทธิ์ถูกปฏิเสธ: เฉพาะผู้ดูแลระบบเท่านั้นที่สามารถแก้ไขเพลงพื้นหลังได้ (กรุณาเข้าสู่ระบบแอดมิน)' },
        { status: 403 }
      );
    }

    const body = await request.json().catch(() => ({}));
    
    // Auto-clean URL if user accidentally pasted concatenated links
    if (body.url && typeof body.url === 'string') {
      let cleaned = body.url.trim();
      // Match first full URL if doubled
      const matchUrl = cleaned.match(/https?:\/\/[^\s]+/);
      if (matchUrl) {
        cleaned = matchUrl[0];
        // If it contains embedded second https://
        const secondHttpIdx = cleaned.indexOf('http', 8);
        if (secondHttpIdx > 0) {
          cleaned = cleaned.substring(0, secondHttpIdx);
        }
      }
      body.url = cleaned;
    }

    const updated = updateBgmSettingsServer(body);

    return NextResponse.json(
      {
        success: true,
        message: 'บันทึกการตั้งค่าเพลงพื้นหลังสำเร็จ!',
        data: updated
      },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate'
        }
      }
    );
  } catch (err: any) {
    console.error('Error updating BGM settings:', err);
    return NextResponse.json(
      { success: false, message: 'เกิดข้อผิดพลาดในการบันทึกเพลง' },
      { status: 500 }
    );
  }
}
