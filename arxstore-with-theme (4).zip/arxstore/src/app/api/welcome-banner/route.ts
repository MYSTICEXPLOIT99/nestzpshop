import { NextResponse } from 'next/server';
import { getWelcomeBannerSettings, updateWelcomeBannerSettings, getSessionFromRequest } from '@/lib/server/db';

export async function GET() {
  try {
    const settings = getWelcomeBannerSettings();
    return NextResponse.json({ success: true, data: settings });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, message: 'Failed to retrieve welcome banner settings' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    if (session?.role !== 'admin') {
      return NextResponse.json(
        { success: false, message: 'สิทธิ์ถูกปฏิเสธ: เฉพาะผู้ดูแลระบบเท่านั้นที่สามารถแก้ไขข้อความต้อนรับได้' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const {
      enabled,
      titlePrefix,
      titleHighlight,
      highlightColor,
      description,
      button1Text,
      button1Link,
      button2Text,
      button2Link
    } = body;

    const updated = updateWelcomeBannerSettings({
      ...(enabled !== undefined ? { enabled: Boolean(enabled) } : {}),
      ...(titlePrefix !== undefined ? { titlePrefix: String(titlePrefix).trim() } : {}),
      ...(titleHighlight !== undefined ? { titleHighlight: String(titleHighlight).trim() } : {}),
      ...(highlightColor !== undefined ? { highlightColor: String(highlightColor).trim() } : {}),
      ...(description !== undefined ? { description: String(description).trim() } : {}),
      ...(button1Text !== undefined ? { button1Text: String(button1Text).trim() } : {}),
      ...(button1Link !== undefined ? { button1Link: String(button1Link).trim() } : {}),
      ...(button2Text !== undefined ? { button2Text: String(button2Text).trim() } : {}),
      ...(button2Link !== undefined ? { button2Link: String(button2Link).trim() } : {})
    });

    return NextResponse.json({
      success: true,
      message: 'บันทึกการตั้งค่าข้อความต้อนรับสำเร็จ!',
      data: updated
    });
  } catch (err: any) {
    console.error('Error updating welcome banner settings:', err);
    return NextResponse.json(
      { success: false, message: 'เกิดข้อผิดพลาดในการบันทึกข้อความต้อนรับ' },
      { status: 500 }
    );
  }
}
