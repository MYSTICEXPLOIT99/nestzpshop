import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { INITIAL_PRODUCTS } from '@/lib/data';
import { Product } from '@/types';
import { getSessionFromRequest } from '@/lib/server/db';

const DATA_DIR = path.join(process.cwd(), 'src', 'data');
const CATALOG_FILE = path.join(DATA_DIR, 'catalog.json');

function ensureCatalogFile(): { products: Product[]; deletedProductIds: string[] } {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(CATALOG_FILE)) {
      const initialData = {
        products: INITIAL_PRODUCTS,
        deletedProductIds: [] as string[]
      };
      fs.writeFileSync(CATALOG_FILE, JSON.stringify(initialData, null, 2), 'utf-8');
      return initialData;
    }
    const raw = fs.readFileSync(CATALOG_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    const deletedProductIds = Array.isArray(parsed.deletedProductIds) ? parsed.deletedProductIds : [];
    let products = Array.isArray(parsed.products) ? parsed.products : [];
    if (products.length === 0 && deletedProductIds.length === 0) {
      products = [...INITIAL_PRODUCTS];
      writeCatalogFile(products, []);
    }
    return {
      products,
      deletedProductIds
    };
  } catch (err) {
    console.error('Error in ensureCatalogFile:', err);
    return {
      products: [...INITIAL_PRODUCTS],
      deletedProductIds: []
    };
  }
}

function writeCatalogFile(products: Product[], deletedProductIds: string[] = []) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(
      CATALOG_FILE,
      JSON.stringify({ products, deletedProductIds }, null, 2),
      'utf-8'
    );
  } catch (err) {
    console.error('Error writing catalog file:', err);
  }
}

export async function GET() {
  const { products, deletedProductIds } = ensureCatalogFile();
  const validProducts = products.filter(p => !deletedProductIds.includes(p.id));
  return NextResponse.json({
    success: true,
    data: validProducts,
    deletedProductIds
  });
}

export async function POST(request: Request) {
  try {
    const session = getSessionFromRequest(request);
    const adminKey = request.headers.get('x-admin-key');
    const isAuthorized = session?.role === 'admin' || adminKey === 'arx_admin_secret_key';
    if (!isAuthorized) {
      return NextResponse.json(
        { success: false, message: 'การเข้าถึงถูกปฏิเสธ: เฉพาะผู้ดูแลระบบเท่านั้นที่สามารถแก้ไขข้อมูลสินค้าได้' },
        { status: 403 }
      );
    }

    const body = await request.json();
    let { products, deletedProductIds } = ensureCatalogFile();

    // 1. Action: Delete single product permanently
    if (body.action === 'delete') {
      const id = String(body.id || '');
      if (id) {
        products = products.filter(p => p.id !== id);
        if (!deletedProductIds.includes(id)) {
          deletedProductIds.push(id);
        }
        writeCatalogFile(products, deletedProductIds);
      }
      return NextResponse.json({
        success: true,
        data: products,
        deletedProductIds,
        message: 'Product deleted permanently from server'
      });
    }

    // 2. Action: Save all current products list (e.g. reorder, bulk promo, updates)
    if (body.action === 'save_all' && Array.isArray(body.products)) {
      products = body.products;
      if (Array.isArray(body.deletedProductIds)) {
        deletedProductIds = Array.from(new Set([...deletedProductIds, ...body.deletedProductIds]));
      }
      // Ensure deleted product IDs are filtered out
      products = products.filter(p => !deletedProductIds.includes(p.id));
      writeCatalogFile(products, deletedProductIds);
      return NextResponse.json({
        success: true,
        data: products,
        deletedProductIds,
        message: 'All products saved permanently to server'
      });
    }

    // 3. Action: Add new product
    if (body.action === 'add' && body.product) {
      const newProd = body.product as Product;
      deletedProductIds = deletedProductIds.filter(id => id !== newProd.id);
      products = [newProd, ...products.filter(p => p.id !== newProd.id)];
      writeCatalogFile(products, deletedProductIds);
      return NextResponse.json({
        success: true,
        data: products,
        deletedProductIds,
        message: 'Product added permanently to server'
      });
    }

    // 4. Action: Update product
    if (body.action === 'update' && body.id && body.data) {
      products = products.map(p => p.id === body.id ? { ...p, ...body.data } : p);
      writeCatalogFile(products, deletedProductIds);
      return NextResponse.json({
        success: true,
        data: products,
        deletedProductIds,
        message: 'Product updated permanently on server'
      });
    }

    // 5. Action: Restore default catalog
    if (body.action === 'restore_defaults') {
      products = [...INITIAL_PRODUCTS];
      deletedProductIds = [];
      writeCatalogFile(products, deletedProductIds);
      return NextResponse.json({
        success: true,
        data: products,
        deletedProductIds,
        message: 'Catalog restored to defaults'
      });
    }

    // Default legacy create
    const name = String(body.name || '').trim();
    if (name) {
      const newProduct: Product = {
        ...body,
        id: body.id || 'prod-' + Date.now(),
        name,
        packages: body.packages || [
          { id: 'pkg-1', name: '1 วัน', duration: '1 วัน', price: 50, stock: 10, inStock: true }
        ]
      };
      products = [newProduct, ...products];
      writeCatalogFile(products, deletedProductIds);
      return NextResponse.json({
        success: true,
        data: newProduct,
        message: 'Product created'
      }, { status: 201 });
    }

    return NextResponse.json({ success: true, data: products });
  } catch (err: any) {
    console.error('API /api/products error:', err);
    return NextResponse.json({ success: false, message: err?.message || 'Server error' }, { status: 500 });
  }
}
