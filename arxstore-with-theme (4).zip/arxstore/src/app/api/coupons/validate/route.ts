import { NextResponse } from 'next/server';
import { validateCouponCode } from '@/lib/server/db';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { code, price } = body;

    const numPrice = Number(price) || 0;
    const result = validateCouponCode(code, numPrice);

    if (!result.valid) {
      return NextResponse.json({
        success: false,
        message: result.message || 'โค้ดส่วนลดไม่ถูกต้องหรือหมดอายุ'
      }, { status: 400 });
    }

    return NextResponse.json({
      success: true,
      message: 'ใช้โค้ดส่วนลดสำเร็จ!',
      code: result.coupon?.code,
      discountPercent: result.discountPercent,
      discountAmount: result.discountAmount,
      description: result.coupon?.description
    });
  } catch (err) {
    return NextResponse.json({
      success: false,
      message: 'เกิดข้อผิดพลาดในการตรวจสอบโค้ดส่วนลด'
    }, { status: 500 });
  }
}
