'use client';

import React, { useState, useEffect } from 'react';
import { useStore } from '@/context/StoreContext';
import { Order } from '@/types';
import {
  ShoppingBag,
  Copy,
  Check,
  Download,
  AlertCircle,
  Clock,
  ShieldCheck,
  ExternalLink,
  ChevronRight,
  Eye,
  X,
  FileText
} from 'lucide-react';
import Link from 'next/link';

export default function OrdersPage() {
  const { user, orders, openAuthModal, playClick, showToast, lang, t, siteContent } = useStore();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [claimModalOpen, setClaimModalOpen] = useState(false);
  const [claimReason, setClaimReason] = useState('');
  const [claimSubmitted, setClaimSubmitted] = useState(false);

  const handleCopy = (text: string, id: string) => {
    playClick();
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    showToast({
      title: lang === 'th' ? 'คัดลอกคีย์สำเร็จ!' : 'License Key Copied!',
      message: text,
      type: 'success'
    });
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleClaimSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playClick();
    setClaimSubmitted(true);
    setTimeout(() => {
      setClaimModalOpen(false);
      setClaimSubmitted(false);
      setClaimReason('');
      showToast({
        title: lang === 'th' ? 'ส่งคำขอเคลมเรียบร้อย' : 'Claim Submitted',
        message: lang === 'th'
          ? 'ทีมงานได้รับเรื่องเคลมสินค้าแล้ว จะติดต่อกลับผ่าน Discord ภายใน 15 นาที'
          : 'Support team received your claim and will reach out via Discord within 15 minutes',
        type: 'success'
      });
    }, 1200);
  };

  // Close modals on Escape key press (กดปุ่ม Esc เพื่อปิดหน้าต่างคำสั่งซื้อ/เคลม)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'Esc') {
        if (claimModalOpen) {
          e.preventDefault();
          playClick();
          setClaimModalOpen(false);
        } else if (selectedOrder) {
          e.preventDefault();
          playClick();
          setSelectedOrder(null);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [claimModalOpen, selectedOrder, playClick]);

  return (
    <div className="py-5 sm:py-6 max-w-4xl mx-auto px-4 space-y-4 sm:space-y-5">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 pb-1 border-b border-white/5">
        <div className="flex items-start gap-3">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={siteContent?.branding?.logoUrl || "/brand/logo.png"}
            alt={siteContent?.branding?.siteName || "ARX STORE"}
            className="w-9 h-9 object-contain drop-shadow-[0_0_10px_rgba(var(--theme-accent-rgb),0.7)] mt-0.5"
            onError={(e) => {
              const target = e.currentTarget;
              if (!target.src.includes('arx-default-logo.png')) {
                target.src = '/brand/arx-default-logo.png';
              }
            }}
          />
          <div>
            <div className="flex items-center gap-1.5 text-[10px] font-bold text-cyan-400 uppercase tracking-widest mb-0.5">
              <ShoppingBag className="w-3.5 h-3.5 text-cyan-400" />
              <span>{siteContent?.branding?.siteName || 'ARX STORE'} · ORDER HISTORY & LICENSE KEYS</span>
            </div>
            <h1 className="text-lg sm:text-xl font-black text-white tracking-tight">
              {lang === 'th' ? 'ประวัติการสั่งซื้อของฉัน' : 'My Purchase Orders'}
            </h1>
            <p className="text-[11px] sm:text-xs text-slate-300 mt-0.5">
              {lang === 'th'
                ? 'ดูรายการสั่งซื้อ คัดลอกรหัสคีย์ (License Key) ดาวน์โหลดไฟล์สินค้า และแจ้งเคลมประกัน'
                : 'View your purchased products, copy license keys, download software and submit support claims.'}
            </p>
          </div>
        </div>

        <Link
          href="/store"
          onClick={playClick}
          className="px-3.5 py-1.5 rounded-full cyber-btn-primary text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto shadow-md"
        >
          <ShoppingBag className="w-3.5 h-3.5" /> {lang === 'th' ? 'เลือกซื้อสินค้าเพิ่ม' : 'Shop More Products'}
        </Link>
      </div>

      {/* Orders List */}
      {!user ? (
        <div className="cyber-card rounded-2xl p-8 text-center border border-cyan-500/20 max-w-sm mx-auto">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mx-auto mb-3">
            <ShoppingBag className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-white mb-1">{lang === 'th' ? 'กรุณาเข้าสู่ระบบ' : 'Please Sign In'}</h3>
          <p className="text-[11px] text-slate-400 mb-4">
            {lang === 'th'
              ? 'เข้าสู่ระบบเพื่อดูประวัติคำสั่งซื้อและรับ License Key ของคุณ'
              : 'Sign in to access your order history and view your license keys.'}
          </p>
          <button
            onClick={() => openAuthModal('login')}
            className="px-4 py-2 rounded-lg cyber-btn-primary font-bold text-xs"
          >
            {lang === 'th' ? 'เข้าสู่ระบบทันที' : 'Sign In Now'}
          </button>
        </div>
      ) : orders.length === 0 ? (
        <div className="cyber-card rounded-2xl p-8 text-center border border-slate-800">
          <div className="w-12 h-12 rounded-xl bg-slate-900 text-slate-500 flex items-center justify-center mx-auto mb-3">
            <ShoppingBag className="w-6 h-6 opacity-40" />
          </div>
          <h3 className="text-sm sm:text-base font-bold text-white mb-1">{lang === 'th' ? 'ยังไม่มีรายการสั่งซื้อ' : 'No Orders Yet'}</h3>
          <p className="text-[11px] text-slate-400 mb-4 max-w-sm mx-auto">
            {lang === 'th'
              ? 'เมื่อคุณสั่งซื้อสินค้า ข้อมูลคีย์ ลิงก์ดาวน์โหลด และคู่มือติดตั้งจะถูกเก็บไว้อย่างปลอดภัยที่นี่ตลอดชีพ'
              : 'When you purchase products, your keys, download links and instructions are safely preserved here.'}
          </p>
          <Link
            href="/store"
            onClick={playClick}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg cyber-btn-primary text-xs font-bold"
          >
            {lang === 'th' ? 'สำรวจสินค้าในร้าน →' : 'Explore Store →'}
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((ord) => (
            <div
              key={ord.id}
              className="cyber-card rounded-xl p-3.5 sm:p-4 bg-slate-950/80 border border-cyan-500/20 hover:border-cyan-400/40 transition flex flex-col lg:flex-row lg:items-center justify-between gap-3 sm:gap-4"
            >
              
              {/* Product Info */}
              <div className="space-y-1 flex-1">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="font-mono font-bold text-cyan-400 text-[11px]">
                    #{ord.orderNumber}
                  </span>
                  <span className="text-slate-600">•</span>
                  <span className="text-slate-400 text-[10.5px]">{ord.createdAt}</span>
                  <span className="px-2 py-0.25 rounded-full text-[9.5px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                    <Check className="w-2.5 h-2.5" /> {lang === 'th' ? 'ได้รับสินค้าแล้ว' : 'Delivered'}
                  </span>
                </div>

                <h3 className="text-sm sm:text-base font-bold text-white">
                  {ord.productName}
                </h3>

                <p className="text-[11px] text-slate-300">
                  {lang === 'th' ? 'แพ็กเกจ: ' : 'Package: '}<strong className="text-cyan-300">{ord.packageName}</strong> • {lang === 'th' ? 'ยอดชำระ: ' : 'Total: '}<strong className="font-mono text-cyan-300">฿{ord.price.toLocaleString()}</strong>
                </p>

                {/* Key Box Inline */}
                <div className="mt-2 p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between gap-2.5 max-w-sm">
                  <div className="min-w-0">
                    <span className="text-[9.5px] text-slate-400 block">License Key:</span>
                    <span className="font-mono text-xs font-bold text-cyan-300 truncate block select-all">
                      {ord.licenseKey}
                    </span>
                  </div>
                  <button
                    onClick={() => handleCopy(ord.licenseKey, ord.id)}
                    className="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 transition shrink-0"
                    title={lang === 'th' ? 'คัดลอกคีย์' : 'Copy Key'}
                  >
                    {copiedKey === ord.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {ord.downloadUrl && (
                  <a
                    href={ord.downloadUrl}
                    target="_blank"
                    rel="noreferrer"
                    onClick={playClick}
                    className="px-3 py-1.5 rounded-lg cyber-btn-primary font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/30"
                  >
                    <Download className="w-3.5 h-3.5" /> {lang === 'th' ? 'ดาวน์โหลดไฟล์' : 'Download File'}
                  </a>
                )}

                <button
                  onClick={() => {
                    playClick();
                    setSelectedOrder(ord);
                  }}
                  className="px-3 py-1.5 rounded-lg cyber-btn-secondary text-xs font-semibold flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" /> {lang === 'th' ? 'ดูรายละเอียด' : 'View Details'}
                </button>

                <button
                  onClick={() => {
                    playClick();
                    setSelectedOrder(ord);
                    setClaimModalOpen(true);
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-[color:var(--theme-main)]/50 text-blue-300 text-xs font-semibold transition"
                >
                  {lang === 'th' ? 'แจ้งเคลม' : 'Claim Warranty'}
                </button>
              </div>

            </div>
          ))}
        </div>
      )}

      {/* Order Detail Modal */}
      {selectedOrder && !claimModalOpen && (
        <div 
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in-50 cursor-pointer"
          onClick={() => setSelectedOrder(null)}
        >
          <div 
            className="relative w-full max-w-md cyber-card rounded-2xl p-4 sm:p-5 bg-slate-950/95 border border-cyan-500/40 shadow-2xl cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedOrder(null)}
              className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-sm sm:text-base font-bold text-white mb-0.5">{lang === 'th' ? 'รายละเอียดคำสั่งซื้อ' : 'Order Details'}</h3>
            <p className="text-[11px] font-mono text-cyan-400 mb-3">#{selectedOrder.orderNumber}</p>

            <div className="space-y-2.5 text-xs">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">{lang === 'th' ? 'สินค้า:' : 'Product:'}</span>
                  <span className="font-bold text-white">{selectedOrder.productName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">{lang === 'th' ? 'แพ็กเกจ:' : 'Package:'}</span>
                  <span className="text-cyan-300 font-semibold">{selectedOrder.packageName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">{lang === 'th' ? 'ราคา:' : 'Price:'}</span>
                  <span className="font-mono font-bold text-emerald-400">฿{selectedOrder.price.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">{lang === 'th' ? 'วันที่สั่งซื้อ:' : 'Order Date:'}</span>
                  <span className="text-slate-300">{selectedOrder.createdAt}</span>
                </div>
              </div>

              <div>
                <span className="font-bold text-slate-300 block mb-1 text-[11px]">{lang === 'th' ? 'รหัสคีย์ใช้งาน (License Key):' : 'License Key:'}</span>
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-cyan-500/30">
                  <span className="font-mono text-xs font-bold text-cyan-300 select-all">{selectedOrder.licenseKey}</span>
                  <button
                    onClick={() => handleCopy(selectedOrder.licenseKey, 'modal')}
                    className="px-2 py-0.5 text-[11px] rounded bg-cyan-600/30 text-cyan-200"
                  >
                    {lang === 'th' ? 'คัดลอก' : 'Copy'}
                  </button>
                </div>
              </div>

              {selectedOrder.credentials && (
                <div>
                  <span className="font-bold text-slate-300 block mb-0.5 text-[11px]">{lang === 'th' ? 'ข้อมูลเพิ่มเติม / รหัสผ่าน / บันทึก:' : 'Credentials / Notes:'}</span>
                  <div className="p-2 rounded-lg bg-slate-900 border border-[color:var(--theme-main)]/35 text-blue-300 font-mono text-[11px] whitespace-pre-line select-all">
                    {selectedOrder.credentials}
                  </div>
                </div>
              )}

              {selectedOrder.instructions && (
                <div>
                  <span className="font-bold text-slate-300 block mb-0.5 text-[11px]">{lang === 'th' ? 'คำแนะนำการใช้งาน:' : 'Usage Instructions:'}</span>
                  <p className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 font-mono text-[10.5px] whitespace-pre-line">
                    {selectedOrder.instructions}
                  </p>
                </div>
              )}
            </div>

            <div className="mt-4 flex gap-2">
              {selectedOrder.downloadUrl && (
                <a
                  href={selectedOrder.downloadUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 py-1.5 rounded-lg cyber-btn-primary font-bold text-xs flex items-center justify-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" /> {lang === 'th' ? 'ดาวน์โหลดไฟล์' : 'Download File'}
                </a>
              )}
              <button
                onClick={() => setSelectedOrder(null)}
                className="flex-1 py-1.5 rounded-lg cyber-btn-secondary font-semibold text-xs"
              >
                {lang === 'th' ? 'ปิดหน้าต่าง' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Claim Modal */}
      {claimModalOpen && selectedOrder && (
        <div 
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in-50 cursor-pointer"
          onClick={() => setClaimModalOpen(false)}
        >
          <div 
            className="relative w-full max-w-sm cyber-card rounded-2xl p-4 sm:p-5 bg-slate-950/95 border border-[color:var(--theme-main)]/40 shadow-2xl cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setClaimModalOpen(false)}
              className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-sm sm:text-base font-bold text-white mb-0.5 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-blue-400" />
              {lang === 'th' ? 'แจ้งเคลมสินค้า / ปัญหาการใช้งาน' : 'Product Warranty / Support Claim'}
            </h3>
            <p className="text-[11px] text-slate-400 mb-3">
              {lang === 'th'
                ? `คำสั่งซื้อ #${selectedOrder.orderNumber} (${selectedOrder.productName})`
                : `Order #${selectedOrder.orderNumber} (${selectedOrder.productName})`}
            </p>

            <form onSubmit={handleClaimSubmit} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  {lang === 'th' ? 'ระบุรายละเอียดปัญหาที่พบ:' : 'Describe the issue encountered:'}
                </label>
                <textarea
                  rows={3}
                  required
                  value={claimReason}
                  onChange={(e) => setClaimReason(e.target.value)}
                  placeholder={lang === 'th' ? 'เช่น คีย์ไม่ทำงาน, โปรแกรมขึ้น Error รหัส ..., ไฟล์ดาวน์โหลดมีปัญหา' : 'e.g. Key not working, error code ..., download issue'}
                  className="w-full p-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-[color:var(--theme-main)]"
                />
              </div>

              <div className="p-2 rounded-lg bg-[color:var(--theme-main)]/15 border border-[color:var(--theme-main)]/30 text-blue-300 text-[10.5px] leading-relaxed">
                {lang === 'th'
                  ? '💡 รับประกันเปลี่ยนคีย์ใหม่หรือแก้ไขปัญหาฟรี 100% ภายในระยะเวลารับประกันของสินค้า'
                  : '💡 100% replacement warranty or support fix during active product coverage'}
              </div>

              <button
                type="submit"
                disabled={claimSubmitted}
                className="w-full py-2.5 rounded-lg bg-[color:var(--theme-main)] hover:bg-[color:var(--theme-sec)] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.4)]"
              >
                {claimSubmitted 
                  ? (lang === 'th' ? 'กำลังส่งข้อมูล...' : 'Submitting...') 
                  : (lang === 'th' ? 'ส่งคำขอแจ้งเคลม' : 'Submit Claim')}
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
