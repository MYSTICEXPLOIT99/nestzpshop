'use client';

import React, { useState, useId, useRef, useEffect, useMemo } from 'react';
import { useStore } from '@/context/StoreContext';
import {
  Wallet,
  QrCode,
  Building2,
  Gift,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  X,
  Upload,
  Clock,
  Sparkles,
  Shield,
  FileText,
  ChevronRight,
  TrendingUp,
  Info,
  RefreshCw,
  Zap,
  ExternalLink
} from 'lucide-react';

import { PromptPayIcon, KPlusIcon, TrueMoneyIcon, BankIcon } from '@/components/common/PaymentIcons';

export default function TopupPage() {
  const {
    user,
    topups,
    topupAngpao,
    topupSlip,
    openAuthModal,
    playClick,
    slipConfig,
    showToast,
    lang
  } = useStore();

  // Active modal state: null | 'promptpay' | 'bank' | 'angpao'
  const [activeModal, setActiveModal] = useState<'promptpay' | 'bank' | 'angpao' | null>(null);

  // Payment channel toggles & fee configured by admin
  const promptPayEnabled = slipConfig?.channelPromptPayEnabled !== false;
  const bankTransferEnabled = slipConfig?.channelBankTransferEnabled !== false;
  const angpaoEnabled = slipConfig?.channelAngpaoEnabled !== false;
  const angpaoFeePercent = typeof slipConfig?.angpaoFeePercent === 'number' ? slipConfig.angpaoFeePercent : 2.9;

  // Bank Info configuration
  const bankAccount = useMemo(() => {
    const rawBank = slipConfig?.bankName?.trim();
    const bankDisplay = rawBank || 'กสิกรไทย (KBANK / K+)';

    return {
      bank: bankDisplay,
      accountNumber: slipConfig?.promptPayNumber && slipConfig.promptPayNumber !== '098-XXX-XXXX' ? slipConfig.promptPayNumber : '5160906053',
      accountName: slipConfig?.accountName && slipConfig.accountName !== 'ARX STORE OFFICIAL' ? slipConfig.accountName : 'ณัฐพงศ์ แซ่หลู่',
    };
  }, [slipConfig]);

  // Copy bank account state
  const [copiedAccount, setCopiedAccount] = useState(false);
  const handleCopyAccount = () => {
    playClick();
    navigator.clipboard.writeText(bankAccount.accountNumber.replace(/[^0-9]/g, ''));
    setCopiedAccount(true);
    showToast({
      title: 'คัดลอกเลขบัญชีแล้ว',
      message: `${bankAccount.bank} ${bankAccount.accountNumber}`,
      type: 'success'
    });
    setTimeout(() => setCopiedAccount(false), 2000);
  };

  // ----------------------------------------------------
  // PROMPTPAY MODAL STATES
  // ----------------------------------------------------
  const [ppAmount, setPpAmount] = useState<number>(100);
  const [ppStep, setPpStep] = useState<'amount' | 'qr'>('amount');
  const [ppTimer, setPpTimer] = useState<number>(600); // 10 minutes
  const [isVerifyingPp, setIsVerifyingPp] = useState<boolean>(false);

  // Countdown timer for PromptPay QR
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (activeModal === 'promptpay' && ppStep === 'qr' && ppTimer > 0) {
      timer = setInterval(() => {
        setPpTimer(prev => Math.max(0, prev - 1));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [activeModal, ppStep, ppTimer]);

  const handleGeneratePpQr = () => {
    playClick();
    if (!user) {
      openAuthModal('login');
      return;
    }
    if (ppAmount <= 0) {
      showToast({ title: 'ยอดเงินไม่ถูกต้อง', message: 'กรุณาระบุยอดเงินอย่างน้อย 1 บาท', type: 'error' });
      return;
    }
    setPpStep('qr');
    setPpTimer(600);
  };

  const handleConfirmPpPayment = async () => {
    playClick();
    if (!user) return;
    setIsVerifyingPp(true);
    try {
      const res = await topupSlip(ppAmount, user.username, 'PromptPay QR', '/images/slip_sample.png');
      setIsVerifyingPp(false);
      if (res.success) {
        showToast({
          title: 'แจ้งการชำระเงินสำเร็จ',
          message: `บันทึกรายการ PromptPay ฿${ppAmount.toFixed(2)} เรียบร้อยแล้ว อยู่ระหว่างตรวจสอบ`,
          type: 'success'
        });
        setActiveModal(null);
        setPpStep('amount');
      } else {
        showToast({ title: 'เกิดข้อผิดพลาด', message: res.message, type: 'error' });
      }
    } catch {
      setIsVerifyingPp(false);
      showToast({ title: 'เกิดข้อผิดพลาด', message: 'ไม่สามารถส่งข้อมูลได้', type: 'error' });
    }
  };

  // ----------------------------------------------------
  // BANK TRANSFER MODAL STATES
  // ----------------------------------------------------
  const [slipFile, setSlipFile] = useState<string | null>(null);
  const [slipFileName, setSlipFileName] = useState<string>('');
  const [slipFileSize, setSlipFileSize] = useState<string>('');
  const [isSubmittingSlip, setIsSubmittingSlip] = useState<boolean>(false);
  const [bankModalMsg, setBankModalMsg] = useState<{ success: boolean; text: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) processSelectedFile(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processSelectedFile(file);
  };

  const processSelectedFile = (file: File) => {
    if (file.size > 4 * 1024 * 1024) {
      setBankModalMsg({
        success: false,
        text: 'ขนาดไฟล์เกินกำหนด (ต้องไม่เกิน 4 MB)'
      });
      return;
    }
    const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type.toLowerCase())) {
      setBankModalMsg({
        success: false,
        text: 'รองรับเฉพาะไฟล์รูปภาพ (PNG, JPG, WEBP) เท่านั้น'
      });
      return;
    }
    setBankModalMsg(null);
    setSlipFileName(file.name);
    setSlipFileSize((file.size / (1024 * 1024)).toFixed(2) + ' MB');
    const reader = new FileReader();
    reader.onloadend = () => {
      setSlipFile(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleBankSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBankModalMsg(null);
    if (!user) {
      openAuthModal('login');
      return;
    }
    if (!slipFile) {
      setBankModalMsg({
        success: false,
        text: 'กรุณาแนบรูปภาพสลิปโอนเงินก่อนกดยืนยัน'
      });
      return;
    }

    setIsSubmittingSlip(true);
    const res = await topupSlip(undefined, undefined, bankAccount.bank, slipFile);
    setIsSubmittingSlip(false);

    if (res.success) {
      showToast({
        title: 'ส่งสลิปโอนเงินสำเร็จ',
        message: 'ระบบได้รับสลิปแล้ว กำลังตรวจสอบยอดเงินให้อัตโนมัติ',
        type: 'success'
      });
      setSlipFile(null);
      setSlipFileName('');
      setActiveModal(null);
    } else {
      setBankModalMsg({ success: false, text: res.message });
    }
  };

  // ----------------------------------------------------
  // TRUEMONEY ANGPAO MODAL STATES
  // ----------------------------------------------------
  const [voucherUrl, setVoucherUrl] = useState('');
  const [angpaoAmount, setAngpaoAmount] = useState('');
  const [isClaimingAngpao, setIsClaimingAngpao] = useState(false);
  const [angpaoModalMsg, setAngpaoModalMsg] = useState<{ success: boolean; text: string } | null>(null);

  const handleAngpaoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAngpaoModalMsg(null);
    if (!user) {
      openAuthModal('login');
      return;
    }
    if (!voucherUrl.trim()) {
      setAngpaoModalMsg({
        success: false,
        text: 'กรุณาวางลิงก์ซองของขวัญ TrueMoney Wallet'
      });
      return;
    }

    setIsClaimingAngpao(true);
    const parsedAmount = angpaoAmount ? parseFloat(angpaoAmount) : undefined;
    const res = await topupAngpao(voucherUrl.trim(), parsedAmount);
    setIsClaimingAngpao(false);

    if (res.success) {
      showToast({
        title: 'ส่งข้อมูลซองของขวัญสำเร็จ!',
        message: res.message || `ส่งซองอั่งเปาเรียบร้อยแล้ว ยอดเงิน ฿${(res.amount || parsedAmount || 100).toLocaleString()}`,
        type: 'success'
      });
      setVoucherUrl('');
      setAngpaoAmount('');
      setActiveModal(null);
    } else {
      setAngpaoModalMsg({ success: false, text: res.message });
    }
  };

  // ----------------------------------------------------
  // TRANSACTION HISTORY DATA
  // ----------------------------------------------------
  // TRANSACTION HISTORY DATA (USER SPECIFIC)
  // ----------------------------------------------------
  const displayHistory = useMemo(() => {
    if (!user) return [];
    if (topups && topups.length > 0) {
      return topups.slice(0, 10).map((t) => ({
        id: t.id,
        title: t.method === 'angpao' ? 'ซองอั่งเปา TrueMoney' : (t.bankName || 'PromptPay QR'),
        date: t.createdAt,
        amount: t.amount,
        status: t.status === 'approved' ? ('success' as const) : ('pending' as const),
        type: t.method === 'angpao' ? 'angpao' : 'bank'
      }));
    }
    return [];
  }, [topups, user]);

  // Monthly stats (Only for logged-in user)
  const monthlyTotal = useMemo(() => {
    if (!user) return 0;
    if (topups && topups.length > 0) {
      return topups.reduce((acc, curr) => acc + (curr.status === 'approved' ? curr.amount : 0), 0);
    }
    return 0;
  }, [topups, user]);

  const lastTopupInfo = useMemo(() => {
    if (!user) return '-';
    if (topups && topups.length > 0) {
      const last = topups[0];
      return `฿${last.amount.toFixed(2)} - ${last.createdAt.split(' ')[0] || 'ล่าสุด'}`;
    }
    return '-';
  }, [topups, user]);

  return (
    <div className="min-h-screen py-8 sm:py-10 max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8 select-none">

      {/* ========================================================
          TOP SECTION: Header Banner & Glowing Wallet Card
         ======================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        
        {/* Left Column: Heading, description & feature tags */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Top Up Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold tracking-wide bg-[color:var(--theme-main)]/20 border border-[color:var(--theme-main)]/50 text-blue-400 shadow-[0_0_15px_rgba(var(--theme-main-rgb),0.35)]">
            <Gift className="w-3.5 h-3.5 text-blue-400" />
            <span>TOP UP</span>
          </div>

          {/* Title */}
          <div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight flex flex-wrap items-center gap-2">
              <span>เติมเครดิต</span>
              <span className="bg-gradient-to-r from-[var(--theme-main)] via-blue-500 to-sky-400 bg-clip-text text-transparent drop-shadow-[0_0_25px_rgba(var(--theme-main-rgb),0.5)]">
                ง่าย ไว ปลอดภัย
              </span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-2 leading-relaxed max-w-xl">
              เลือกช่องทางที่สะดวก ชำระเงินแล้วระบบเติมเครดิตเข้าบัญชีให้อัตโนมัติ ใช้ซื้อสินค้าและบริการได้ทันที
            </p>
          </div>

          {/* Feature Pills */}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-slate-300 bg-white/[0.03] border border-white/10 backdrop-blur-sm">
              <Zap className="w-3.5 h-3.5 text-blue-400" />
              <span>เข้าอัตโนมัติ</span>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-slate-300 bg-white/[0.03] border border-white/10 backdrop-blur-sm">
              <Shield className="w-3.5 h-3.5 text-blue-400" />
              <span>ตรวจสอบทุกรายการ</span>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-slate-300 bg-white/[0.03] border border-white/10 backdrop-blur-sm">
              <Clock className="w-3.5 h-3.5 text-blue-400" />
              <span>ดูประวัติได้ตลอด</span>
            </div>
          </div>

        </div>

        {/* Right Column: Sleek Glowing Blue Wallet Card (#0000FF) */}
        <div className="lg:col-span-5">
          <div className="relative overflow-hidden rounded-2xl p-6 text-white bg-gradient-to-br from-[var(--theme-main)] via-[var(--theme-sec)] to-[#050b28] shadow-[0_12px_45px_rgba(var(--theme-main-rgb),0.45)] border border-[color:var(--theme-main)]/40 transition-transform duration-300 hover:scale-[1.01]">
            
            {/* Background Decorative Circles / Mesh */}
            <div className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-white/10 blur-2xl pointer-events-none" />
            <div className="absolute -bottom-16 -left-16 w-48 h-48 rounded-full bg-black/20 blur-2xl pointer-events-none" />
            <div className="absolute right-4 top-1/2 -translate-y-1/2 w-32 h-32 rounded-full border border-white/10 pointer-events-none" />

            {/* Top row: Label + username */}
            <div className="flex items-center justify-between relative z-10">
              <div className="flex items-center gap-2 text-xs font-medium text-white/90">
                <Wallet className="w-4 h-4 text-white" />
                <span>เครดิตคงเหลือ</span>
              </div>
              <span className="text-xs font-mono tracking-wider text-white/80 italic font-semibold">
                {user ? user.username : 'ยังไม่ได้เข้าสู่ระบบ'}
              </span>
            </div>

            {/* Main Balance Display */}
            <div className="mt-4 mb-5 relative z-10">
              <div className="text-3xl sm:text-4xl md:text-5xl font-black font-mono tracking-tight drop-shadow-md flex items-baseline gap-1">
                <span>{user ? user.balance.toFixed(2) : '0.00'}</span>
                <span className="text-2xl sm:text-3xl font-normal opacity-90">฿</span>
              </div>
            </div>

            {/* Bottom row: Monthly stats & Last Topup */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/20 relative z-10 text-xs">
              <div>
                <span className="text-white/70 block text-[11px] font-medium">เติมเดือนนี้</span>
                <span className="text-sm font-bold font-mono text-white mt-0.5 block">
                  {user ? `${monthlyTotal.toFixed(2)} ฿` : '-'}
                </span>
              </div>
              <div className="text-right sm:text-left">
                <span className="text-white/70 block text-[11px] font-medium">เติมล่าสุด</span>
                <span className="text-sm font-bold font-mono text-white mt-0.5 block truncate">
                  {user ? lastTopupInfo : '-'}
                </span>
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* ========================================================
          CENTER SECTION: เลือกช่องทางเติมเงิน (3 Channels Grid)
         ======================================================== */}
      <div className="space-y-4">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
            เลือกช่องทางเติมเงิน
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            กดเลือกแล้วทำตามขั้นตอนในหน้าต่างที่เปิดขึ้น
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Card 1: PromptPay QR */}
          <div
            onClick={() => {
              if (!promptPayEnabled) {
                playError();
                showToast({ title: 'ปิดให้บริการชั่วคราว', message: 'ช่องทาง PromptPay QR ปิดให้บริการชั่วคราว', type: 'warning' });
                return;
              }
              playClick();
              setActiveModal('promptpay');
            }}
            className={`group relative rounded-2xl p-4 sm:p-5 border transition-all duration-300 flex flex-col justify-between ${
              promptPayEnabled
                ? 'bg-[color:var(--arx-dk-0e1017)]/90 border-white/10 hover:border-[color:var(--theme-main)]/60 hover:shadow-[0_0_25px_rgba(var(--theme-main-rgb),0.35)] cursor-pointer'
                : 'bg-[color:var(--arx-dk-0e1017)]/50 border-white/5 opacity-55 grayscale cursor-not-allowed'
            }`}
          >
            {/* Top Badge */}
            <div className="absolute top-3.5 right-3.5">
              {promptPayEnabled ? (
                <span className="bg-[color:var(--theme-main)] text-white text-[10.5px] font-black px-2 py-0.5 rounded-full shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.5)]">
                  แนะนำ
                </span>
              ) : (
                <span className="bg-slate-800 text-slate-400 text-[10.5px] font-bold px-2 py-0.5 rounded-full border border-white/5">
                  ปิดบริการ
                </span>
              )}
            </div>

            <div>
              {/* Logo & Header */}
              <div className="w-12 h-12 rounded-xl bg-white p-1.5 flex items-center justify-center shadow-md mb-3 border border-slate-200">
                <PromptPayIcon className="w-full h-full" />
              </div>

              <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-blue-400 transition-colors">
                PromptPay QR
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                สแกนจ่ายผ่านแอปธนาคารไหนก็ได้
              </p>

              {/* Tag */}
              <div className="mt-3">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium text-slate-300 bg-white/5 border border-white/10">
                  <Zap className="w-3 h-3 text-blue-400" />
                  <span>เข้าอัตโนมัติ 1-3 นาที</span>
                </span>
              </div>
            </div>

            {/* Bottom Action Link */}
            <div className="mt-5 pt-3 border-t border-white/5 flex items-center justify-center gap-1 text-xs text-slate-400 group-hover:text-blue-400 font-semibold transition-colors">
              <span>{promptPayEnabled ? 'เติมด้วย QR' : 'ปิดให้บริการ'}</span>
              {promptPayEnabled && <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />}
            </div>
          </div>

          {/* Card 2: โอนผ่านธนาคาร (K+) */}
          <div
            onClick={() => {
              if (!bankTransferEnabled) {
                playError();
                showToast({ title: 'ปิดให้บริการชั่วคราว', message: 'ช่องทางโอนผ่านธนาคารปิดให้บริการชั่วคราว', type: 'warning' });
                return;
              }
              playClick();
              setActiveModal('bank');
            }}
            className={`group relative rounded-2xl p-4 sm:p-5 border transition-all duration-300 flex flex-col justify-between ${
              bankTransferEnabled
                ? 'bg-[color:var(--arx-dk-0e1017)]/90 border-white/10 hover:border-[color:var(--theme-main)]/60 hover:shadow-[0_0_25px_rgba(var(--theme-main-rgb),0.35)] cursor-pointer'
                : 'bg-[color:var(--arx-dk-0e1017)]/50 border-white/5 opacity-55 grayscale cursor-not-allowed'
            }`}
          >
            {/* Top Badge */}
            <div className="absolute top-3.5 right-3.5">
              {!bankTransferEnabled && (
                <span className="bg-slate-800 text-slate-400 text-[10.5px] font-bold px-2 py-0.5 rounded-full border border-white/5">
                  ปิดบริการ
                </span>
              )}
            </div>

            <div>
              {/* Bank Logo */}
              <div className="w-12 h-12 rounded-xl overflow-hidden flex items-center justify-center shadow-md mb-3 group-hover:scale-105 transition-transform">
                <BankIcon bankName={slipConfig?.bankName} className="w-full h-full" />
              </div>

              <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-blue-400 transition-colors">
                โอนผ่านธนาคาร
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                {bankAccount.bank}
              </p>

              {/* Tag */}
              <div className="mt-3">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium text-slate-300 bg-white/5 border border-white/10">
                  <Shield className="w-3 h-3 text-blue-400" />
                  <span>ตรวจสอบอัตโนมัติ</span>
                </span>
              </div>
            </div>

            {/* Bottom Action Link */}
            <div className="mt-5 pt-3 border-t border-white/5 flex items-center justify-center gap-1 text-xs text-slate-400 group-hover:text-blue-400 font-semibold transition-colors">
              <span>{bankTransferEnabled ? 'เติมด้วยการโอน' : 'ปิดให้บริการ'}</span>
              {bankTransferEnabled && <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />}
            </div>
          </div>

          {/* Card 3: ซองอั่งเปา TrueMoney */}
          <div
            onClick={() => {
              if (!angpaoEnabled) {
                playError();
                showToast({ title: 'ปิดให้บริการชั่วคราว', message: 'ช่องทางซองของขวัญ TrueMoney Wallet ปิดให้บริการชั่วคราว', type: 'warning' });
                return;
              }
              playClick();
              setActiveModal('angpao');
            }}
            className={`group relative rounded-2xl p-4 sm:p-5 border transition-all duration-300 flex flex-col justify-between ${
              angpaoEnabled
                ? 'bg-[color:var(--arx-dk-0e1017)]/90 border-white/10 hover:border-[color:var(--theme-main)]/60 hover:shadow-[0_0_25px_rgba(var(--theme-main-rgb),0.35)] cursor-pointer'
                : 'bg-[color:var(--arx-dk-0e1017)]/50 border-white/5 opacity-55 grayscale cursor-not-allowed'
            }`}
          >
            {/* Top Badge */}
            <div className="absolute top-3.5 right-3.5">
              {!angpaoEnabled && (
                <span className="bg-slate-800 text-slate-400 text-[10.5px] font-bold px-2 py-0.5 rounded-full border border-white/5">
                  ปิดบริการ
                </span>
              )}
            </div>

            <div>
              {/* TrueMoney Logo */}
              <div className="w-12 h-12 rounded-xl bg-white p-1 flex items-center justify-center shadow-md mb-3 border border-slate-200">
                <TrueMoneyIcon className="w-9 h-9" />
              </div>

              <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-blue-400 transition-colors">
                ซองอั่งเปา TrueMoney
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                วางลิงก์ซองของขวัญ
              </p>

              {/* Tags */}
              <div className="mt-3 flex flex-wrap items-center gap-1.5">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20">
                  <Zap className="w-2.5 h-2.5" />
                  <span>เติมทันที</span>
                </span>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10.5px] font-medium text-slate-300 bg-white/5 border border-white/10">
                  {angpaoFeePercent === 0 ? 'ฟรีค่าธรรมเนียม' : `ค่าธรรมเนียม ${angpaoFeePercent}%`}
                </span>
              </div>
            </div>

            {/* Bottom Action Link */}
            <div className="mt-5 pt-3 border-t border-white/5 flex items-center justify-center gap-1 text-xs text-slate-400 group-hover:text-blue-400 font-semibold transition-colors">
              <span>{angpaoEnabled ? 'เติมด้วยซอง' : 'ปิดให้บริการ'}</span>
              {angpaoEnabled && <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />}
            </div>
          </div>

        </div>
      </div>

      {/* ========================================================
          BOTTOM SECTION: ประวัติการเติมเงิน & เติมเงินยังไง
         ======================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column (8 cols): ประวัติการเติมเงิน */}
        <div id="topup-history" className="lg:col-span-8 rounded-2xl p-4 sm:p-5 bg-[color:var(--arx-dk-0e1017)]/90 border border-white/10 space-y-4 scroll-mt-24">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-400" />
              <h3 className="text-sm sm:text-base font-bold text-white">
                ประวัติการเติมเงิน
              </h3>
            </div>
            {user && displayHistory.length > 0 && (
              <span className="text-xs text-slate-400">
                {displayHistory.length} รายการล่าสุด
              </span>
            )}
          </div>

          {!user ? (
            <div className="py-10 px-4 text-center rounded-xl bg-white/[0.02] border border-white/5 flex flex-col items-center justify-center space-y-3">
              <div className="w-12 h-12 rounded-xl bg-[color:var(--theme-main)]/15 border border-[color:var(--theme-main)]/30 text-blue-400 flex items-center justify-center">
                <Clock className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm sm:text-base font-bold text-white">
                  กรุณาเข้าสู่ระบบเพื่อดูประวัติการเติมเงิน
                </h4>
                <p className="text-xs text-slate-400 max-w-sm">
                  เข้าสู่ระบบเพื่อตรวจสอบสถานะเครดิตและรายการเติมเงินของคุณ
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  playClick();
                  openAuthModal('login');
                }}
                className="mt-2 px-5 py-2.5 rounded-xl text-xs font-black text-white bg-[color:var(--theme-main)] hover:bg-[color:var(--theme-sec)] shadow-md shadow-blue-500/25 transition-all cursor-pointer active:scale-95"
              >
                เข้าสู่ระบบทันที
              </button>
            </div>
          ) : displayHistory.length === 0 ? (
            <div className="py-10 px-4 text-center rounded-xl bg-white/[0.02] border border-white/5 flex flex-col items-center justify-center space-y-2">
              <div className="w-10 h-10 rounded-full bg-white/5 text-slate-500 flex items-center justify-center">
                <Clock className="w-5 h-5" />
              </div>
              <h4 className="text-xs sm:text-sm font-semibold text-slate-300">
                ยังไม่มีประวัติการเติมเงิน
              </h4>
              <p className="text-[11px] text-slate-500 max-w-xs">
                เมื่อคุณทำรายการเติมเงิน ระบบจะบันทึกและแสดงสถานะรายการของคุณที่นี่
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {displayHistory.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/5 hover:border-white/10 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 shrink-0">
                      {item.type === 'promptpay' ? (
                        <QrCode className="w-4 h-4 text-red-400" />
                      ) : item.type === 'angpao' ? (
                        <Gift className="w-4 h-4 text-orange-400" />
                      ) : (
                        <Building2 className="w-4 h-4 text-blue-400" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-white">
                        {item.title}
                      </h4>
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        {item.date}
                      </span>
                    </div>
                  </div>

                  <div className="text-right flex flex-col items-end">
                    <span className="text-xs sm:text-sm font-bold font-mono text-emerald-400">
                      +{item.amount.toFixed(2)} ฿
                    </span>
                    {item.status === 'success' ? (
                      <span className="inline-flex items-center gap-1 text-[10.5px] font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full mt-1">
                        <Check className="w-2.5 h-2.5" />
                        <span>สำเร็จ</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[10.5px] font-medium text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full mt-1">
                        <Clock className="w-2.5 h-2.5" />
                        <span>รอตรวจสอบ</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Column (4 cols): เติมเงินยังไง */}
        <div className="lg:col-span-4 rounded-2xl p-4 sm:p-5 bg-[color:var(--arx-dk-0e1017)]/90 border border-white/10 flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <h3 className="text-sm sm:text-base font-bold text-white pb-2 border-b border-white/5">
              เติมเงินยังไง
            </h3>

            {/* 3 Steps */}
            <div className="space-y-4">
              {/* Step 1 */}
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-[color:var(--theme-main)] text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.6)]">
                  1
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-white">
                    เลือกช่องทาง
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    PromptPay, โอนธนาคาร หรือซองอั่งเปา
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-[color:var(--theme-main)] text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.6)]">
                  2
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-white">
                    ชำระเงิน
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    สแกน QR / โอนแล้วแนบสลิป / วางลิงก์ซอง
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-[color:var(--theme-main)] text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.6)]">
                  3
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-white">
                    รับเครดิต
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    ระบบตรวจสอบแล้วเติมเข้าบัญชีอัตโนมัติ
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Policy / Warning Box */}
          <div className="bg-amber-950/20 border border-amber-500/30 rounded-xl p-3 flex items-start gap-2.5 text-[11px] text-amber-300/90 leading-relaxed">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p>
              กรุณาตรวจสอบยอดเงินก่อนกดยืนยันทุกครั้ง ร้านไม่มีนโยบายคืนเงินไม่ว่ากรณีใดๆ อ่าน{' '}
              <a href="/terms" className="text-amber-400 hover:text-amber-300 underline font-semibold">
                นโยบายความเป็นส่วนตัว
              </a>
            </p>
          </div>

        </div>

      </div>

      {/* ========================================================
          MODAL 1: PROMPTPAY QR MODAL
         ======================================================== */}
      {activeModal === 'promptpay' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="relative w-full max-w-md bg-[color:var(--arx-dk-0e1017)] border border-white/10 rounded-2xl p-5 sm:p-6 shadow-2xl overflow-hidden space-y-5">
            
            {/* Top Glow Accent */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-16 bg-[color:var(--theme-main)]/25 blur-3xl pointer-events-none" />

            {/* Header */}
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center shrink-0 text-white">
                  <QrCode className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    PromptPay QR
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5 line-clamp-2">
                    สแกนผ่านแอปธนาคารใดก็ได้ - ระบบตรวจสอบอัตโนมัติภายใน 1-3 นาที
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  playClick();
                  setActiveModal(null);
                  setPpStep('amount');
                }}
                className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {ppStep === 'amount' ? (
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-white block mb-2">
                    ระบุจำนวนเงินที่ต้องการเติม
                  </label>
                  
                  {/* Currency Input with stepper */}
                  <div className="relative flex items-center">
                    <span className="absolute left-4 text-base font-bold text-slate-400">
                      ฿
                    </span>
                    <input
                      type="number"
                      min="1"
                      step="any"
                      value={ppAmount || ''}
                      onChange={(e) => setPpAmount(Number(e.target.value))}
                      placeholder="0"
                      className="w-full pl-9 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white font-mono font-bold text-lg focus:outline-none focus:border-[color:var(--theme-main)] focus:ring-1 focus:ring-[color:var(--theme-main)] transition-colors"
                    />
                  </div>

                  {/* Quick Preset Buttons */}
                  <div className="grid grid-cols-5 gap-1.5 mt-2.5">
                    {[50, 100, 300, 500, 1000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => {
                          playClick();
                          setPpAmount(amt);
                        }}
                        className={`py-1.5 text-xs font-mono font-bold rounded-lg border transition-all ${
                          ppAmount === amt
                            ? 'bg-[color:var(--theme-main)] text-white font-black border-[color:var(--theme-main)] shadow-[0_0_10px_rgba(var(--theme-main-rgb),0.5)]'
                            : 'bg-white/5 text-slate-300 border-white/5 hover:border-white/20'
                        }`}
                      >
                        +{amt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Submit button */}
                <button
                  type="button"
                  onClick={handleGeneratePpQr}
                  className="w-full py-3 rounded-xl bg-[color:var(--theme-main)] hover:bg-[color:var(--theme-sec)] text-white font-black text-xs sm:text-sm shadow-lg shadow-blue-500/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <span>สร้าง QR Code สำหรับชำระเงิน</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="space-y-4 text-center">
                {/* QR Code Container */}
                <div className="bg-white p-4 rounded-2xl w-fit mx-auto shadow-xl border-4 border-white/10 relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={`https://promptpay.io/${bankAccount.accountNumber.replace(/[^0-9]/g, '')}/${ppAmount}.png`}
                    alt="PromptPay QR Code"
                    className="w-52 h-52 object-contain"
                  />
                  <div className="mt-1 flex items-center justify-center gap-1.5 text-[#003b70] text-xs font-bold">
                    <PromptPayIcon className="w-4 h-4" />
                    <span>พร้อมเพย์ (PromptPay)</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="text-xl font-black font-mono text-white">
                    ฿{ppAmount.toFixed(2)}
                  </div>
                  <p className="text-xs text-slate-400">
                    ชื่อบัญชี: <span className="text-white font-semibold">{bankAccount.accountName}</span>
                  </p>
                  <p className="text-[11px] text-amber-400 font-mono">
                    เวลาที่เหลือ: {Math.floor(ppTimer / 60)}:{(ppTimer % 60).toString().padStart(2, '0')} นาที
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      playClick();
                      setPpStep('amount');
                    }}
                    className="py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold transition-colors"
                  >
                    เปลี่ยนยอดเงิน
                  </button>
                  <button
                    type="button"
                    disabled={isVerifyingPp}
                    onClick={handleConfirmPpPayment}
                    className="py-2.5 rounded-xl bg-[color:var(--theme-main)] hover:bg-[color:var(--theme-sec)] text-white text-xs font-black shadow-md shadow-blue-500/30 flex items-center justify-center gap-1.5 transition-all"
                  >
                    {isVerifyingPp ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>กำลังตรวจสอบ...</span>
                      </>
                    ) : (
                      <>
                        <span>ฉันชำระเงินแล้ว</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* ========================================================
          MODAL 2: โอนผ่านธนาคาร (BANK TRANSFER) MODAL
         ======================================================== */}
      {activeModal === 'bank' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="relative w-full max-w-md bg-[color:var(--arx-dk-0e1017)] border border-white/10 rounded-2xl p-5 sm:p-6 shadow-2xl overflow-hidden space-y-4">
            
            {/* Top Glow Accent */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-16 bg-[color:var(--theme-main)]/25 blur-3xl pointer-events-none" />

            {/* Header */}
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl overflow-hidden flex items-center justify-center shrink-0 shadow-md">
                  <BankIcon bankName={slipConfig?.bankName} className="w-full h-full" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    โอนผ่านธนาคาร
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    โอนเงินแล้วแนบสลิปเพื่อตรวจสอบ
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  playClick();
                  setActiveModal(null);
                  setBankModalMsg(null);
                }}
                className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Bank Info Card */}
            <div className="border border-[color:var(--theme-main)]/35 bg-[color:var(--theme-main)]/10 rounded-xl p-3.5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg overflow-hidden flex items-center justify-center shrink-0 shadow-sm">
                    <BankIcon bankName={slipConfig?.bankName} className="w-full h-full" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white leading-tight">
                      {bankAccount.bank}
                    </h4>
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      {bankAccount.accountName}
                    </span>
                  </div>
                </div>
                <span className="bg-emerald-500/10 text-emerald-300 text-[10px] px-2.5 py-1 rounded-full border border-emerald-500/30 font-semibold">
                  โอนเข้าบัญชีนี้
                </span>
              </div>

              {/* Account Number Box */}
              <div className="bg-black/50 border border-white/5 rounded-lg p-3 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block">เลขบัญชี</span>
                  <span className="text-lg sm:text-xl font-black font-mono text-white tracking-wider">
                    {bankAccount.accountNumber}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleCopyAccount}
                  className="flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300 px-2.5 py-1.5 rounded-md hover:bg-emerald-500/10 transition-colors font-semibold"
                >
                  {copiedAccount ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">คัดลอกแล้ว</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>คัดลอก</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Slip Upload Section */}
            <form onSubmit={handleBankSubmit} className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold text-white">
                    แนบสลิปโอนเงิน
                  </label>
                  <span className="text-xs text-slate-400">
                    ขั้นตอนที่ 2
                  </span>
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleFileInputChange}
                  className="hidden"
                />

                {/* Dropzone */}
                <div
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={handleFileDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-white/10 hover:border-emerald-500/50 rounded-xl p-5 text-center cursor-pointer transition-all bg-white/[0.02] hover:bg-white/[0.04]"
                >
                  {slipFile ? (
                    <div className="flex items-center gap-3 text-left">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={slipFile}
                        alt="Slip preview"
                        className="w-14 h-14 object-cover rounded-lg border border-white/20 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <span className="text-xs font-bold text-white block truncate">
                          {slipFileName}
                        </span>
                        <span className="text-[10.5px] text-slate-400 mt-0.5 block">
                          {slipFileSize}
                        </span>
                        <span className="text-[10px] text-emerald-400 hover:underline mt-1 block">
                          คลิกเพื่อเปลี่ยนรูป
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-1.5 py-2">
                      <div className="w-9 h-9 rounded-full bg-white/5 mx-auto flex items-center justify-center text-slate-400">
                        <Upload className="w-4 h-4" />
                      </div>
                      <p className="text-xs text-slate-300">
                        ลากไฟล์มาวาง หรือ{' '}
                        <span className="text-emerald-400 font-bold underline">
                          เลือกรูป
                        </span>
                      </p>
                      <p className="text-[10.5px] text-slate-500">
                        PNG, JPG, WEBP ไม่เกิน 4 MB
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {bankModalMsg && (
                <div className={`p-2.5 rounded-lg text-xs flex items-center gap-2 ${
                  bankModalMsg.success
                    ? 'bg-emerald-950/30 border border-emerald-500/30 text-emerald-300'
                    : 'bg-red-950/30 border border-red-500/30 text-red-300'
                }`}>
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{bankModalMsg.text}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setActiveModal(null);
                  }}
                  className="py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold transition-colors"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingSlip}
                  className="py-2.5 rounded-xl bg-[color:var(--theme-main)] hover:bg-[color:var(--theme-sec)] text-white text-xs font-black shadow-md shadow-blue-500/30 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  {isSubmittingSlip ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>กำลังส่งสลิป...</span>
                    </>
                  ) : (
                    <>
                      <span>ส่งสลิปและตรวจสอบ</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ========================================================
          MODAL 3: ซองอั่งเปา TRUEMONEY MODAL
         ======================================================== */}
      {activeModal === 'angpao' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="relative w-full max-w-md bg-[color:var(--arx-dk-0e1017)] border border-white/10 rounded-2xl p-5 sm:p-6 shadow-2xl overflow-hidden space-y-4">
            
            {/* Top Glow Accent */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-16 bg-[color:var(--theme-main)]/25 blur-3xl pointer-events-none" />

            {/* Header */}
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-white p-1 flex items-center justify-center shrink-0 shadow-md border border-slate-200">
                  <TrueMoneyIcon className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    ซองอั่งเปา TrueMoney
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    วางลิงก์จากแอป TrueMoney Wallet
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  playClick();
                  setActiveModal(null);
                  setAngpaoModalMsg(null);
                }}
                className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Badges */}
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium text-blue-300 bg-[color:var(--theme-main)]/15 border border-[color:var(--theme-main)]/30">
                <Zap className="w-3 h-3 text-blue-400" />
                <span>{angpaoFeePercent === 0 ? 'ฟรีค่าธรรมเนียม' : `ค่าธรรมเนียม ${angpaoFeePercent}%`}</span>
              </span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20">
                <Shield className="w-3 h-3 text-emerald-400" />
                <span>รับเครดิตทันที</span>
              </span>
            </div>

            {/* Voucher input form */}
            <form onSubmit={handleAngpaoSubmit} className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-white">
                    ลิงก์ซองอั่งเปา
                  </label>
                  <span className="text-xs text-blue-400 font-medium">
                    {angpaoFeePercent === 0 ? 'ไม่หักค่าธรรมเนียม' : `หัก ${angpaoFeePercent}%`}
                  </span>
                </div>

                <div className="relative">
                  <input
                    type="text"
                    value={voucherUrl}
                    onChange={(e) => setVoucherUrl(e.target.value)}
                    placeholder="https://gift.truemoney.com/campaign/?v=..."
                    className="w-full px-3.5 py-3 bg-white/5 border border-white/10 rounded-xl text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-[color:var(--theme-main)] focus:ring-1 focus:ring-[color:var(--theme-main)] transition-colors font-mono"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1.5">
                  คัดลอกลิงก์จากแอป TrueMoney Wallet → แชร์ซอง → คัดลอกลิงก์
                </p>
              </div>

              <div>
                <label className="text-xs font-bold text-white mb-1.5 block">
                  จำนวนเงินในซอง (บาท) <span className="text-slate-400 font-normal">(ระบุยอดเงิน หรือปล่อยว่าง)</span>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="1"
                    step="any"
                    value={angpaoAmount}
                    onChange={(e) => setAngpaoAmount(e.target.value)}
                    placeholder="เช่น 50, 100, 300, 500 (หรือปล่อยว่าง)"
                    className="w-full px-3.5 py-3 bg-white/5 border border-white/10 rounded-xl text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-[color:var(--theme-main)] focus:ring-1 focus:ring-[color:var(--theme-main)] transition-colors font-mono"
                  />
                </div>

                {/* Real-time Calculation Breakdown */}
                {parseFloat(angpaoAmount) > 0 && (
                  <div className="p-3 rounded-xl bg-orange-950/20 border border-orange-500/25 text-xs space-y-1 mt-2.5 animate-in fade-in">
                    <div className="flex justify-between text-slate-300">
                      <span>ยอดเงินในซอง:</span>
                      <span className="font-mono font-bold text-white">
                        ฿{parseFloat(angpaoAmount).toLocaleString('th-TH', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                    {angpaoFeePercent > 0 && (
                      <div className="flex justify-between text-rose-300">
                        <span>หักค่าธรรมเนียม ({angpaoFeePercent}%):</span>
                        <span className="font-mono font-bold">
                          -฿{(Math.round(parseFloat(angpaoAmount) * (angpaoFeePercent / 100) * 100) / 100).toLocaleString('th-TH', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                    )}
                    <div className="h-px bg-white/10 my-1" />
                    <div className="flex justify-between text-emerald-300 font-bold">
                      <span>ยอดเครดิตที่จะได้รับสุทธิ:</span>
                      <span className="font-mono text-sm text-emerald-400">
                        ฿{Math.max(0, Math.round((parseFloat(angpaoAmount) - (parseFloat(angpaoAmount) * (angpaoFeePercent / 100))) * 100) / 100).toLocaleString('th-TH', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Instructions Box */}
              <div className="bg-black/40 border border-white/5 rounded-xl p-3.5 space-y-2.5">
                <h4 className="text-xs font-bold text-blue-400">
                  วิธีรับลิงก์
                </h4>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-2.5">
                    <div className="w-4 h-4 rounded-full bg-[color:var(--theme-main)] text-white font-black text-[10px] flex items-center justify-center shrink-0">
                      1
                    </div>
                    <span className="text-slate-300">เปิดแอป TrueMoney Wallet</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-4 h-4 rounded-full bg-[color:var(--theme-main)] text-white font-black text-[10px] flex items-center justify-center shrink-0">
                      2
                    </div>
                    <span className="text-slate-300">เลือก &ldquo;ซองอั่งเปา&rdquo; และสร้างซอง</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-4 h-4 rounded-full bg-[color:var(--theme-main)] text-white font-black text-[10px] flex items-center justify-center shrink-0">
                      3
                    </div>
                    <span className="text-slate-300">กด &ldquo;แชร์&rdquo; แล้วคัดลอกลิงก์</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-4 h-4 rounded-full bg-[color:var(--theme-main)] text-white font-black text-[10px] flex items-center justify-center shrink-0">
                      4
                    </div>
                    <span className="text-slate-300">วางลิงก์ในช่องด้านบน</span>
                  </div>
                </div>
              </div>

              {angpaoModalMsg && (
                <div className={`p-2.5 rounded-lg text-xs flex items-center gap-2 ${
                  angpaoModalMsg.success
                    ? 'bg-emerald-950/30 border border-emerald-500/30 text-emerald-300'
                    : 'bg-rose-950/30 border border-rose-500/30 text-rose-300'
                }`}>
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{angpaoModalMsg.text}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setActiveModal(null);
                  }}
                  className="py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold transition-colors"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  disabled={isClaimingAngpao}
                  className="py-2.5 rounded-xl bg-[color:var(--theme-main)] hover:bg-[color:var(--theme-sec)] text-white text-xs font-black shadow-md shadow-blue-500/30 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  {isClaimingAngpao ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>กำลังตรวจสอบซอง...</span>
                    </>
                  ) : (
                    <>
                      <span>เติมเงิน</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
}
