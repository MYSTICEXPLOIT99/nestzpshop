'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '@/context/StoreContext';
import {
  User,
  Camera,
  Upload,
  Check,
  Sparkles,
  ShieldCheck,
  Wallet,
  AlertCircle,
  Loader2,
  RefreshCw,
  ArrowRight,
  ShoppingBag,
  Clock,
  KeyRound,
  ExternalLink
} from 'lucide-react';
import Link from 'next/link';

const PRESET_AVATARS = [
  '/brand/logo.png',
  'https://api.dicebear.com/7.x/bottts/svg?seed=arx_cyber',
  'https://api.dicebear.com/7.x/bottts/svg?seed=arx_titan',
  'https://api.dicebear.com/7.x/bottts/svg?seed=arx_ghost',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Shadow',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Valkyrie',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Neo'
];

export default function ProfilePage() {
  const { user, siteContent, updateUserProfile, openAuthModal, playClick, playSuccess, playError } = useStore();

  const storeLogo = siteContent?.branding?.logoUrl || '/brand/logo.png';
  const [username, setUsername] = useState('');
  const [avatar, setAvatar] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user) {
      setUsername(user.username || '');
      const eff = (!user.avatar || user.avatar === '/brand/logo.png' || user.avatar === '/brand/arx-default-logo.png' || user.avatar.includes('placeholder'))
        ? storeLogo
        : user.avatar;
      setAvatar(eff);
    }
  }, [user, storeLogo]);

  if (!user) {
    return (
      <main className="min-h-[70vh] flex items-center justify-center px-4 py-16">
        <div className="max-w-md w-full text-center space-y-4 p-8 rounded-2xl bg-[color:var(--arx-dk-0a0d14)]/90 border border-white/10 shadow-2xl backdrop-blur-xl">
          <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mx-auto text-cyan-400">
            <User className="w-8 h-8" />
          </div>
          <h1 className="text-xl font-bold text-white">กรุณาเข้าสู่ระบบก่อน</h1>
          <p className="text-xs text-slate-400">
            เข้าสู่ระบบเพื่อจัดการข้อมูลโปรไฟล์ บัญชีผู้ใช้ และประวัติการทำรายการของคุณ
          </p>
          <button
            type="button"
            onClick={() => {
              playClick();
              openAuthModal('login');
            }}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-400 via-[var(--theme-accent)] to-cyan-500 hover:brightness-110 text-slate-950 font-black text-sm shadow-[0_0_20px_rgba(var(--theme-accent-rgb),0.4)] transition-all cursor-pointer"
          >
            เข้าสู่ระบบทันที
          </button>
        </div>
      </main>
    );
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMessage('กรุณาเลือกไฟล์รูปภาพเท่านั้น (PNG, JPG, WEBP)');
      return;
    }

    if (file.size > 3 * 1024 * 1024) {
      setErrorMessage('ขนาดรูปภาพต้องไม่เกิน 3 MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setAvatar(reader.result);
        setErrorMessage('');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    const cleanUsername = username.trim();
    if (!cleanUsername) {
      setErrorMessage('กรุณากรอกชื่อผู้ใช้');
      playError();
      return;
    }

    if (cleanUsername.length < 3 || cleanUsername.length > 25) {
      setErrorMessage('ชื่อผู้ใช้ต้องมีความยาว 3 - 25 ตัวอักษร');
      playError();
      return;
    }

    setIsSaving(true);
    try {
      const res = await updateUserProfile({
        username: cleanUsername,
        avatar: avatar.trim() || undefined
      });

      if (res.success) {
        playSuccess();
        setSuccessMessage('บันทึกข้อมูลโปรไฟล์เรียบร้อยแล้ว');
        setTimeout(() => setSuccessMessage(''), 4000);
      } else {
        setErrorMessage(res.message || 'บันทึกไม่สำเร็จ');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'เกิดข้อผิดพลาดในการบันทึกข้อมูล');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <main className="min-h-screen max-w-4xl mx-auto px-4 py-8 sm:py-12 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white tracking-wide flex items-center gap-2.5">
            <User className="w-6 h-6 text-cyan-400" />
            <span>จัดการโปรไฟล์</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            เปลี่ยนรูปโปรไฟล์ ชื่อผู้ใช้ และดูข้อมูลสถานะบัญชีของคุณ
          </p>
        </div>

        {/* Quick Nav Links */}
        <div className="flex items-center gap-2">
          <Link
            href="/orders"
            className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors"
          >
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>ประวัติการซื้อ</span>
          </Link>
          <Link
            href="/topup"
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-400 via-[var(--theme-accent)] to-cyan-500 hover:brightness-110 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 flex items-center gap-1.5 transition-all"
          >
            <Wallet className="w-3.5 h-3.5" />
            <span>เติมเงิน</span>
          </Link>
        </div>
      </div>

      {/* Main Profile Editor Card */}
      <div className="rounded-2xl bg-[color:var(--arx-dk-0a0d16)]/95 border border-cyan-500/30 shadow-[0_15px_40px_rgba(0,0,0,0.8),0_0_25px_rgba(var(--theme-accent-rgb),0.12)] p-6 sm:p-8 backdrop-blur-2xl">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Status Alerts */}
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2.5">
              <Check className="w-4 h-4 shrink-0 text-emerald-400 stroke-[3]" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* User Info Overview Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-[color:var(--arx-dk-061824)] border border-cyan-500/30">
            <div>
              <span className="text-[11px] text-slate-400 font-medium block">สถานะบัญชี</span>
              <span className="inline-flex items-center gap-1 mt-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-cyan-950/60 text-cyan-300 border border-cyan-500/30">
                {user.role === 'admin' ? (
                  <>
                    <ShieldCheck className="w-3 h-3 text-cyan-400" />
                    <span>ADMIN (ผู้ดูแลระบบ)</span>
                  </>
                ) : (
                  <span>MEMBER (สมาชิกทั่วไป)</span>
                )}
              </span>
            </div>

            <div>
              <span className="text-[11px] text-slate-400 font-medium block">ยอดเงินคงเหลือ</span>
              <span className="text-base font-black text-cyan-300 font-mono block mt-0.5">
                ฿{user.balance.toFixed(2)} บาท
              </span>
            </div>

            <div>
              <span className="text-[11px] text-slate-400 font-medium block">รหัสประจำตัว</span>
              <span className="text-xs text-slate-300 font-mono block mt-1 truncate">
                {user.id}
              </span>
            </div>
          </div>

          {/* Avatar Section */}
          <div className="space-y-3 pt-2">
            <label className="text-sm font-bold text-white block">
              รูปโปรไฟล์ (Avatar)
            </label>

            <div className="flex flex-col sm:flex-row items-center gap-6 p-4 rounded-xl bg-white/[0.02] border border-white/5">
              {/* Avatar Preview with Camera overlay */}
              <div className="relative group shrink-0">
                <div className="w-24 h-24 rounded-2xl bg-cyan-950/40 border-2 border-cyan-500/50 overflow-hidden shadow-[0_0_25px_rgba(var(--theme-accent-rgb),0.25)] flex items-center justify-center">
                  {avatar ? (
                    <img
                      key={avatar}
                      src={avatar}
                      alt="Preview avatar"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = storeLogo;
                      }}
                    />
                  ) : (
                    <User className="w-12 h-12 text-cyan-400" />
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute inset-0 rounded-2xl bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-cyan-300 text-xs font-bold cursor-pointer"
                  title="คลิกเพื่ออัปโหลดรูป"
                >
                  <Camera className="w-6 h-6 mb-1" />
                  <span>เปลี่ยนรูป</span>
                </button>
              </div>

              <div className="flex-1 space-y-3 text-center sm:text-left w-full">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleFileUpload}
                  className="hidden"
                />

                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 hover:text-white text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer"
                  >
                    <Upload className="w-4 h-4 text-cyan-400" />
                    <span>เลือกรูปภาพจากเครื่อง</span>
                  </button>
                </div>

                {/* Preset Avatars Chips */}
                <div className="space-y-1.5">
                  <span className="text-[11px] text-slate-400 block">
                    หรือเลือกรูปภาพสำเร็จรูป (Presets):
                  </span>
                  <div className="flex items-center justify-center sm:justify-start gap-2 flex-wrap">
                    {PRESET_AVATARS.map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          playClick();
                          setAvatar(preset);
                        }}
                        className={`w-9 h-9 rounded-xl border p-0.5 overflow-hidden transition-all cursor-pointer ${
                          avatar === preset
                            ? 'border-cyan-400 ring-2 ring-cyan-500/50 scale-105 shadow-[0_0_12px_rgba(var(--theme-accent-rgb),0.4)]'
                            : 'border-white/10 hover:border-cyan-500/40 opacity-70 hover:opacity-100'
                        }`}
                      >
                        <img
                          src={preset}
                          alt={`Preset ${idx}`}
                          className="w-full h-full object-cover rounded-lg"
                        />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Custom URL */}
                <div className="space-y-1 pt-1">
                  <span className="text-[11px] text-slate-400 block">
                    หรือระบุลิงก์รูปภาพ (Image URL):
                  </span>
                  <div className="relative">
                    <input
                      type="text"
                      value={avatar.startsWith('data:') ? 'รูปภาพที่อัปโหลดจากเครื่อง (Base64)' : avatar}
                      onChange={(e) => setAvatar(e.target.value)}
                      placeholder="https://example.com/avatar.png"
                      disabled={avatar.startsWith('data:')}
                      className="w-full px-3.5 py-2 bg-white/5 border border-white/10 rounded-xl text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-colors font-mono"
                    />
                    {avatar.startsWith('data:') && (
                      <button
                        type="button"
                        onClick={() => setAvatar('')}
                        className="absolute right-2.5 top-2 text-[11px] text-rose-400 hover:underline cursor-pointer"
                      >
                        รีเซ็ต
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Username Section */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-white flex items-center gap-1.5">
                <User className="w-4 h-4 text-cyan-400" />
                <span>ชื่อผู้ใช้ (Username)</span>
              </label>
              <span className="text-xs text-slate-400">
                {username.length}/25 ตัวอักษร
              </span>
            </div>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="กรอกชื่อผู้ใช้..."
              maxLength={25}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-colors font-semibold"
            />
            <p className="text-xs text-slate-400">
              ชื่อผู้ใช้ต้องมีความยาวระหว่าง 3 ถึง 25 ตัวอักษร และจะแสดงบนระบบร้านค้าและประวัติการซื้อของคุณ
            </p>
          </div>

          {/* Submit Button */}
          <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-400 via-[var(--theme-accent)] to-cyan-500 hover:brightness-110 text-slate-950 font-black text-sm shadow-[0_0_25px_rgba(var(--theme-accent-rgb),0.4)] flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50 active:scale-95"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>กำลังบันทึกข้อมูล...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>บันทึกการเปลี่ยนแปลง</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </main>
  );
}
