'use client';

import React from 'react';
import { ShieldCheck, Database, Cookie, UserCheck, Scale } from 'lucide-react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';

export default function PrivacyPage() {
  const { lang, playClick } = useStore();

  return (
    <div className="py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
      
      {/* Page Header */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-widest">
          <ShieldCheck className="w-4 h-4 text-cyan-400" />
          <span>PDPA COMPLIANCE & PRIVACY STATEMENT</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
          {lang === 'th' ? 'นโยบายความเป็นส่วนตัว และการคุ้มครองข้อมูลส่วนบุคคล' : 'Privacy Policy & Data Protection'}
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
          {lang === 'th'
            ? 'สำรวจเส้นทางข้อมูลของคุณ ตั้งแต่บัญชีและรายการซื้อ ไปจนถึงการจัดเก็บบนอุปกรณ์ การเลือกคุกกี้ และช่องทางขอใช้สิทธิตามพระราชบัญญัติคุ้มครองข้อมูลส่วนบุคคล พ.ศ. 2562'
            : 'Learn how your data is handled from account credentials and purchase records to local storage, cookies, and your rights under PDPA regulations.'}
        </p>
        <div className="pt-2 flex items-center gap-2 text-xs text-slate-500 font-mono">
          <span>{lang === 'th' ? 'ปรับปรุงล่าสุด: 14 กันยายน 2569' : 'Last updated: September 14, 2026'}</span>
          <span>•</span>
          <span className="text-emerald-400">เวอร์ชัน 2.4</span>
        </div>
      </div>

      {/* Sections */}
      <div className="space-y-6">
        
        {/* Section 1 */}
        <div className="cyber-card rounded-2xl p-6 bg-slate-950/80 border border-cyan-500/25 space-y-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400">
              <UserCheck className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-white">
              {lang === 'th' ? '1. ข้อมูลสำหรับระบุตัวตนและบัญชีสมาชิก' : '1. Identification & User Account Data'}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pl-11">
            {lang === 'th'
              ? 'ข้อมูลที่คุณให้ระหว่างการสมัครสมาชิกและใช้งาน เช่น ชื่อผู้ใช้ (Username) รหัสผ่านที่ผ่านการแฮชแบบ One-Way Cryptographic Hash (SHA-256/Bcrypt) และประวัติยอดเงิน ใช้เพื่อการเชื่อมโยงคำสั่งซื้อและดูแลความปลอดภัยของบัญชีเท่านั้น ทางร้านไม่มีนโยบายส่งต่อหรือเปิดเผยข้อมูลของท่านต่อบุคคลภายนอก'
              : 'Information provided during registration (username, one-way cryptographic salted hash passwords SHA-256/Bcrypt, and credit history) is strictly used for order linkage and account security. We never share or sell personal data to third parties.'}
          </p>
        </div>

        {/* Section 2 */}
        <div className="cyber-card rounded-2xl p-6 bg-slate-950/80 border border-cyan-500/25 space-y-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400">
              <Database className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-white">
              {lang === 'th' ? '2. รายการคำสั่งซื้อและประวัติการเติมเงิน' : '2. Orders & Deposit Records'}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pl-11">
            {lang === 'th'
              ? 'ข้อมูลการสั่งซื้อ รายละเอียดแพ็กเกจ License Key วันที่ทำรายการ และหลักฐานการโอนเงิน (สลิป) ถูกจัดเก็บเพื่อใช้ในการตรวจสอบความถูกต้อง การเคลมประกันสินค้า และการให้บริการรีเซ็ต HWID ข้อมูลเหล่านี้จะถูกเก็บรักษาอย่างเป็นความลับและสามารถตรวจสอบได้เฉพาะเจ้าของบัญชีเท่านั้น'
              : 'Order details, package tiers, license keys, purchase timestamps, and payment proof (slips) are securely stored for license verification, warranty claims, and HWID reset operations. All records remain confidential and accessible solely by the account holder.'}
          </p>
        </div>

        {/* Section 3 */}
        <div className="cyber-card rounded-2xl p-6 bg-slate-950/80 border border-cyan-500/25 space-y-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400">
              <Cookie className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-white">
              {lang === 'th' ? '3. การใช้งานคุกกี้ (Cookies) และพื้นที่จัดเก็บบนอุปกรณ์' : '3. Cookies & Local Device Storage'}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pl-11">
            {lang === 'th'
              ? 'เว็บไซต์ใช้คุกกี้ที่จำเป็น (Essential Cookies) เพื่อคงสถานะการเข้าสู่ระบบ ความปลอดภัยในการทำธุรกรรม และการจดจำตัวเลือกเสียงคีย์บอร์ด โดยข้อมูลประสิทธิภาพ (Performance Cache) จะถูกลบออกเมื่อท่านปิดแท็บเบราว์เซอร์ ทั้งนี้ท่านสามารถปรับแต่งตัวเลือกคุกกี้ได้ผ่านแถบการตั้งค่าด้านล่างของเว็บไซต์'
              : 'We use essential cookies to maintain secure sessions, transaction validation, and sound effect preferences. Performance cache is cleared when browser tabs close. You may customize your cookie preferences anytime.'}
          </p>
        </div>

        {/* Section 4 */}
        <div className="cyber-card rounded-2xl p-6 bg-slate-950/80 border border-cyan-500/25 space-y-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
              <Scale className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-white">
              {lang === 'th' ? '4. สิทธิของเจ้าของข้อมูลส่วนบุคคล (Data Subject Rights)' : '4. Data Subject Rights (PDPA)'}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pl-11">
            {lang === 'th'
              ? 'ตามพระราชบัญญัติคุ้มครองข้อมูลส่วนบุคคล พ.ศ. 2562 ท่านมีสิทธิขอเข้าถึง รับสำเนา ขอแก้ไข หรือขอลบข้อมูลบัญชีของท่านได้ตลอดเวลา โดยสามารถติดต่อทีมงานผู้ดูแลระบบผ่านช่องทาง Discord หรือศูนย์ช่วยเหลือของร้านเพื่อดำเนินการยืนยันตัวตนและดำเนินการตามคำขอ'
              : 'Under the Personal Data Protection Act, you have full rights to access, request copies, update, or request deletion of your account information. Contact our administration team via Discord or support channels to verify identity and process requests.'}
          </p>
        </div>

      </div>

      <div className="text-center pt-4">
        <Link
          href="/"
          onClick={playClick}
          className="px-6 py-2.5 rounded-xl cyber-btn-secondary text-xs font-semibold inline-flex items-center gap-2"
        >
          {lang === 'th' ? 'กลับหน้าหลัก' : 'Back to Home'}
        </Link>
      </div>

    </div>
  );
}
