import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { evaluateSecurity } from '@/lib/waf/shield';

export function proxy(request: NextRequest) {
  // 1. Evaluate incoming request against ARX CyberShield WAF & Anti-DDoS Engine
  const verdict = evaluateSecurity(request);

  if (!verdict.allowed) {
    const status = verdict.status || 403;
    const responseHeaders: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-Blocked-By': 'ARX-CyberShield-WAF',
      'X-Threat-Detected': verdict.threatType || 'UNKNOWN_THREAT',
      'X-CyberShield-Status': 'Enforcing',
      ...(verdict.headers || {})
    };

    return new NextResponse(
      JSON.stringify({
        success: false,
        error: verdict.reason || 'Security Shield: Request blocked by WAF policy',
        threat: verdict.threatType,
        shield: 'ARX CyberShield Active'
      }),
      {
        status,
        headers: responseHeaders
      }
    );
  }


  // 3. Inject Enhanced Defense Headers
  const response = NextResponse.next();
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('X-Frame-Options', 'SAMEORIGIN');
  response.headers.set('X-XSS-Protection', '1; mode=block');
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  response.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  response.headers.set('X-CyberShield-Status', 'Protected');

  return response;
}

export const config = {
  matcher: [
    /*
     * Match all request paths except Next.js internal bundles
     */
    '/((?!_next/static|_next/image).*)'
  ]
};
