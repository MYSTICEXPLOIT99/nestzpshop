export type ProductStatus = 'ready' | 'out_of_stock' | 'maintenance' | 'updating';

export interface DigitalStockItem {
  id: string;
  key: string;              // คีย์ใช้งาน License Key / Code
  downloadUrl?: string;     // ลิงก์ดาวน์โหลด เช่น Google Drive, Mega, MediaFire, Discord, Loader
  fileName?: string;        // ชื่อไฟล์ หรือประเภทไฟล์ เช่น 'ARX_Loader_v2.zip'
  note?: string;            // หมายเหตุ / บัญชี เช่น user:pass หรือคำแนะนำเฉพาะคีย์นี้
  createdAt: string;
  isUsed?: boolean;         // ขายไปแล้วหรือยัง
  orderId?: string;         // รหัสคำสั่งซื้อที่ได้รับคีย์นี้
  usedBy?: string;          // username ของผู้ซื้อ
  usedAt?: string;          // เวลาที่ซื้อ
}

export interface ProductPackage {
  id: string;
  name: string;
  duration: string; // e.g., '1 วัน', '7 วัน', '30 วัน', 'ถาวร (Lifetime)'
  price: number;
  originalPrice?: number;
  stock: number;
  inStock: boolean;
  stockItems?: DigitalStockItem[]; // คลังสต็อกดิจิทัลของแพ็กเกจนี้
  badge?: string; // e.g. '✨ ยอดนิยม'
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  categoryId: string;
  categoryName: string;
  description: string;
  shortDescription: string;
  image: string;
  badge?: string; // e.g. 'ขายดี', 'HOT'
  discountBadge?: string; // e.g. '-40%', '-60%'
  rating: number;
  salesCount: number;
  isPopular?: boolean;
  rank?: number;
  status: ProductStatus;
  statusNote?: string;
  statusUpdatedAt?: string;
  packages: ProductPackage[];
  tags: string[];
  instructions?: string;
  downloadUrl?: string;
  youtubeUrl?: string;
  updatedAt?: string;
  optionType?: 'single' | 'multiple';
  requiresCustomInput?: boolean;
  customInputLabel?: string;
  customInputPlaceholder?: string;
  customInputHelp?: string;
  guaranteeDays?: number;
  features?: string[];
  detailsList?: string[];
}

export interface SubCategory {
  id: string;
  name: string;
  itemCount?: number;
  badge?: string;
  icon?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  iconName: string;
  description: string;
  itemCount: number;
  badge?: string;
  image?: string;
  linkUrl?: string;
  subCategories?: SubCategory[];
}

export interface User {
  id: string;
  username: string;
  password?: string;
  email?: string;
  avatar?: string;
  role: 'user' | 'admin';
  balance: number;
  memberSince?: string;
  createdAt?: string;
  totalSpent: number;
  freeHwidResets: number;
  accumulatedHwidResets: number;
}

export type OrderStatus = 'delivered' | 'pending' | 'cancelled';

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  username: string;
  productId: string;
  productName: string;
  packageId: string;
  packageName: string;
  price: number;
  originalPrice?: number;
  status: OrderStatus;
  licenseKey: string;
  credentials?: string;
  downloadUrl?: string;
  instructions?: string;
  createdAt: string;
}

export type TopupMethod = 'angpao' | 'bank_transfer' | 'promptpay';
export type TopupStatus = 'approved' | 'pending' | 'rejected';

export interface TopupTransaction {
  id: string;
  transactionNo: string;
  userId: string;
  username: string;
  method: TopupMethod;
  amount: number;
  status: TopupStatus;
  refCode?: string;
  slipUrl?: string;
  senderName?: string;
  bankName?: string;
  createdAt: string;
}

export type HwidStatus = 'completed' | 'pending' | 'failed';

export interface HwidResetRecord {
  id: string;
  userId: string;
  username: string;
  productId: string;
  productName: string;
  licenseKey: string;
  status: HwidStatus;
  cost: number;
  wasFree: boolean;
  createdAt: string;
}

export type ServiceHealthStatus = 'online' | 'updating' | 'maintenance';

export interface ServiceStatusItem {
  id: string;
  productId: string;
  name?: string;
  productName?: string;
  category: string;
  status: ServiceHealthStatus;
  version?: string;
  image?: string;
  responseTimeMs?: number;
  uptimePercent?: number;
  lastChecked: string;
  note?: string;
  notes?: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  type: 'info' | 'promo' | 'warning' | 'success';
  active?: boolean;
  isActive?: boolean;
  createdAt: string;
}

export interface HeroSlide {
  id: string;
  badge: string;
  badgeColor?: string;
  title: string;
  subtitle: string[];
  description: string;
  ctaText: string;
  ctaAction: string;
  accentColor: string;
  image?: string;
  theme?: 'arx-brand' | 'fivem' | 'windows';
  isActive: boolean;
}

export interface SiteStats {
  users: number;
  topup: number;
  stock: number;
  sales: number;
  isCustom: boolean;
  mode?: 'direct' | 'boost';
}

export interface RealSiteStats {
  users: number;
  topup: number;
  stock: number;
  sales: number;
}

export interface SlipApiConfig {
  provider: 'slipok' | 'easyslip' | 'openslip' | 'byshop' | 'custom';
  apiKey: string;
  branchId: string;
  promptPayNumber: string;
  accountName: string;
  bankName: string;
  trueMoneyPhone?: string;
  autoApprove: boolean;
  byshopApiKey?: string;
  byshopMerchantId?: string;
  channelPromptPayEnabled?: boolean;
  channelBankTransferEnabled?: boolean;
  channelAngpaoEnabled?: boolean;
  channelTrueMoneyWalletEnabled?: boolean;
  angpaoFeePercent?: number;
}

export interface DiscordWebhookSettings {
  registerEnabled: boolean;
  registerUrl: string;
  topupEnabled: boolean;
  topupUrl: string;
  orderEnabled: boolean;
  orderUrl: string;
  stockEnabled: boolean;
  stockUrl: string;
  botName?: string;
  botAvatarUrl?: string;
}

export interface WebhookLogItem {
  id: string;
  type: 'register' | 'topup_bank' | 'topup_truemoney' | 'order' | 'stock' | 'test';
  title: string;
  details: string;
  status: 'success' | 'failed';
  timestamp: string;
  httpStatus?: number;
  error?: string;
}
export interface BgmSettings {
  enabled: boolean;
  title: string;
  subtitle: string;
  url: string;
  volume: number; // 0 - 100
  autoplay: boolean;
  loop: boolean;
  showVisualizer: boolean;
  position: 'bottom-left' | 'bottom-right';
}

export interface WelcomeBannerSettings {
  enabled: boolean;
  titlePrefix: string;
  titleHighlight: string;
  highlightColor?: string;
  description: string;
  button1Text: string;
  button1Link: string;
  button2Text: string;
  button2Link: string;
  bannerUrl?: string;
}

export interface StepItem {
  number: string;
  title: string;
  description: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

export interface ContactChannel {
  id: string;
  platform: 'facebook' | 'discord' | 'instagram' | 'line' | 'tiktok' | 'telegram' | 'custom';
  label: string;
  url: string;
  color?: string;
  enabled: boolean;
}

export interface SiteBranding {
  siteName: string;
  siteTitle: string;
  slogan?: string;
  logoUrl: string;
  faviconUrl?: string;
  heroBannerUrl?: string;
}

export interface SiteContent {
  branding?: SiteBranding;
  stepsSection: {
    subtitle: string;
    title: string;
    steps: StepItem[];
  };
  faqSection: {
    subtitle: string;
    title: string;
    faqs: FaqItem[];
  };
  contactModal: {
    title: string;
    subtitle: string;
    channels: ContactChannel[];
  };
  footer: {
    description: string;
    reportText: string;
    reportUrl: string;
    copyright: string;
    currencyNote: string;
  };
}

export interface ResellerTier {
  id: string;
  name: string;
  minTopup: number;
  discountPercent: number;
  badgeText: string;
  displayDiscount: string;
  color: string;
  description?: string;
}

export interface ResellerLeaderboardItem {
  id: string;
  username: string;
  tierName: string;
  discountLabel: string;
  color: string;
  rank: number;
  totalTopup?: number;
}

export interface ResellerSettings {
  title: string;
  subtitle: string;
  badgeTitle: string;
  badgeDescription: string;
  allTiersTitle: string;
  allTiersSubtitle: string;
  leaderboardTitle: string;
  leaderboardSubtitle: string;
  tiers: ResellerTier[];
  leaderboard: ResellerLeaderboardItem[];
}


