'use client';

import React, { useState, useEffect } from 'react';
import { ResellerSettings, ResellerTier, ResellerLeaderboardItem } from '@/types';
import { useStore } from '@/context/StoreContext';
import {
  Award,
  Save,
  Plus,
  Trash2,
  ExternalLink,
  RotateCcw,
  Sparkles,
  Trophy,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ShieldCheck,
  TrendingUp,
  CreditCard,
  DollarSign,
  Palette
} from 'lucide-react';

const PRESET_COLORS = [
  { label: 'Cyan', value: '#00e5ff' },
  { label: 'Orange', value: '#f97316' },
  { label: 'Yellow', value: '#eab308' },
  { label: 'Emerald', value: '#10b981' },
  { label: 'Purple', value: '#a855f7' },
  { label: 'Rose', value: '#f43f5e' },
  { label: 'Sky', value: '#38bdf8' }
];

export default function ResellerSettingsTab() {
  const { playClick, showToast } = useStore();

  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'tiers' | 'texts' | 'leaderboard'>('tiers');

  const [settings, setSettings] = useState<ResellerSettings>({
    title: 'โปรแกรมตัวแทนจำหน่าย',
    subtitle: 'เติมสะสมยิ่งเยอะ ยิ่งลดเยอะทุกออเดอร์ — ระบบเลื่อนระดับให้อัตโนมัติเมื่อยอดเติมสะสมถึงเกณฑ์ ส่วนลดหักให้ทันทีตอนสั่งซื้อ',
    badgeTitle: 'ยศของคุณไม่มีวันหมดอายุ',
    badgeDescription: 'ยศนี้ไม่มีเงื่อนไขยอดรักษายศ — ใช้สิทธิ์ได้ต่อเนื่อง เติมสะสมเพื่อเลื่อนระดับถัดไป',
    allTiersTitle: 'ระดับทั้งหมด',
    allTiersSubtitle: 'เลื่อนอัตโนมัติเมื่อยอดเติมสะสมถึงเกณฑ์',
    leaderboardTitle: 'อันดับตัวแทนจำหน่าย',
    leaderboardSubtitle: 'ตัวแทนที่มียอดเติมสะสมสูงสุดในร้าน',
    tiers: [],
    leaderboard: []
  });

  // Fetch current reseller settings
  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      try {
        const res = await fetch('/api/reseller');
        const json = await res.json();
        if (isMounted && json.success && json.data) {
          setSettings(json.data);
        }
      } catch (err) {
        console.error('Failed to load reseller settings:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, []);

  // Save reseller settings
  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    playClick();
    setSaving(true);

    try {
      const res = await fetch('/api/admin/reseller', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      const json = await res.json();

      if (json.success) {
        showToast({
          title: 'บันทึกสำเร็จ',
          message: 'อัปเดตข้อมูลและเกณฑ์ยอดเติมตัวแทนจำหน่ายเรียบร้อยแล้ว',
          type: 'success'
        });
      } else {
        showToast({
          title: 'บันทึกไม่สำเร็จ',
          message: json.message || 'เกิดข้อผิดพลาดในการบันทึก',
          type: 'error'
        });
      }
    } catch (err) {
      console.error('Save reseller error:', err);
      showToast({
        title: 'เกิดข้อผิดพลาด',
        message: 'ไม่สามารถติดต่อเซิร์ฟเวอร์ได้',
        type: 'error'
      });
    } finally {
      setSaving(false);
    }
  };

  // Add new Tier
  const handleAddTier = () => {
    playClick();
    const newId = `tier-${Date.now()}`;
    const newTier: ResellerTier = {
      id: newId,
      name: `ตัวแทนระดับ ${settings.tiers.length + 1}`,
      minTopup: 10000,
      discountPercent: 25,
      badgeText: 'ลดทุกออเดอร์',
      displayDiscount: '-25%',
      color: '#a855f7',
      description: 'สิทธิพิเศษสำหรับตัวแทน'
    };
    setSettings((prev) => ({
      ...prev,
      tiers: [...prev.tiers, newTier]
    }));
  };

  // Remove Tier
  const handleRemoveTier = (id: string) => {
    playClick();
    if (settings.tiers.length <= 1) {
      alert('ต้องมีระดับตัวแทนอย่างน้อย 1 ระดับ');
      return;
    }
    setSettings((prev) => ({
      ...prev,
      tiers: prev.tiers.filter((t) => t.id !== id)
    }));
  };

  // Update Tier field
  const handleTierChange = (id: string, field: keyof ResellerTier, value: any) => {
    setSettings((prev) => ({
      ...prev,
      tiers: prev.tiers.map((t) => (t.id === id ? { ...t, [field]: value } : t))
    }));
  };

  // Add new Leaderboard item
  const handleAddLeaderboard = () => {
    playClick();
    const newItem: ResellerLeaderboardItem = {
      id: `lb-${Date.now()}`,
      rank: settings.leaderboard.length + 1,
      username: `user•••${Math.floor(10 + Math.random() * 90)}`,
      tierName: settings.tiers[settings.tiers.length - 1]?.name || 'สิทธิ์ตัวแทน',
      discountLabel: settings.tiers[settings.tiers.length - 1]?.displayDiscount || 'ลด 50%',
      color: settings.tiers[settings.tiers.length - 1]?.color || '#eab308',
      totalTopup: 5000
    };
    setSettings((prev) => ({
      ...prev,
      leaderboard: [...prev.leaderboard, newItem]
    }));
  };

  // Remove Leaderboard item
  const handleRemoveLeaderboard = (id: string) => {
    playClick();
    setSettings((prev) => ({
      ...prev,
      leaderboard: prev.leaderboard
        .filter((i) => i.id !== id)
        .map((it, idx) => ({ ...it, rank: idx + 1 }))
    }));
  };

  // Update Leaderboard item
  const handleLeaderboardChange = (id: string, field: keyof ResellerLeaderboardItem, value: any) => {
    setSettings((prev) => ({
      ...prev,
      leaderboard: prev.leaderboard.map((i) => (i.id === id ? { ...i, [field]: value } : i))
    }));
  };

  if (loading) {
    return (
      <div className="p-8 text-center text-slate-400 font-mono text-xs">
        <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping inline-block mr-2" />
        กำลังโหลดการตั้งค่าตัวแทนจำหน่าย...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 1. Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0 shadow-lg shadow-amber-500/10">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <span>จัดการโปรแกรมตัวแทนจำหน่าย (Reseller & VIP Tiers)</span>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
                /reseller
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              กำหนดเกณฑ์ยอดเติมสะสม, ส่วนลด %, ข้อความ และรายชื่ออันดับตัวแทน
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <a
            href="/reseller"
            target="_blank"
            rel="noreferrer"
            onClick={playClick}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1.5 transition"
          >
            <span>ดูหน้าร้าน</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <button
            type="button"
            onClick={() => handleSave()}
            disabled={saving}
            className="px-5 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-cyan-500/20 active:scale-95 transition disabled:opacity-50 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'กำลังบันทึก...' : 'บันทึกการตั้งค่า'}</span>
          </button>
        </div>
      </div>

      {/* 2. Sub-tab Navigation */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2">
        <button
          type="button"
          onClick={() => {
            playClick();
            setActiveTab('tiers');
          }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'tiers'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
          }`}
        >
          <Award className="w-3.5 h-3.5" />
          <span>ระดับยศ & ยอดเติมขั้นต่ำ ({settings.tiers.length})</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playClick();
            setActiveTab('texts');
          }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'texts'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>ข้อความ & คำอธิบายหน้าเว็บ</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playClick();
            setActiveTab('leaderboard');
          }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'leaderboard'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
          }`}
        >
          <Trophy className="w-3.5 h-3.5 text-amber-400" />
          <span>อันดับตัวแทน ({settings.leaderboard.length})</span>
        </button>
      </div>

      {/* 3. Tab Contents */}

      {/* TAB 1: TIERS & TOP-UP THRESHOLDS */}
      {activeTab === 'tiers' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">กำหนดเกณฑ์ยอดเติมและสิทธิ์ส่วนลด</h3>
              <p className="text-xs text-slate-400">
                เมื่อผู้ใช้เติมเงินสะสมถึงเกณฑ์ ระบบจะเลื่อนระดับและปรับส่วนลดให้อัตโนมัติทันที
              </p>
            </div>

            <button
              type="button"
              onClick={handleAddTier}
              className="px-3.5 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>เพิ่มระดับตัวแทน</span>
            </button>
          </div>

          {/* Tiers List */}
          <div className="space-y-3">
            {settings.tiers.map((tier, idx) => (
              <div
                key={tier.id}
                className="p-4 sm:p-5 rounded-2xl bg-[color:var(--arx-dk-090b12)] border border-white/10 space-y-4 hover:border-white/20 transition relative group"
              >
                {/* Header of Tier Card */}
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center font-mono font-bold text-xs text-slate-400">
                      {idx + 1}
                    </span>
                    <span
                      className="w-3 h-3 rounded-full shrink-0 shadow-[0_0_8px_currentColor]"
                      style={{ backgroundColor: tier.color, color: tier.color }}
                    />
                    <span className="font-bold text-white text-sm">
                      {tier.name || 'ไม่มีชื่อ'}
                    </span>
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-white/5 text-slate-400 border border-white/5">
                      ยอดสะสม ≥ {tier.minTopup.toLocaleString()} ฿
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleRemoveTier(tier.id)}
                      className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition cursor-pointer"
                      title="ลบระดับนี้"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Form Inputs Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-white/5">
                  {/* Field 1: ชื่อระดับ */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">
                      ชื่อระดับ (Tier Name) *
                    </label>
                    <input
                      type="text"
                      value={tier.name}
                      onChange={(e) => handleTierChange(tier.id, 'name', e.target.value)}
                      placeholder="เช่น ลดราคาสินค้าทุกอย่าง 15%"
                      className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                    />
                  </div>

                  {/* Field 2: ยอดเติมสะสมขั้นต่ำ (กำหนดจำนวนเติมได้) */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1 flex items-center justify-between">
                      <span>ยอดเติมสะสมขั้นต่ำ (บาท) *</span>
                      <span className="text-[10px] text-cyan-400 font-mono font-bold">กำหนดได้</span>
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        min="0"
                        step="1"
                        value={tier.minTopup}
                        onChange={(e) => handleTierChange(tier.id, 'minTopup', Number(e.target.value) || 0)}
                        placeholder="0"
                        className="w-full bg-slate-900 border border-white/10 rounded-xl pl-3 pr-8 py-2 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-400">
                        ฿
                      </span>
                    </div>
                  </div>

                  {/* Field 3: ส่วนลดตัวเลขใหญ่ (Display Discount) */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">
                      ข้อความส่วนลดตัวใหญ่ (Display) *
                    </label>
                    <input
                      type="text"
                      value={tier.displayDiscount}
                      onChange={(e) => handleTierChange(tier.id, 'displayDiscount', e.target.value)}
                      placeholder="เช่น —, -20%, -50%"
                      className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                    />
                  </div>

                  {/* Field 4: ข้อความในป้าย (Badge Text) */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">
                      ข้อความกำกับ (Subtext)
                    </label>
                    <input
                      type="text"
                      value={tier.badgeText}
                      onChange={(e) => handleTierChange(tier.id, 'badgeText', e.target.value)}
                      placeholder="เช่น ยังไม่มีส่วนลด, ลดทุกออเดอร์"
                      className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                    />
                  </div>
                </div>

                {/* Row 2: Color selection & percent discount */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {/* ส่วนลด % จริง (Discount Percent) */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">
                      ส่วนลดจริงตอนสั่งซื้อ (%)
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={tier.discountPercent}
                        onChange={(e) => handleTierChange(tier.id, 'discountPercent', Number(e.target.value) || 0)}
                        placeholder="0"
                        className="w-full bg-slate-900 border border-white/10 rounded-xl pl-3 pr-8 py-2 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-400">
                        %
                      </span>
                    </div>
                  </div>

                  {/* สีของจุดและระดับ (Color) */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1 flex items-center justify-between">
                      <span>สีประจำระดับ (Color)</span>
                      <span className="font-mono text-[10px]" style={{ color: tier.color }}>
                        {tier.color}
                      </span>
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={tier.color || '#00e5ff'}
                        onChange={(e) => handleTierChange(tier.id, 'color', e.target.value)}
                        className="w-8 h-8 rounded-lg bg-slate-900 border border-white/10 cursor-pointer p-0.5 shrink-0"
                      />
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {PRESET_COLORS.map((c) => (
                          <button
                            key={c.value}
                            type="button"
                            onClick={() => handleTierChange(tier.id, 'color', c.value)}
                            className={`w-6 h-6 rounded-md border transition cursor-pointer ${
                              tier.color === c.value ? 'border-white scale-110' : 'border-transparent hover:scale-105'
                            }`}
                            style={{ backgroundColor: c.value }}
                            title={c.label}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: PAGE TEXTS & HEADINGS */}
      {activeTab === 'texts' && (
        <div className="p-5 sm:p-6 rounded-2xl bg-[color:var(--arx-dk-090b12)] border border-white/10 space-y-5">
          <div className="border-b border-white/5 pb-3">
            <h3 className="text-sm font-bold text-white">ข้อความและคำอธิบายในหน้าตัวแทนจำหน่าย</h3>
            <p className="text-xs text-slate-400">
              แก้ไขหัวข้อหลัก, สโลแกน และคำอธิบายเงื่อนไขยศของเว็บไซต์
            </p>
          </div>

          <div className="space-y-4">
            {/* Page Title */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                หัวข้อหลักหน้าตัวแทนจำหน่าย (Page Title)
              </label>
              <input
                type="text"
                value={settings.title}
                onChange={(e) => setSettings({ ...settings, title: e.target.value })}
                placeholder="โปรแกรมตัวแทนจำหน่าย"
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
              />
            </div>

            {/* Page Subtitle */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                คำอธิบายใต้หัวข้อหลัก (Subtitle)
              </label>
              <textarea
                rows={2}
                value={settings.subtitle}
                onChange={(e) => setSettings({ ...settings, subtitle: e.target.value })}
                placeholder="เติมสะสมยิ่งเยอะ ยิ่งลดเยอะทุกออเดอร์ — ระบบเลื่อนระดับให้อัตโนมัติเมื่อยอดเติมสะสมถึงเกณฑ์ ส่วนลดหักให้ทันทีตอนสั่งซื้อ"
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {/* Badge Box Title */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  หัวข้อกล่องเงื่อนไขขวา (Badge Title)
                </label>
                <input
                  type="text"
                  value={settings.badgeTitle}
                  onChange={(e) => setSettings({ ...settings, badgeTitle: e.target.value })}
                  placeholder="ยศของคุณไม่มีวันหมดอายุ"
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                />
              </div>

              {/* Badge Box Description */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  คำอธิบายกล่องเงื่อนไขขวา (Badge Description)
                </label>
                <input
                  type="text"
                  value={settings.badgeDescription}
                  onChange={(e) => setSettings({ ...settings, badgeDescription: e.target.value })}
                  placeholder="ยศนี้ไม่มีเงื่อนไขยอดรักษายศ — ใช้สิทธิ์ได้ต่อเนื่อง เติมสะสมเพื่อเลื่อนระดับถัดไป"
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {/* All Tiers Title */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  หัวข้อส่วนระดับทั้งหมด (Tiers Title)
                </label>
                <input
                  type="text"
                  value={settings.allTiersTitle}
                  onChange={(e) => setSettings({ ...settings, allTiersTitle: e.target.value })}
                  placeholder="ระดับทั้งหมด"
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                />
              </div>

              {/* All Tiers Subtitle */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  คำอธิบายส่วนระดับทั้งหมด (Tiers Subtitle)
                </label>
                <input
                  type="text"
                  value={settings.allTiersSubtitle}
                  onChange={(e) => setSettings({ ...settings, allTiersSubtitle: e.target.value })}
                  placeholder="เลื่อนอัตโนมัติเมื่อยอดเติมสะสมถึงเกณฑ์"
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                />
              </div>
            </div>

          </div>
        </div>
      )}

      {/* TAB 3: LEADERBOARD SETTINGS */}
      {activeTab === 'leaderboard' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">จัดการอันดับตัวแทนจำหน่าย (Leaderboard)</h3>
              <p className="text-xs text-slate-400">
                แสดงรายชื่อตัวแทนยอดเติมสูงสุดด้านล่างของหน้าตัวแทนจำหน่าย
              </p>
            </div>

            <button
              type="button"
              onClick={handleAddLeaderboard}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>เพิ่มอันดับ</span>
            </button>
          </div>

          <div className="space-y-3">
            {settings.leaderboard.map((item, idx) => (
              <div
                key={item.id}
                className="p-3.5 sm:p-4 rounded-xl bg-[color:var(--arx-dk-090b12)] border border-white/10 flex items-center gap-3 flex-wrap"
              >
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 font-mono font-bold flex items-center justify-center text-sm shrink-0">
                  #{idx + 1}
                </div>

                <div className="flex-1 min-w-[140px]">
                  <label className="block text-[10px] text-slate-400 font-semibold mb-0.5">
                    ชื่อผู้ใช้ (Username)
                  </label>
                  <input
                    type="text"
                    value={item.username}
                    onChange={(e) => handleLeaderboardChange(item.id, 'username', e.target.value)}
                    placeholder="เช่น bea•••xa"
                    className="w-full bg-slate-900 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="flex-1 min-w-[160px]">
                  <label className="block text-[10px] text-slate-400 font-semibold mb-0.5">
                    ระดับยศ (Tier Name)
                  </label>
                  <input
                    type="text"
                    value={item.tierName}
                    onChange={(e) => handleLeaderboardChange(item.id, 'tierName', e.target.value)}
                    placeholder="เช่น ลดราคาสินค้าทุกอย่าง 50%"
                    className="w-full bg-slate-900 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="w-28">
                  <label className="block text-[10px] text-slate-400 font-semibold mb-0.5">
                    ป้ายส่วนลด
                  </label>
                  <input
                    type="text"
                    value={item.discountLabel}
                    onChange={(e) => handleLeaderboardChange(item.id, 'discountLabel', e.target.value)}
                    placeholder="เช่น ลด 50%"
                    className="w-full bg-slate-900 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="w-20">
                  <label className="block text-[10px] text-slate-400 font-semibold mb-0.5">
                    สียศ
                  </label>
                  <input
                    type="color"
                    value={item.color || '#eab308'}
                    onChange={(e) => handleLeaderboardChange(item.id, 'color', e.target.value)}
                    className="w-full h-8 rounded-lg bg-slate-900 border border-white/10 cursor-pointer p-0.5"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => handleRemoveLeaderboard(item.id)}
                  className="p-2 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition cursor-pointer self-end mb-0.5"
                  title="ลบรายการนี้"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. Bottom Sticky / Standard Save Bar */}
      <div className="p-4 rounded-2xl bg-slate-950/90 border border-white/10 flex items-center justify-between shadow-xl">
        <div className="text-xs text-slate-400 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>แก้ไขข้อมูลแล้วอย่าลืมกดปุ่มบันทึก เพื่อให้มีผลในหน้าเว็บทันที</span>
        </div>

        <button
          type="button"
          onClick={() => handleSave()}
          disabled={saving}
          className="px-6 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-cyan-500/20 active:scale-95 transition disabled:opacity-50 cursor-pointer"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'กำลังบันทึก...' : 'บันทึกการตั้งค่าตัวแทนจำหน่าย'}</span>
        </button>
      </div>

    </div>
  );
}
