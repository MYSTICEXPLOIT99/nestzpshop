'use client';

import React, { useState, useEffect } from 'react';
import {
  Gift,
  Plus,
  Trash2,
  Edit,
  CheckCircle2,
  XCircle,
  Copy,
  Sparkles,
  History,
  Coins,
  Gamepad2,
  Layers,
  Save,
  X,
  Check,
  Search,
  ExternalLink,
  ChevronRight,
  RefreshCw,
  Award
} from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export interface BoxItem {
  id: string;
  name: string;
  tier: 'common' | 'rare' | 'epic' | 'legendary';
  chance: number;
  accounts: string[];
  image?: string;
}

export interface RandomBox {
  id: string;
  name: string;
  category?: string;
  game: string;
  image: string;
  price: number;
  badge?: string;
  isActive: boolean;
  totalSpins: number;
  items: BoxItem[];
}

export interface RollHistoryRecord {
  id: string;
  boxId: string;
  boxName: string;
  userId: string;
  username: string;
  itemName: string;
  tier: string;
  resultAccount: string;
  price: number;
  createdAt: string;
}

export default function RandomBoxesTab() {
  const { playClick, playSuccess, playError, showToast } = useStore();

  const [boxes, setBoxes] = useState<RandomBox[]>([]);
  const [history, setHistory] = useState<RollHistoryRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeSubTab, setActiveSubTab] = useState<'boxes' | 'history'>('boxes');
  const [historySearch, setHistorySearch] = useState('');

  // Modal State for Add / Edit Box
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form State
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState('หมวดสุ่มทดสอบ 1');
  const [formGame, setFormGame] = useState('ROV');
  const [formImage, setFormImage] = useState('/catalog/imported/banner_fivem.webp');
  const [formPrice, setFormPrice] = useState(39);
  const [formBadge, setFormBadge] = useState('ยอดนิยม');
  const [formIsActive, setFormIsActive] = useState(true);
  const [formItems, setFormItems] = useState<BoxItem[]>([
    {
      id: 'item-1',
      name: 'ไอดี ROV รูท 300+ สกินแรร์',
      tier: 'legendary',
      chance: 15,
      accounts: ['rov_acc1:pass123', 'rov_acc2:pass456']
    },
    {
      id: 'item-2',
      name: 'ไอดี ROV รูน 90 พร้อมลงแรงค์',
      tier: 'rare',
      chance: 55,
      accounts: ['rov_rank01:pass99', 'rov_rank02:pass88']
    },
    {
      id: 'item-3',
      name: 'เสียใจด้วย ได้รับกำลังใจจากแอดมิน (เกลือ)',
      tier: 'common',
      chance: 30,
      accounts: ['เกลือ: ขอบคุณที่ร่วมสนุก ลองใหม่อีกครั้งนะ!']
    }
  ]);

  const fetchAdminBoxes = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/admin/random-boxes');
      const data = await res.json();
      if (data.success) {
        setBoxes(data.boxes || []);
        setHistory(data.history || []);
      }
    } catch (err) {
      console.error('Failed to fetch admin random boxes', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminBoxes();
  }, []);

  const openAddModal = () => {
    playClick();
    setEditingId(null);
    setFormName('');
    setFormCategory('หมวดสุ่มทดสอบ 1');
    setFormGame('ROV');
    setFormImage('/catalog/random/card_asuna.png');
    setFormPrice(39);
    setFormBadge('ยอดนิยม');
    setFormIsActive(true);
    setFormItems([
      {
        id: 'item-' + Date.now() + '-1',
        name: 'ไอดี ROV สกินแรร์ 100%',
        tier: 'legendary',
        chance: 20,
        accounts: ['demo_user01:demopass']
      },
      {
        id: 'item-' + Date.now() + '-2',
        name: 'ไอดี ROV ธรรมดา',
        tier: 'rare',
        chance: 50,
        accounts: ['demo_user02:demopass']
      },
      {
        id: 'item-' + Date.now() + '-3',
        name: 'เสียใจด้วย ลองใหม่อีกครั้ง',
        tier: 'common',
        chance: 30,
        accounts: ['เกลือ: ขอบคุณที่ร่วมสนุก!']
      }
    ]);
    setIsModalOpen(true);
  };

  const openEditModal = (box: RandomBox) => {
    playClick();
    setEditingId(box.id);
    setFormName(box.name);
    setFormCategory(box.category || 'หมวดสุ่มทดสอบ 1');
    setFormGame(box.game);
    setFormImage(box.image);
    setFormPrice(box.price);
    setFormBadge(box.badge || '');
    setFormIsActive(box.isActive);
    setFormItems(box.items ? JSON.parse(JSON.stringify(box.items)) : []);
    setIsModalOpen(true);
  };

  const handleToggleActive = async (boxId: string) => {
    playClick();
    try {
      const res = await fetch('/api/admin/random-boxes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'toggle_active', boxId })
      });
      const data = await res.json();
      if (data.success) {
        setBoxes(data.boxes);
        showToast({ title: 'สำเร็จ', message: 'อัปเดตสถานะเปิด/ปิดแล้ว', type: 'success' });
      }
    } catch (err: any) {
      showToast({ title: 'ข้อผิดพลาด', message: err.message, type: 'error' });
    }
  };

  const handleDeleteBox = async (boxId: string) => {
    if (!confirm('คุณแน่ใจหรือไม่ว่าต้องการลบกล่องสุ่มนี้?')) return;
    playClick();
    try {
      const res = await fetch('/api/admin/random-boxes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', boxId })
      });
      const data = await res.json();
      if (data.success) {
        setBoxes(data.boxes);
        playSuccess();
        showToast({ title: 'สำเร็จ', message: 'ลบกล่องสุ่มเรียบร้อยแล้ว', type: 'success' });
      }
    } catch (err: any) {
      showToast({ title: 'ข้อผิดพลาด', message: err.message, type: 'error' });
    }
  };

  const handleAddItemToForm = () => {
    playClick();
    setFormItems([
      ...formItems,
      {
        id: 'item-' + Date.now(),
        name: 'รางวัลใหม่',
        tier: 'rare',
        chance: 10,
        accounts: []
      }
    ]);
  };

  const handleRemoveItemFromForm = (idx: number) => {
    playClick();
    setFormItems(formItems.filter((_, i) => i !== idx));
  };

  const handleUpdateItemField = (idx: number, field: keyof BoxItem, val: any) => {
    const updated = [...formItems];
    (updated[idx] as any)[field] = val;
    setFormItems(updated);
  };

  const handleSaveBox = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || formPrice <= 0) {
      showToast({ title: 'แจ้งเตือน', message: 'กรุณากรอกชื่อกล่องและราคาให้ถูกต้อง', type: 'warning' });
      return;
    }

    const payloadBox: Partial<RandomBox> = {
      ...(editingId ? { id: editingId } : {}),
      name: formName.trim(),
      category: formCategory.trim() || 'หมวดสุ่มทดสอบ 1',
      game: formGame.trim(),
      image: formImage.trim() || '/catalog/random/card_asuna.png',
      price: Number(formPrice),
      badge: formBadge.trim() || undefined,
      isActive: formIsActive,
      items: formItems
    };

    try {
      const res = await fetch('/api/admin/random-boxes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'save', box: payloadBox })
      });
      const data = await res.json();
      if (data.success) {
        setBoxes(data.boxes);
        setIsModalOpen(false);
        playSuccess();
        showToast({ title: 'สำเร็จ', message: 'บันทึกกล่องสุ่มเรียบร้อยแล้ว', type: 'success' });
      } else {
        showToast({ title: 'ข้อผิดพลาด', message: data.error, type: 'error' });
      }
    } catch (err: any) {
      showToast({ title: 'ข้อผิดพลาด', message: err.message, type: 'error' });
    }
  };

  const totalSpinsAll = boxes.reduce((acc, b) => acc + (b.totalSpins || 0), 0);
  const totalRevenueAll = history.reduce((acc, h) => acc + (h.price || 0), 0);

  const filteredHistory = history.filter(h => {
    if (!historySearch.trim()) return true;
    const term = historySearch.toLowerCase();
    return (
      h.username.toLowerCase().includes(term) ||
      h.boxName.toLowerCase().includes(term) ||
      h.itemName.toLowerCase().includes(term) ||
      h.resultAccount.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6">
      {/* 1. Header Overview & Stats */}
      <div className="p-4 sm:p-6 rounded-2xl bg-slate-950/80 border border-cyan-500/20 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Gift className="w-5 h-5 text-cyan-400" />
              <h2 className="text-base sm:text-lg font-black text-white">จัดการระบบสุ่มรหัส (Random Account Manager)</h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              สร้างกล่องสุ่มรหัสเกม (ROV, Free Fire, Valorant ฯลฯ) กำหนดโอกาส % ใส่สต็อกไอดี และตรวจสอบประวัติการสุ่ม
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={openAddModal}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-[0_0_15px_rgba(var(--theme-accent-rgb),0.4)] transition cursor-pointer"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>สร้างกล่องสุ่มใหม่</span>
            </button>
            <button
              type="button"
              onClick={fetchAdminBoxes}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 transition cursor-pointer border border-white/10"
              title="รีเฟรชข้อมูล"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 pt-4 border-t border-white/5">
          <div className="p-3 rounded-xl bg-cyan-950/20 border border-cyan-500/20">
            <span className="text-[11px] text-slate-400 block">กล่องสุ่มทั้งหมด</span>
            <b className="text-lg font-black text-cyan-300">{boxes.length} กล่อง</b>
          </div>
          <div className="p-3 rounded-xl bg-purple-950/20 border border-purple-500/20">
            <span className="text-[11px] text-slate-400 block">จำนวนครั้งที่สุ่มแล้ว</span>
            <b className="text-lg font-black text-purple-300">{totalSpinsAll.toLocaleString()} ครั้ง</b>
          </div>
          <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/20">
            <span className="text-[11px] text-slate-400 block">ยอดเงินจากการสุ่มทั้งหมด</span>
            <b className="text-lg font-black text-emerald-400 font-mono">฿{totalRevenueAll.toLocaleString()}</b>
          </div>
        </div>
      </div>

      {/* 2. Sub Tabs (รายการกล่องสุ่ม / ประวัติการสุ่ม) */}
      <div className="flex gap-2 border-b border-white/10 pb-2">
        <button
          type="button"
          onClick={() => {
            playClick();
            setActiveSubTab('boxes');
          }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
            activeSubTab === 'boxes'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Gift className="w-3.5 h-3.5" />
          <span>รายการตู้สุ่ม ({boxes.length})</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playClick();
            setActiveSubTab('history');
          }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
            activeSubTab === 'history'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>ประวัติการสุ่ม ({history.length})</span>
        </button>
      </div>

      {/* 3. Tab Contents */}
      {activeSubTab === 'boxes' ? (
        /* Boxes List */
        <div className="space-y-4">
          {boxes.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-black/40 border border-white/10 text-slate-400">
              <Gift className="w-10 h-10 mx-auto text-slate-600 mb-2" />
              <p>ยังไม่มีกล่องสุ่มในระบบ</p>
              <button
                type="button"
                onClick={openAddModal}
                className="mt-3 px-4 py-1.5 rounded-xl bg-cyan-500 text-black font-bold text-xs"
              >
                + สร้างกล่องสุ่มแรก
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {boxes.map((box) => (
                <div
                  key={box.id}
                  className="p-4 sm:p-5 rounded-2xl bg-slate-950/90 border border-white/10 hover:border-cyan-500/30 transition-all space-y-3 shadow-md"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-14 h-14 rounded-xl overflow-hidden bg-black border border-white/10 shrink-0">
                        <img src={box.image} alt={box.name} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                            {box.game}
                          </span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                            {box.category || 'หมวดสุ่มทั่วไป'}
                          </span>
                          {box.badge && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                              {box.badge}
                            </span>
                          )}
                        </div>
                        <h3 className="font-bold text-white text-sm mt-1">{box.name}</h3>
                        <p className="text-xs font-mono text-cyan-400 font-bold">฿{box.price} / ครั้ง</p>
                      </div>
                    </div>

                    {/* Active toggle & buttons */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleToggleActive(box.id)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                          box.isActive
                            ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {box.isActive ? 'เปิดอยู่' : 'ปิดอยู่'}
                      </button>
                      <button
                        type="button"
                        onClick={() => openEditModal(box)}
                        className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition cursor-pointer"
                        title="แก้ไข"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteBox(box.id)}
                        className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 transition cursor-pointer"
                        title="ลบ"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Items Summary in this box */}
                  <div className="pt-2 border-t border-white/5 space-y-1">
                    <span className="text-[10px] text-slate-400 font-semibold block">
                      ของรางวัลในกล่อง ({box.items?.length || 0} รายการ):
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-32 overflow-y-auto pr-1">
                      {box.items?.map((it) => (
                        <div
                          key={it.id}
                          className="p-2 rounded-lg bg-black/50 border border-white/5 text-[11px] flex items-center justify-between"
                        >
                          <span className="truncate pr-1 text-slate-300">{it.name}</span>
                          <span className="font-mono text-cyan-300 font-bold shrink-0">{it.chance}%</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-500">
                    <span>สุ่มไปแล้ว {box.totalSpins.toLocaleString()} ครั้ง</span>
                    <span className="text-cyan-400 font-mono">ID: {box.id}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* History View */
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="relative flex-1 max-w-sm">
              <input
                type="text"
                value={historySearch}
                onChange={e => setHistorySearch(e.target.value)}
                placeholder="ค้นหาชื่อผู้ใช้, กล่อง, หรือรางวัล..."
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white placeholder:text-slate-500 outline-none focus:border-cyan-400"
              />
            </div>
            <span className="text-xs text-slate-400">พบ {filteredHistory.length} รายการ</span>
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-950/80 overflow-hidden shadow-lg overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-white/5 text-slate-400 uppercase font-mono text-[10px] tracking-wider">
                <tr>
                  <th className="px-4 py-3">ผู้ใช้</th>
                  <th className="px-4 py-3">กล่องสุ่ม</th>
                  <th className="px-4 py-3">รางวัลที่ได้รับ</th>
                  <th className="px-4 py-3">ข้อมูลรหัส/ไอดี</th>
                  <th className="px-4 py-3">ราคา</th>
                  <th className="px-4 py-3">เวลา</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredHistory.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                      ไม่พบประวัติการสุ่ม
                    </td>
                  </tr>
                ) : (
                  filteredHistory.map((item) => (
                    <tr key={item.id} className="hover:bg-white/[0.02]">
                      <td className="px-4 py-3 font-bold text-white">{item.username}</td>
                      <td className="px-4 py-3 text-cyan-300">{item.boxName}</td>
                      <td className="px-4 py-3 font-semibold text-white">{item.itemName}</td>
                      <td className="px-4 py-3 font-mono text-emerald-400 max-w-[200px] truncate select-all">
                        {item.resultAccount}
                      </td>
                      <td className="px-4 py-3 font-mono text-cyan-400">฿{item.price}</td>
                      <td className="px-4 py-3 text-slate-400 font-mono text-[11px]">{item.createdAt}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. Modal for Add / Edit Box */}
      {isModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150 overflow-y-auto"
        >
          <div
            className="w-full max-w-2xl rounded-3xl bg-[color:var(--arx-dk-090d16)] border border-cyan-500/40 p-6 shadow-2xl relative my-8 max-h-[90vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Gift className="w-5 h-5 text-cyan-400" />
                <span>{editingId ? 'แก้ไขกล่องสุ่ม' : 'สร้างกล่องสุ่มใหม่'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveBox} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">ชื่อกล่องสุ่ม *</label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={e => setFormName(e.target.value)}
                    placeholder="เช่น กล่องสุ่มรหัส ROV สกินแรร์"
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">หมวดหมู่กล่องสุ่ม *</label>
                  <input
                    type="text"
                    required
                    value={formCategory}
                    onChange={e => setFormCategory(e.target.value)}
                    placeholder="เช่น หมวดสุ่มทดสอบ 1"
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">หมวดหมู่เกม *</label>
                  <input
                    type="text"
                    required
                    value={formGame}
                    onChange={e => setFormGame(e.target.value)}
                    placeholder="เช่น ROV, Free Fire, Valorant"
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">ราคาต่อครั้ง (บาท) *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={formPrice}
                    onChange={e => setFormPrice(Number(e.target.value))}
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-cyan-400 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">ป้ายกำกับ (Badge)</label>
                  <input
                    type="text"
                    value={formBadge}
                    onChange={e => setFormBadge(e.target.value)}
                    placeholder="เช่น ยอดนิยม, คุ้มสุด"
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">URL รูปภาพหน้าปก</label>
                  <input
                    type="text"
                    value={formImage}
                    onChange={e => setFormImage(e.target.value)}
                    placeholder="/catalog/imported/banner_fivem.webp หรือ URL รูปภาพ"
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* Items in Box Editor */}
              <div className="pt-3 border-t border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Award className="w-4 h-4 text-amber-400" />
                    <span>รายการของรางวัลในกล่อง & สต็อกรหัสไอดี</span>
                  </h4>
                  <button
                    type="button"
                    onClick={handleAddItemToForm}
                    className="px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>เพิ่มรางวัล</span>
                  </button>
                </div>

                <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                  {formItems.map((item, idx) => (
                    <div key={item.id || idx} className="p-3 rounded-xl bg-black/60 border border-white/10 space-y-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={item.name}
                          onChange={e => handleUpdateItemField(idx, 'name', e.target.value)}
                          placeholder="ชื่อรางวัล เช่น ไอดี ROV ฮีโร่ครบ"
                          className="flex-1 bg-slate-900 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white"
                        />
                        <select
                          value={item.tier}
                          onChange={e => handleUpdateItemField(idx, 'tier', e.target.value)}
                          className="bg-slate-900 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-slate-300"
                        >
                          <option value="common">Common (ทั่วไป)</option>
                          <option value="rare">Rare (หายาก)</option>
                          <option value="epic">Epic (สุดยอด)</option>
                          <option value="legendary">Legendary (ตำนาน)</option>
                        </select>
                        <div className="flex items-center gap-1 w-24">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            value={item.chance}
                            onChange={e => handleUpdateItemField(idx, 'chance', Number(e.target.value))}
                            className="w-full bg-slate-900 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-cyan-300 font-mono text-center"
                          />
                          <span className="text-xs text-slate-400">%</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveItemFromForm(idx)}
                          className="p-1.5 text-rose-400 hover:bg-rose-500/10 rounded-lg cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Multiline Accounts Stock */}
                      <div>
                        <label className="block text-[10px] text-slate-400 mb-0.5">
                          สต็อกไอดี/รหัสผ่าน (ใส่ 1 รายการต่อ 1 บรรทัด เช่น `id:pass` หรือข้อความรางวัล):
                        </label>
                        <textarea
                          rows={2}
                          value={(item.accounts || []).join('\n')}
                          onChange={e => {
                            const lines = e.target.value.split('\n');
                            handleUpdateItemField(idx, 'accounts', lines);
                          }}
                          placeholder="user1:pass1&#10;user2:pass2"
                          className="w-full bg-slate-900 border border-white/10 rounded-lg p-2 text-[11px] font-mono text-emerald-300 outline-none"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Form Buttons */}
              <div className="pt-3 border-t border-white/10 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-slate-300 cursor-pointer"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-lg"
                >
                  <Save className="w-4 h-4" />
                  <span>บันทึกกล่องสุ่ม</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
