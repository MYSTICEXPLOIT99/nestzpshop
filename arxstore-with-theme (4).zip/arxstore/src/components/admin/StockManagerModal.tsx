'use client';

import React, { useState, useMemo } from 'react';
import { Product, ProductPackage, DigitalStockItem } from '@/types';
import { useStore } from '@/context/StoreContext';
import {
  Key,
  Plus,
  Trash2,
  Copy,
  Check,
  ExternalLink,
  Download,
  Layers,
  Search,
  XCircle,
  FileText,
  AlertCircle,
  CheckCircle2,
  Package,
  Sparkles,
  Zap
} from 'lucide-react';

interface StockManagerModalProps {
  product: Product | null;
  initialPackageId?: string;
  isOpen: boolean;
  onClose: () => void;
}

export default function StockManagerModal({
  product,
  initialPackageId,
  isOpen,
  onClose
}: StockManagerModalProps) {
  const {
    products,
    addStockItem,
    addBulkStockItems,
    deleteStockItem,
    clearSoldStockItems,
    playClick,
    playSuccess
  } = useStore();

  // Find the fresh live product from store state
  const liveProduct = useMemo(() => {
    if (!product) return null;
    return products.find(p => p.id === product.id) || product;
  }, [products, product]);

  const [selectedPkgId, setSelectedPkgId] = useState<string>(() => {
    return initialPackageId || product?.packages[0]?.id || '';
  });

  // Keep selectedPkgId in sync when initialPackageId changes
  React.useEffect(() => {
    if (initialPackageId) {
      setSelectedPkgId(initialPackageId);
    } else if (liveProduct && liveProduct.packages[0]) {
      setSelectedPkgId(liveProduct.packages[0].id);
    }
  }, [initialPackageId, liveProduct]);

  const currentPackage: ProductPackage | undefined = useMemo(() => {
    if (!liveProduct) return undefined;
    return liveProduct.packages.find(p => p.id === selectedPkgId) || liveProduct.packages[0];
  }, [liveProduct, selectedPkgId]);

  // Close on Escape key press (กดปุ่ม Esc เพื่อปิดหน้าต่างจัดการคลัง)
  React.useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'Esc') {
        e.preventDefault();
        playClick();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, playClick]);

  // Auto-heal / Populate stock items if package has stock count > 0 but stockItems is empty
  React.useEffect(() => {
    if (!isOpen || !liveProduct || !currentPackage) return;
    const currentUnused = (currentPackage.stockItems || []).filter(s => !s.isUsed).length;
    const targetStock = currentPackage.stock || 0;
    if (targetStock > currentUnused) {
      const needed = targetStock - currentUnused;
      const itemsToAdd: Array<Omit<DigitalStockItem, 'id' | 'createdAt'>> = [];
      const cleanProdName = (liveProduct.name || 'ARX_PRODUCT').replace(/[^a-zA-Z0-9ก-๙]/g, '_');
      const cleanPkgDuration = (currentPackage.duration || 'Package').replace(/[^a-zA-Z0-9ก-๙]/g, '_');
      for (let i = 0; i < needed; i++) {
        const randChunk = () => Math.random().toString(36).substring(2, 6).toUpperCase();
        itemsToAdd.push({
          key: `ARX-${randChunk()}-${randChunk()}-${randChunk()}`,
          downloadUrl: liveProduct.downloadUrl || 'https://cdn.arxstore.com/download/latest.zip',
          fileName: `${cleanProdName}_${cleanPkgDuration}.zip`,
          note: 'คลังสินค้าพร้อมส่ง (Real-time Key)',
          isUsed: false
        });
      }
      addBulkStockItems(liveProduct.id, currentPackage.id, itemsToAdd);
    }
  }, [isOpen, liveProduct, currentPackage, addBulkStockItems]);

  // Stock input form state (1 line = 1 stock)
  const [bulkText, setBulkText] = useState('');

  // Table filter & search
  const [filterStatus, setFilterStatus] = useState<'all' | 'available' | 'sold'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen || !liveProduct || !currentPackage) return null;

  const stockItems: DigitalStockItem[] = currentPackage.stockItems || [];
  const availableItems = stockItems.filter(s => !s.isUsed);
  const soldItems = stockItems.filter(s => s.isUsed);

  // Filtered items
  const filteredItems = stockItems
    .filter(item => {
      if (filterStatus === 'available') return !item.isUsed;
      if (filterStatus === 'sold') return item.isUsed;
      return true;
    })
    .filter(item => {
      if (!searchQuery) return true;
      const q = searchQuery.toLowerCase();
      return (
        item.key.toLowerCase().includes(q) ||
        (item.fileName && item.fileName.toLowerCase().includes(q)) ||
        (item.note && item.note.toLowerCase().includes(q)) ||
        (item.usedBy && item.usedBy.toLowerCase().includes(q)) ||
        (item.orderId && item.orderId.toLowerCase().includes(q))
      );
    });

  // Count lines in bulk text (1 line = 1 stock)
  const bulkLines = bulkText
    .split('\n')
    .map(l => l.trim())
    .filter(l => l.length > 0);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    playClick();
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleGenerateDemoKeys = () => {
    playClick();
    const pkgPrefix = (liveProduct.name || 'ARX')
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, '')
      .slice(0, 5) || 'ARX';
    const durationCode = currentPackage.duration
      ? currentPackage.duration.replace(/[^0-9A-Za-z]/g, '').toUpperCase()
      : 'VIP';
    const generated: string[] = [];
    for (let i = 0; i < 5; i++) {
      const randPart1 = Math.random().toString(36).substring(2, 6).toUpperCase();
      const randPart2 = Math.random().toString(36).substring(2, 6).toUpperCase();
      generated.push(`${pkgPrefix}-${durationCode}-${randPart1}-${randPart2}`);
    }
    setBulkText(prev => (prev.trim() ? prev.trim() + '\n' + generated.join('\n') : generated.join('\n')));
  };

  const handleAddStock = (e: React.FormEvent) => {
    e.preventDefault();
    if (bulkLines.length === 0) return;

    const itemsToAdd = bulkLines.map(line => {
      // Check if line contains pipe or tab separated custom data: KEY | URL | FILENAME | NOTE
      const parts = line.split(/[|\t]/).map(p => p.trim());
      if (parts.length > 1) {
        return {
          key: parts[0],
          downloadUrl: parts[1] || liveProduct.downloadUrl || undefined,
          fileName: parts[2] || undefined,
          note: parts[3] || undefined,
          isUsed: false
        };
      }
      return {
        key: line.trim(),
        downloadUrl: liveProduct.downloadUrl || undefined,
        fileName: undefined,
        note: undefined,
        isUsed: false
      };
    });

    addBulkStockItems(liveProduct.id, currentPackage.id, itemsToAdd);
    playSuccess();
    setBulkText('');
  };

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          playClick();
          onClose();
        }
      }}
      className="fixed inset-0 z-[99999] flex items-center justify-center p-2 sm:p-3 bg-black/85 backdrop-blur-md overflow-y-auto cursor-pointer"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-xl cyber-card rounded-2xl bg-slate-950 border border-cyan-500/40 shadow-2xl my-auto overflow-hidden flex flex-col max-h-[86vh] cursor-default"
      >
        
        {/* Header */}
        <div className="px-3 py-2 bg-slate-900/95 border-b border-white/10 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 shadow-[0_0_8px_rgba(var(--theme-accent-rgb),0.2)]">
              <Key className="w-3 h-3" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[8.5px] font-mono font-bold uppercase tracking-wider text-cyan-400 bg-cyan-500/10 px-1.5 py-0.2 rounded border border-cyan-500/20">
                  {liveProduct.categoryName}
                </span>
                <span className="text-slate-600 text-xs">•</span>
                <span className="text-[9px] text-slate-400">ระบบจัดการสต็อกดิจิทัล</span>
              </div>
              <h2 className="text-xs sm:text-sm font-bold text-white leading-tight">
                {liveProduct.name}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[9.5px] font-mono font-bold text-slate-400 bg-white/5 border border-white/10 px-1.5 py-0.5 rounded">
              ESC
            </span>
            <button
              type="button"
              onClick={() => {
                playClick();
                onClose();
              }}
              className="p-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
              title="ปิดหน้าต่าง (กด Esc)"
            >
              <XCircle className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Package Selector Tabs */}
        <div className="px-3 py-1.5 bg-slate-900/40 border-b border-white/5 flex items-center gap-1 overflow-x-auto scrollbar-none">
          <span className="text-[10px] font-bold text-slate-400 shrink-0 mr-1 flex items-center gap-1">
            <Layers className="w-3 h-3 text-cyan-400" />
            <span>เลือกแพ็กเกจ:</span>
          </span>
          {liveProduct.packages.map(pkg => {
            const isSelected = pkg.id === currentPackage.id;
            const pkgItems = pkg.stockItems || [];
            const avail = pkgItems.filter(s => !s.isUsed).length;
            const total = pkgItems.length;

            return (
              <button
                key={pkg.id}
                type="button"
                onClick={() => {
                  playClick();
                  setSelectedPkgId(pkg.id);
                }}
                className={`px-2 py-0.5 rounded-md text-[10px] font-bold flex items-center gap-1 transition cursor-pointer shrink-0 border select-none ${
                  isSelected
                    ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-black shadow-sm shadow-cyan-500/20'
                    : 'bg-slate-950/60 text-slate-300 hover:text-white hover:bg-slate-900 border-white/10'
                }`}
              >
                <span>{pkg.name} ({pkg.duration})</span>
                <span className={`text-[8.5px] px-1 py-0.2 rounded-full font-mono font-bold ${
                  isSelected ? 'bg-slate-950 text-cyan-300' : 'bg-slate-800 text-slate-400'
                }`}>
                  {total > 0 ? `${avail}/${total}` : `${pkg.stock} ชิ้น`}
                </span>
              </button>
            );
          })}
        </div>

        {/* Modal Body with Scroll */}
        <div className="p-2 sm:p-2.5 overflow-y-auto space-y-2 flex-1">

          {/* Quick Package Stock KPI Cards */}
          <div className="grid grid-cols-3 gap-1.5">
            <div className="p-1.5 rounded-lg bg-slate-900/70 border border-emerald-500/30 flex items-center justify-between">
              <div>
                <span className="text-[8px] font-bold text-slate-400 block leading-tight">คีย์พร้อมส่ง</span>
                <span className="text-xs sm:text-sm font-black text-emerald-400 font-mono leading-tight">{availableItems.length}</span>
                <span className="text-[7.5px] text-slate-500 ml-1">รายการ</span>
              </div>
              <div className="w-4 h-4 rounded bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-2.5 h-2.5" />
              </div>
            </div>

            <div className="p-1.5 rounded-lg bg-slate-900/70 border border-rose-500/30 flex items-center justify-between">
              <div>
                <span className="text-[8px] font-bold text-slate-400 block leading-tight">ขายไปแล้ว</span>
                <span className="text-xs sm:text-sm font-black text-rose-400 font-mono leading-tight">{soldItems.length}</span>
                <span className="text-[7.5px] text-slate-500 ml-1">รายการ</span>
              </div>
              <div className="w-4 h-4 rounded bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <Package className="w-2.5 h-2.5" />
              </div>
            </div>

            <div className="p-1.5 rounded-lg bg-slate-900/70 border border-cyan-500/30 flex items-center justify-between">
              <div>
                <span className="text-[8px] font-bold text-slate-400 block leading-tight">คลังสต็อกรวม</span>
                <span className="text-xs sm:text-sm font-black text-cyan-400 font-mono leading-tight">{stockItems.length}</span>
                <span className="text-[7.5px] text-slate-500 ml-1">รายการ</span>
              </div>
              <div className="w-4 h-4 rounded bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Key className="w-2.5 h-2.5" />
              </div>
            </div>
          </div>

          {/* Form to Add Stock Items (1 Line = 1 Stock Direct Input) */}
          <div className="p-2 sm:p-2.5 rounded-lg bg-slate-900/80 border border-cyan-500/20 shadow-sm space-y-1.5">
            <div className="flex flex-wrap items-center justify-between gap-1 pb-1 border-b border-white/5">
              <div className="flex items-center gap-1.5">
                <div className="w-5 h-5 rounded bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
                  <Plus className="w-3 h-3" />
                </div>
                <div>
                  <h3 className="text-[11px] sm:text-xs font-bold text-white flex items-center gap-1">
                    <span>เพิ่มสต็อกสินค้าเข้าระบบ</span>
                    <span className="text-[8.5px] font-bold text-cyan-400 bg-cyan-500/10 px-1.5 py-0.2 rounded-full border border-cyan-500/20 font-mono">
                      1 บรรทัด = 1 สต็อก
                    </span>
                  </h3>
                </div>
              </div>

              {/* Action Tools */}
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={handleGenerateDemoKeys}
                  className="px-1.5 py-0.5 rounded bg-slate-800/80 hover:bg-slate-700 border border-white/10 text-[9px] font-medium text-slate-300 hover:text-white transition flex items-center gap-0.5 cursor-pointer select-none"
                  title="สุ่มสร้างคีย์ตัวอย่าง 5 รายการลงในช่อง"
                >
                  <Sparkles className="w-2.5 h-2.5 text-amber-400" />
                  <span>สุ่มตัวอย่าง 5 คีย์</span>
                </button>
                {bulkText.trim().length > 0 && (
                  <button
                    type="button"
                    onClick={() => { playClick(); setBulkText(''); }}
                    className="px-1.5 py-0.5 rounded bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-[9px] font-medium text-rose-300 transition cursor-pointer select-none"
                  >
                    ล้างช่อง
                  </button>
                )}
              </div>
            </div>

            <form onSubmit={handleAddStock} className="space-y-1.5 text-xs">
              {/* Direct Multi-line Input Box */}
              <div>
                <div className="flex items-center justify-between mb-0.5">
                  <label className="text-[10px] font-bold text-slate-300 flex items-center gap-1">
                    <Key className="w-2.5 h-2.5 text-cyan-400" />
                    <span>ช่องใส่คีย์ / รหัสสินค้า (1 บรรทัด = 1 สต็อก) *</span>
                  </label>
                  <div
                    className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded border transition ${
                      bulkLines.length > 0
                        ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
                        : 'text-slate-500 bg-slate-950 border-white/10'
                    }`}
                  >
                    {bulkLines.length > 0
                      ? `🟢 ${bulkLines.length} สต็อก`
                      : 'ยังไม่มีข้อมูล'}
                  </div>
                </div>

                <textarea
                  rows={5}
                  value={bulkText}
                  onChange={e => setBulkText(e.target.value)}
                  placeholder={`วางหรือพิมพ์คีย์ที่นี่ (1 บรรทัด = 1 สต็อก) เช่น:\nARX-FIVEM-1D-ABCD-1234\nARX-FIVEM-1D-EFGH-5678\nARX-FIVEM-1D-IJKL-9012\nARX-FIVEM-1D-MNOP-3456`}
                  className="w-full p-2.5 sm:p-3 rounded-xl bg-slate-950 border border-white/10 text-white font-mono text-xs sm:text-[13px] focus:outline-none focus:border-cyan-400 leading-relaxed placeholder:text-slate-600 transition resize-y min-h-[120px] sm:min-h-[140px] shadow-inner"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between gap-2 pt-0.5">
                <span className="text-[9px] text-slate-500 flex items-center gap-1">
                  <span>💡 1 บรรทัด = 1 ชิ้นสต็อก</span>
                </span>

                <button
                  type="submit"
                  disabled={bulkLines.length === 0}
                  className="px-3 py-1 rounded cyber-btn-primary font-bold text-[10.5px] flex items-center justify-center gap-1 shadow-sm shadow-cyan-500/20 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition"
                >
                  <Plus className="w-3 h-3" />
                  <span>
                    {bulkLines.length > 0
                      ? `เพิ่มเข้าสต็อก (${bulkLines.length} ชิ้น)`
                      : 'เพิ่มเข้าระบบสต็อก'}
                  </span>
                </button>
              </div>
            </form>
          </div>

          {/* Stock Items Inventory Table */}
          <div className="space-y-1.5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
              {/* Filter tabs */}
              <div className="flex items-center gap-1 overflow-x-auto pb-0.5 sm:pb-0">
                <button
                  type="button"
                  onClick={() => setFilterStatus('all')}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold transition cursor-pointer select-none ${
                    filterStatus === 'all'
                      ? 'bg-cyan-500 text-slate-950 font-black'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  ทั้งหมด ({stockItems.length})
                </button>
                <button
                  type="button"
                  onClick={() => setFilterStatus('available')}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold transition cursor-pointer select-none flex items-center gap-1 ${
                    filterStatus === 'available'
                      ? 'bg-emerald-400 text-slate-950 font-black'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  <span>พร้อมส่ง ({availableItems.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFilterStatus('sold')}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold transition cursor-pointer select-none flex items-center gap-1 ${
                    filterStatus === 'sold'
                      ? 'bg-rose-400 text-slate-950 font-black'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
                  <span>ขายแล้ว ({soldItems.length})</span>
                </button>
              </div>

              {/* Search & Actions */}
              <div className="flex items-center gap-1">
                <div className="relative w-full sm:w-36">
                  <Search className="w-2.5 h-2.5 text-slate-400 absolute left-2 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="ค้นหา..."
                    className="w-full pl-6 pr-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                {soldItems.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm(`ต้องการล้างประวัติรายการที่ขายแล้ว (${soldItems.length} รายการ) หรือไม่?`)) {
                        clearSoldStockItems(liveProduct.id, currentPackage.id);
                      }
                    }}
                    className="px-1.5 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-rose-400 border border-white/5 text-[9.5px] font-bold transition cursor-pointer shrink-0"
                    title="ล้างรายการที่ขายแล้วออกจากคลัง"
                  >
                    ล้างที่ขายแล้ว
                  </button>
                )}
              </div>
            </div>

            {/* Inventory Table */}
            <div className="overflow-x-auto rounded-lg border border-white/10 bg-slate-950/70 max-h-40 overflow-y-auto">
              <table className="w-full text-left text-[11px]">
                <thead className="bg-slate-900 text-slate-400 uppercase tracking-wider text-[9px] border-b border-white/10 sticky top-0 z-10">
                  <tr>
                    <th className="py-1 px-2 text-center w-8">#</th>
                    <th className="py-1 px-2 text-left">คีย์ (License Key)</th>
                    <th className="py-1 px-2 text-left">ลิงก์ดาวน์โหลด & ไฟล์</th>
                    <th className="py-1 px-2 text-center w-20">สถานะ</th>
                    <th className="py-1 px-2 text-left min-w-[100px]">ข้อมูลการขาย</th>
                    <th className="py-1 px-2 text-center w-10">ลบ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 font-mono">
                  {filteredItems.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-3 text-center text-[10.5px] text-slate-500 font-sans italic">
                        {stockItems.length === 0 ? (
                          <div className="flex flex-col items-center justify-center gap-1.5 py-1 font-sans not-italic">
                            <p className="text-slate-400 text-[10px]">ยังไม่มีรายการสต็อกดิจิทัลในคลังแพ็กเกจนี้</p>
                            {currentPackage.stock > 0 && (
                              <button
                                type="button"
                                onClick={() => {
                                  playClick();
                                  const itemsToAdd: Array<Omit<DigitalStockItem, 'id' | 'createdAt'>> = [];
                                  const cleanProdName = (liveProduct.name || 'ARX_PRODUCT').replace(/[^a-zA-Z0-9ก-๙]/g, '_');
                                  const cleanPkgDuration = (currentPackage.duration || 'Package').replace(/[^a-zA-Z0-9ก-๙]/g, '_');
                                  for (let i = 0; i < currentPackage.stock; i++) {
                                    const randChunk = () => Math.random().toString(36).substring(2, 6).toUpperCase();
                                    itemsToAdd.push({
                                      key: `ARX-${randChunk()}-${randChunk()}-${randChunk()}`,
                                      downloadUrl: liveProduct.downloadUrl || 'https://cdn.arxstore.com/download/latest.zip',
                                      fileName: `${cleanProdName}_${cleanPkgDuration}.zip`,
                                      note: 'คลังสินค้าพร้อมส่ง (Real-time Key)',
                                      isUsed: false
                                    });
                                  }
                                  addBulkStockItems(liveProduct.id, currentPackage.id, itemsToAdd);
                                  playSuccess();
                                }}
                                className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-emerald-500 hover:from-amber-400 hover:to-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer transition hover:scale-105"
                              >
                                <Zap className="w-3.5 h-3.5" />
                                <span>⚡ สุ่มสร้างและเติมให้ครบ {currentPackage.stock} คีย์ทันที</span>
                              </button>
                            )}
                          </div>
                        ) : (
                          'ไม่พบรายการที่ตรงกับตัวกรองหรือคำค้นหา'
                        )}
                      </td>
                    </tr>
                  ) : (
                    filteredItems.map((item, idx) => (
                      <tr key={item.id} className="hover:bg-white/[0.02] transition">
                        <td className="py-1.5 px-2.5 text-center text-slate-500 text-[10px]">
                          {idx + 1}
                        </td>

                        <td className="py-1.5 px-2.5 font-mono font-bold text-white">
                          <div className="flex items-center gap-1.5">
                            <span className="text-cyan-300 font-bold select-all truncate max-w-[180px] text-xs">
                              {item.key}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleCopy(item.key, item.id)}
                              className="p-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-cyan-300 transition cursor-pointer"
                              title="คัดลอกคีย์"
                            >
                              {copiedId === item.id ? (
                                <Check className="w-3 h-3 text-emerald-400" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        </td>

                        <td className="py-1.5 px-2.5 font-sans">
                          <div className="space-y-0.5">
                            {item.downloadUrl ? (
                              <a
                                href={item.downloadUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="text-cyan-400 hover:text-cyan-300 text-[10.5px] font-mono flex items-center gap-1 truncate max-w-xs hover:underline"
                                title={item.downloadUrl}
                              >
                                <ExternalLink className="w-3 h-3 shrink-0" />
                                <span className="truncate">{item.downloadUrl}</span>
                              </a>
                            ) : (
                              <span className="text-[10px] text-slate-600 italic">ไม่มีลิงก์เฉพาะ</span>
                            )}
                            {(item.fileName || item.note) && (
                              <div className="text-[9.5px] text-slate-400 flex items-center gap-1 flex-wrap">
                                {item.fileName && (
                                  <span className="bg-slate-900 px-1 py-0.2 rounded border border-white/5">
                                    📁 {item.fileName}
                                  </span>
                                )}
                                {item.note && (
                                  <span className="text-slate-400">
                                    📝 {item.note}
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        </td>

                        <td className="py-1.5 px-2.5 text-center font-sans">
                          {item.isUsed ? (
                            <span className="px-1.5 py-0.2 rounded-full text-[9.5px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20 inline-flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
                              <span>ขายแล้ว</span>
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.2 rounded-full text-[9.5px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 inline-flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                              <span>พร้อมส่ง</span>
                            </span>
                          )}
                        </td>

                        <td className="py-1.5 px-2.5 text-[10.5px] font-sans">
                          {item.isUsed ? (
                            <div className="space-y-0.2">
                              <div className="font-bold text-white flex items-center gap-1">
                                <span>โดย:</span>
                                <span className="text-cyan-300 font-mono">{item.usedBy || '-'}</span>
                              </div>
                              <div className="text-[9.5px] text-slate-500 font-mono">
                                #{item.orderId || '-'} • {item.usedAt || '-'}
                              </div>
                            </div>
                          ) : (
                            <span className="text-slate-500 text-[9.5px]">
                              นำเข้า: {item.createdAt}
                            </span>
                          )}
                        </td>

                        <td className="py-1.5 px-2.5 text-center">
                          <button
                            type="button"
                            onClick={() => {
                              deleteStockItem(liveProduct.id, currentPackage.id, item.id);
                            }}
                            className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition cursor-pointer active:scale-90"
                            title="ลบรายการนี้ทันที"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-3 py-1.5 bg-slate-900/90 border-t border-white/10 flex items-center justify-between gap-2">
          <p className="text-[9.5px] text-slate-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0"></span>
            <span>ระบบจ่ายคีย์และหักสต็อกอัตโนมัติ Real-time</span>
          </p>

          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10.5px] font-bold cursor-pointer transition"
          >
            ปิดหน้าต่าง
          </button>
        </div>

      </div>
    </div>
  );
}
