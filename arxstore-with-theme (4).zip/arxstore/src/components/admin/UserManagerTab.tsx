'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { useStore } from '@/context/StoreContext';
import { User, Order, Product } from '@/types';
import {
  Users,
  Search,
  Filter,
  Edit,
  Trash2,
  Package,
  DollarSign,
  Plus,
  Key,
  ShieldCheck,
  UserCheck,
  UserX,
  CreditCard,
  Save,
  X,
  ExternalLink,
  Copy,
  Check,
  Sparkles,
  RefreshCw,
  ShoppingBag,
  SlidersHorizontal,
  Eye,
  EyeOff
} from 'lucide-react';

export default function UserManagerTab() {
  const {
    user: currentUser,
    siteContent,
    users,
    orders,
    products,
    refreshUsers,
    adminUpdateUser,
    adminAddUserProduct,
    adminUpdateUserOrder,
    adminDeleteUserOrder,
    adminDeleteUser,
    adminCreateUser,
    playClick,
    playSuccess,
    showToast
  } = useStore();

  const DEFAULT_STORE_LOGO = siteContent?.branding?.logoUrl || '/brand/logo.png';

  const resolveUserAvatar = (avatarUrl?: string, role?: string): string => {
    if (role === 'admin' || !avatarUrl || avatarUrl === '/brand/logo.png' || avatarUrl === '/brand/arx-default-logo.png' || avatarUrl.includes('unsplash.com') || avatarUrl.includes('placeholder')) {
      return DEFAULT_STORE_LOGO;
    }
    return avatarUrl;
  };

  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isSavingUser, setIsSavingUser] = useState(false);
  const [isCreatingUser, setIsCreatingUser] = useState(false);

  // Auto-fetch fresh users from server on mount
  useEffect(() => {
    refreshUsers();
  }, [refreshUsers]);

  const handleRefresh = async () => {
    playClick();
    setIsRefreshing(true);
    try {
      await refreshUsers();
      playSuccess();
      showToast({ title: 'รีเฟรชข้อมูลสำเร็จ', message: 'ดึงรายชื่อผู้ใช้ล่าสุดจากเซิร์ฟเวอร์เรียบร้อย', type: 'info' });
    } finally {
      setIsRefreshing(false);
    }
  };

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | 'user' | 'admin'>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'balance_desc' | 'balance_asc' | 'username'>('recent');

  // Modals state
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [managingProductsUser, setManagingProductsUser] = useState<User | null>(null);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);

  // Edit User Form State
  const [formUsername, setFormUsername] = useState('');
  const [formAvatar, setFormAvatar] = useState('');
  const [formBalance, setFormBalance] = useState<number>(0);
  const [formRole, setFormRole] = useState<'user' | 'admin'>('user');
  const [formPassword, setFormPassword] = useState('');

  // Add Product to User Form State
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [selectedPackageId, setSelectedPackageId] = useState<string>('');
  const [customLicenseKey, setCustomLicenseKey] = useState('');

  // Inline Key Editing in Product Manager
  const [editingOrderId, setEditingOrderId] = useState<string | null>(null);
  const [editKeyText, setEditKeyText] = useState('');

  // New User Form State
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('123456');
  const [newBalance, setNewBalance] = useState(0);
  const [newAvatar, setNewAvatar] = useState(DEFAULT_STORE_LOGO);
  const [newRole, setNewRole] = useState<'user' | 'admin'>('user');

  // Copy helper
  const handleCopyKey = (key: string, id: string) => {
    navigator.clipboard.writeText(key);
    setCopiedKeyId(id);
    playSuccess();
    showToast({ title: 'คัดลอกคีย์แล้ว', message: key, type: 'info' });
    setTimeout(() => setCopiedKeyId(null), 2000);
  };

  // Open Edit User Modal
  const openEditModal = (target: User) => {
    playClick();
    setEditingUser(target);
    setFormUsername(target.username);
    setFormAvatar(resolveUserAvatar(target.avatar));
    setFormBalance(Number(target.balance || 0));
    setFormRole(target.role || 'user');
    setFormPassword('');
  };

  // Open Manage Products Modal
  const openManageProductsModal = (target: User) => {
    playClick();
    setManagingProductsUser(target);
    setEditingOrderId(null);
    if (products.length > 0) {
      setSelectedProductId(products[0].id);
      setSelectedPackageId(products[0].packages[0]?.id || '');
    }
    setCustomLicenseKey('');
  };

  // Close modals on Escape key press (กดปุ่ม Esc เพื่อปิดหน้าต่าง)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'Esc') {
        if (showAddUserModal) {
          e.preventDefault();
          playClick();
          setShowAddUserModal(false);
        } else if (managingProductsUser) {
          e.preventDefault();
          playClick();
          setManagingProductsUser(null);
        } else if (editingUser) {
          e.preventDefault();
          playClick();
          setEditingUser(null);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showAddUserModal, managingProductsUser, editingUser, playClick]);

  // Submit Edit User
  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    if (!formUsername.trim()) {
      showToast({ title: 'เกิดข้อผิดพลาด', message: 'กรุณากรอกชื่อผู้ใช้', type: 'warning' });
      return;
    }

    const payload: Partial<User> = {
      username: formUsername.trim(),
      avatar: formAvatar.trim(),
      balance: Math.max(0, Number(formBalance) || 0),
      role: formRole
    };

    if (formPassword.trim()) {
      payload.password = formPassword.trim();
    }

    setIsSavingUser(true);
    try {
      await adminUpdateUser(editingUser.id, payload);
      setEditingUser(null);
    } finally {
      setIsSavingUser(false);
    }
  };

  // Submit Grant Product to User
  const handleGrantProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!managingProductsUser || !selectedProductId) return;

    adminAddUserProduct(
      managingProductsUser.id,
      selectedProductId,
      selectedPackageId,
      customLicenseKey.trim() || undefined
    );

    setCustomLicenseKey('');
  };

  // Save Inline Edited Key
  const handleSaveEditedKey = (orderId: string) => {
    if (!editKeyText.trim()) return;
    adminUpdateUserOrder(orderId, { licenseKey: editKeyText.trim() });
    setEditingOrderId(null);
  };

  // Submit New User
  const handleCreateNewUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername.trim()) {
      showToast({ title: 'เกิดข้อผิดพลาด', message: 'กรุณากรอกชื่อผู้ใช้', type: 'warning' });
      return;
    }

    setIsCreatingUser(true);
    try {
      await adminCreateUser({
        username: newUsername.trim(),
        password: newPassword.trim() || '123456',
        balance: Math.max(0, Number(newBalance) || 0),
        avatar: newAvatar,
        role: newRole
      });

      setShowAddUserModal(false);
      setNewUsername('');
      setNewPassword('123456');
      setNewBalance(0);
    } catch {} finally {
      setIsCreatingUser(false);
    }
  };

  // Filter & Sort Users
  const filteredUsers = useMemo(() => {
    return users
      .filter(u => {
        const query = searchQuery.toLowerCase().trim();
        const matchesQuery = !query ||
          u.username.toLowerCase().includes(query) ||
          u.id.toLowerCase().includes(query) ||
          (u.email && u.email.toLowerCase().includes(query));

        const matchesRole = roleFilter === 'all' || u.role === roleFilter;

        return matchesQuery && matchesRole;
      })
      .sort((a, b) => {
        if (sortBy === 'balance_desc') return (b.balance || 0) - (a.balance || 0);
        if (sortBy === 'balance_asc') return (a.balance || 0) - (b.balance || 0);
        if (sortBy === 'username') return a.username.localeCompare(b.username);
        return 0; // recent default
      });
  }, [users, searchQuery, roleFilter, sortBy]);

  // Compute products owned per user
  const getUserProducts = (userId: string, username: string) => {
    return orders.filter(
      o => (o.userId && o.userId === userId) || (o.username && o.username.toLowerCase() === username.toLowerCase())
    );
  };

  // Total system stats
  const totalBalance = useMemo(() => users.reduce((sum, u) => sum + (u.balance || 0), 0), [users]);
  const totalAdmins = useMemo(() => users.filter(u => u.role === 'admin').length, [users]);

  return (
    <div className="space-y-3 sm:space-y-3.5">
      {/* ======================================================== */}
      {/* 📊 SUMMARY STATS CARDS */}
      {/* ======================================================== */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-2.5">
        <div className="p-2.5 sm:p-3 rounded-xl bg-slate-950/70 border border-cyan-500/25 shadow-md relative overflow-hidden min-h-[52px]">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5 flex items-center justify-between">
            <span>ผู้ใช้งานทั้งหมด</span>
            <Users className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-base sm:text-lg font-black text-white font-mono">{users.length} <span className="text-[10px] font-normal text-slate-400">บัญชี</span></div>
          <div className="text-[9.5px] text-cyan-400 mt-0.5">สมาชิกระบบ Real-time</div>
        </div>

        <div className="p-2.5 sm:p-3 rounded-xl bg-slate-950/70 border border-emerald-500/25 shadow-md relative overflow-hidden min-h-[52px]">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5 flex items-center justify-between">
            <span>เครดิตรวมทั้งหมด</span>
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-base sm:text-lg font-black text-emerald-400 font-mono">฿{totalBalance.toLocaleString()}</div>
          <div className="text-[9.5px] text-emerald-300/80 mt-0.5">ยอดเงินในกระเป๋าลูกค้า</div>
        </div>

        <div className="p-2.5 sm:p-3 rounded-xl bg-slate-950/70 border border-purple-500/25 shadow-md relative overflow-hidden min-h-[52px]">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5 flex items-center justify-between">
            <span>สินค้า/คีย์ในมือ User</span>
            <Package className="w-3.5 h-3.5 text-purple-400" />
          </div>
          <div className="text-base sm:text-lg font-black text-purple-400 font-mono">{orders.length} <span className="text-[10px] font-normal text-slate-400">รายการ</span></div>
          <div className="text-[9.5px] text-purple-300/80 mt-0.5">คีย์ที่เปิดใช้งานแล้ว</div>
        </div>

        <div className="p-2.5 sm:p-3 rounded-xl bg-slate-950/70 border border-amber-500/25 shadow-md relative overflow-hidden min-h-[52px]">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5 flex items-center justify-between">
            <span>ผู้ดูแลระบบ</span>
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-base sm:text-lg font-black text-amber-400 font-mono">{totalAdmins} <span className="text-[10px] font-normal text-slate-400">คน</span></div>
          <div className="text-[9.5px] text-amber-300/80 mt-0.5">สิทธิ์ระดับ Admin</div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 🔍 SEARCH, FILTER & ACTION BAR */}
      {/* ======================================================== */}
      <div className="cyber-card rounded-xl p-3 sm:p-3.5 bg-slate-950/90 border border-cyan-500/30 shadow-md space-y-2.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
              <Users className="w-4 h-4 text-cyan-400" />
              <span>ระบบจัดการผู้ใช้งาน (User Management)</span>
            </h3>
            <p className="text-[10.5px] text-slate-400 mt-0.5">
              สามารถแก้ไขชื่อผู้ใช้, รูปโปรไฟล์, เติม/ลดยอดเงิน, และมอบหรือเพิกถอนสินค้าของแต่ละ User ได้ทันที
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700/60 hover:border-cyan-500/50 text-slate-300 hover:text-white font-medium text-xs flex items-center justify-center gap-1.5 shadow-sm cursor-pointer transition shrink-0 disabled:opacity-50"
              title="ดึงข้อมูลผู้ใช้ล่าสุดจากเซิร์ฟเวอร์"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">รีเฟรชข้อมูล</span>
            </button>

            <button
              type="button"
              onClick={() => { playClick(); setShowAddUserModal(true); }}
              className="px-3 py-1.5 rounded-lg cyber-btn-primary font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-cyan-500/20 cursor-pointer shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>สร้างผู้ใช้งานใหม่</span>
            </button>
          </div>
        </div>

        {/* Search, Filter & Sort inputs */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-1.5 border-t border-white/5">
          <div className="sm:col-span-6 relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="ค้นหาชื่อผู้ใช้, ID, อีเมล..."
              className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
            />
          </div>

          <div className="sm:col-span-3">
            <select
              value={roleFilter}
              onChange={e => setRoleFilter(e.target.value as any)}
              className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400 transition cursor-pointer"
            >
              <option value="all">ระดับทั้งหมด (All Roles)</option>
              <option value="user">สมาชิกทั่วไป (Member)</option>
              <option value="admin">ผู้ดูแลระบบ (Admin)</option>
            </select>
          </div>

          <div className="sm:col-span-3">
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400 transition cursor-pointer"
            >
              <option value="recent">เรียงตาม: ล่าสุด</option>
              <option value="balance_desc">เรียงตาม: ยอดเงิน (มาก → น้อย)</option>
              <option value="balance_asc">เรียงตาม: ยอดเงิน (น้อย → มาก)</option>
              <option value="username">เรียงตาม: ตัวอักษร (A-Z)</option>
            </select>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 👥 USERS TABLE LIST */}
      {/* ======================================================== */}
      <div className="cyber-card rounded-xl bg-slate-950/80 border border-cyan-500/20 shadow-md overflow-hidden">
        <div className="px-3 py-2 border-b border-white/5 flex items-center justify-between bg-slate-900/40">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
            <span>พบทั้งหมด:</span>
            <span className="px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[11px]">
              {filteredUsers.length} บัญชี
            </span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono">Real-time LocalStorage Persistent</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 text-[10px] bg-slate-900/60 select-none">
                <th className="py-1.5 px-3 font-semibold">ผู้ใช้งาน (User & Avatar)</th>
                <th className="py-1.5 px-2.5 font-semibold">ระดับ (Role)</th>
                <th className="py-1.5 px-2.5 font-semibold text-right">ยอดเงินคงเหลือ</th>
                <th className="py-1.5 px-2.5 font-semibold text-center">สินค้าที่ถือครอง</th>
                <th className="py-1.5 px-2.5 font-semibold text-right">ยอดใช้จ่ายรวม</th>
                <th className="py-1.5 px-3 font-semibold text-center">จัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    <Users className="w-7 h-7 mx-auto mb-1.5 opacity-40" />
                    <p className="text-xs">ไม่พบข้อมูลผู้ใช้งานตามเงื่อนไขที่ค้นหา</p>
                  </td>
                </tr>
              ) : (
                filteredUsers.map(u => {
                  const isAdmin = u.role === 'admin';
                  const isCurrent = currentUser?.id === u.id || currentUser?.username.toLowerCase() === u.username.toLowerCase();
                  const userProds = getUserProducts(u.id, u.username);

                  return (
                    <tr key={u.id} className={`hover:bg-cyan-500/[0.03] transition-colors ${isCurrent ? 'bg-cyan-500/[0.04]' : ''}`}>
                      {/* Avatar & Username */}
                      <td className="py-1.5 px-3">
                        <div className="flex items-center gap-2.5">
                          <div className="relative group shrink-0">
                            <img
                              key={`u-av-${u.id}-${resolveUserAvatar(u.avatar, u.role)}`}
                              src={resolveUserAvatar(u.avatar, u.role)}
                              alt={u.username}
                              className="w-7 h-7 rounded-lg object-contain bg-slate-900 border border-cyan-500/40 p-0.5 shadow-sm"
                              onError={(e: any) => {
                                e.target.onerror = null;
                                e.target.src = DEFAULT_STORE_LOGO;
                              }}
                            />
                          </div>

                          <div>
                            <div className="flex items-center gap-1.5 font-bold text-white text-xs">
                              <span>{u.username}</span>
                              {isCurrent && (
                                <span className="text-[8.5px] px-1 py-0.2 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                                  คุณ
                                </span>
                              )}
                            </div>
                            <div className="text-[9.5px] text-slate-500 font-mono">
                              ID: {u.id} • {u.memberSince || u.createdAt || 'สมาชิก'}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Role */}
                      <td className="py-1.5 px-2.5">
                        {isAdmin ? (
                          <span className="px-1.5 py-0.2 rounded-md text-[9.5px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1 w-fit">
                            <ShieldCheck className="w-2.5 h-2.5 text-amber-400" />
                            <span>ผู้ดูแลระบบ</span>
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.2 rounded-md text-[9.5px] font-semibold bg-slate-800 text-slate-300 border border-white/10 flex items-center gap-1 w-fit">
                            <UserCheck className="w-2.5 h-2.5 text-cyan-400" />
                            <span>สมาชิก</span>
                          </span>
                        )}
                      </td>

                      {/* Balance */}
                      <td className="py-1.5 px-2.5 text-right">
                        <div className="font-mono font-black text-emerald-400 text-xs">
                          ฿{Number(u.balance || 0).toLocaleString()}
                        </div>
                        <div className="text-[9px] text-slate-500">เครดิตกระเป๋า</div>
                      </td>

                      {/* Products Owned */}
                      <td className="py-1.5 px-2.5 text-center">
                        <button
                          type="button"
                          onClick={() => openManageProductsModal(u)}
                          className="px-2 py-0.5 rounded-md bg-purple-950/60 hover:bg-purple-900/60 border border-purple-500/40 text-purple-300 text-[10.5px] font-mono font-bold transition flex items-center gap-1 mx-auto cursor-pointer"
                          title="คลิกเพื่อจัดการสินค้าของผู้ใช้นี้"
                        >
                          <Package className="w-3 h-3 text-purple-400" />
                          <span>{userProds.length} ชิ้น</span>
                        </button>
                      </td>

                      {/* Total Spent */}
                      <td className="py-1.5 px-2.5 text-right font-mono text-slate-400 text-xs">
                        ฿{Number(u.totalSpent || 0).toLocaleString()}
                      </td>

                      {/* Actions */}
                      <td className="py-1.5 px-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {/* Edit User Button */}
                          <button
                            type="button"
                            onClick={() => openEditModal(u)}
                            className="p-1 rounded-md bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 transition cursor-pointer"
                            title="แก้ไขชื่อ, รูป, ยอดเงิน"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>

                          {/* Manage Products Button */}
                          <button
                            type="button"
                            onClick={() => openManageProductsModal(u)}
                            className="p-1 rounded-md bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 border border-purple-500/30 transition cursor-pointer"
                            title="จัดการสินค้า / มอบคีย์"
                          >
                            <Package className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete User Button (disabled for current user) */}
                          <button
                            type="button"
                            disabled={isCurrent}
                            onClick={() => {
                              if (confirm(`ยืนยันการลบผู้ใช้ "${u.username}" ออกจากระบบหรือไม่?`)) {
                                adminDeleteUser(u.id);
                              }
                            }}
                            className="p-1 rounded-md bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                            title={isCurrent ? 'ไม่สามารถลบบัญชีตัวเองได้' : 'ลบผู้ใช้'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ======================================================== */}
      {/* ✏️ MODAL 1: EDIT USER (เปลี่ยนชื่อ, รูป, ยอดเงิน, บทบาท) */}
      {/* ======================================================== */}
      {editingUser && (
        <div
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              playClick();
              setEditingUser(null);
            }
          }}
          className="fixed inset-0 z-[99999] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md cursor-pointer"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-md cyber-card rounded-2xl p-4 sm:p-4.5 bg-slate-950/95 border border-cyan-500/40 shadow-2xl space-y-3 max-h-[90vh] overflow-y-auto arx-modal-card-in cursor-default"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
                  <Edit className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                    <span>แก้ไขข้อมูลผู้ใช้งาน</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 font-mono">
                      {editingUser.username}
                    </span>
                  </h3>
                  <p className="text-[10px] text-slate-400">เปลี่ยนชื่อ, รูปโปรไฟล์, เติมยอดเงิน หรือเปลี่ยนสิทธิ์</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-[9.5px] font-mono font-bold text-slate-400 bg-white/5 border border-white/10 px-1.5 py-0.5 rounded">
                  ESC
                </span>
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setEditingUser(null);
                  }}
                  title="ปิดหน้าต่าง (กด Esc)"
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <form onSubmit={handleSaveUser} className="space-y-2.5">
              {/* 1. เปลี่ยนชื่อผู้ใช้ (Username) */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  👤 ชื่อผู้ใช้งาน (Username) *
                </label>
                <input
                  type="text"
                  required
                  value={formUsername}
                  onChange={e => setFormUsername(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                  placeholder="เช่น PlayerOne"
                />
              </div>

              {/* 2. เปลี่ยนรูปโปรไฟล์ (Avatar) */}
              <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-bold text-cyan-300 flex items-center gap-1">
                    <span>🖼️ รูปโปรไฟล์ (Profile Avatar)</span>
                  </label>
                  <span className="text-[9.5px] text-slate-400">รูปภาพประจำตัวผู้ใช้</span>
                </div>

                <div className="flex items-center gap-2.5">
                  <img
                    src={resolveUserAvatar(formAvatar)}
                    alt="Preview"
                    className="w-10 h-10 rounded-xl object-contain bg-slate-950 border border-cyan-400/60 p-0.5 shadow-sm shrink-0"
                    onError={(e: any) => {
                      e.target.onerror = null;
                      e.target.src = DEFAULT_STORE_LOGO;
                    }}
                  />
                  <div className="flex-1 space-y-1">
                    <input
                      type="text"
                      value={formAvatar}
                      onChange={e => setFormAvatar(e.target.value)}
                      placeholder="ใส่ URL รูปภาพโปรไฟล์..."
                      className="w-full px-2.5 py-1.5 rounded-lg bg-black/60 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                    />
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setFormAvatar(DEFAULT_STORE_LOGO)}
                        className={`text-[10px] px-2 py-0.5 rounded-md border font-bold flex items-center gap-1 transition cursor-pointer ${
                          !formAvatar || formAvatar === DEFAULT_STORE_LOGO || formAvatar.includes('unsplash.com')
                            ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                            : 'bg-slate-800 text-slate-400 hover:text-white border-white/5'
                        }`}
                      >
                        <img src={DEFAULT_STORE_LOGO} alt="ARX" className="w-3 h-3 object-contain" />
                        <span>ใช้รูปโลโก้ร้าน (ค่าเริ่มต้น)</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* 3. เปลี่ยนยอดเงินคงเหลือ (Balance) */}
              <div className="p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                    <DollarSign className="w-3.5 h-3.5" />
                    <span>💰 ยอดเงินคงเหลือ (Wallet ฿) *</span>
                  </label>
                  <span className="text-[11px] font-mono font-bold text-emerald-300">
                    ปัจจุบัน: ฿{Number(formBalance).toLocaleString()}
                  </span>
                </div>

                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    step="1"
                    required
                    value={formBalance}
                    onChange={e => setFormBalance(Number(e.target.value))}
                    className="w-full pl-6 pr-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-sm font-bold font-mono text-emerald-300 focus:outline-none focus:border-emerald-400 transition"
                  />
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono font-bold text-xs">฿</span>
                </div>

                {/* Quick Add Balance Buttons */}
                <div className="flex flex-wrap items-center gap-1 pt-0.5">
                  <span className="text-[9.5px] text-slate-400 mr-0.5">ปุ่มลัด:</span>
                  {[50, 100, 300, 500, 1000].map(amt => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setFormBalance(prev => Number(prev || 0) + amt)}
                      className="px-1.5 py-0.5 rounded-md bg-emerald-500/10 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-[10px] font-mono font-bold transition cursor-pointer"
                    >
                      +{amt}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setFormBalance(0)}
                    className="px-1.5 py-0.5 rounded-md bg-rose-500/10 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-[10px] font-mono font-bold transition cursor-pointer ml-auto"
                  >
                    ตั้งเป็น 0
                  </button>
                </div>
              </div>

              {/* 4. สิทธิ์ระดับผู้ใช้ (Role) */}
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => setFormRole('user')}
                  className={`p-2 rounded-lg border text-left transition cursor-pointer ${
                    formRole === 'user'
                      ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-sm'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="font-bold text-xs">สมาชิกทั่วไป (Member)</div>
                  <div className="text-[9.5px] text-slate-400">สั่งซื้อสินค้าและเติมเงิน</div>
                </button>

                <button
                  type="button"
                  onClick={() => setFormRole('admin')}
                  className={`p-2 rounded-lg border text-left transition cursor-pointer ${
                    formRole === 'admin'
                      ? 'bg-amber-500/20 border-amber-400 text-white shadow-sm'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="font-bold text-xs text-amber-300">ผู้ดูแลระบบ (Admin)</div>
                  <div className="text-[9.5px] text-slate-400">เข้าถึง Admin Panel ได้</div>
                </button>
              </div>

              {/* 5. รีเซ็ตรหัสผ่าน (Password) */}
              <div>
                <label className="block text-[10.5px] font-bold text-slate-400 mb-0.5">
                  🔑 รีเซ็ตรหัสผ่านใหม่ (ไม่บังคับ - ปล่อยว่างถ้าไม่ต้องการเปลี่ยน)
                </label>
                <input
                  type="text"
                  value={formPassword}
                  onChange={e => setFormPassword(e.target.value)}
                  placeholder="ตั้งรหัสผ่านใหม่ให้ผู้ใช้..."
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-cyan-400 transition"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-bold transition cursor-pointer"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  disabled={isSavingUser}
                  className="px-4 py-1.5 rounded-lg cyber-btn-primary text-xs font-bold flex items-center gap-1.5 shadow-md shadow-cyan-500/25 cursor-pointer disabled:opacity-50"
                >
                  <Save className={`w-3.5 h-3.5 ${isSavingUser ? 'animate-spin' : ''}`} />
                  <span>{isSavingUser ? 'กำลังบันทึก...' : 'บันทึก'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 📦 MODAL 2: MANAGE USER'S PRODUCTS (เปลี่ยนสินค้า & มอบคีย์) */}
      {/* ======================================================== */}
      {managingProductsUser && (
        <div
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              playClick();
              setManagingProductsUser(null);
            }
          }}
          className="fixed inset-0 z-[99999] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md cursor-pointer"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-xl cyber-card rounded-2xl p-4 sm:p-4.5 bg-slate-950/95 border border-purple-500/40 shadow-2xl space-y-3 max-h-[90vh] overflow-y-auto arx-modal-card-in cursor-default"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-2 border-b border-purple-500/20">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 shrink-0">
                  <Package className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                    <span>จัดการสินค้า & คีย์ของผู้ใช้:</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-purple-500/20 text-purple-300 font-mono font-bold">
                      {managingProductsUser.username}
                    </span>
                  </h3>
                  <p className="text-[10px] text-slate-400">มอบสินค้าใหม่, แก้ไข License Key หรือเพิกถอนสินค้า</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-[9.5px] font-mono font-bold text-slate-400 bg-white/5 border border-white/10 px-1.5 py-0.5 rounded">
                  ESC
                </span>
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setManagingProductsUser(null);
                  }}
                  title="ปิดหน้าต่าง (กด Esc)"
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* SECTION 1: มอบสินค้าใหม่ให้แก่ User (Grant New Product) */}
            <div className="p-2.5 sm:p-3 rounded-xl bg-gradient-to-r from-purple-950/30 to-slate-900 border border-purple-500/30 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-purple-300 flex items-center gap-1">
                  <Plus className="w-3.5 h-3.5 text-purple-400" />
                  <span>มอบสินค้าใหม่ให้ผู้ใช้นี้ (Grant Product)</span>
                </span>
                <span className="text-[9.5px] text-slate-400">ส่งคีย์โดยตรงไม่ต้องจ่ายเงิน</span>
              </div>

              <form onSubmit={handleGrantProduct} className="space-y-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {/* Select Product */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-0.5">เลือกสินค้า</label>
                    <select
                      value={selectedProductId}
                      onChange={e => {
                        setSelectedProductId(e.target.value);
                        const prod = products.find(p => p.id === e.target.value);
                        if (prod && prod.packages.length > 0) {
                          setSelectedPackageId(prod.packages[0].id);
                        }
                      }}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-purple-400 cursor-pointer"
                    >
                      {products.map(p => (
                        <option key={p.id} value={p.id}>{p.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Select Package */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-0.5">แพ็กเกจ / ระยะเวลา</label>
                    <select
                      value={selectedPackageId}
                      onChange={e => setSelectedPackageId(e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-purple-400 cursor-pointer"
                    >
                      {products.find(p => p.id === selectedProductId)?.packages.map(pkg => (
                        <option key={pkg.id} value={pkg.id}>
                          {pkg.name} ({pkg.duration}) - ฿{pkg.price}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Custom License Key */}
                <div>
                  <div className="flex items-center justify-between mb-0.5">
                    <label className="text-[10px] font-bold text-slate-400">
                      License Key (รหัสคีย์ที่ต้องการมอบ)
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        const randomKey = `ARX-PRO-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
                        setCustomLicenseKey(randomKey);
                      }}
                      className="text-[9.5px] text-purple-400 hover:text-purple-300 flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-2.5 h-2.5" />
                      <span>สุ่มคีย์</span>
                    </button>
                  </div>
                  <input
                    type="text"
                    value={customLicenseKey}
                    onChange={e => setCustomLicenseKey(e.target.value)}
                    placeholder="ปล่อยว่างเพื่อให้ระบบสุ่มให้อัตโนมัติ"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-black/60 border border-slate-700 text-xs font-mono text-purple-300 placeholder-slate-500 focus:outline-none focus:border-purple-400 transition"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-purple-500/25 transition cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>มอบสินค้าให้ผู้ใช้ทันที</span>
                </button>
              </form>
            </div>

            {/* SECTION 2: รายการสินค้าที่ผู้ใช้นี้ถือครองอยู่ (Existing Products) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
                  <ShoppingBag className="w-3.5 h-3.5 text-cyan-400" />
                  <span>สินค้าที่ {managingProductsUser.username} ครอบครอง:</span>
                </h4>
                <span className="text-[10px] font-mono text-slate-400">
                  {getUserProducts(managingProductsUser.id, managingProductsUser.username).length} รายการ
                </span>
              </div>

              {getUserProducts(managingProductsUser.id, managingProductsUser.username).length === 0 ? (
                <div className="p-6 text-center bg-slate-900/40 rounded-xl border border-white/5 text-slate-500">
                  <Package className="w-6 h-6 mx-auto mb-1.5 opacity-30" />
                  <p className="text-xs">ผู้ใช้งานนี้ยังไม่มีสินค้าหรือ License Key ใด ๆ ในระบบ</p>
                  <p className="text-[10px] text-slate-600 mt-0.5">สามารถเลือกเมนู "มอบสินค้าใหม่" ด้านบนเพื่อเพิ่มได้ทันที</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {getUserProducts(managingProductsUser.id, managingProductsUser.username).map(ord => (
                    <div
                      key={ord.id}
                      className="p-2.5 rounded-xl bg-slate-900/70 border border-white/10 hover:border-purple-500/30 transition space-y-1.5"
                    >
                      <div className="flex items-start justify-between gap-2.5">
                        <div>
                          <div className="font-bold text-white text-xs flex items-center gap-1.5">
                            <span>{ord.productName}</span>
                            <span className="px-1.5 py-0.2 rounded-md bg-purple-500/20 text-purple-300 text-[9.5px] font-normal">
                              {ord.packageName}
                            </span>
                          </div>
                          <div className="text-[9.5px] text-slate-500 font-mono mt-0.2">
                            Order #{ord.orderNumber} • {ord.createdAt}
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          {/* Toggle Edit Key Button */}
                          <button
                            type="button"
                            onClick={() => {
                              if (editingOrderId === ord.id) {
                                setEditingOrderId(null);
                              } else {
                                setEditingOrderId(ord.id);
                                setEditKeyText(ord.licenseKey);
                              }
                            }}
                            className="p-1 rounded-md bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-white/5 transition cursor-pointer"
                            title="แก้ไข License Key"
                          >
                            <Edit className="w-3 h-3" />
                          </button>

                          {/* Delete/Revoke Order Button */}
                          <button
                            type="button"
                            onClick={() => {
                              playClick();
                              adminDeleteUserOrder(ord.id);
                            }}
                            className="p-1 rounded-md bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition cursor-pointer"
                            title="เพิกถอนสินค้านี้ทันที"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* License Key Display or Edit */}
                      {editingOrderId === ord.id ? (
                        <div className="flex items-center gap-1.5 pt-0.5">
                          <input
                            type="text"
                            value={editKeyText}
                            onChange={e => setEditKeyText(e.target.value)}
                            className="flex-1 px-2.5 py-1 rounded-lg bg-black border border-cyan-400 text-xs font-mono text-cyan-300 focus:outline-none"
                            placeholder="กรอกคีย์ใหม่..."
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveEditedKey(ord.id)}
                            className="px-2.5 py-1 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition cursor-pointer"
                          >
                            บันทึก
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingOrderId(null)}
                            className="px-2 py-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white text-xs transition cursor-pointer"
                          >
                            ยกเลิก
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between p-1.5 rounded-lg bg-black/60 border border-slate-800 font-mono text-xs">
                          <span className="text-purple-300 font-bold select-all tracking-wider text-[11.5px]">
                            {ord.licenseKey}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleCopyKey(ord.licenseKey, ord.id)}
                            className="p-1 rounded-md text-slate-400 hover:text-white transition cursor-pointer"
                            title="คัดลอกคีย์"
                          >
                            {copiedKeyId === ord.id ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-1.5 border-t border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setManagingProductsUser(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition cursor-pointer"
              >
                ปิดหน้าต่าง
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* ➕ MODAL 3: CREATE NEW USER */}
      {/* ======================================================== */}
      {showAddUserModal && (
        <div
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              playClick();
              setShowAddUserModal(false);
            }
          }}
          className="fixed inset-0 z-[99999] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md cursor-pointer"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-sm sm:max-w-md cyber-card rounded-2xl p-4 sm:p-4.5 bg-slate-950/95 border border-cyan-500/40 shadow-2xl space-y-2.5 max-h-[90vh] overflow-y-auto arx-modal-card-in cursor-default"
          >
            <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-cyan-400" />
                <span>สร้างบัญชีผู้ใช้งานใหม่</span>
              </h3>
              <div className="flex items-center gap-1.5">
                <span className="text-[9.5px] font-mono font-bold text-slate-400 bg-white/5 border border-white/10 px-1.5 py-0.5 rounded">
                  ESC
                </span>
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setShowAddUserModal(false);
                  }}
                  title="ปิดหน้าต่าง (กด Esc)"
                  className="p-1 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <form onSubmit={handleCreateNewUser} className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-0.5">ชื่อผู้ใช้ (Username) *</label>
                <input
                  type="text"
                  required
                  value={newUsername}
                  onChange={e => setNewUsername(e.target.value)}
                  placeholder="เช่น Player_New"
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-0.5">รหัสผ่านเริ่มต้น *</label>
                <input
                  type="text"
                  required
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="รหัสผ่านเข้าสู่ระบบ"
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-emerald-400 mb-0.5">ยอดเงินเริ่มต้น (฿)</label>
                <input
                  type="number"
                  min="0"
                  value={newBalance}
                  onChange={e => setNewBalance(Number(e.target.value))}
                  placeholder="0"
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs font-mono font-bold text-emerald-300 focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <label className="block text-[10.5px] font-bold text-slate-300">รูปโปรไฟล์ (Default: โลโก้ร้าน)</label>
                <div className="flex items-center gap-2.5">
                  <img
                    src={resolveUserAvatar(newAvatar)}
                    alt="Preview"
                    className="w-9 h-9 rounded-lg object-contain bg-slate-950 border border-cyan-500/40 p-0.5 shrink-0"
                    onError={(e: any) => {
                      e.target.onerror = null;
                      e.target.src = DEFAULT_STORE_LOGO;
                    }}
                  />
                  <div className="flex-1 space-y-1">
                    <input
                      type="text"
                      value={newAvatar}
                      onChange={e => setNewAvatar(e.target.value)}
                      placeholder="ใส่ URL รูปภาพ..."
                      className="w-full px-2.5 py-1 rounded-lg bg-black/60 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                    />
                    <button
                      type="button"
                      onClick={() => setNewAvatar(DEFAULT_STORE_LOGO)}
                      className="text-[9.5px] text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <img src={DEFAULT_STORE_LOGO} alt="Logo" className="w-3 h-3 object-contain" />
                      <span>รีเซ็ตเป็นรูปโลโก้ร้าน</span>
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-1.5 pt-0.5">
                <button
                  type="button"
                  onClick={() => setNewRole('user')}
                  className={`p-2 rounded-lg border text-center text-xs font-bold transition cursor-pointer ${
                    newRole === 'user' ? 'bg-cyan-500/20 border-cyan-400 text-white' : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  สมาชิก (Member)
                </button>
                <button
                  type="button"
                  onClick={() => setNewRole('admin')}
                  className={`p-2 rounded-lg border text-center text-xs font-bold transition cursor-pointer ${
                    newRole === 'admin' ? 'bg-amber-500/20 border-amber-400 text-amber-300' : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  แอดมิน (Admin)
                </button>
              </div>

              <div className="pt-1.5 flex justify-end gap-1.5 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setShowAddUserModal(false);
                  }}
                  title="ยกเลิกและปิดหน้าต่าง (กด Esc)"
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700 transition cursor-pointer flex items-center gap-1"
                >
                  <span>ยกเลิก</span>
                  <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">(Esc)</span>
                </button>
                <button
                  type="submit"
                  disabled={isCreatingUser}
                  className="px-4 py-1.5 rounded-lg cyber-btn-primary text-xs font-bold shadow-md shadow-cyan-500/20 disabled:opacity-50"
                >
                  {isCreatingUser ? 'กำลังสร้าง...' : 'ยืนยันสร้างบัญชี'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
