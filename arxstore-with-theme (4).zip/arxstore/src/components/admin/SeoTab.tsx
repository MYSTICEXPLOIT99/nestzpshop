'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '@/context/StoreContext';
import {
  Share2,
  Image as ImageIcon,
  Upload,
  Link as LinkIcon,
  Check,
  RefreshCw,
  Palette,
  Eye,
  Info,
  Sparkles,
  ExternalLink
} from 'lucide-react';

interface SeoFormData {
  title: string;
  description: string;
  ogImage: string;
  themeColor: string;
  siteName: string;
  keywords: string;
}

const PRESET_IMAGES = [
  { label: 'แบนเนอร์ Banner 3 (ต้นฉบับคมชัด ไม่เบลอขอบ)', path: '/brand/banner3.png' },
  { label: 'แบนเนอร์ Cyber 3D (1200x630 สวยคม)', path: '/brand/arx-banner-cyber.jpg' },
  { label: 'โลโก้ร้านทางการ', path: '/brand/logo.png' },
  { label: 'โลโก้ร้านคลาสสิก', path: '/brand/arx-default-logo.png' },
  { label: 'ไอคอนแอป (512x512)', path: '/icon.png' },
  { label: 'แบนเนอร์ FiveM', path: '/catalog/imported/banner_fivem.webp' },
  { label: 'แบนเนอร์ BoostFPS', path: '/catalog/imported/banner_cheat.webp' }
];

const PRESET_COLORS = [
  { label: 'Cyan ARX', color: '#00e5ff' },
  { label: 'Electric Blue', color: '#0284c7' },
  { label: 'Neon Emerald', color: '#10b981' },
  { label: 'Cyber Red', color: '#ef4444' },
  { label: 'Cyberpunk Purple', color: '#a855f7' },
  { label: 'Golden Amber', color: '#f59e0b' },
  { label: 'Discord Blurple', color: '#5865f2' }
];

export default function SeoTab() {
  const { playClick, playSuccess, playError } = useStore();

  const [form, setForm] = useState<SeoFormData>({
    title: 'Arx Store',
    description: 'ARX STORE I บริการจำหน่าย Setting , BoostFPS , Windows ต่างๆ ซอฟต์แวร์เพิ่มประสิทธิภาพ สั่งซื้อออนไลน์ พร้อมบริการเติมเงินและรีเซ็ต HWID อัตโนมัติ 24 ชม.',
    ogImage: '/brand/logo.png',
    themeColor: '#00e5ff',
    siteName: 'Arx Store',
    keywords: 'ARX STORE, Setting, BoostFPS, Windows, บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ, FiveM'
  });

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [statusMsg, setStatusMsg] = useState<{ success: boolean; text: string } | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Fetch current SEO settings on mount
  useEffect(() => {
    let isMounted = true;
    fetch('/api/admin/seo')
      .then(res => res.json())
      .then(data => {
        if (isMounted && data.success && data.data) {
          setForm(prev => ({
            ...prev,
            ...data.data
          }));
        }
      })
      .catch(() => {
        // use defaults
      })
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });

    return () => { isMounted = false; };
  }, []);

  // Handle file upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    playClick();
    setIsUploading(true);
    setStatusMsg(null);

    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
      const formData = new FormData();
      formData.append('file', file);

      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: {
          ...(token ? { 'x-session-token': token } : {})
        },
        body: formData
      });

      const data = await res.json();
      if (res.ok && data.success && data.url) {
        setForm(prev => ({ ...prev, ogImage: data.url }));
        playSuccess();
        setStatusMsg({ success: true, text: 'อัปโหลดรูปภาพสำเร็จ! พร้อมแสดงผลใน Discord Preview' });
      } else {
        playError();
        setStatusMsg({ success: false, text: data.message || 'การอัปโหลดรูปภาพล้มเหลว' });
      }
    } catch {
      playError();
      setStatusMsg({ success: false, text: 'เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์' });
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Handle saving SEO form
  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    playClick();
    setIsSaving(true);
    setStatusMsg(null);

    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
      const res = await fetch('/api/admin/seo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-session-token': token } : {})
        },
        body: JSON.stringify(form)
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playSuccess();
        setStatusMsg({
          success: true,
          text: 'บันทึกการตั้งค่ารูปโปรโมทและ Discord Embed เรียบร้อยแล้ว! (มีผลต่อบอท Discord และแชร์โซเชียลทันที)'
        });
      } else {
        playError();
        setStatusMsg({ success: false, text: data.message || 'บันทึกไม่สำเร็จ' });
      }
    } catch {
      playError();
      setStatusMsg({ success: false, text: 'เกิดข้อผิดพลาดในการเชื่อมต่อ' });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-[var(--arx-dk-061524)] via-[#091b2e] to-[var(--arx-dk-040e1a)] border border-cyan-500/25 shadow-xl shadow-cyan-950/20">
        <div className="flex items-start gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0 shadow-lg shadow-cyan-500/10 mt-0.5">
            <Share2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-base sm:text-lg font-black text-white tracking-wide">
                จัดการรูปแชร์ลิงก์ & Discord Embed (Open Graph / SEO)
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[10px] font-mono font-bold">
                DISCORD PREVIEW
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
              ปรับเปลี่ยนรูปภาพ หัวข้อ และคำอธิบายที่แสดงเมื่อแชร์ลิงก์เว็บ <code className="text-cyan-400 font-mono text-[11px]">https://arxstore.xyz/</code> ลงใน <strong>Discord, Facebook, LINE, Twitter</strong> ได้แบบเรียลไทม์
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => handleSave()}
          disabled={isSaving}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-black text-xs shadow-lg shadow-cyan-500/30 transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer disabled:opacity-50"
        >
          {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
          <span>{isSaving ? 'กำลังบันทึก...' : 'บันทึกการตั้งค่า SEO'}</span>
        </button>
      </div>

      {/* Notification Banner */}
      {statusMsg && (
        <div
          className={`p-3.5 rounded-xl border text-xs font-semibold flex items-center gap-2.5 transition-all ${
            statusMsg.success
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
          }`}
        >
          <Info className="w-4 h-4 shrink-0" />
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* Main Grid: Form on Left, Discord Embed Mockup on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column (7 cols): Settings Form */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* Card 1: Image Selector */}
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-white/10 shadow-lg space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/5">
              <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider">
                <ImageIcon className="w-4 h-4 text-cyan-400" />
                <span>1. รูปภาพตัวอย่างลิงก์ (Open Graph / Discord Embed Image)</span>
              </div>
              <span className="text-[10px] text-cyan-400 font-mono">1:1 หรือ 16:9 แนะนำ 800x800px</span>
            </div>

            {/* Input URL */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-slate-300 block">
                URL รูปภาพ (หรือเลือกอัปโหลดด้านล่าง)
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={form.ogImage}
                  onChange={(e) => setForm({ ...form, ogImage: e.target.value })}
                  placeholder="/brand/logo.png หรือ https://..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/15 focus:border-cyan-400 text-xs text-white placeholder-slate-500 focus:outline-none transition pr-10 font-mono"
                />
                <LinkIcon className="w-3.5 h-3.5 text-slate-500 absolute right-3.5 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            {/* Upload Button */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/png,image/jpeg,image/webp,image/gif"
                onChange={handleFileUpload}
                className="hidden"
                id="seo-file-upload"
              />
              <label
                htmlFor="seo-file-upload"
                className={`px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-cyan-500/30 text-white text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-sm ${
                  isUploading ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                {isUploading ? <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" /> : <Upload className="w-3.5 h-3.5 text-cyan-400" />}
                <span>{isUploading ? 'กำลังอัปโหลด...' : 'อัปโหลดรูปภาพใหม่จากเครื่อง'}</span>
              </label>

              <span className="text-[11px] text-slate-500">รองรับ PNG, JPG, WebP, GIF ขนาดไม่เกิน 10MB</span>
            </div>

            {/* Quick Pick Presets */}
            <div className="space-y-2 pt-2 border-t border-white/5">
              <span className="text-[10.5px] font-bold text-slate-400 block">
                เลือกรูปภาพด่วนจากระบบ (Quick Presets):
              </span>
              <div className="flex flex-wrap gap-2">
                {PRESET_IMAGES.map((preset) => {
                  const isSelected = form.ogImage === preset.path;
                  return (
                    <button
                      key={preset.path}
                      type="button"
                      onClick={() => {
                        playClick();
                        setForm({ ...form, ogImage: preset.path });
                      }}
                      className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition flex items-center gap-1.5 cursor-pointer ${
                        isSelected
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm'
                          : 'bg-slate-950 text-slate-400 hover:text-white border border-white/5 hover:border-white/15'
                      }`}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={preset.path} alt="" className="w-3.5 h-3.5 object-contain rounded shrink-0" />
                      <span>{preset.label}</span>
                      {isSelected && <Check className="w-3 h-3 text-cyan-400" />}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Card 2: Texts & Theme Color */}
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-white/10 shadow-lg space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-white/5 text-xs font-bold text-white uppercase tracking-wider">
              <Palette className="w-4 h-4 text-cyan-400" />
              <span>2. ข้อความและสีแถบแสดงผลใน Discord</span>
            </div>

            {/* Title */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-bold">
                <label className="text-slate-300">หัวข้อลิงก์ (Embed Title)</label>
                <span className="text-slate-500 font-mono text-[10px]">{form.title.length} / 100 ตัวอักษร</span>
              </div>
              <input
                type="text"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="ARX STORE I บริการจำหน่าย Setting..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/15 focus:border-cyan-400 text-xs text-white placeholder-slate-500 focus:outline-none transition"
              />
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-bold">
                <label className="text-slate-300">คำอธิบายใต้หัวข้อ (Embed Description)</label>
                <span className="text-slate-500 font-mono text-[10px]">{form.description.length} / 300 ตัวอักษร</span>
              </div>
              <textarea
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="ข้อความโปรโมทร้าน บริการ และรายละเอียด..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/15 focus:border-cyan-400 text-xs text-white placeholder-slate-500 focus:outline-none transition resize-none leading-relaxed"
              />
            </div>

            {/* Theme Color Picker */}
            <div className="space-y-2 pt-1">
              <label className="text-[11px] font-bold text-slate-300 block">
                สีแถบด้านซ้ายของ Discord Embed (Theme Color)
              </label>
              
              <div className="flex items-center gap-3">
                <div className="relative flex items-center">
                  <input
                    type="color"
                    value={form.themeColor}
                    onChange={(e) => setForm({ ...form, themeColor: e.target.value })}
                    className="w-9 h-9 rounded-xl bg-transparent border border-white/20 cursor-pointer p-0.5"
                  />
                </div>
                <input
                  type="text"
                  value={form.themeColor}
                  onChange={(e) => setForm({ ...form, themeColor: e.target.value })}
                  placeholder="#00e5ff"
                  className="w-28 px-3 py-1.5 rounded-xl bg-slate-950 border border-white/15 text-xs text-white font-mono uppercase focus:border-cyan-400 focus:outline-none"
                />
              </div>

              {/* Color Presets */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {PRESET_COLORS.map((c) => (
                  <button
                    key={c.color}
                    type="button"
                    onClick={() => {
                      playClick();
                      setForm({ ...form, themeColor: c.color });
                    }}
                    className={`px-2 py-1 rounded-md text-[10.5px] font-medium flex items-center gap-1.5 transition cursor-pointer ${
                      form.themeColor.toLowerCase() === c.color.toLowerCase()
                        ? 'bg-white/15 text-white border border-white/30'
                        : 'bg-slate-950 text-slate-400 hover:text-white border border-white/5'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full shrink-0 shadow-sm" style={{ backgroundColor: c.color }} />
                    <span>{c.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Live Discord Embed Preview */}
        <div className="lg:col-span-5 space-y-3 sticky top-4">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5 uppercase tracking-wider">
              <Eye className="w-3.5 h-3.5 text-cyan-400" />
              <span>ภาพตัวอย่างบน Discord (Live Preview)</span>
            </span>
            <span className="text-[10px] text-emerald-400 font-mono font-bold">● Real-time</span>
          </div>

          {/* Discord Message Shell (Authentic Discord Dark Theme #313338) */}
          <div className="rounded-2xl p-4 sm:p-5 bg-[#313338] border border-[color:var(--arx-dk-232428)] shadow-2xl text-left select-none font-sans">
            
            {/* Discord User Message Header */}
            <div className="flex items-start gap-3 mb-2">
              <div className="w-10 h-10 rounded-full bg-[color:var(--arx-dk-1e1f22)] overflow-hidden shrink-0 border border-black/20">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="/brand/logo.png"
                  alt="User"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/brand/arx-default-logo.png';
                  }}
                />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-white text-sm hover:underline cursor-pointer">
                    ! Jetz
                  </span>
                  <span className="text-[10px] font-bold px-1 py-0.5 rounded bg-[#5865f2] text-white uppercase font-mono">
                    ARX
                  </span>
                  <span className="text-[10.5px] text-[#949ba4] font-medium ml-1">
                    วันนี้ เวลา 09:59
                  </span>
                </div>
                {/* Sent Link text */}
                <div className="text-xs text-[#00a8fc] hover:underline cursor-pointer break-all mt-0.5 font-medium">
                  https://arxstore.xyz/
                </div>
              </div>
            </div>

            {/* Discord Embed Container (Background #2b2d31, with Left Color Bar) */}
            <div className="ml-12 mt-1 rounded-md bg-[color:var(--arx-dk-2b2d31)] p-3 sm:p-4 max-w-[420px] relative overflow-hidden border border-[color:var(--arx-dk-1e1f22)]">
              {/* Left Accent Border (Colored by themeColor) */}
              <div
                className="absolute left-0 top-0 bottom-0 w-[4px]"
                style={{ backgroundColor: form.themeColor || '#00e5ff' }}
              />

              {/* Provider / Site Name */}
              <div className="text-[10.5px] text-[#dbdee1] font-medium mb-1 uppercase tracking-wide">
                {form.siteName || 'ARX STORE'}
              </div>

              {/* Embed Title */}
              <h4 className="text-[13.5px] font-bold text-[#00a8fc] hover:underline cursor-pointer leading-snug mb-1.5 line-clamp-2">
                {form.title || 'ARX STORE I บริการจำหน่าย Setting , Boost...'}
              </h4>

              {/* Embed Description */}
              <p className="text-[11.5px] text-[#dbdee1] leading-relaxed mb-3 line-clamp-3">
                {form.description || 'ARX STORE I บริการจำหน่าย Setting , BoostFPS , Windows ต่างๆ ซอฟต์แวร์เพิ่มประสิทธิภาพ สั่งซื้อออนไลน์ พร้อมบริการเติมเงินและรีเซ็ต HWID อัตโนมัติ 24 ชม.'}
              </p>

              {/* Embed Image Box */}
              <div className="relative rounded-lg overflow-hidden bg-[color:var(--arx-dk-1e1f22)] border border-[color:var(--arx-dk-1e1f22)] max-h-[300px] flex items-center justify-center group">
                {form.ogImage ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={form.ogImage}
                    alt="Embed Preview"
                    className="w-full h-auto max-h-[280px] object-contain rounded-lg transition-transform duration-300 group-hover:scale-105"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/brand/logo.png';
                    }}
                  />
                ) : (
                  <div className="p-8 text-center text-slate-500 text-xs">
                    ไม่มีรูปภาพตัวอย่าง
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Helpful Tips Card */}
          <div className="p-4 rounded-xl bg-slate-900/60 border border-white/5 text-[11px] text-slate-400 space-y-2 leading-relaxed">
            <div className="font-bold text-white flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>เทคนิคสำหรับ Discord Link Preview:</span>
            </div>
            <ul className="list-disc pl-4 space-y-1 text-slate-400">
              <li>เมื่อเปลี่ยนรูปแล้ว บอทของ Discord จะจำ Cache ไว้ชั่วคราว หากแชร์ลิงก์เดิมใน Discord แล้วยังไม่เปลี่ยนรูป ให้ลองเติมเครื่องหมาย <code className="text-cyan-400 font-mono">?v=2</code> ท้ายลิงก์ใน Discord (เช่น <code className="text-cyan-400 font-mono">https://arxstore.xyz/?v=2</code>)</li>
              <li>แนะนำให้ใช้รูปขนาด <strong>800 x 800 พิกเซล (1:1 Square)</strong> หรือ <strong>1200 x 630 พิกเซล (16:9 Banner)</strong> เพื่อความคมชัดสูงสุด</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
