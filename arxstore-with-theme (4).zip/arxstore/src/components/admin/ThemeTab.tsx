'use client';

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useStore } from '@/context/StoreContext';
import {
  Palette,
  Save,
  RotateCcw,
  Undo2,
  Eye,
  EyeOff,
  Check,
  AlertTriangle,
  Sparkles,
  Power
} from 'lucide-react';
import {
  ColorKey,
  ThemeSettings,
  DEFAULT_THEME,
  THEME_PRESETS,
  applyThemeToDocument,
  contrastRatio,
  normalizeHex,
  readableOn,
  sanitizeTheme
} from '@/lib/theme';

const FIELDS: { key: ColorKey; label: string; hint: string }[] = [
  { key: 'main', label: 'สีหลัก (Main)', hint: 'ปุ่มหลัก, ลิงก์, ไฮไลต์ (แทนน้ำเงิน #0000ff และชุดสี blue ทั้งเว็บ)' },
  { key: 'secondary', label: 'สีรอง (Secondary)', hint: 'เฉดไล่สี, ป้ายรอง (ชุดสีม่วง/คราม)' },
  { key: 'accent', label: 'สีเน้น (Accent)', hint: 'ไอคอน, ตัวเลข, เส้นเรืองแสง และหลังบ้านทั้งหมด (ชุดสี cyan)' },
  { key: 'background', label: 'พื้นหลังเว็บ + หลังบ้าน', hint: 'พื้นหลังหลักของทุกหน้า (โหมดมืด)' },
  { key: 'card', label: 'พื้นการ์ด / แผง', hint: 'การ์ดสินค้า, เมนู, กล่องข้อมูล, ช่องกรอก' },
  { key: 'text', label: 'ตัวอักษรหลัก', hint: 'หัวข้อและข้อความทั่วไป' },
  { key: 'textMuted', label: 'ตัวอักษรรอง', hint: 'คำอธิบาย, ข้อความจาง' },
  { key: 'border', label: 'สีขอบการ์ด', hint: 'ใช้ความโปร่งใสต่ำอัตโนมัติ' }
];

function token(): string | null {
  return typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
}

export default function ThemeTab() {
  const { playClick, playSuccess, playError } = useStore();

  const [saved, setSaved] = useState<ThemeSettings>(DEFAULT_THEME);
  const [form, setForm] = useState<ThemeSettings>(DEFAULT_THEME);
  const [livePreview, setLivePreview] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const savedRef = useRef(saved);
  savedRef.current = saved;

  // โหลดค่าที่บันทึกไว้
  useEffect(() => {
    let alive = true;
    fetch('/api/admin/theme', { cache: 'no-store' })
      .then(r => r.json())
      .then(d => {
        if (!alive || !d.success) return;
        const t = sanitizeTheme(d.data);
        setSaved(t);
        setForm(t);
      })
      .catch(() => {})
      .finally(() => alive && setIsLoading(false));
    return () => {
      alive = false;
    };
  }, []);

  // พรีวิวสดบนหน้าจริง และคืนค่าที่บันทึกไว้เมื่อออกจากแท็บ
  useEffect(() => {
    applyThemeToDocument(livePreview ? form : savedRef.current);
  }, [form, livePreview]);

  useEffect(() => {
    return () => applyThemeToDocument(savedRef.current);
  }, []);

  const dirty = useMemo(() => JSON.stringify({ ...form, updatedAt: '' }) !== JSON.stringify({ ...saved, updatedAt: '' }), [form, saved]);

  const warnings = useMemo(() => {
    const w: string[] = [];
    if (contrastRatio(form.text, form.background) < 4.5) w.push('ตัวอักษรหลักกับพื้นหลังเว็บมีความคมชัดต่ำ อ่านยาก');
    if (contrastRatio(form.text, form.card) < 4.5) w.push('ตัวอักษรหลักกับพื้นการ์ดมีความคมชัดต่ำ อ่านยาก');
    if (contrastRatio(form.textMuted, form.background) < 3) w.push('ตัวอักษรรองกับพื้นหลังจางเกินไป');
    if (contrastRatio(form.main, form.background) < 2) w.push('สีหลักกลืนกับพื้นหลัง ปุ่ม/ลิงก์อาจมองไม่เห็น');
    return w;
  }, [form]);

  const setColor = (key: ColorKey, value: string) => {
    setForm(prev => ({ ...prev, [key]: value }));
  };

  // ช่อง hex: พิมพ์ได้อิสระ แต่รับเฉพาะค่าที่ถูกต้องเข้า state
  const [hexDraft, setHexDraft] = useState<Partial<Record<ColorKey, string>>>({});
  const onHexInput = (key: ColorKey, raw: string) => {
    const v = raw.startsWith('#') ? raw : '#' + raw;
    setHexDraft(d => ({ ...d, [key]: v }));
    const n = normalizeHex(v);
    if (n) setColor(key, n);
  };
  const onHexBlur = (key: ColorKey) => setHexDraft(d => ({ ...d, [key]: undefined }));

  const applyPreset = (id: string) => {
    const p = THEME_PRESETS.find(x => x.id === id);
    if (!p) return;
    playClick();
    setHexDraft({});
    setForm(prev => ({ ...prev, ...p.values }));
  };

  const handleSave = async () => {
    playClick();
    setIsSaving(true);
    setMsg(null);
    try {
      const t = token();
      const res = await fetch('/api/admin/theme', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(t ? { 'x-session-token': t } : {}) },
        body: JSON.stringify(form)
      });
      const d = await res.json();
      if (res.ok && d.success) {
        const next = sanitizeTheme(d.data);
        setSaved(next);
        setForm(next);
        playSuccess();
        setMsg({ ok: true, text: d.message || 'บันทึกสำเร็จ' });
      } else {
        playError();
        setMsg({ ok: false, text: d.message || 'บันทึกไม่สำเร็จ' });
      }
    } catch {
      playError();
      setMsg({ ok: false, text: 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = async () => {
    if (!window.confirm('คืนค่าสีทั้งหมดเป็นสีเดิมของเว็บ (Electric Blue) ใช่หรือไม่?')) return;
    playClick();
    setIsSaving(true);
    setMsg(null);
    try {
      const t = token();
      const res = await fetch('/api/admin/theme', {
        method: 'DELETE',
        headers: t ? { 'x-session-token': t } : {}
      });
      const d = await res.json();
      if (res.ok && d.success) {
        const next = sanitizeTheme(d.data);
        setSaved(next);
        setForm(next);
        setHexDraft({});
        playSuccess();
        setMsg({ ok: true, text: d.message || 'คืนค่าสีเดิมแล้ว' });
      } else {
        playError();
        setMsg({ ok: false, text: d.message || 'คืนค่าไม่สำเร็จ' });
      }
    } catch {
      playError();
      setMsg({ ok: false, text: 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleUndo = () => {
    playClick();
    setHexDraft({});
    setForm(saved);
    setMsg(null);
  };

  if (isLoading) {
    return <div className="p-10 text-center text-slate-400 text-sm">กำลังโหลดการตั้งค่าสี…</div>;
  }

  const onMain = readableOn(form.main);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center border border-white/10" style={{ background: `${form.main}22`, color: form.main }}>
            <Palette className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-white">ปรับสีเว็บไซต์</h2>
            <p className="text-sm text-slate-400 mt-1">เปลี่ยนสีทั้งเว็บและหลังบ้านได้ทันที ไม่ต้องแก้โค้ด — กดบันทึกแล้วมีผลกับผู้เข้าชมทุกคน (สีที่ไม่ได้แก้จะคงเดิม)</p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => { playClick(); setForm(p => ({ ...p, enabled: !p.enabled })); }}
          className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg border text-sm transition ${
            form.enabled ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300' : 'border-white/10 bg-white/5 text-slate-400'
          }`}
          aria-pressed={form.enabled}
        >
          <Power className="w-4 h-4" />
          {form.enabled ? 'ใช้สีที่กำหนดเอง' : 'ใช้สีเดิมของเว็บ'}
        </button>
      </div>

      {/* Presets */}
      <section className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
        <div className="flex items-center gap-2 mb-3 text-sm text-slate-300">
          <Sparkles className="w-4 h-4" style={{ color: form.main }} /> ธีมสำเร็จรูป
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {THEME_PRESETS.map(p => {
            const active = (['main', 'secondary', 'accent', 'background', 'card', 'text'] as ColorKey[]).every(k => form[k] === p.values[k]);
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => applyPreset(p.id)}
                className={`text-left rounded-lg border p-2.5 transition hover:border-white/30 ${active ? 'border-white/40 bg-white/10' : 'border-white/10 bg-white/[0.02]'}`}
              >
                <div className="flex h-7 rounded-md overflow-hidden border border-white/10 mb-2">
                  <span className="flex-1" style={{ background: p.values.background }} />
                  <span className="flex-1" style={{ background: p.values.card }} />
                  <span className="flex-1" style={{ background: p.values.main }} />
                  <span className="flex-1" style={{ background: p.values.secondary }} />
                  <span className="flex-1" style={{ background: p.values.accent }} />
                </div>
                <div className="flex items-center justify-between gap-1 text-xs text-slate-300">
                  <span className="truncate">{p.label}</span>
                  {active && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                </div>
              </button>
            );
          })}
        </div>
      </section>

      <div className="grid lg:grid-cols-[1fr_340px] gap-6 items-start">
        {/* Color fields */}
        <section className="rounded-xl border border-white/10 bg-white/[0.03] p-4 space-y-3">
          <div className="text-sm text-slate-300 mb-1">กำหนดสีเอง</div>
          {FIELDS.map(f => (
            <div key={f.key} className="flex items-center gap-3 rounded-lg border border-white/5 bg-black/20 p-2.5">
              <label className="relative shrink-0">
                <input
                  type="color"
                  value={form[f.key]}
                  onChange={e => setColor(f.key, e.target.value)}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  aria-label={f.label}
                />
                <span className="block w-11 h-11 rounded-lg border border-white/20" style={{ background: form[f.key] }} />
              </label>
              <div className="min-w-0 flex-1">
                <div className="text-sm text-white">{f.label}</div>
                <div className="text-xs text-slate-500 truncate">{f.hint}</div>
              </div>
              <input
                type="text"
                value={hexDraft[f.key] ?? form[f.key]}
                onChange={e => onHexInput(f.key, e.target.value)}
                onBlur={() => onHexBlur(f.key)}
                maxLength={7}
                spellCheck={false}
                aria-label={`รหัสสี ${f.label}`}
                className="w-[92px] shrink-0 rounded-md border border-white/10 bg-black/40 px-2 py-1.5 text-xs font-mono text-slate-200 uppercase outline-none focus:border-white/40"
              />
            </div>
          ))}

          {warnings.length > 0 && (
            <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-200 space-y-1">
              {warnings.map(w => (
                <div key={w} className="flex items-start gap-2">
                  <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" /> {w}
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Live preview */}
        <aside className="rounded-xl border border-white/10 bg-white/[0.03] p-4 lg:sticky lg:top-4 space-y-3">
          <div className="flex items-center justify-between text-sm text-slate-300">
            <span>ตัวอย่าง</span>
            <button
              type="button"
              onClick={() => { playClick(); setLivePreview(v => !v); }}
              className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white"
            >
              {livePreview ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              {livePreview ? 'พรีวิวบนหน้าจริง: เปิด' : 'พรีวิวบนหน้าจริง: ปิด'}
            </button>
          </div>

          <div className="rounded-xl p-4 border" style={{ background: form.background, borderColor: `${form.border}1f` }}>
            <div className="text-sm font-medium" style={{ color: form.text }}>ชื่อร้านของคุณ</div>
            <div className="text-xs mt-0.5" style={{ color: form.textMuted }}>ข้อความอธิบายตัวอย่าง</div>

            <div className="mt-3 rounded-lg p-3 border" style={{ background: form.card, borderColor: `${form.border}1f` }}>
              <div className="flex items-center justify-between">
                <span className="text-sm" style={{ color: form.text }}>สินค้าตัวอย่าง</span>
                <span className="text-sm font-medium" style={{ color: form.accent }}>฿199</span>
              </div>
              <div className="text-xs mt-1" style={{ color: form.textMuted }}>คำอธิบายสินค้าสั้น ๆ</div>
              <div className="mt-3 flex gap-2">
                <span className="flex-1 text-center text-xs py-2 rounded-md font-medium" style={{ background: form.main, color: onMain }}>
                  ซื้อเลย
                </span>
                <span className="flex-1 text-center text-xs py-2 rounded-md font-medium border" style={{ color: form.secondary, borderColor: `${form.secondary}66`, background: `${form.secondary}14` }}>
                  รายละเอียด
                </span>
              </div>
            </div>

            <div className="mt-3 h-1.5 rounded-full" style={{ background: `linear-gradient(90deg, ${form.main}, ${form.secondary}, ${form.accent})` }} />
          </div>

          <p className="text-[11px] leading-relaxed text-slate-500">
            เมื่อเปิดพรีวิวบนหน้าจริง สีของหน้านี้จะเปลี่ยนตามทันที หากไม่กดบันทึกแล้วออกจากแท็บ ระบบจะกลับเป็นสีที่บันทึกไว้
          </p>
        </aside>
      </div>

      {/* Action bar */}
      <div className="sticky bottom-3 z-10 flex flex-wrap items-center gap-3 rounded-xl border border-white/10 bg-slate-900/90 backdrop-blur p-3">
        <button
          type="button"
          onClick={handleSave}
          disabled={isSaving || !dirty}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition disabled:opacity-40 disabled:cursor-not-allowed"
          style={{ background: form.main, color: onMain }}
        >
          <Save className="w-4 h-4" />
          {isSaving ? 'กำลังบันทึก…' : 'บันทึกสี'}
        </button>
        <button
          type="button"
          onClick={handleUndo}
          disabled={isSaving || !dirty}
          className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-lg border border-white/10 text-sm text-slate-300 hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Undo2 className="w-4 h-4" /> ยกเลิกการแก้ไข
        </button>
        <button
          type="button"
          onClick={handleReset}
          disabled={isSaving}
          className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-lg border border-white/10 text-sm text-slate-300 hover:bg-white/5 disabled:opacity-40 ml-auto"
        >
          <RotateCcw className="w-4 h-4" /> คืนค่าสีเดิม
        </button>
        {dirty && !msg && <span className="text-xs text-amber-300 w-full sm:w-auto">มีการแก้ไขที่ยังไม่ได้บันทึก</span>}
        {msg && (
          <span className={`text-xs w-full sm:w-auto ${msg.ok ? 'text-emerald-300' : 'text-rose-300'}`} role="status">
            {msg.text}
          </span>
        )}
      </div>
    </div>
  );
}
