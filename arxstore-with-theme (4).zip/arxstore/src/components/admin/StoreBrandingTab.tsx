'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '@/context/StoreContext';
import {
  Globe,
  Upload,
  Image as ImageIcon,
  Check,
  RefreshCw,
  Sparkles,
  Save,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Palette,
  Eye,
  Store,
  Laptop
} from 'lucide-react';

export default function StoreBrandingTab() {
  const { siteContent, updateSiteContent, playClick, playSuccess, playError, showToast } = useStore();

  const branding = siteContent?.branding || {
    siteName: 'ARX STORE',
    siteTitle: 'ARX STORE | บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ',
    slogan: 'บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ ซื้อขายระบบอัตโนมัติ 24 ชม.',
    logoUrl: '/brand/logo.png',
    faviconUrl: '/icon.png'
  };

  const footer = siteContent?.footer;

  const [siteName, setSiteName] = useState(branding.siteName || 'ARX STORE');
  const [siteTitle, setSiteTitle] = useState(branding.siteTitle || 'ARX STORE | บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ');
  const [slogan, setSlogan] = useState(branding.slogan || 'บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ ซื้อขายระบบอัตโนมัติ 24 ชม.');
  const [logoUrl, setLogoUrl] = useState(branding.logoUrl || '/brand/logo.png');
  const [faviconUrl, setFaviconUrl] = useState(branding.faviconUrl || '/icon.png');
  const [heroBannerUrl, setHeroBannerUrl] = useState(branding.heroBannerUrl || '/brand/hero-reflex-banner.png');
  const [copyright, setCopyright] = useState(footer?.copyright || `© 2026 ${branding.siteName || 'ARX STORE'}`);

  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);
  const [isUploadingFavicon, setIsUploadingFavicon] = useState(false);
  const [isUploadingHeroBanner, setIsUploadingHeroBanner] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const logoFileInputRef = useRef<HTMLInputElement>(null);
  const faviconFileInputRef = useRef<HTMLInputElement>(null);
  const heroBannerFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (siteContent?.branding) {
      setSiteName(siteContent.branding.siteName || 'ARX STORE');
      setSiteTitle(siteContent.branding.siteTitle || 'ARX STORE | บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ');
      setSlogan(siteContent.branding.slogan || 'บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ ซื้อขายระบบอัตโนมัติ 24 ชม.');
      setLogoUrl(siteContent.branding.logoUrl || '/brand/logo.png');
      setFaviconUrl(siteContent.branding.faviconUrl || '/icon.png');
      setHeroBannerUrl(siteContent.branding.heroBannerUrl || '/brand/hero-reflex-banner.png');
    }
    if (siteContent?.footer?.copyright) {
      setCopyright(siteContent.footer.copyright);
    }
  }, [siteContent]);

  // Handle Logo file upload
  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast({ title: 'ไฟล์ไม่ถูกต้อง', message: 'กรุณาเลือกไฟล์รูปภาพ (PNG, JPG, WEBP, GIF, SVG)', type: 'error' });
      playError();
      return;
    }

    setIsUploadingLogo(true);
    playClick();

    try {
      const formData = new FormData();
      formData.append('file', file);

      const token = typeof window !== 'undefined' ? (localStorage.getItem('arx_session_token') || localStorage.getItem('arx_admin_token')) : null;
      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: token ? {
          'Authorization': `Bearer ${token}`,
          'x-session-token': token
        } : undefined,
        body: formData
      });

      const data = await res.json();
      if (data?.success && data?.url) {
        setLogoUrl(data.url);
        playSuccess();
        showToast({ title: 'อัปโหลดสำเร็จ!', message: 'เปลี่ยนรูปโลโก้เรียบร้อยแล้ว อย่าลืมกดบันทึก', type: 'success' });
      } else {
        throw new Error(data?.message || 'อัปโหลดไม่สำเร็จ');
      }
    } catch (err: any) {
      playError();
      showToast({ title: 'เกิดข้อผิดพลาด', message: err.message || 'ไม่สามารถอัปโหลดรูปภาพได้', type: 'error' });
    } finally {
      setIsUploadingLogo(false);
      if (logoFileInputRef.current) logoFileInputRef.current.value = '';
    }
  };

  // Handle Favicon file upload
  const handleFaviconUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingFavicon(true);
    playClick();

    try {
      const formData = new FormData();
      formData.append('file', file);

      const token = typeof window !== 'undefined' ? (localStorage.getItem('arx_session_token') || localStorage.getItem('arx_admin_token')) : null;
      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: token ? {
          'Authorization': `Bearer ${token}`,
          'x-session-token': token
        } : undefined,
        body: formData
      });

      const data = await res.json();
      if (data?.success && data?.url) {
        setFaviconUrl(data.url);
        playSuccess();
        showToast({ title: 'อัปโหลด Favicon สำเร็จ!', message: 'อัปเดตรูป Favicon เรียบร้อยแล้ว อย่าลืมกดบันทึก', type: 'success' });
      } else {
        throw new Error(data?.message || 'อัปโหลดไม่สำเร็จ');
      }
    } catch (err: any) {
      playError();
      showToast({ title: 'เกิดข้อผิดพลาด', message: err.message || 'ไม่สามารถอัปโหลดได้', type: 'error' });
    } finally {
      setIsUploadingFavicon(false);
      if (faviconFileInputRef.current) faviconFileInputRef.current.value = '';
    }
  };

  // Handle Hero Banner file upload
  const handleHeroBannerUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast({ title: 'ไฟล์ไม่ถูกต้อง', message: 'กรุณาเลือกไฟล์รูปภาพ (PNG, JPG, WEBP, GIF)', type: 'error' });
      playError();
      return;
    }

    setIsUploadingHeroBanner(true);
    playClick();

    try {
      const formData = new FormData();
      formData.append('file', file);

      const token = typeof window !== 'undefined' ? (localStorage.getItem('arx_session_token') || localStorage.getItem('arx_admin_token')) : null;
      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: token ? {
          'Authorization': `Bearer ${token}`,
          'x-session-token': token
        } : undefined,
        body: formData
      });

      const data = await res.json();
      if (data?.success && data?.url) {
        setHeroBannerUrl(data.url);
        playSuccess();
        showToast({ title: 'อัปโหลดสำเร็จ!', message: 'เปลี่ยนรูปแบนเนอร์หลักเรียบร้อยแล้ว อย่าลืมกดบันทึก', type: 'success' });
      } else {
        throw new Error(data?.message || 'อัปโหลดไม่สำเร็จ');
      }
    } catch (err: any) {
      playError();
      showToast({ title: 'เกิดข้อผิดพลาด', message: err.message || 'ไม่สามารถอัปโหลดได้', type: 'error' });
    } finally {
      setIsUploadingHeroBanner(false);
      if (heroBannerFileInputRef.current) heroBannerFileInputRef.current.value = '';
    }
  };

  // Save Branding Settings
  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!siteName.trim()) {
      showToast({ title: 'แจ้งเตือน', message: 'กรุณากรอกชื่อเว็บไซต์', type: 'error' });
      playError();
      return;
    }

    playClick();
    setIsSaving(true);

    try {
      const ok = await updateSiteContent({
        branding: {
          siteName: siteName.trim(),
          siteTitle: siteTitle.trim() || siteName.trim(),
          slogan: slogan.trim(),
          logoUrl: logoUrl.trim() || '/brand/logo.png',
          faviconUrl: faviconUrl.trim() || '/icon.png',
          heroBannerUrl: heroBannerUrl.trim() || '/brand/hero-reflex-banner.png'
        },
        footer: {
          description: slogan.trim(),
          reportText: footer?.reportText || 'ติดต่อร้านค้าไม่ได้ หรือต้องการรายงานปัญหาร้านค้าขี้โกง? แจ้งเรื่องกับทีมงานกลาง',
          reportUrl: footer?.reportUrl || '#',
          copyright: copyright.trim() || `© 2026 ${siteName.trim()}`,
          currencyNote: footer?.currencyNote || 'ราคาทั้งหมดเป็นเงินบาท'
        }
      });

      if (ok) {
        playSuccess();
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3500);
        showToast({
          title: 'บันทึกสำเร็จ!',
          message: 'อัปเดตชื่อเว็บไซต์และโลโก้เรียบร้อยแล้ว หน้าเว็บจะแสดงผลใหม่ทันที',
          type: 'success'
        });
      }
    } catch (err) {
      playError();
      showToast({ title: 'เกิดข้อผิดพลาด', message: 'ไม่สามารถบันทึกข้อมูลได้', type: 'error' });
    } finally {
      setIsSaving(false);
    }
  };

  // Reset to default
  const handleResetToDefault = () => {
    if (confirm('คุณต้องการรีเซ็ตชื่อเว็บและโลโก้กลับเป็นค่าเริ่มต้นหรือไม่?')) {
      playClick();
      setSiteName('ARX STORE');
      setSiteTitle('ARX STORE | บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ');
      setSlogan('บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ ซื้อขายระบบอัตโนมัติ 24 ชม.');
      setLogoUrl('/brand/logo.png');
      setFaviconUrl('/icon.png');
      setCopyright('© 2026 ARX STORE');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-white/10 p-5 sm:p-6 shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-[11px] font-bold uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              Store Identity & Branding
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2.5">
              <span>ตั้งค่าชื่อเว็บ & โลโก้เว็บ</span>
              <span className="text-xs font-mono font-normal px-2 py-0.5 rounded-md bg-white/10 text-cyan-400">
                Live Dynamic
              </span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
              ปรับแต่งชื่อร้านค้า หัวข้อแท็บเบราว์เซอร์ โลโก้ และข้อความสโลแกน เมื่อบันทึกแล้วระบบจะอัปเดตแถบเมนู (Navbar), ส่วนท้ายเว็บ (Footer), หน้าต่างติดต่อ, และ Meta SEO ทันทีโดยไม่ต้องเขียนโค้ดใหม่
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handleResetToDefault}
              className="px-3.5 py-2 rounded-xl border border-white/10 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>คืนค่าเริ่มต้น</span>
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={isSaving}
              className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center gap-2 cursor-pointer shadow-lg ${
                saveSuccess
                  ? 'bg-emerald-500 text-slate-950 shadow-emerald-500/30'
                  : 'bg-gradient-to-r from-[var(--theme-accent)] to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-950 shadow-cyan-500/25'
              }`}
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>กำลังบันทึก...</span>
                </>
              ) : saveSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>บันทึกสำเร็จแล้ว!</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>บันทึกการตั้งค่า</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Form Left, Real-time Preview Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Input Form (Col 7) */}
        <div className="lg:col-span-7 space-y-5">
          {/* Card 1: ชื่อเว็บไซต์ & แท็บเบราว์เซอร์ */}
          <div className="bg-slate-950/80 rounded-2xl border border-white/10 p-5 sm:p-6 shadow-md space-y-4">
            <div className="flex items-center gap-2.5 pb-3 border-b border-white/5">
              <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Store className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-white">ชื่อเว็บไซต์และหัวข้อร้านค้า</h3>
                <p className="text-xs text-slate-400">กำหนดชื่อแบรนด์ที่จะแสดงในแถบเมนูและหัวแท็บ</p>
              </div>
            </div>

            <div className="space-y-4">
              {/* Site Name */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>ชื่อเว็บไซต์ / ชื่อร้าน (Store Name) *</span>
                  <span className="text-[10px] text-cyan-400 font-mono">แสดงบน Navbar & Footer</span>
                </label>
                <input
                  type="text"
                  value={siteName}
                  onChange={(e) => setSiteName(e.target.value)}
                  placeholder="เช่น ARX STORE"
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                  required
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  ตัวอย่าง: <span className="text-slate-400">ARX STORE, DEMOxSHOP, YOURSTORE</span>
                </p>
              </div>

              {/* Site Title / Tab Title */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>หัวข้อหน้าเว็บ / ข้อความบนแท็บเบราว์เซอร์ (Browser Tab Title)</span>
                  <span className="text-[10px] text-slate-400 font-mono">SEO Meta Title</span>
                </label>
                <input
                  type="text"
                  value={siteTitle}
                  onChange={(e) => setSiteTitle(e.target.value)}
                  placeholder="เช่น ARX STORE | บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ"
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  ข้อความนี้จะแสดงบนหัวแท็บเบราว์เซอร์ด้านบนสุดของ Chrome, Edge, Safari และบน Google Search
                </p>
              </div>

              {/* Store Slogan / Description */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>คำโปรย / สโลแกนร้านค้า (Store Slogan / Description)</span>
                  <span className="text-[10px] text-slate-400 font-mono">แสดงใน Footer</span>
                </label>
                <textarea
                  value={slogan}
                  onChange={(e) => setSlogan(e.target.value)}
                  rows={2}
                  placeholder="คำอธิบายร้านค้าสั้นๆ สำหรับแสดงในส่วนล่างสุดของเว็บ"
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition resize-none"
                />
              </div>

              {/* Footer Copyright */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  ข้อความลิขสิทธิ์ด้านล่างสุด (Copyright Text)
                </label>
                <input
                  type="text"
                  value={copyright}
                  onChange={(e) => setCopyright(e.target.value)}
                  placeholder="เช่น © 2026 ARX STORE"
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition font-mono"
                />
              </div>
            </div>
          </div>

          {/* Card 2: โลโก้เว็บไซต์ (Website Logo & Favicon) */}
          <div className="bg-slate-950/80 rounded-2xl border border-white/10 p-5 sm:p-6 shadow-md space-y-4">
            <div className="flex items-center gap-2.5 pb-3 border-b border-white/5">
              <div className="w-7 h-7 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                <ImageIcon className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-white">โลโก้และไอคอนเว็บไซต์ (Logo & Favicon)</h3>
                <p className="text-xs text-slate-400">อัปโหลดรูปภาพจากเครื่อง หรือใส่ลิงก์รูปภาพโดยตรง</p>
              </div>
            </div>

            {/* Logo Settings */}
            <div className="space-y-3">
              <label className="block text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>โลโก้เว็บไซต์ (Website Logo) *</span>
                <span className="text-[10px] text-cyan-400 font-mono">PNG / JPG / WEBP / SVG</span>
              </label>

              <div className="flex flex-col sm:flex-row gap-2.5">
                <input
                  type="text"
                  value={logoUrl}
                  onChange={(e) => setLogoUrl(e.target.value)}
                  placeholder="/brand/logo.png หรือ https://..."
                  className="flex-1 bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition font-mono"
                />
                
                {/* Hidden File Input */}
                <input
                  ref={logoFileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml,image/gif"
                  onChange={handleLogoUpload}
                  className="hidden"
                />

                <button
                  type="button"
                  onClick={() => logoFileInputRef.current?.click()}
                  disabled={isUploadingLogo}
                  className="px-4 py-2 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-cyan-300 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                >
                  {isUploadingLogo ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>กำลังอัปโหลด...</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-3.5 h-3.5" />
                      <span>เลือกไฟล์รูป...</span>
                    </>
                  )}
                </button>
              </div>

            </div>

            {/* Favicon Settings */}
            <div className="space-y-3 pt-3 border-t border-white/5">
              <label className="block text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>ไอคอน Favicon บนแท็บเบราว์เซอร์ (Favicon URL)</span>
                <span className="text-[10px] text-slate-400 font-mono">16x16 หรือ 32x32 หรือ 512x512</span>
              </label>

              <div className="flex flex-col sm:flex-row gap-2.5">
                <input
                  type="text"
                  value={faviconUrl}
                  onChange={(e) => setFaviconUrl(e.target.value)}
                  placeholder="/icon.png หรือ /favicon.ico"
                  className="flex-1 bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition font-mono"
                />

                {/* Hidden File Input for Favicon */}
                <input
                  ref={faviconFileInputRef}
                  type="file"
                  accept="image/png,image/x-icon,image/vnd.microsoft.icon,image/svg+xml"
                  onChange={handleFaviconUpload}
                  className="hidden"
                />

                <button
                  type="button"
                  onClick={() => faviconFileInputRef.current?.click()}
                  disabled={isUploadingFavicon}
                  className="px-4 py-2 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/40 text-purple-300 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                >
                  {isUploadingFavicon ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>กำลังอัปโหลด...</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-3.5 h-3.5" />
                      <span>อัปโหลด Favicon...</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Hero Banner Settings */}
            <div className="space-y-3 pt-3 border-t border-white/5">
              <label className="block text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>แบนเนอร์หลักหน้าแรก (Hero Banner Image)</span>
                <span className="text-[10px] text-amber-400 font-mono">1100x375 หรือ 16:6 (PNG/JPG/WEBP)</span>
              </label>

              <div className="flex flex-col sm:flex-row gap-2.5">
                <input
                  type="text"
                  value={heroBannerUrl}
                  onChange={(e) => setHeroBannerUrl(e.target.value)}
                  placeholder="/brand/hero-reflex-banner.png หรือ https://..."
                  className="flex-1 bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition font-mono"
                />

                <input
                  ref={heroBannerFileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif"
                  onChange={handleHeroBannerUpload}
                  className="hidden"
                />

                <button
                  type="button"
                  onClick={() => heroBannerFileInputRef.current?.click()}
                  disabled={isUploadingHeroBanner}
                  className="px-4 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                >
                  {isUploadingHeroBanner ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>กำลังอัปโหลด...</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-3.5 h-3.5" />
                      <span>อัปโหลดแบนเนอร์...</span>
                    </>
                  )}
                </button>
              </div>

              {heroBannerUrl && (
                <div className="relative rounded-xl overflow-hidden border border-white/10 max-h-36 bg-black">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    key={heroBannerUrl}
                    src={heroBannerUrl}
                    alt="Hero Banner Preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Action bottom button */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={handleSave}
              disabled={isSaving}
              className={`w-full sm:w-auto px-6 py-3 rounded-xl text-sm font-black transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg ${
                saveSuccess
                  ? 'bg-emerald-500 text-slate-950 shadow-emerald-500/30'
                  : 'bg-gradient-to-r from-[var(--theme-accent)] to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-950 shadow-cyan-500/25'
              }`}
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>กำลังบันทึกข้อมูล...</span>
                </>
              ) : saveSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>บันทึกสำเร็จเรียบร้อย!</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>บันทึกการตั้งค่าชื่อเว็บและโลโก้</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Real-time Live Previews (Col 5) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-950/80 rounded-2xl border border-white/10 p-4 sm:p-5 shadow-md">
            <div className="flex items-center justify-between pb-3 border-b border-white/5 mb-4">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-cyan-400" />
                Live Preview (ตัวอย่างแสดงผลจริง)
              </span>
              <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                เรียลไทม์
              </span>
            </div>

            <div className="space-y-4">
              {/* Preview 1: Browser Window Tab Mockup */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 block mb-1.5">
                  1. แท็บเบราว์เซอร์ Google Chrome
                </span>
                <div className="rounded-xl border border-white/10 bg-[color:var(--arx-dk-1e232a)] overflow-hidden shadow-inner">
                  {/* Chrome top bar */}
                  <div className="bg-[color:var(--arx-dk-181c22)] px-3 pt-2 pb-0 flex items-center gap-1.5">
                    <div className="flex items-center gap-1.5 mr-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-rose-500/80"></div>
                      <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></div>
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></div>
                    </div>
                    {/* Active tab */}
                    <div className="bg-[color:var(--arx-dk-242932)] px-3 py-1.5 rounded-t-lg flex items-center gap-2 max-w-[260px] border-t border-x border-white/10">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        key={`tab-${faviconUrl || logoUrl}`}
                        src={faviconUrl || logoUrl || '/brand/logo.png'}
                        alt="Favicon"
                        className="w-3.5 h-3.5 object-contain rounded shrink-0"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = '/brand/logo.png';
                        }}
                      />
                      <span className="text-[11px] text-slate-200 truncate font-sans font-medium">
                        {siteTitle || siteName}
                      </span>
                      <span className="text-[10px] text-slate-500 hover:text-white shrink-0 ml-auto">✕</span>
                    </div>
                  </div>
                  {/* Chrome URL bar */}
                  <div className="p-2 bg-[color:var(--arx-dk-242932)] border-t border-white/5 flex items-center gap-2">
                    <div className="w-full bg-[color:var(--arx-dk-181c22)] rounded-lg px-2.5 py-1 text-[10px] font-mono text-slate-400 flex items-center gap-1.5 border border-white/5 truncate">
                      <span className="text-emerald-400">🔒 https://</span>
                      <span className="text-slate-200">{siteName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'arxstore'}.xyz</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Preview 2: Floating Navbar Header Mockup */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 block mb-1.5">
                  2. แถบเมนูด้านบน (Floating Navbar Pill)
                </span>
                <div className="rounded-2xl border border-white/10 bg-[color:var(--arx-dk-070b14)] p-3 shadow-md flex items-center justify-between">
                  {/* Left: Brand Link + Nav Links (ชิดซ้ายหลังชื่อร้าน) */}
                  <div className="flex items-center gap-3.5 select-none min-w-0">
                    <div className="flex items-center gap-2 shrink-0">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        key={`nav-${logoUrl}`}
                        src={logoUrl || '/brand/logo.png'}
                        alt={siteName}
                        className="w-7 h-7 rounded-full object-contain filter drop-shadow-[0_0_8px_rgba(var(--theme-accent-rgb),0.65)]"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = '/brand/logo.png';
                        }}
                      />
                      <span className="font-black text-xs tracking-tight text-white">
                        {siteName}
                      </span>
                    </div>

                    {/* Dummy links */}
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 font-medium shrink-0">
                      <span className="text-cyan-400 font-bold">หน้าหลัก</span>
                      <span>สินค้า</span>
                      <span>เติมเงิน</span>
                    </div>
                  </div>

                  {/* Dummy auth button */}
                  <div className="px-2 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[10px] font-bold shrink-0">
                    เข้าสู่ระบบ
                  </div>
                </div>
              </div>

              {/* Preview 3: Footer Brand Section Mockup */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 block mb-1.5">
                  3. ส่วนท้ายเว็บไซต์ (Footer Brand Area)
                </span>
                <div className="rounded-2xl border border-white/10 bg-[color:var(--arx-dk-04060c)] p-4 shadow-md space-y-2.5">
                  <div className="flex items-center gap-2">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      key={`foot-${logoUrl}`}
                      src={logoUrl || '/brand/logo.png'}
                      alt={siteName}
                      className="w-5 h-5 rounded-full object-contain filter drop-shadow-[0_0_8px_rgba(var(--theme-accent-rgb),0.65)]"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/brand/logo.png';
                      }}
                    />
                    <span className="font-black text-xs text-white">
                      {siteName}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed line-clamp-2">
                    {slogan}
                  </p>
                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                    <span>{copyright}</span>
                    <span>ราคาทั้งหมดเป็นเงินบาท</span>
                  </div>
                </div>
              </div>

              {/* Logo Zoom Box */}
              <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 text-center">
                <span className="text-[11px] font-bold text-slate-400 block mb-2">
                  ตัวอย่างรูปโลโก้ขนาดใหญ่ (Hi-res Preview)
                </span>
                <div className="w-24 h-24 mx-auto rounded-2xl bg-black/70 border border-cyan-500/30 p-2 flex items-center justify-center shadow-[0_0_20px_rgba(var(--theme-accent-rgb),0.2)]">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    key={`hires-${logoUrl}`}
                    src={logoUrl || '/brand/logo.png'}
                    alt={siteName}
                    className="max-w-full max-h-full object-contain filter drop-shadow-[0_0_10px_rgba(var(--theme-accent-rgb),0.7)]"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/brand/logo.png';
                    }}
                  />
                </div>
                <div className="text-[11px] font-mono text-cyan-400 mt-2 truncate px-2">
                  {logoUrl}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
