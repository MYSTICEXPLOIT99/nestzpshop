'use client';

import React, { useState, useEffect } from 'react';
import { useStore } from '@/context/StoreContext';
import { SiteContent, StepItem, FaqItem, ContactChannel } from '@/types';
import {
  Save,
  Plus,
  Trash2,
  ExternalLink,
  MessageCircle,
  HelpCircle,
  ListOrdered,
  FileText,
  RotateCcw,
  CheckCircle2,
  Layers,
  ArrowUpRight,
  Globe
} from 'lucide-react';
import StoreBrandingTab from '@/components/admin/StoreBrandingTab';

export default function SiteContentTab() {
  const { siteContent, updateSiteContent, playClick, showToast } = useStore();

  const [formData, setFormData] = useState<SiteContent>(siteContent);
  const [isSaving, setIsSaving] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'branding' | 'steps' | 'faqs' | 'contact' | 'footer'>('branding');

  useEffect(() => {
    if (siteContent) {
      setFormData(siteContent);
    }
  }, [siteContent]);

  // Handle Save
  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    playClick();
    setIsSaving(true);
    try {
      const ok = await updateSiteContent(formData);
      if (ok) {
        showToast({
          title: 'บันทึกสำเร็จ',
          message: 'อัปเดตข้อมูลเนื้อหาเว็บไซต์และช่องทางติดต่อเรียบร้อยแล้ว',
          type: 'success'
        });
      }
    } finally {
      setIsSaving(false);
    }
  };

  // Step item handlers
  const handleStepChange = (index: number, field: keyof StepItem, value: string) => {
    setFormData(prev => {
      const nextSteps = [...(prev.stepsSection?.steps || [])];
      nextSteps[index] = { ...nextSteps[index], [field]: value };
      return {
        ...prev,
        stepsSection: {
          ...prev.stepsSection,
          steps: nextSteps
        }
      };
    });
  };

  // FAQ handlers
  const handleFaqChange = (index: number, field: keyof FaqItem, value: string) => {
    setFormData(prev => {
      const nextFaqs = [...(prev.faqSection?.faqs || [])];
      nextFaqs[index] = { ...nextFaqs[index], [field]: value };
      return {
        ...prev,
        faqSection: {
          ...prev.faqSection,
          faqs: nextFaqs
        }
      };
    });
  };

  const handleAddFaq = () => {
    playClick();
    setFormData(prev => {
      const newFaq: FaqItem = {
        id: 'faq-' + Date.now(),
        question: 'คำถามที่พบบ่อยใหม่',
        answer: 'คำอธิบายคำตอบสำหรับคำถามนี้...'
      };
      return {
        ...prev,
        faqSection: {
          ...prev.faqSection,
          faqs: [...(prev.faqSection?.faqs || []), newFaq]
        }
      };
    });
  };

  const handleDeleteFaq = (index: number) => {
    playClick();
    setFormData(prev => {
      const nextFaqs = (prev.faqSection?.faqs || []).filter((_, i) => i !== index);
      return {
        ...prev,
        faqSection: {
          ...prev.faqSection,
          faqs: nextFaqs
        }
      };
    });
  };

  // Contact channel handlers
  const handleChannelChange = (
    index: number,
    field: keyof ContactChannel,
    value: any
  ) => {
    setFormData(prev => {
      const nextChannels = [...(prev.contactModal?.channels || [])];
      nextChannels[index] = { ...nextChannels[index], [field]: value };
      return {
        ...prev,
        contactModal: {
          ...prev.contactModal,
          channels: nextChannels
        }
      };
    });
  };

  const handleAddChannel = () => {
    playClick();
    setFormData(prev => {
      const newChannel: ContactChannel = {
        id: 'channel-' + Date.now(),
        platform: 'custom',
        label: 'ช่องทางใหม่',
        url: 'https://',
        color: '#00E5FF',
        enabled: true
      };
      return {
        ...prev,
        contactModal: {
          ...prev.contactModal,
          channels: [...(prev.contactModal?.channels || []), newChannel]
        }
      };
    });
  };

  const handleDeleteChannel = (index: number) => {
    playClick();
    setFormData(prev => {
      const nextChannels = (prev.contactModal?.channels || []).filter((_, i) => i !== index);
      return {
        ...prev,
        contactModal: {
          ...prev.contactModal,
          channels: nextChannels
        }
      };
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Save Action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-slate-900/90 to-blue-950/30 border border-cyan-500/30 shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <span>ตั้งค่าร้าน & ข้อมูลเว็บ (Branding & Content)</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                LIVE SYNC
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              แก้ไขชื่อร้าน, โลโก้, ขั้นตอนการซื้อ (ซื้อยังไง), คำถามที่พบบ่อย (FAQ), ช่องทางติดต่อ (Modal), และข้อมูลส่วนท้าย
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => handleSave()}
          disabled={isSaving}
          className="px-5 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-[0_0_20px_rgba(var(--theme-accent-rgb),0.4)] transition-all hover:scale-105 active:scale-95 cursor-pointer shrink-0"
        >
          <Save className="w-4 h-4" />
          <span>{isSaving ? 'กำลังบันทึก...' : 'บันทึกข้อมูลทั้งหมด'}</span>
        </button>
      </div>

      {/* Subtabs Navigation */}
      <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900/90 border border-white/10 overflow-x-auto">
        <button
          type="button"
          onClick={() => { playClick(); setActiveSubTab('branding'); }}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all shrink-0 cursor-pointer ${
            activeSubTab === 'branding'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>✨ ชื่อเว็บ & โลโก้ (Branding)</span>
        </button>

        <button
          type="button"
          onClick={() => { playClick(); setActiveSubTab('steps'); }}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all shrink-0 cursor-pointer ${
            activeSubTab === 'steps'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <ListOrdered className="w-3.5 h-3.5" />
          <span>1. ขั้นตอน (ซื้อยังไง)</span>
        </button>

        <button
          type="button"
          onClick={() => { playClick(); setActiveSubTab('faqs'); }}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all shrink-0 cursor-pointer ${
            activeSubTab === 'faqs'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <HelpCircle className="w-3.5 h-3.5" />
          <span>2. คำถามที่พบบ่อย (FAQ)</span>
        </button>

        <button
          type="button"
          onClick={() => { playClick(); setActiveSubTab('contact'); }}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all shrink-0 cursor-pointer ${
            activeSubTab === 'contact'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <MessageCircle className="w-3.5 h-3.5" />
          <span>3. หน้าต่างติดต่อ (Modal)</span>
        </button>

        <button
          type="button"
          onClick={() => { playClick(); setActiveSubTab('footer'); }}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all shrink-0 cursor-pointer ${
            activeSubTab === 'footer'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>4. ข้อความส่วนท้าย (Footer)</span>
        </button>
      </div>

      {/* ======================================================== */}
      {/* 0. BRANDING SUBTAB (ชื่อเว็บ & โลโก้) */}
      {/* ======================================================== */}
      {activeSubTab === 'branding' && (
        <StoreBrandingTab />
      )}

      {/* ======================================================== */}
      {/* 1. STEPS SUBTAB (ขั้นตอน / ซื้อยังไง) */}
      {/* ======================================================== */}
      {activeSubTab === 'steps' && (
        <div className="space-y-5 p-5 rounded-2xl bg-slate-900/60 border border-white/10">
          <div className="border-b border-white/10 pb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ListOrdered className="w-4 h-4 text-cyan-400" />
              <span>หัวข้อและ 4 ขั้นตอนการซื้อ (Image 1 Style)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              กำหนดข้อความของกล่อง 2x2 "ซื้อยังไง" ที่แสดงอยู่ด้านล่างตารางสินค้าหน้าแรก
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                ข้อความส่วนหัวรอง (Subtitle)
              </label>
              <input
                type="text"
                value={formData.stepsSection?.subtitle || ''}
                onChange={(e) =>
                  setFormData(prev => ({
                    ...prev,
                    stepsSection: { ...prev.stepsSection, subtitle: e.target.value }
                  }))
                }
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/10 text-white text-xs focus:border-cyan-400 focus:outline-none"
                placeholder="ขั้นตอน"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                หัวข้อหลัก (Title)
              </label>
              <input
                type="text"
                value={formData.stepsSection?.title || ''}
                onChange={(e) =>
                  setFormData(prev => ({
                    ...prev,
                    stepsSection: { ...prev.stepsSection, title: e.target.value }
                  }))
                }
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/10 text-white text-xs focus:border-cyan-400 focus:outline-none"
                placeholder="ซื้อยังไง"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            {(formData.stepsSection?.steps || []).map((step, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl bg-slate-950/80 border border-white/10 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-black text-cyan-400">
                    ขั้นตอนที่ {idx + 1}
                  </span>
                  <input
                    type="text"
                    value={step.number}
                    onChange={(e) => handleStepChange(idx, 'number', e.target.value)}
                    className="w-16 px-2 py-1 rounded-lg bg-slate-900 border border-white/10 text-cyan-300 text-center font-mono font-bold text-xs"
                    placeholder={`0${idx + 1}`}
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    ชื่อขั้นตอน
                  </label>
                  <input
                    type="text"
                    value={step.title}
                    onChange={(e) => handleStepChange(idx, 'title', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs focus:border-cyan-400 focus:outline-none"
                    placeholder="เช่น เลือกสินค้า"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    รายละเอียดคำอธิบาย
                  </label>
                  <textarea
                    rows={2}
                    value={step.description}
                    onChange={(e) => handleStepChange(idx, 'description', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-slate-300 text-xs focus:border-cyan-400 focus:outline-none"
                    placeholder="ดูรายละเอียดและจำนวนคงเหลือก่อนซื้อสินค้า"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 2. FAQS SUBTAB (คำถามที่พบบ่อย / สงสัยอะไรไหม) */}
      {/* ======================================================== */}
      {activeSubTab === 'faqs' && (
        <div className="space-y-5 p-5 rounded-2xl bg-slate-900/60 border border-white/10">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-cyan-400" />
                <span>คำถามที่พบบ่อย (FAQ Accordion)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                เพิ่ม ลบ หรือแก้ไขข้อความคำถามและคำตอบที่แสดงบนหน้าแรก
              </p>
            </div>

            <button
              type="button"
              onClick={handleAddFaq}
              className="px-3.5 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>เพิ่มคำถาม</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                ข้อความส่วนหัวรอง (Subtitle)
              </label>
              <input
                type="text"
                value={formData.faqSection?.subtitle || ''}
                onChange={(e) =>
                  setFormData(prev => ({
                    ...prev,
                    faqSection: { ...prev.faqSection, subtitle: e.target.value }
                  }))
                }
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/10 text-white text-xs focus:border-cyan-400 focus:outline-none"
                placeholder="คำถามที่พบบ่อย"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                หัวข้อหลัก (Title)
              </label>
              <input
                type="text"
                value={formData.faqSection?.title || ''}
                onChange={(e) =>
                  setFormData(prev => ({
                    ...prev,
                    faqSection: { ...prev.faqSection, title: e.target.value }
                  }))
                }
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/10 text-white text-xs focus:border-cyan-400 focus:outline-none"
                placeholder="สงสัยอะไรไหม"
              />
            </div>
          </div>

          <div className="space-y-3 pt-2">
            {(formData.faqSection?.faqs || []).map((faq, idx) => (
              <div
                key={faq.id || idx}
                className="p-4 rounded-xl bg-slate-950/80 border border-white/10 space-y-2.5 relative group"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex-1">
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                      คำถามที่ {idx + 1}
                    </label>
                    <input
                      type="text"
                      value={faq.question}
                      onChange={(e) => handleFaqChange(idx, 'question', e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs font-bold focus:border-cyan-400 focus:outline-none"
                      placeholder="คำถาม..."
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => handleDeleteFaq(idx)}
                    className="p-2 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition cursor-pointer shrink-0 mt-4"
                    title="ลบคำถามนี้"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    คำตอบ
                  </label>
                  <textarea
                    rows={2}
                    value={faq.answer}
                    onChange={(e) => handleFaqChange(idx, 'answer', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-slate-300 text-xs focus:border-cyan-400 focus:outline-none"
                    placeholder="คำตอบ..."
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 3. CONTACT MODAL SUBTAB (หน้าต่างติดต่อหลายช่องทาง) */}
      {/* ======================================================== */}
      {activeSubTab === 'contact' && (
        <div className="space-y-5 p-5 rounded-2xl bg-slate-900/60 border border-white/10">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-cyan-400" />
                <span>ช่องทางติดต่อในหน้าต่าง Modal (Image 2 Style)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                กำหนดปุ่มและลิงก์ติดต่อ เช่น Facebook, Discord, Instagram เมื่อลูกค้ากดปุ่ม "ติดต่อแอดมิน"
              </p>
            </div>

            <button
              type="button"
              onClick={handleAddChannel}
              className="px-3.5 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>เพิ่มช่องทาง</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                ชื่อร้านค้าใน Modal
              </label>
              <input
                type="text"
                value={formData.contactModal?.title || ''}
                onChange={(e) =>
                  setFormData(prev => ({
                    ...prev,
                    contactModal: { ...prev.contactModal, title: e.target.value }
                  }))
                }
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/10 text-white text-xs focus:border-cyan-400 focus:outline-none"
                placeholder="ARX STORE"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                คำบรรยายใต้ชื่อ
              </label>
              <input
                type="text"
                value={formData.contactModal?.subtitle || ''}
                onChange={(e) =>
                  setFormData(prev => ({
                    ...prev,
                    contactModal: { ...prev.contactModal, subtitle: e.target.value }
                  }))
                }
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/10 text-white text-xs focus:border-cyan-400 focus:outline-none"
                placeholder="ช่องทางติดต่อและติดตามเรา"
              />
            </div>
          </div>

          <div className="space-y-3 pt-2">
            {(formData.contactModal?.channels || []).map((ch, idx) => (
              <div
                key={ch.id || idx}
                className="p-4 rounded-xl bg-slate-950/80 border border-white/10 space-y-3"
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full" style={{ backgroundColor: ch.color || '#3b82f6' }} />
                    <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                      {ch.platform}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={ch.enabled !== false}
                        onChange={(e) => handleChannelChange(idx, 'enabled', e.target.checked)}
                        className="rounded border-white/20 text-cyan-500 focus:ring-cyan-400"
                      />
                      <span>เปิดใช้งาน</span>
                    </label>

                    <button
                      type="button"
                      onClick={() => handleDeleteChannel(idx)}
                      className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition cursor-pointer"
                      title="ลบช่องทางนี้"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                      แพลตฟอร์ม
                    </label>
                    <select
                      value={ch.platform}
                      onChange={(e) => {
                        const plat = e.target.value;
                        let color = ch.color;
                        if (plat === 'facebook') color = '#1877F2';
                        if (plat === 'discord') color = '#5865F2';
                        if (plat === 'instagram') color = '#E1306C';
                        handleChannelChange(idx, 'platform', plat);
                        if (color) handleChannelChange(idx, 'color', color);
                      }}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs focus:border-cyan-400 focus:outline-none"
                    >
                      <option value="facebook">Facebook</option>
                      <option value="discord">Discord</option>
                      <option value="instagram">Instagram</option>
                      <option value="custom">ช่องทางอื่นๆ (Custom)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                      ข้อความบนปุ่ม
                    </label>
                    <input
                      type="text"
                      value={ch.label}
                      onChange={(e) => handleChannelChange(idx, 'label', e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs focus:border-cyan-400 focus:outline-none font-bold"
                      placeholder="เช่น Facebook"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                      ลิงก์ URL
                    </label>
                    <input
                      type="text"
                      value={ch.url}
                      onChange={(e) => handleChannelChange(idx, 'url', e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-cyan-300 text-xs focus:border-cyan-400 focus:outline-none font-mono"
                      placeholder="https://discord.gg/..."
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 4. FOOTER SUBTAB (ข้อความส่วนท้าย) */}
      {/* ======================================================== */}
      {activeSubTab === 'footer' && (
        <div className="space-y-5 p-5 rounded-2xl bg-slate-900/60 border border-white/10">
          <div className="border-b border-white/10 pb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-cyan-400" />
              <span>ข้อความส่วนท้ายและป้ายแจ้งปัญหา (Footer)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              กำหนดข้อความแนะนำร้าน, ป้ายแจ้งเตือน/รายงานปัญหา, และข้อความลิขสิทธิ์
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                ข้อความแนะนำร้าน (ใต้โลโก้ ARX STORE)
              </label>
              <textarea
                rows={3}
                value={formData.footer?.description || ''}
                onChange={(e) =>
                  setFormData(prev => ({
                    ...prev,
                    footer: { ...prev.footer, description: e.target.value }
                  }))
                }
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/10 text-white text-xs focus:border-cyan-400 focus:outline-none leading-relaxed"
                placeholder="ซื้อไปแล้วกลัวใช้ไม่ได้? ไม่ต้องกังวลครับ ทุกโปรแกรมมีคลิปสอนให้..."
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  ข้อความกล่องแจ้งรายงานปัญหา
                </label>
                <input
                  type="text"
                  value={formData.footer?.reportText || ''}
                  onChange={(e) =>
                    setFormData(prev => ({
                      ...prev,
                      footer: { ...prev.footer, reportText: e.target.value }
                    }))
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/10 text-white text-xs focus:border-cyan-400 focus:outline-none"
                  placeholder="ติดต่อร้านค้าไม่ได้ หรือต้องการรายงานปัญหาร้านค้าขี้โกง? แจ้งเรื่องกับทีมงานกลาง"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  ลิงก์แจ้งเรื่องกับทีมงานกลาง
                </label>
                <input
                  type="text"
                  value={formData.footer?.reportUrl || ''}
                  onChange={(e) =>
                    setFormData(prev => ({
                      ...prev,
                      footer: { ...prev.footer, reportUrl: e.target.value }
                    }))
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/10 text-cyan-300 font-mono text-xs focus:border-cyan-400 focus:outline-none"
                  placeholder="https://discord.gg/..."
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  ข้อความลิขสิทธิ์ (Copyright)
                </label>
                <input
                  type="text"
                  value={formData.footer?.copyright || ''}
                  onChange={(e) =>
                    setFormData(prev => ({
                      ...prev,
                      footer: { ...prev.footer, copyright: e.target.value }
                    }))
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/10 text-white text-xs focus:border-cyan-400 focus:outline-none font-mono"
                  placeholder="© 2026 ARX STORE"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  หมายเหตุสกุลเงิน
                </label>
                <input
                  type="text"
                  value={formData.footer?.currencyNote || ''}
                  onChange={(e) =>
                    setFormData(prev => ({
                      ...prev,
                      footer: { ...prev.footer, currencyNote: e.target.value }
                    }))
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/10 text-slate-300 text-xs focus:border-cyan-400 focus:outline-none font-mono"
                  placeholder="ราคาทั้งหมดเป็นเงินบาท"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Save Action */}
      <div className="flex justify-end pt-2">
        <button
          type="button"
          onClick={() => handleSave()}
          disabled={isSaving}
          className="px-6 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-[0_0_20px_rgba(var(--theme-accent-rgb),0.4)] transition-all hover:scale-105 active:scale-95 cursor-pointer"
        >
          <Save className="w-4 h-4" />
          <span>{isSaving ? 'กำลังบันทึกข้อมูล...' : 'บันทึกข้อมูลทั้งหมด'}</span>
        </button>
      </div>
    </div>
  );
}
