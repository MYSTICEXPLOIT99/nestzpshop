'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useStore, DEFAULT_BGM_SETTINGS } from '@/context/StoreContext';
import { BgmSettings } from '@/types';
import { extractYouTubeId } from '@/lib/youtube';
import {
  Music,
  Radio,
  Volume2,
  VolumeX,
  Volume1,
  Disc3,
  Sparkles,
  Save,
  RotateCcw,
  CheckCircle2,
  ExternalLink,
  Headphones,
  Sliders,
  Eye,
  SlidersHorizontal,
  Loader2,
  Link2,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  AlertCircle,
  Edit3,
  X,
  Play
} from 'lucide-react';

export default function MusicTab() {
  const { bgmSettings, updateBgmSettings, playClick, playSuccess, showToast } = useStore();

  const [form, setForm] = useState<BgmSettings>(bgmSettings || DEFAULT_BGM_SETTINGS);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  
  // Auto-detection states
  const [isDetecting, setIsDetecting] = useState<boolean>(false);
  const [detectError, setDetectError] = useState<string | null>(null);
  const [detectedMeta, setDetectedMeta] = useState<{
    title: string;
    author?: string;
    thumbnail?: string | null;
    provider?: string;
  } | null>(null);
  const [showManualFields, setShowManualFields] = useState<boolean>(false);
  const lastDetectedUrlRef = useRef<string>(form.url || '');
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Sync local form state if store settings change
  useEffect(() => {
    if (bgmSettings) {
      setForm(bgmSettings);
    }
  }, [bgmSettings]);

  // Clean up debounce timer on unmount
  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    };
  }, []);

  // Instant field change & auto-save to StoreContext
  const handleFieldChange = (field: keyof BgmSettings, value: any) => {
    const updated = { ...form, [field]: value };
    setForm(updated);
    updateBgmSettings(updated, true);
    setSavedNotice('✓ บันทึกอัตโนมัติแล้ว (อัปเดตหน้าเว็บ Real-time ทันที)');
  };

  // Detect song title & metadata from link
  const detectMusic = async (urlToDetect?: string, isExplicit: boolean = false) => {
    const targetUrl = (urlToDetect !== undefined ? urlToDetect : form.url).trim();
    if (!targetUrl) {
      if (isExplicit) setDetectError('กรุณาวางลิงก์เพลงก่อนกดตรวจจับ');
      return;
    }

    // Don't re-detect if URL hasn't changed unless explicitly triggered
    if (!isExplicit && targetUrl === lastDetectedUrlRef.current && detectedMeta) {
      return;
    }

    setIsDetecting(true);
    setDetectError(null);

    try {
      const res = await fetch('/api/bgm/detect-title', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: targetUrl })
      });

      const data = await res.json();

      if (data.success && data.title) {
        const newTitle = data.title;
        const newAuthor = data.author || 'เพลงพื้นหลัง';
        
        const updated: BgmSettings = {
          ...form,
          url: targetUrl,
          title: newTitle,
          subtitle: newAuthor
        };

        setForm(updated);
        updateBgmSettings(updated, true);
        lastDetectedUrlRef.current = targetUrl;

        setDetectedMeta({
          title: newTitle,
          author: data.author,
          thumbnail: data.thumbnail,
          provider: data.provider
        });

        playSuccess?.();
        setSavedNotice(`✓ ตรวจพบชื่อเพลง: "${newTitle}" และบันทึกแล้ว`);
        showToast({
          title: 'ตรวจพบชื่อเพลงแล้ว! ✨',
          message: newTitle,
          type: 'success'
        });
      } else {
        setDetectError(data.message || 'ไม่สามารถตรวจหาชื่อเพลงจากลิงก์นี้ได้');
      }
    } catch (err) {
      setDetectError('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์เพื่อตรวจหาชื่อเพลง');
    } finally {
      setIsDetecting(false);
    }
  };

  const sanitizeMusicUrl = (url: string): string => {
    if (!url) return '';
    const trimmed = url.trim();
    const secondHttp = trimmed.indexOf('http', 8);
    if (secondHttp > 0) {
      return trimmed.substring(0, secondHttp);
    }
    return trimmed;
  };

  // Handle URL change with auto debounce detection
  const handleUrlChange = (newUrl: string) => {
    const cleaned = sanitizeMusicUrl(newUrl);
    handleFieldChange('url', cleaned);

    // Auto-detect after user finishes typing
    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    if (cleaned && (cleaned.startsWith('http://') || cleaned.startsWith('https://'))) {
      debounceTimerRef.current = setTimeout(() => {
        detectMusic(cleaned, false);
      }, 1000);
    }
  };

  // Handle Paste event for immediate auto detection
  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const pasted = e.clipboardData.getData('text')?.trim();
    if (pasted && (pasted.startsWith('http://') || pasted.startsWith('https://'))) {
      const cleaned = sanitizeMusicUrl(pasted);
      handleFieldChange('url', cleaned);
      // Immediately run detection
      setTimeout(() => {
        detectMusic(cleaned, true);
      }, 50);
    }
  };

  // Explicit Save
  const handleSave = () => {
    playClick();
    const cleanedForm = {
      ...form,
      url: sanitizeMusicUrl(form.url)
    };
    setForm(cleanedForm);
    updateBgmSettings(cleanedForm, false);
    setSavedNotice('✓ บันทึกการตั้งค่าเพลงเรียบร้อยแล้ว (อัปเดตเซิร์ฟเวอร์ & หน้าเว็บทันที)');
  };

  // Reset to default
  const handleReset = () => {
    playClick();
    if (confirm('ต้องการคืนค่าการตั้งค่าเพลงเป็นค่าเริ่มต้นใช่หรือไม่?')) {
      setForm(DEFAULT_BGM_SETTINGS);
      updateBgmSettings(DEFAULT_BGM_SETTINGS, false);
      setDetectedMeta(null);
      lastDetectedUrlRef.current = DEFAULT_BGM_SETTINGS.url;
      showToast({
        title: 'คืนค่าเริ่มต้นแล้ว',
        message: 'รีเซ็ตเพลงพื้นหลังเป็นค่าเริ่มต้นเรียบร้อย',
        type: 'info'
      });
    }
  };

  const detectedYtId = extractYouTubeId(form.url);

  return (
    <div className="space-y-2.5">
      {/* 1. Header Banner */}
      <div className="rounded-xl p-2.5 sm:p-3 bg-gradient-to-r from-cyan-950/40 via-blue-950/30 to-purple-950/40 border border-cyan-500/30 shadow-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-500/40 text-cyan-400 flex items-center justify-center shadow-md shadow-cyan-500/20 shrink-0">
              <Music className="w-4 h-4 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-xs sm:text-sm font-black text-white tracking-wide">
                  ระบบเพลงพื้นหลัง (Background Music - BGM)
                </h2>
                <span className="text-[8.5px] px-1.5 py-0.2 rounded-full font-bold uppercase tracking-wider bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                  REAL-TIME
                </span>
              </div>
              <p className="text-[10px] text-slate-300 mt-0.5 leading-tight">
                เพียงแค่วางลิงก์ YouTube หรือไฟล์เสียง ระบบจะตรวจจับชื่อเพลงและศิลปินให้อัตโนมัติทันที
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0 self-start sm:self-auto">
            <button
              type="button"
              onClick={handleReset}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-white/10 text-[11px] font-semibold flex items-center gap-1 transition cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>คืนค่าเริ่มต้น</span>
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-3 py-1 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-[11px] shadow-md shadow-cyan-500/30 flex items-center gap-1 transition cursor-pointer"
            >
              <Save className="w-3 h-3" />
              <span>บันทึกการตั้งค่า</span>
            </button>
          </div>
        </div>

        {savedNotice && (
          <div className="mt-2 py-0.5 px-2 rounded-md bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] font-medium flex items-center gap-1 animate-in fade-in duration-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>{savedNotice}</span>
          </div>
        )}
      </div>

      {/* 2. Main Layout: Settings & Live Preview */}
      <div className="flex flex-col xl:flex-row items-start gap-2.5">
        
        {/* Left Column: Form Settings */}
        <div className="flex-1 w-full space-y-2.5">
          
          {/* Card: Master Enable / Disable */}
          <div className="p-2.5 sm:p-3 rounded-xl bg-slate-950/80 border border-white/10 shadow-md space-y-2">
            <div className="flex items-center justify-between gap-2.5">
              <div className="flex items-center gap-2.5">
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors shrink-0 ${
                  form.enabled
                    ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                    : 'bg-slate-900 text-slate-500 border border-white/5'
                }`}>
                  <Radio className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white">
                    เปิดใช้งานเพลงพื้นหลังบนเว็บไซต์
                  </h3>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    เมื่อเปิดใช้งาน จะมี Widget เครื่องเล่นเพลงลอยอยู่ที่มุมจอของผู้เข้าชมทุกคน
                  </p>
                </div>
              </div>

              {/* Compact Toggle Switch */}
              <button
                type="button"
                onClick={() => {
                  playClick();
                  handleFieldChange('enabled', !form.enabled);
                }}
                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border border-transparent transition-colors duration-200 ease-in-out focus:outline-none items-center ${
                  form.enabled ? 'bg-cyan-500 shadow-[0_0_10px_rgba(var(--theme-accent-rgb),0.5)]' : 'bg-slate-800'
                }`}
                aria-label="เปิด/ปิดเพลงพื้นหลัง"
              >
                <span
                  className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition duration-200 ease-in-out ${
                    form.enabled ? 'translate-x-4.5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Card: Music Link & Auto Detection (PRIMARY SECTION) */}
          <div className="p-2.5 sm:p-3 rounded-xl bg-slate-950/80 border border-cyan-500/30 shadow-lg shadow-cyan-950/20 space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between pb-2 border-b border-white/5">
              <div className="flex items-center gap-1.5">
                <Disc3 className="w-3.5 h-3.5 text-cyan-400 animate-[spin_6s_linear_infinite]" />
                <h3 className="text-xs font-bold text-white">
                  ใส่ลิงก์เพลง & ตรวจจับชื่ออัตโนมัติ (Music Link & Auto-Detect)
                </h3>
              </div>
              <span className="text-[10px] text-cyan-400 font-mono flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-cyan-300" />
                <span>ใส่แค่ลิงก์ ระบบตรวจจับชื่อให้อัตโนมัติ</span>
              </span>
            </div>

            {/* Main Music URL Input */}
            <div className="space-y-1.5">
              <label className="block text-[10.5px] font-bold text-slate-200 flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <Link2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>ลิงก์เพลง (Music Link / YouTube URL):</span>
                </span>
                <span className="text-[9.5px] text-emerald-400 font-medium">
                  ✓ รองรับ YouTube (MV, คลิป, Shorts) และ .mp3
                </span>
              </label>

              <div className="flex flex-col sm:flex-row items-stretch gap-1.5">
                <div className="relative flex-1">
                  <input
                    type="text"
                    required
                    value={form.url}
                    onChange={(e) => handleUrlChange(e.target.value)}
                    onPaste={handlePaste}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        detectMusic(form.url, true);
                      }
                    }}
                    placeholder="วางลิงก์ เช่น https://www.youtube.com/watch?v=... หรือ https://youtu.be/..."
                    className="w-full pl-8 pr-8 py-2 rounded-lg bg-slate-900 border border-cyan-500/40 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 focus:outline-none text-white text-xs font-mono transition shadow-inner placeholder:text-slate-500"
                  />
                  <div className="absolute left-2.5 top-1/2 -translate-y-1/2 text-cyan-400/70 pointer-events-none">
                    <Music className="w-3.5 h-3.5" />
                  </div>
                  {form.url && (
                    <button
                      type="button"
                      onClick={() => handleFieldChange('url', '')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition p-0.5"
                      title="ล้างลิงก์"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => detectMusic(form.url, true)}
                  disabled={isDetecting || !form.url.trim()}
                  className="px-3.5 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 font-black text-xs shadow-md shadow-cyan-500/20 flex items-center justify-center gap-1.5 transition cursor-pointer shrink-0"
                >
                  {isDetecting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>กำลังตรวจจับ...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>ตรวจจับชื่อเพลง</span>
                    </>
                  )}
                </button>
              </div>

              {detectError && (
                <div className="py-1 px-2.5 rounded-md bg-rose-500/15 border border-rose-500/30 text-rose-300 text-[10.5px] flex items-center gap-1.5 animate-in fade-in duration-200">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                  <span>{detectError}</span>
                </div>
              )}

              <p className="text-[10px] text-slate-400 leading-normal">
                💡 <strong>เพียงแค่วางลิงก์เพลง:</strong> ระบบจะค้นหาชื่อเพลงและศิลปินมาใส่ให้ทันทีอัตโนมัติ โดยที่คุณไม่ต้องพิมพ์ชื่อเพลงเอง
              </p>
            </div>

            {/* Detected Song Showcase Card */}
            {(form.title || detectedMeta || detectedYtId) && (
              <div className="p-2.5 rounded-xl bg-slate-900/90 border border-cyan-500/30 shadow-md relative overflow-hidden space-y-2">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="font-bold text-cyan-400 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-cyan-300" />
                    <span>ข้อมูลเพลงที่ตรวจพบ (Detected Song):</span>
                  </span>
                  <div className="flex items-center gap-2">
                    {detectedYtId && (
                      <span className="font-mono text-[9.5px] px-1.5 py-0.2 rounded bg-cyan-950/80 border border-cyan-500/30 text-cyan-300">
                        YouTube ID: {detectedYtId}
                      </span>
                    )}
                    {form.url && (
                      <a
                        href={form.url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[9.5px] text-slate-400 hover:text-cyan-300 flex items-center gap-0.5 transition"
                      >
                        <span>เปิดดูลิงก์</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-black/40 p-2 rounded-lg border border-white/5">
                  {/* Thumbnail / Disc Icon */}
                  {detectedMeta?.thumbnail ? (
                    <div className="relative w-12 h-12 rounded-lg overflow-hidden shrink-0 border border-cyan-500/40 shadow-sm bg-black">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={detectedMeta.thumbnail}
                        alt="Music Thumbnail"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="w-10 h-10 rounded-lg bg-cyan-950/60 border border-cyan-500/40 text-cyan-400 flex items-center justify-center shrink-0 shadow-[0_0_12px_rgba(var(--theme-accent-rgb),0.2)]">
                      <Disc3 className="w-5 h-5 animate-[spin_4s_linear_infinite]" />
                    </div>
                  )}

                  {/* Song Title & Subtitle */}
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-black text-white truncate flex items-center gap-1">
                      <span className="truncate">{form.title || 'ไม่พบชื่อเพลง'}</span>
                    </div>
                    <div className="text-[10px] text-cyan-400 font-medium truncate mt-0.5">
                      {form.subtitle || detectedMeta?.author || 'เพลงพื้นหลัง'}
                    </div>
                  </div>

                  {/* Re-detect button */}
                  <button
                    type="button"
                    onClick={() => detectMusic(form.url, true)}
                    disabled={isDetecting}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-cyan-300 transition shrink-0"
                    title="ตรวจจับชื่อใหม่อีกครั้ง"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isDetecting ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>
            )}

            {/* Optional Manual Override Toggle */}
            <div className="pt-1 border-t border-white/5">
              <button
                type="button"
                onClick={() => setShowManualFields(!showManualFields)}
                className="text-[10.5px] font-semibold text-slate-400 hover:text-cyan-300 flex items-center gap-1 transition cursor-pointer"
              >
                <Edit3 className="w-3 h-3" />
                <span>{showManualFields ? 'ซ่อนการแก้ไขชื่อเพลงด้วยตนเอง' : 'ต้องการแก้ไขชื่อเพลงหรือข้อความกำกับเอง? (ทางเลือก / ปรับแต่งพิเศษ)'}</span>
                {showManualFields ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>

              {showManualFields && (
                <div className="mt-2 space-y-2 p-2.5 rounded-lg bg-slate-900/60 border border-white/5 animate-in fade-in duration-200">
                  <p className="text-[9.5px] text-slate-400">
                    * โดยปกติระบบจะตรวจจับชื่อเพลงจากลิงก์ให้อัตโนมัติ หากต้องการระบุชื่อเฉพาะตามต้องการ สามารถแก้ไขในช่องด้านล่างนี้ได้:
                  </p>

                  {/* Track Title */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-300 mb-0.5">
                      ชื่อเพลง / ศิลปิน (Track Title):
                    </label>
                    <input
                      type="text"
                      value={form.title}
                      onChange={(e) => handleFieldChange('title', e.target.value)}
                      placeholder="เช่น Sexski - YSL GIRL Feat MEYOU Official MV"
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 focus:border-cyan-400 focus:outline-none text-white text-xs font-bold transition"
                    />
                  </div>

                  {/* Subtitle / Label */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-300 mb-0.5">
                      ข้อความกำกับ (Subtitle):
                    </label>
                    <input
                      type="text"
                      value={form.subtitle}
                      onChange={(e) => handleFieldChange('subtitle', e.target.value)}
                      placeholder="เพลงพื้นหลัง"
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 focus:border-cyan-400 focus:outline-none text-white text-xs transition"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Card: Volume & Playback Controls */}
          <div className="p-2.5 sm:p-3 rounded-xl bg-slate-950/80 border border-white/10 shadow-md space-y-2.5">
            <div className="flex items-center gap-1.5 pb-2 border-b border-white/5">
              <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
              <h3 className="text-xs font-bold text-white">
                ระดับเสียง & พฤติกรรมการเล่นเพลง (Playback & Volume Settings)
              </h3>
            </div>

            {/* Volume Slider */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10.5px] font-bold text-slate-300 flex items-center gap-1">
                  <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>ระดับเสียงเริ่มต้น (Default Volume):</span>
                </label>
                <span className="text-xs font-black font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.2 rounded border border-cyan-500/20">
                  {form.volume}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={form.volume}
                onChange={(e) => handleFieldChange('volume', Number(e.target.value))}
                className="w-full h-1.5 bg-slate-900 rounded-lg appearance-none cursor-pointer accent-cyan-400 hover:accent-cyan-300 transition"
              />
              <div className="flex justify-between text-[9px] text-slate-500 font-mono mt-0.5">
                <span>0% (ปิดเสียง)</span>
                <span>25% (แนะนำ)</span>
                <span>50%</span>
                <span>100% (ดังสุด)</span>
              </div>
            </div>

            {/* Behavior Toggles Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1.5 border-t border-white/5">
              {/* Autoplay Toggle */}
              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/60 border border-white/5">
                <div>
                  <div className="text-[11px] font-bold text-white">เล่นอัตโนมัติ (Autoplay)</div>
                  <div className="text-[9px] text-slate-400">เริ่มเล่นทันทีเมื่อเข้าชมเว็บ</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleFieldChange('autoplay', !form.autoplay)}
                  className={`relative inline-flex h-4.5 w-8 shrink-0 cursor-pointer rounded-full border border-transparent transition-colors duration-200 items-center ${
                    form.autoplay ? 'bg-cyan-500' : 'bg-slate-800'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-sm transition duration-200 ${
                      form.autoplay ? 'translate-x-4' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>

              {/* Loop Toggle */}
              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/60 border border-white/5">
                <div>
                  <div className="text-[11px] font-bold text-white">เล่นวนซ้ำ (Loop Audio)</div>
                  <div className="text-[9px] text-slate-400">เล่นซ้ำต่อเนื่องเมื่อเพลงจบ</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleFieldChange('loop', !form.loop)}
                  className={`relative inline-flex h-4.5 w-8 shrink-0 cursor-pointer rounded-full border border-transparent transition-colors duration-200 items-center ${
                    form.loop ? 'bg-cyan-500' : 'bg-slate-800'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-sm transition duration-200 ${
                      form.loop ? 'translate-x-4' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>

              {/* Visualizer Toggle */}
              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/60 border border-white/5">
                <div>
                  <div className="text-[11px] font-bold text-white">คลื่นเสียง Equalizer</div>
                  <div className="text-[9px] text-slate-400">แสดงแท่งกราฟเสียงเต้นตามจังหวะ</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleFieldChange('showVisualizer', !form.showVisualizer)}
                  className={`relative inline-flex h-4.5 w-8 shrink-0 cursor-pointer rounded-full border border-transparent transition-colors duration-200 items-center ${
                    form.showVisualizer ? 'bg-cyan-500' : 'bg-slate-800'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-sm transition duration-200 ${
                      form.showVisualizer ? 'translate-x-4' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>

              {/* Widget Position Picker */}
              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/60 border border-white/5">
                <div>
                  <div className="text-[11px] font-bold text-white">ตำแหน่งวิดเจ็ต</div>
                  <div className="text-[9px] text-slate-400">เลือกมุมแสดงผลบนจอ</div>
                </div>
                <select
                  value={form.position}
                  onChange={(e) => handleFieldChange('position', e.target.value)}
                  className="px-2 py-0.5 rounded-md bg-black/60 border border-slate-700 text-[10.5px] text-white focus:outline-none focus:border-cyan-400 font-bold cursor-pointer"
                >
                  <option value="bottom-left">มุมซ้ายล่าง (แนะนำ)</option>
                  <option value="bottom-right">มุมขวาล่าง</option>
                </select>
              </div>
            </div>
          </div>

        </div>

        {/* Right Column: Live Widget Preview */}
        <div className="w-full xl:w-80 shrink-0 space-y-2.5">
          <div className="p-2.5 sm:p-3 rounded-xl bg-slate-950/80 border border-white/10 shadow-md space-y-2.5">
            <div className="flex items-center justify-between pb-2 border-b border-white/5">
              <div className="flex items-center gap-1.5 text-white font-bold text-xs">
                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                <span>ตัวอย่างหน้าตาจริง (Live Preview)</span>
              </div>
              <span className={`w-1.5 h-1.5 rounded-full ${form.enabled ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`} />
            </div>

            <p className="text-[10px] text-slate-400 leading-normal">
              เครื่องเล่นเพลงลอยตัวดีไซน์กระจก Cyber Glassmorphism ปรากฏที่มุมจอของผู้ใช้:
            </p>

            {/* Widget Preview Mockup Card */}
            <div className="p-2.5 rounded-xl bg-[color:var(--arx-dk-090e1b)] border border-cyan-500/40 shadow-lg relative space-y-2">
              <div className="absolute -top-[1px] left-4 right-4 h-[1px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent pointer-events-none" />

              {/* Top Row */}
              <div className="flex items-center justify-between gap-1.5 pb-1.5 border-b border-white/5">
                <div className="flex items-center gap-1.5">
                  <div className="relative w-5 h-5 rounded-md bg-cyan-950/60 border border-cyan-500/40 text-cyan-400 flex items-center justify-center shrink-0">
                    <span className="absolute -top-0.5 -left-0.5 w-1.5 h-1.5 rounded-full bg-cyan-300 shadow-[0_0_6px_#22d3ee] animate-pulse" />
                    <Music className="w-2.5 h-2.5" />
                  </div>
                  <span className="text-[9px] font-bold tracking-wider text-slate-400 uppercase truncate">
                    {form.subtitle || 'เพลงพื้นหลัง'}
                  </span>
                </div>

                {form.showVisualizer && (
                  <div className="flex items-end gap-[2px] h-2.5 px-0.5">
                    <span className="w-[1.5px] h-2.5 rounded-full bg-cyan-400 animate-[bounce_0.6s_ease-in-out_infinite]" />
                    <span className="w-[1.5px] h-3 rounded-full bg-cyan-300 animate-[bounce_0.8s_ease-in-out_0.2s_infinite]" />
                    <span className="w-[1.5px] h-2 rounded-full bg-cyan-400 animate-[bounce_0.5s_ease-in-out_0.1s_infinite]" />
                    <span className="w-[1.5px] h-2.5 rounded-full bg-cyan-200 animate-[bounce_0.7s_ease-in-out_0.3s_infinite]" />
                  </div>
                )}
              </div>

              {/* Track Title */}
              <div className="min-w-0">
                <div className="text-[11px] font-bold text-white truncate">
                  {form.title || 'Sexski - YSL GIRL Feat MEYOU Official MV'}
                </div>
              </div>

              {/* Volume Slider */}
              <div className="flex items-center gap-1.5 pt-1 border-t border-white/5">
                <Volume2 className="w-3 h-3 text-cyan-400 shrink-0" />
                <span className="text-[9.5px] text-slate-400 font-semibold shrink-0">เสียง</span>
                <div className="flex-1 h-1 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-cyan-400 rounded-full"
                    style={{ width: `${form.volume}%` }}
                  />
                </div>
                <span className="text-[9px] font-mono text-slate-400 shrink-0">
                  {form.volume}%
                </span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
