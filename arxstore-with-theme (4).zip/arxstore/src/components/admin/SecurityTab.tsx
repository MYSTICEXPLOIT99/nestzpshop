'use client';

import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Zap,
  Activity,
  AlertTriangle,
  RotateCw,
  Terminal,
  Database,
  Code,
  FileCode,
  Lock,
  Globe,
  Radio,
  Clock,
  CheckCircle2,
  XCircle,
  Eye,
  Server
} from 'lucide-react';

interface SecurityLog {
  id: string;
  timestamp: string;
  ip: string;
  method: string;
  path: string;
  threatType: string;
  action: string;
  riskScore: number;
  details: string;
}

interface SecurityMetrics {
  totalAttacksBlocked: number;
  activeRateLimits: number;
  activeQuarantinedIPs: number;
  recentLogs: SecurityLog[];
  threatCounters: Record<string, number>;
  wafUptime: number;
}

export function SecurityTab() {
  const [metrics, setMetrics] = useState<SecurityMetrics | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [simulating, setSimulating] = useState<string | null>(null);
  const [simResult, setSimResult] = useState<{ test: string; status: number; text: string } | null>(null);

  // Anti-DevTools Configuration State
  const [devtoolSettings, setDevtoolSettings] = useState({
    enabled: true,
    blockF12: true,
    blockRightClick: true,
    detectWindowResize: true,
    debuggerTrap: true,
    clearConsole: true,
    adminBypass: true
  });
  const [isSavingDevtools, setIsSavingDevtools] = useState(false);
  const [saveDevtoolsSuccess, setSaveDevtoolsSuccess] = useState(false);

  const fetchMetrics = async () => {
    setIsLoading(true);
    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
      const res = await fetch('/api/admin/security', {
        headers: token ? { 'x-session-token': token } : {}
      });
      const json = await res.json();
      if (json.success && json.metrics) {
        setMetrics(json.metrics);
      }
      if (json.success && json.securitySettings) {
        setDevtoolSettings(json.securitySettings);
      }
    } catch (e) {
      console.error('Failed to fetch security metrics:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveDevtoolSettings = async () => {
    setIsSavingDevtools(true);
    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
      const res = await fetch('/api/admin/security', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-session-token': token } : {})
        },
        body: JSON.stringify({
          action: 'update_settings',
          settings: devtoolSettings
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setSaveDevtoolsSuccess(true);
        setTimeout(() => setSaveDevtoolsSuccess(false), 2500);
        if (typeof window !== 'undefined') {
          localStorage.setItem('arx_antidevtool_settings', JSON.stringify(devtoolSettings));
          window.dispatchEvent(new CustomEvent('arx:shield:change', { detail: devtoolSettings }));
        }
      }
    } catch (e) {
      console.error('Failed to save devtool settings:', e);
    } finally {
      setIsSavingDevtools(false);
    }
  };

  const handleTestDevtoolsAlert = () => {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('arx:shield:trigger'));
    }
  };

  useEffect(() => {
    fetchMetrics();
    if (!autoRefresh) return;
    const interval = setInterval(fetchMetrics, 4000);
    return () => clearInterval(interval);
  }, [autoRefresh]);

  const handleSimulateAttack = async (type: 'sqli' | 'xss' | 'path' | 'scanner' | 'flood') => {
    setSimulating(type);
    setSimResult(null);

    try {
      let targetUrl = '/';
      let options: RequestInit = { method: 'GET' };

      if (type === 'sqli') {
        targetUrl = '/?s=' + encodeURIComponent('union select 1,2,3 from users--');
      } else if (type === 'xss') {
        targetUrl = '/?q=' + encodeURIComponent('<script>alert("XSS")</script>');
      } else if (type === 'path') {
        targetUrl = '/.env';
      } else if (type === 'scanner') {
        targetUrl = '/';
        options = {
          headers: {
            'User-Agent': 'sqlmap/1.6.8#stable'
          }
        };
      } else if (type === 'flood') {
        targetUrl = '/api/discord-webhook';
        options = {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ webhookUrl: 'invalid' })
        };
      }

      const res = await fetch(targetUrl, options);
      const text = await res.text();
      setSimResult({
        test: type.toUpperCase(),
        status: res.status,
        text: `Status: ${res.status} (${res.status === 403 || res.status === 429 ? '✅ WAF บล็อกสำเร็จ' : 'Response code'})`
      });

      // Refresh metrics immediately to show new log
      setTimeout(fetchMetrics, 500);
    } catch (err: any) {
      setSimResult({
        test: type.toUpperCase(),
        status: 0,
        text: 'Blocked / Network intercept: ' + err.message
      });
    } finally {
      setSimulating(null);
    }
  };

  const threatLabels: Record<string, { label: string; icon: any; color: string }> = {
    SQL_INJECTION: { label: 'SQL Injection', icon: Database, color: 'text-rose-400 bg-rose-500/10 border-rose-500/30' },
    XSS: { label: 'Cross-Site Scripting (XSS)', icon: Code, color: 'text-amber-400 bg-amber-500/10 border-amber-500/30' },
    PATH_TRAVERSAL: { label: 'Path Traversal / LFI', icon: FileCode, color: 'text-orange-400 bg-orange-500/10 border-orange-500/30' },
    COMMAND_INJECTION: { label: 'Command Injection', icon: Terminal, color: 'text-red-400 bg-red-500/10 border-red-500/30' },
    MALICIOUS_SCANNER: { label: 'Exploit Scanner / Bot', icon: Eye, color: 'text-purple-400 bg-purple-500/10 border-purple-500/30' },
    RATE_LIMIT_EXCEEDED: { label: 'Rate Limit (กันยิง Flood)', icon: Zap, color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/30' },
    CSRF_BLOCKED: { label: 'CSRF Origin Mismatch', icon: Globe, color: 'text-blue-400 bg-blue-500/10 border-blue-500/30' },
    BRUTE_FORCE: { label: 'Brute Force Password', icon: Lock, color: 'text-pink-400 bg-pink-500/10 border-pink-500/30' },
    SSRF_BLOCKED: { label: 'SSRF Attack Blocked', icon: Server, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' }
  };

  return (
    <div className="space-y-3 sm:space-y-3.5">
      
      {/* 1. Header & Shield Status Banner */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-slate-950/80 border border-rose-500/30 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-rose-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3.5 relative z-10">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shadow-md shadow-rose-500/20 shrink-0">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 mb-0.5">
                <span className="px-2 py-0.2 rounded-full text-[9.5px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  ARX CYBERSHIELD ACTIVE · 100% PROTECTED
                </span>
                <span className="text-[10px] text-slate-500 font-mono">v2.5 Enterprise WAF</span>
              </div>
              <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                ศูนย์บัญชาการความปลอดภัย & ระบบป้องกันการยิง (WAF Security Console)
              </h2>
              <p className="text-[11px] text-slate-300 mt-0.5 max-w-2xl leading-relaxed">
                ระบบตรวจจับและสกัดกั้นการโจมตีอัตโนมัติ: ป้องกัน DDoS/HTTP Flood, บอทสแปม, SQLi, XSS, CSRF, SSRF, Path Traversal และ Brute Force เรียลไทม์
              </p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-bold border transition flex items-center gap-1.5 ${
                autoRefresh
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : 'bg-slate-900 text-slate-400 border-white/10 hover:text-white'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Auto Refresh: {autoRefresh ? 'ON' : 'OFF'}</span>
            </button>

            <button
              type="button"
              onClick={fetchMetrics}
              disabled={isLoading}
              className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-white/10 text-xs font-bold flex items-center gap-1.5 transition"
            >
              <RotateCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              <span>อัปเดต</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Real-Time Metrics KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-2.5">
        {/* KPI 1 */}
        <div className="p-2.5 sm:p-3 rounded-xl bg-slate-950/70 border border-rose-500/30 shadow-md min-h-[54px]">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">ยอดสกัดกั้นทั้งหมด</span>
            <div className="w-7 h-7 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-black text-white font-mono">
            {metrics?.totalAttacksBlocked ?? 0}
            <span className="text-[10px] font-normal text-rose-400 ml-1">ครั้ง</span>
          </div>
          <p className="text-[9.5px] text-slate-400 mt-0.5">สกัดกั้นสำเร็จ 100% ปลอดภัย</p>
        </div>

        {/* KPI 2 */}
        <div className="p-2.5 sm:p-3 rounded-xl bg-slate-950/70 border border-amber-500/30 shadow-md min-h-[54px]">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">จำกัดความถี่ (Rate Limits)</span>
            <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Zap className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-black text-amber-400 font-mono">
            {metrics?.activeRateLimits ?? 0}
            <span className="text-[10px] font-normal text-slate-400 ml-1">IP</span>
          </div>
          <p className="text-[9.5px] text-slate-400 mt-0.5">IP ที่ส่งคำขอถี่เกินเกณฑ์</p>
        </div>

        {/* KPI 3 */}
        <div className="p-2.5 sm:p-3 rounded-xl bg-slate-950/70 border border-purple-500/30 shadow-md min-h-[54px]">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">กักกันชั่วคราว (Quarantined)</span>
            <div className="w-7 h-7 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Lock className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-black text-purple-300 font-mono">
            {metrics?.activeQuarantinedIPs ?? 0}
            <span className="text-[10px] font-normal text-slate-400 ml-1">IP</span>
          </div>
          <p className="text-[9.5px] text-slate-400 mt-0.5">Risk Score {'>'}= 75 กักกัน 10 นาที</p>
        </div>

        {/* KPI 4 */}
        <div className="p-2.5 sm:p-3 rounded-xl bg-slate-950/70 border border-cyan-500/30 shadow-md min-h-[54px]">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">เวลาปกป้องระบบ (Uptime)</span>
            <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Clock className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-base sm:text-lg font-black text-cyan-300 font-mono">
            {Math.floor((metrics?.wafUptime ?? 0) / 60)}m {(metrics?.wafUptime ?? 0) % 60}s
          </div>
          <p className="text-[9.5px] text-emerald-400 mt-0.5 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            ทำงานต่อเนื่องไม่มีสะดุด
          </p>
        </div>
      </div>

      {/* 🛡️ ANTI-DEVTOOLS & INSPECT PROTECTION CONTROLS */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-slate-950/80 border border-rose-500/30 shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-2.5 border-b border-white/5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                <span>ระบบป้องกัน Anti-DevTools & ป้องกันการแกะโค้ด (Anti-Inspect Suite)</span>
                <span className={`px-2 py-0.2 rounded-full text-[9px] font-mono font-bold ${devtoolSettings.enabled ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'}`}>
                  {devtoolSettings.enabled ? '🟢 กำลังทำงาน' : '⚪ ปิดใช้งาน'}
                </span>
              </h3>
              <p className="text-[10.5px] text-slate-400 mt-0.5">
                บล็อก F12, คลิกขวา, ตรวจจับการเปิดหน้าต่าง Console / Inspect แบบเรียลไทม์ และระบบ Debugger Trap
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleTestDevtoolsAlert}
              className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-rose-500/30 text-rose-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              title="ทดสอบแสดงหน้าต่างแจ้งเตือน Anti-Devtool"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>ทดสอบแจ้งเตือน</span>
            </button>

            <button
              type="button"
              onClick={handleSaveDevtoolSettings}
              disabled={isSavingDevtools}
              className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-rose-600/30 cursor-pointer disabled:opacity-50"
            >
              {saveDevtoolsSuccess ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                  <span>บันทึกแล้ว!</span>
                </>
              ) : (
                <>
                  <RotateCw className={`w-3.5 h-3.5 ${isSavingDevtools ? 'animate-spin' : ''}`} />
                  <span>บันทึกการตั้งค่า</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Toggles Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {/* Master Switch */}
          <div className={`p-2.5 rounded-xl border transition flex items-center justify-between ${devtoolSettings.enabled ? 'bg-rose-950/20 border-rose-500/40' : 'bg-slate-900/60 border-white/5'}`}>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                <span>เปิดใช้งาน Anti-Devtools</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">สวิตช์หลักควบคุมระบบป้องกันทั้งหมด</div>
            </div>
            <button
              type="button"
              onClick={() => setDevtoolSettings(s => ({ ...s, enabled: !s.enabled }))}
              className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer ${devtoolSettings.enabled ? 'bg-rose-600' : 'bg-slate-700'}`}
            >
              <div className={`w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.5 ${devtoolSettings.enabled ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>

          {/* Block F12 */}
          <div className={`p-2.5 rounded-xl border transition flex items-center justify-between ${devtoolSettings.blockF12 ? 'bg-slate-900/80 border-cyan-500/40' : 'bg-slate-900/40 border-white/5'}`}>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                <span>บล็อก F12 & คีย์ลัดตรวจสอบ</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">F12, Ctrl+Shift+I/J/C, Ctrl+U/S/P</div>
            </div>
            <button
              type="button"
              onClick={() => setDevtoolSettings(s => ({ ...s, blockF12: !s.blockF12 }))}
              className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer ${devtoolSettings.blockF12 ? 'bg-cyan-600' : 'bg-slate-700'}`}
            >
              <div className={`w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.5 ${devtoolSettings.blockF12 ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>

          {/* Block Right Click */}
          <div className={`p-2.5 rounded-xl border transition flex items-center justify-between ${devtoolSettings.blockRightClick ? 'bg-slate-900/80 border-purple-500/40' : 'bg-slate-900/40 border-white/5'}`}>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-purple-400" />
                <span>บล็อกการคลิกขวา (Context Menu)</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">ป้องกันการกด Inspect ผ่านเมนูคลิกขวา</div>
            </div>
            <button
              type="button"
              onClick={() => setDevtoolSettings(s => ({ ...s, blockRightClick: !s.blockRightClick }))}
              className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer ${devtoolSettings.blockRightClick ? 'bg-purple-600' : 'bg-slate-700'}`}
            >
              <div className={`w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.5 ${devtoolSettings.blockRightClick ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>

          {/* Detect Window Resize */}
          <div className={`p-2.5 rounded-xl border transition flex items-center justify-between ${devtoolSettings.detectWindowResize ? 'bg-slate-900/80 border-amber-500/40' : 'bg-slate-900/40 border-white/5'}`}>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-amber-400" />
                <span>ตรวจจับหน้าต่าง DevTools อัตโนมัติ</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">ตรวจจับขนาดช่องว่างหน้าต่าง Docked DevTools</div>
            </div>
            <button
              type="button"
              onClick={() => setDevtoolSettings(s => ({ ...s, detectWindowResize: !s.detectWindowResize }))}
              className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer ${devtoolSettings.detectWindowResize ? 'bg-amber-600' : 'bg-slate-700'}`}
            >
              <div className={`w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.5 ${devtoolSettings.detectWindowResize ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>

          {/* Debugger Trap */}
          <div className={`p-2.5 rounded-xl border transition flex items-center justify-between ${devtoolSettings.debuggerTrap ? 'bg-slate-900/80 border-rose-500/40' : 'bg-slate-900/40 border-white/5'}`}>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <Code className="w-3.5 h-3.5 text-rose-400" />
                <span>ระบบ Debugger Trap</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">หยุดโค้ดทันทีเมื่อตรวจพบ Breakpoint / Debug</div>
            </div>
            <button
              type="button"
              onClick={() => setDevtoolSettings(s => ({ ...s, debuggerTrap: !s.debuggerTrap }))}
              className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer ${devtoolSettings.debuggerTrap ? 'bg-rose-600' : 'bg-slate-700'}`}
            >
              <div className={`w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.5 ${devtoolSettings.debuggerTrap ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>

          {/* Admin Bypass */}
          <div className={`p-2.5 rounded-xl border transition flex items-center justify-between ${devtoolSettings.adminBypass ? 'bg-slate-900/80 border-emerald-500/40' : 'bg-slate-900/40 border-white/5'}`}>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>อนุญาตบัญชี Admin (Admin Bypass)</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">ยกเว้นผู้ดูแลระบบให้กด F12 / ตรวจสอบได้</div>
            </div>
            <button
              type="button"
              onClick={() => setDevtoolSettings(s => ({ ...s, adminBypass: !s.adminBypass }))}
              className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer ${devtoolSettings.adminBypass ? 'bg-emerald-600' : 'bg-slate-700'}`}
            >
              <div className={`w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.5 ${devtoolSettings.adminBypass ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>
        </div>
      </div>

      {/* 3. Threat Counters Breakdown */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-slate-950/80 border border-white/10 space-y-2.5">
        <h3 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
          <span>สถิติการโจมตีแยกตามประเภทภัยคุกคาม (Threat Category Counters)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {Object.entries(threatLabels).map(([key, item]) => {
            const count = metrics?.threatCounters?.[key] ?? 0;
            const IconComp = item.icon;
            return (
              <div key={key} className={`p-2.5 rounded-lg border flex items-center justify-between ${item.color}`}>
                <div className="flex items-center gap-2">
                  <IconComp className="w-3.5 h-3.5 shrink-0" />
                  <span className="text-[11px] font-bold text-white">{item.label}</span>
                </div>
                <span className="font-mono font-black text-xs px-1.5 py-0.2 rounded-md bg-black/40 text-white">
                  {count}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Interactive Threat Simulation Testing Suite (ปุ่มทดสอบยิงเจาะระบบ) */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-slate-950/80 border border-cyan-500/30 space-y-2.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>เครื่องมือจำลองการโจมตีเพื่อทดสอบเกราะป้องกัน (WAF Simulator)</span>
            </h3>
            <p className="text-[10.5px] text-slate-400 mt-0.5">
              คลิกปุ่มเพื่อส่ง Payload จำลองเข้าเซิร์ฟเวอร์ และดูผลการสกัดกั้นแบบสดๆ ทันที
            </p>
          </div>

          {simResult && (
            <div className="px-2.5 py-1 rounded-lg bg-slate-900 border border-white/20 text-[11px] font-mono text-cyan-300 flex items-center gap-1.5">
              {simResult.status === 403 || simResult.status === 429 ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <XCircle className="w-3.5 h-3.5 text-rose-400" />
              )}
              <span>{simResult.text}</span>
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            disabled={simulating !== null}
            onClick={() => handleSimulateAttack('sqli')}
            className="px-2.5 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/40 text-xs font-bold flex items-center gap-1.5 transition disabled:opacity-50"
          >
            <Database className="w-3.5 h-3.5" />
            <span>{simulating === 'sqli' ? 'กำลังยิง...' : 'ทดสอบ SQL Injection'}</span>
          </button>

          <button
            type="button"
            disabled={simulating !== null}
            onClick={() => handleSimulateAttack('xss')}
            className="px-2.5 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-white border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 transition disabled:opacity-50"
          >
            <Code className="w-3.5 h-3.5" />
            <span>{simulating === 'xss' ? 'กำลังยิง...' : 'ทดสอบ XSS Payload'}</span>
          </button>

          <button
            type="button"
            disabled={simulating !== null}
            onClick={() => handleSimulateAttack('path')}
            className="px-2.5 py-1.5 rounded-lg bg-orange-500/20 hover:bg-orange-500 text-orange-300 hover:text-white border border-orange-500/40 text-xs font-bold flex items-center gap-1.5 transition disabled:opacity-50"
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>{simulating === 'path' ? 'กำลังยิง...' : 'ทดสอบ Path Traversal (.env)'}</span>
          </button>

          <button
            type="button"
            disabled={simulating !== null}
            onClick={() => handleSimulateAttack('scanner')}
            className="px-2.5 py-1.5 rounded-lg bg-purple-500/20 hover:bg-purple-500 text-purple-300 hover:text-white border border-purple-500/40 text-xs font-bold flex items-center gap-1.5 transition disabled:opacity-50"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>{simulating === 'scanner' ? 'กำลังยิง...' : 'ทดสอบ Scanner Bot (sqlmap)'}</span>
          </button>

          <button
            type="button"
            disabled={simulating !== null}
            onClick={() => handleSimulateAttack('flood')}
            className="px-2.5 py-1.5 rounded-lg bg-yellow-500/20 hover:bg-yellow-500 text-yellow-300 hover:text-slate-950 border border-yellow-500/40 text-xs font-bold flex items-center gap-1.5 transition disabled:opacity-50"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>{simulating === 'flood' ? 'กำลังยิง...' : 'ทดสอบ HTTP Flood'}</span>
          </button>
        </div>
      </div>

      {/* 5. Live Incident Logs Table */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-slate-950/80 border border-white/10 space-y-2.5">
        <div className="flex items-center justify-between">
          <h3 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <span>บันทึกเหตุการณ์ความปลอดภัยล่าสุด (Live Incident Logs)</span>
          </h3>
          <span className="text-[10.5px] text-slate-500 font-mono">
            แสดง {metrics?.recentLogs?.length ?? 0} รายการล่าสุด
          </span>
        </div>

        {(!metrics?.recentLogs || metrics.recentLogs.length === 0) ? (
          <div className="py-8 text-center text-slate-500 text-xs border border-dashed border-white/10 rounded-xl">
            <ShieldCheck className="w-8 h-8 text-emerald-500/40 mx-auto mb-1.5" />
            <p className="font-semibold text-slate-400">ยังไม่มีการโจมตีตรวจพบในขณะนี้</p>
            <p className="text-[10px] text-slate-500 mt-0.5">ระบบ WAF กำลังตรวจการณ์ทุกคำขอที่เข้ามาอย่างเข้มงวดตลอด 24 ชม.</p>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-white/10">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/90 text-slate-400 font-mono text-[10px] uppercase border-b border-white/10">
                <tr>
                  <th className="py-2 px-3">เวลา</th>
                  <th className="py-2 px-3">IP Address</th>
                  <th className="py-2 px-3">ประเภทภัยคุกคาม</th>
                  <th className="py-2 px-3">Path / Method</th>
                  <th className="py-2 px-3">Risk</th>
                  <th className="py-2 px-3">การตอบสนอง</th>
                  <th className="py-2 px-3">รายละเอียด</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono text-[10.5px]">
                {metrics.recentLogs.map((log) => {
                  const threatConfig = threatLabels[log.threatType] || { label: log.threatType, color: 'text-slate-300' };
                  return (
                    <tr key={log.id} className="hover:bg-white/[0.02] transition">
                      <td className="py-2 px-3 text-slate-400 whitespace-nowrap">{log.timestamp}</td>
                      <td className="py-2 px-3 font-bold text-white whitespace-nowrap">{log.ip}</td>
                      <td className="py-2 px-3 whitespace-nowrap">
                        <span className="px-1.5 py-0.2 rounded-md font-bold text-[9.5px] bg-rose-500/15 text-rose-300 border border-rose-500/30">
                          {threatConfig.label}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-cyan-300 whitespace-nowrap">
                        <span className="font-bold text-slate-400 mr-1">{log.method}</span>
                        {log.path}
                      </td>
                      <td className="py-2 px-3 whitespace-nowrap">
                        <span className={`font-bold ${log.riskScore >= 75 ? 'text-rose-400' : 'text-amber-400'}`}>
                          {log.riskScore}/100
                        </span>
                      </td>
                      <td className="py-2 px-3 whitespace-nowrap">
                        {log.action.includes('403') ? (
                          <span className="px-1.5 py-0.2 rounded bg-rose-950 text-rose-300 font-bold border border-rose-700/50 text-[10px]">
                            BLOCKED (403)
                          </span>
                        ) : log.action.includes('429') ? (
                          <span className="px-1.5 py-0.2 rounded bg-yellow-950 text-yellow-300 font-bold border border-yellow-700/50 text-[10px]">
                            RATE LIMITED (429)
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.2 rounded bg-purple-950 text-purple-300 font-bold text-[10px]">
                            {log.action}
                          </span>
                        )}
                      </td>
                      <td className="py-2 px-3 text-slate-300 max-w-xs truncate" title={log.details}>
                        {log.details}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}
