'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useStore } from '@/context/StoreContext';

export default function Footer() {
  const pathname = usePathname();
  const { playClick, siteContent, openContactModal } = useStore();
  const { footer } = siteContent || {};

  if (pathname?.startsWith('/admin')) {
    return null;
  }

  const siteName = siteContent?.branding?.siteName || 'ARX STORE';
  const logoUrl = siteContent?.branding?.logoUrl || '/brand/logo.png';
  const description =
    siteContent?.branding?.slogan ||
    footer?.description ||
    'ซื้อไปแล้วกลัวใช้ไม่ได้? ไม่ต้องกังวลครับ ทุกโปรแกรมมีคลิปสอนให้ ใช้งานง่ายไม่ต้องเซ็ตเอง พร้อมแลกและมีแอดมินคอยให้คำปรึกษาตลอดการใช้งาน';
  const reportText =
    footer?.reportText ||
    'ติดต่อร้านค้าไม่ได้ หรือต้องการรายงานปัญหาร้านค้าขี้โกง? แจ้งเรื่องกับทีมงานกลาง';
  const reportUrl = footer?.reportUrl || '#';
  const copyright = footer?.copyright || `© 2026 ${siteName}`;
  const currencyNote = footer?.currencyNote || 'ราคาทั้งหมดเป็นเงินบาท';

  return (
    <footer className="w-full mt-auto border-t border-white/10 bg-[color:var(--arx-dk-04060c)] text-slate-400 select-none">
      <div className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-8">
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12 mb-10">
          {/* Left Column (Brand + Description + Report Capsule) */}
          <div className="md:col-span-7 space-y-4">
            {/* Brand Logo & Name */}
            <div className="flex items-center gap-2.5">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                key={logoUrl}
                src={logoUrl}
                alt={siteName}
                className="w-6 h-6 object-contain rounded-full drop-shadow-[0_0_8px_rgba(var(--theme-accent-rgb),0.7)]"
                onError={(e) => {
                  const target = e.currentTarget;
                  if (!target.src.includes('arx-default-logo.png')) {
                    target.src = '/brand/arx-default-logo.png';
                  }
                }}
              />
              <span className="font-black text-sm tracking-tight text-white">
                {siteName}
              </span>
            </div>

            {/* Description Text */}
            <p className="text-xs sm:text-[12.5px] text-slate-400 leading-relaxed max-w-lg">
              {description}
            </p>

            {/* Report Issue Capsule Box (Image 1 Style) */}
            <div className="rounded-xl border border-white/10 bg-black/60 px-4 py-2.5 max-w-lg text-[11px] sm:text-xs flex items-center justify-between gap-2 shadow-sm">
              <span className="text-slate-300">
                {reportText.includes('?') ? reportText.split('?')[0] + '?' : reportText}
              </span>
              <a
                href={reportUrl}
                target={reportUrl !== '#' ? "_blank" : undefined}
                rel="noopener noreferrer"
                onClick={(e) => {
                  playClick();
                  if (reportUrl === '#' || !reportUrl) {
                    e.preventDefault();
                  }
                }}
                className="text-cyan-400 hover:text-cyan-300 font-bold hover:underline shrink-0 cursor-pointer"
              >
                {reportText.includes('?') ? reportText.split('?')[1]?.trim() || 'แจ้งเรื่องกับทีมงานกลาง' : 'แจ้งเรื่องกับทีมงานกลาง'}
              </a>
            </div>
          </div>

          {/* Right Columns (Links) */}
          <div className="md:col-span-5 grid grid-cols-2 gap-6 sm:gap-8">
            {/* Column: ร้านค้า */}
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                ร้านค้า
              </h4>
              <ul className="space-y-2 text-xs">
                <li>
                  <Link
                    href="/store"
                    onClick={playClick}
                    className="text-slate-400 hover:text-cyan-300 transition-colors"
                  >
                    สินค้าทั้งหมด
                  </Link>
                </li>
                <li>
                  <Link
                    href="/topup"
                    onClick={playClick}
                    className="text-slate-400 hover:text-cyan-300 transition-colors"
                  >
                    เติมเงิน
                  </Link>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => {
                      playClick();
                      openContactModal();
                    }}
                    className="text-slate-400 hover:text-cyan-300 transition-colors text-left cursor-pointer"
                  >
                    ช่องทางการรับ
                  </button>
                </li>
              </ul>
            </div>

            {/* Column: ช่วยเหลือ */}
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                ช่วยเหลือ
              </h4>
              <ul className="space-y-2 text-xs">
                <li>
                  <Link
                    href="/orders"
                    onClick={playClick}
                    className="text-slate-400 hover:text-cyan-300 transition-colors"
                  >
                    ตรวจสอบคำสั่งซื้อ
                  </Link>
                </li>
                <li>
                  <Link
                    href="/topup"
                    onClick={playClick}
                    className="text-slate-400 hover:text-cyan-300 transition-colors"
                  >
                    เติมเงิน
                  </Link>
                </li>
                <li>
                  <Link
                    href="/privacy"
                    onClick={playClick}
                    className="text-slate-400 hover:text-cyan-300 transition-colors"
                  >
                    เงื่อนไขการใช้งาน
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom Line */}
        <div className="pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500 font-mono">
          <div>{copyright}</div>
          <div>{currencyNote}</div>
        </div>
      </div>
    </footer>
  );
}
