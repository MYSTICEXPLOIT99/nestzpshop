'use client';

import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import {
  House,
  ShoppingBag,
  Search,
  WalletCards,
  ReceiptText,
  RotateCcw,
  Gauge,
  MessageCircle,
  ChevronDown,
  ShieldCheck,
  LogOut,
  Sparkles,
  X,
  Bell,
  Check,
  ArrowRight,
  Globe,
  AlertTriangle,
  User,
  Wallet,
  Gift,
  Store,
  ChevronRight,
  CreditCard,
  Clock,
  DollarSign,
  Wrench,
  AlertCircle,
  Coins,
  Flame
} from 'lucide-react';
import ProfileModal from '@/components/modals/ProfileModal';

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const {
    user,
    logout,
    openAuthModal,
    closeAuthModal,
    closeBuyModal,
    playClick,
    playError,
    playSuccess,
    showToast,
    lang,
    setLang,
    t,
    theme,
    toggleTheme,
    siteContent
  } = useStore();

  const [isFloating, setIsFloating] = useState(false);

  // เลื่อนลง -> แท็บเมนูลอยตาม (ย่อเล็กน้อย + กระจกใส)
  useEffect(() => {
    let raf = 0;
    const update = () => {
      raf = 0;
      const next = window.scrollY > 24;
      setIsFloating(prev => (prev === next ? prev : next));
    };
    const onScroll = () => {
      if (!raf) raf = window.requestAnimationFrame(update);
    };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      if (raf) window.cancelAnimationFrame(raf);
    };
  }, []);

  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isCouponModalOpen, setIsCouponModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [couponInput, setCouponInput] = useState('');
  const [couponResult, setCouponResult] = useState<{ success: boolean; message: string } | null>(null);
  const [isCheckingCoupon, setIsCheckingCoupon] = useState(false);

  const userMenuRef = useRef<HTMLDivElement>(null);
  const moreMenuRef = useRef<HTMLDivElement>(null);

  const handleCheckCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    setIsCheckingCoupon(true);
    try {
      const res = await fetch('/api/coupons/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: couponInput.trim() })
      });
      const data = await res.json();
      if (data.valid) {
        setCouponResult({
          success: true,
          message: `โค้ดใช้งานได้! รับส่วนลด ${data.discountPercent}% (${data.description || 'นำโค้ดไปใช้ในหน้าสั่งซื้อสินค้าได้ทันที'})`
        });
        playSuccess();
      } else {
        setCouponResult({
          success: false,
          message: data.message || 'โค้ดส่วนลดไม่ถูกต้องหรือหมดอายุ'
        });
        playError();
      }
    } catch {
      setCouponResult({
        success: false,
        message: 'เกิดข้อผิดพลาดในการตรวจสอบโค้ด'
      });
      playError();
    } finally {
      setIsCheckingCoupon(false);
    }
  };

  // Handler for product search click - แสดงข้อความ "ระบบนี้ยังไม่เปิดให้พร้อมบริการ"
  const handleOpenSearch = () => {
    playClick();
    setIsSearchModalOpen(true);
    showToast({
      title: lang === 'th' ? 'แจ้งเตือน' : 'Notice',
      message: lang === 'th' ? 'ระบบนี้ยังไม่เปิดให้พร้อมบริการ' : 'This service is currently unavailable',
      type: 'warning'
    });
  };

  // Close modals when pathname changes
  const prevPathname = useRef(pathname);
  useEffect(() => {
    if (prevPathname.current !== pathname) {
      prevPathname.current = pathname;
      closeBuyModal();
      closeAuthModal();
      setIsUserMenuOpen(false);
      setIsMoreMenuOpen(false);
      setIsSearchModalOpen(false);
    }
  }, [pathname, closeBuyModal, closeAuthModal]);

  // Handle outside clicks for dropdowns
  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      const target = e.target as Node;
      if (userMenuRef.current && !userMenuRef.current.contains(target)) {
        setIsUserMenuOpen(false);
      }
      if (moreMenuRef.current && !moreMenuRef.current.contains(target)) {
        setIsMoreMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  // Keyboard shortcut (Escape to close search, or Ctrl+K to open)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isSearchModalOpen) {
        setIsSearchModalOpen(false);
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        handleOpenSearch();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSearchModalOpen]);

  if (pathname?.startsWith('/admin')) {
    return null;
  }

  const navLinks = [
    {
      label: 'หน้าหลัก',
      href: '/',
      icon: House
    },
    {
      label: 'สินค้า',
      href: '/store',
      icon: ShoppingBag
    },
    {
      label: 'เติมเงิน',
      href: '/topup',
      icon: WalletCards
    }
  ];

  const announcementText = siteContent?.branding?.slogan || 'โปรแกรมมีปัญหาให้ติดต่อแอดมินได้ที่ Discord เท่านั้น !!';

  return (
    <header className="store-nav-header w-full" data-storefront-nav="true" data-floating={isFloating ? 'true' : 'false'}>
      {/* 1. Slim Announcement Marquee Bar */}
      <div className="store-nav-announce">
        <div className="store-nav-announce-track">
          {Array.from({ length: 8 }).map((_, i) => (
            <span key={i} className="store-nav-announce-item text-white">
              <Flame className="w-3.5 h-3.5 text-blue-400 shrink-0 animate-pulse" />
              <span className="text-white font-bold tracking-wide">{announcementText}</span>
            </span>
          ))}
        </div>
      </div>

      {/* 2. Main Navigation Shell */}
      <div className="store-nav-shell">
        {/* Left: Brand Logo + Category/Nav Tabs */}
        <div className="flex items-center gap-4 sm:gap-6 md:gap-7 min-w-0">
          <Link
            href="/"
            onClick={() => {
              playClick();
              closeBuyModal();
              closeAuthModal();
              setIsUserMenuOpen(false);
            }}
            className="flex items-center gap-2.5 shrink-0 group select-none text-decoration-none"
            title={siteContent?.branding?.siteName || "ARX STORE"}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              key={siteContent?.branding?.logoUrl || "/brand/logo.png"}
              src={siteContent?.branding?.logoUrl || "/brand/logo.png"}
              alt={siteContent?.branding?.siteName || "ARX STORE"}
              width={32}
              height={32}
              className="w-8 h-8 rounded-full object-contain filter drop-shadow-[0_0_8px_rgba(var(--theme-main-rgb),0.7)] group-hover:scale-105 transition-transform"
              onError={(e) => {
                const target = e.currentTarget;
                if (!target.src.includes('arx-default-logo.png')) {
                  target.src = '/brand/arx-default-logo.png';
                }
              }}
            />
            <span className="font-black text-sm tracking-wider uppercase text-white group-hover:text-blue-400 transition-colors">
              {siteContent?.branding?.siteName || 'ARX STORE'}
            </span>
          </Link>

          {/* Navigation Links */}
          <nav className="store-nav-desktopNav items-center" aria-label="เมนูหลัก">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = link.href === '/' ? pathname === '/' : pathname.startsWith(link.href!);

              return (
                <Link
                  key={link.href}
                  href={link.href!}
                  onClick={() => {
                    playClick();
                    closeBuyModal();
                    closeAuthModal();
                  }}
                  draggable="false"
                  className={`store-nav-navLink ${isActive ? 'store-nav-active' : ''}`}
                  aria-current={isActive ? 'page' : undefined}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{link.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Right: Actions (User Profile / Login) */}
        <div className="flex items-center gap-2 shrink-0">
          {/* User Profile & Balance */}
          {!user ? (
            <button
              type="button"
              onClick={() => {
                playClick();
                openAuthModal('login');
              }}
              className="px-4 py-1.5 rounded-xl bg-[color:var(--theme-main)] hover:bg-[color:var(--theme-sec)] text-white font-extrabold text-xs sm:text-sm shadow-[0_0_16px_rgba(var(--theme-main-rgb),0.4)] transition-all cursor-pointer"
            >
              <span>{t('nav_login') || 'เข้าสู่ระบบ'}</span>
            </button>
          ) : (
            <div className="relative" ref={userMenuRef}>
              <button
                type="button"
                onClick={() => {
                  playClick();
                  setIsUserMenuOpen(!isUserMenuOpen);
                }}
                className="flex items-center gap-1.5 sm:gap-2.5 p-1 rounded-full hover:bg-white/[0.06] transition-colors cursor-pointer select-none"
              >
                {/* Avatar with blue glow ring */}
                {(() => {
                  const storeLogo = siteContent?.branding?.logoUrl || '/brand/logo.png';
                  const effectiveAvatar = (user.role === 'admin' || !user.avatar || user.avatar === '/brand/logo.png' || user.avatar === '/brand/arx-default-logo.png' || user.avatar.includes('placeholder'))
                    ? storeLogo
                    : user.avatar;

                  return (
                    <div className="relative w-8 h-8 rounded-full p-0.5 bg-gradient-to-tr from-[var(--theme-main)] via-blue-600 to-indigo-500 shadow-[0_0_14px_rgba(var(--theme-main-rgb),0.5)] flex items-center justify-center shrink-0 overflow-hidden">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        key={effectiveAvatar}
                        src={effectiveAvatar}
                        alt={user.username}
                        className="w-full h-full object-contain rounded-full bg-slate-950 p-0.5"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = storeLogo;
                        }}
                      />
                    </div>
                  );
                })()}

                <ChevronDown
                  className={`w-3.5 h-3.5 text-zinc-400 transition-transform duration-200 ${
                    isUserMenuOpen ? 'rotate-180 text-white' : ''
                  }`}
                />
              </button>

              {/* User Dropdown matching user reference & compact sizing */}
              {isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 sm:w-72 rounded-2xl bg-[color:var(--arx-dk-080a10)]/98 border border-[color:var(--theme-main)]/35 backdrop-blur-2xl shadow-[0_15px_40px_rgba(0,0,0,0.95),0_0_25px_rgba(var(--theme-main-rgb),0.2)] p-2.5 z-50 animate-in fade-in zoom-in-95 duration-150 space-y-2 max-h-[calc(100vh-80px)] overflow-y-auto">
                  
                  {/* 1. Header Profile Info */}
                  <div className="flex items-center gap-2.5 px-1 py-0.5">
                    {/* Cyan outlined avatar box */}
                    {(() => {
                      const storeLogo = siteContent?.branding?.logoUrl || '/brand/logo.png';
                      const effectiveAvatar = (user.role === 'admin' || !user.avatar || user.avatar === '/brand/logo.png' || user.avatar === '/brand/arx-default-logo.png' || user.avatar.includes('placeholder'))
                        ? storeLogo
                        : user.avatar;

                      return (
                        <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-cyan-950/40 border border-cyan-500/40 flex items-center justify-center shrink-0 overflow-hidden shadow-[0_0_12px_rgba(var(--theme-accent-rgb),0.25)]">
                          <img
                            key={`dropdown-${effectiveAvatar}`}
                            src={effectiveAvatar}
                            alt={user.username}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = storeLogo;
                            }}
                          />
                        </div>
                      );
                    })()}

                    <div className="min-w-0 flex-1">
                      <h3 className="text-xs sm:text-sm font-bold text-white tracking-wide truncate leading-tight">
                        {user.username}
                      </h3>
                      <div className="mt-1">
                        <span className="inline-block px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-cyan-950/60 text-cyan-300 border border-cyan-500/30">
                          {user.role === 'admin' ? 'ADMIN' : 'MEMBER'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 2. Balance & Top-up Card matching cyan theme */}
                  <div className="rounded-xl bg-[color:var(--arx-dk-061824)] border border-cyan-500/30 p-2 sm:p-2.5 flex items-center justify-between shadow-[0_4px_16px_rgba(var(--theme-accent-rgb),0.06)]">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-cyan-950/70 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0">
                        <Wallet className="w-3.5 h-3.5 text-cyan-400" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-[10px] text-slate-400 font-medium block leading-tight">
                          ยอดเงินคงเหลือ
                        </span>
                        <span className="text-xs sm:text-sm font-black text-white font-mono block leading-tight mt-0.5 truncate">
                          {user.balance.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} บาท
                        </span>
                      </div>
                    </div>

                    <Link
                      href="/topup"
                      onClick={() => {
                        playClick();
                        setIsUserMenuOpen(false);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-cyan-400 via-[var(--theme-accent)] to-cyan-500 hover:brightness-110 text-slate-950 font-bold text-[11px] shadow-[0_0_15px_rgba(var(--theme-accent-rgb),0.5)] flex items-center gap-1 transition-all shrink-0 cursor-pointer active:scale-95"
                    >
                      <Wallet className="w-3 h-3" />
                      <span>เติมเงิน</span>
                    </Link>
                  </div>

                  {/* 3. Navigation Rows List matching user reference image strictly:
                      1. ร้านค้า (ดูสินค้าทั้งหมด)
                      2. เติมเงิน (เพิ่มยอดเงินในบัญชี)
                      3. ประวัติการซื้อ (รายการสั่งซื้อทั้งหมด)
                      4. ประวัติเติมเงิน (ดูรายการเติมเงิน)
                      5. โปรไฟล์ (ข้อมูลบัญชีของฉัน)
                      6. ระบบแอดมิน (ถ้าเป็น Admin)
                      7. ออกจากระบบ
                  */}
                  <div className="space-y-0.5">
                    {/* 1. ร้านค้า (ดูสินค้าทั้งหมด) */}
                    <Link
                      href="/store"
                      onClick={() => {
                        playClick();
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full flex items-center justify-between px-2 py-1.5 rounded-lg hover:bg-white/[0.04] transition-colors group cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[color:var(--arx-dk-14151c)] border border-white/5 flex items-center justify-center text-slate-300 group-hover:text-cyan-400 group-hover:border-cyan-500/30 transition-colors shrink-0">
                          <ShoppingBag className="w-3.5 h-3.5" />
                        </div>
                        <div className="min-w-0 text-left">
                          <h4 className="text-xs font-bold text-white group-hover:text-cyan-400 transition-colors leading-tight">
                            ร้านค้า
                          </h4>
                          <span className="text-[10px] text-slate-400 block leading-tight mt-0.5">ดูสินค้าทั้งหมด</span>
                        </div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all shrink-0" />
                    </Link>

                    {/* 2. เติมเงิน (เพิ่มยอดเงินในบัญชี) */}
                    <Link
                      href="/topup"
                      onClick={() => {
                        playClick();
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full flex items-center justify-between px-2 py-1.5 rounded-lg hover:bg-white/[0.04] transition-colors group cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[color:var(--arx-dk-14151c)] border border-white/5 flex items-center justify-center text-slate-300 group-hover:text-cyan-400 group-hover:border-cyan-500/30 transition-colors shrink-0">
                          <DollarSign className="w-3.5 h-3.5" />
                        </div>
                        <div className="min-w-0 text-left">
                          <h4 className="text-xs font-bold text-white group-hover:text-cyan-400 transition-colors leading-tight">
                            เติมเงิน
                          </h4>
                          <span className="text-[10px] text-slate-400 block leading-tight mt-0.5">เพิ่มยอดเงินในบัญชี</span>
                        </div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all shrink-0" />
                    </Link>

                    {/* 3. ประวัติการซื้อ (รายการสั่งซื้อทั้งหมด) */}
                    <Link
                      href="/orders"
                      onClick={() => {
                        playClick();
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full flex items-center justify-between px-2 py-1.5 rounded-lg hover:bg-white/[0.04] transition-colors group cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[color:var(--arx-dk-14151c)] border border-white/5 flex items-center justify-center text-slate-300 group-hover:text-cyan-400 group-hover:border-cyan-500/30 transition-colors shrink-0">
                          <Clock className="w-3.5 h-3.5" />
                        </div>
                        <div className="min-w-0 text-left">
                          <h4 className="text-xs font-bold text-white group-hover:text-cyan-400 transition-colors leading-tight">
                            ประวัติการซื้อ
                          </h4>
                          <span className="text-[10px] text-slate-400 block leading-tight mt-0.5">รายการสั่งซื้อทั้งหมด</span>
                        </div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all shrink-0" />
                    </Link>

                    {/* 4. ประวัติเติมเงิน (ดูรายการเติมเงิน) */}
                    <Link
                      href="/topup#topup-history"
                      onClick={() => {
                        playClick();
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full flex items-center justify-between px-2 py-1.5 rounded-lg hover:bg-white/[0.04] transition-colors group cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[color:var(--arx-dk-14151c)] border border-white/5 flex items-center justify-center text-slate-300 group-hover:text-cyan-400 group-hover:border-cyan-500/30 transition-colors shrink-0">
                          <CreditCard className="w-3.5 h-3.5" />
                        </div>
                        <div className="min-w-0 text-left">
                          <h4 className="text-xs font-bold text-white group-hover:text-cyan-400 transition-colors leading-tight">
                            ประวัติเติมเงิน
                          </h4>
                          <span className="text-[10px] text-slate-400 block leading-tight mt-0.5">ดูรายการเติมเงิน</span>
                        </div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all shrink-0" />
                    </Link>

                    {/* 5. โปรไฟล์ (ข้อมูลบัญชีของฉัน) -> Opens Profile Modal */}
                    <button
                      type="button"
                      onClick={() => {
                        playClick();
                        setIsUserMenuOpen(false);
                        setIsProfileModalOpen(true);
                      }}
                      className="w-full flex items-center justify-between px-2 py-1.5 rounded-lg hover:bg-white/[0.04] transition-colors group cursor-pointer text-left"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[color:var(--arx-dk-14151c)] border border-white/5 flex items-center justify-center text-slate-300 group-hover:text-cyan-400 group-hover:border-cyan-500/30 transition-colors shrink-0">
                          <User className="w-3.5 h-3.5" />
                        </div>
                        <div className="min-w-0 text-left">
                          <h4 className="text-xs font-bold text-white group-hover:text-cyan-400 transition-colors leading-tight">
                            โปรไฟล์
                          </h4>
                          <span className="text-[10px] text-slate-400 block leading-tight mt-0.5">ข้อมูลบัญชีของฉัน</span>
                        </div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all shrink-0" />
                    </button>

                    {/* แอดมิน (ถ้าเป็น Admin) */}
                    {user.role === 'admin' && (
                      <Link
                        href="/admin"
                        onClick={() => {
                          playClick();
                          setIsUserMenuOpen(false);
                        }}
                        className="w-full flex items-center justify-between px-2 py-1.5 rounded-lg bg-cyan-950/20 hover:bg-cyan-950/40 border border-cyan-500/20 transition-colors group cursor-pointer"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-cyan-950/60 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
                            <ShieldCheck className="w-3.5 h-3.5" />
                          </div>
                          <div className="min-w-0 text-left">
                            <h4 className="text-xs font-bold text-cyan-300 leading-tight">
                              ระบบแอดมิน
                            </h4>
                            <span className="text-[10px] text-cyan-400/80 block leading-tight mt-0.5">จัดการระบบร้านค้า</span>
                          </div>
                        </div>
                        <ChevronRight className="w-3.5 h-3.5 text-cyan-400 group-hover:translate-x-0.5 transition-all shrink-0" />
                      </Link>
                    )}
                  </div>

                  {/* 4. Footer Logout Action */}
                  <div className="pt-1.5 border-t border-white/5">
                    <button
                      type="button"
                      onClick={() => {
                        playClick();
                        logout();
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 text-slate-400 hover:text-cyan-400 hover:bg-cyan-500/10 rounded-lg transition-colors font-bold text-xs text-left cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5 text-slate-400" />
                      <span>ออกจากระบบ</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* 4. Instant Product Search Modal Notice ("หาสินค้า" - ระบบนี้ยังไม่เปิดให้พร้อมบริการ) */}
      {isSearchModalOpen && (
        <div
          className="fixed inset-0 z-[1200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150"
          onClick={() => setIsSearchModalOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl bg-[color:var(--arx-dk-070b13)] border border-[color:var(--theme-main)]/40 shadow-[0_20px_60px_rgba(0,0,0,0.9),0_0_35px_rgba(var(--theme-main-rgb),0.25)] overflow-hidden animate-in zoom-in-95 duration-150 p-6 sm:p-7 text-center relative"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close button */}
            <button
              type="button"
              onClick={() => setIsSearchModalOpen(false)}
              className="absolute top-3.5 right-3.5 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              title="ปิด (ESC)"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Warning Icon with Blue Glow */}
            <div className="w-14 h-14 rounded-2xl bg-[color:var(--theme-main)]/15 border border-[color:var(--theme-main)]/35 text-blue-400 flex items-center justify-center mx-auto mb-4 shadow-[0_0_25px_rgba(var(--theme-main-rgb),0.3)]">
              <AlertTriangle className="w-7 h-7" />
            </div>

            {/* Status Badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-[color:var(--theme-main)]/20 text-blue-300 border border-[color:var(--theme-main)]/35 mb-3">
              <span className="w-1.5 h-1.5 rounded-full bg-[color:var(--theme-main)] animate-pulse" />
              <span>TEMPORARILY UNAVAILABLE</span>
            </div>

            {/* Main Title requested by user */}
            <h3 className="text-base sm:text-lg font-black text-white tracking-wide mb-2">
              ระบบนี้ยังไม่เปิดให้พร้อมบริการ
            </h3>

            <p className="text-xs text-slate-300 max-w-xs mx-auto mb-6 leading-relaxed">
              {lang === 'th'
                ? 'ระบบค้นหาสินค้ากำลังอยู่ในระหว่างการพัฒนาและเตรียมความพร้อม ขออภัยในความไม่สะดวก สามารถเลือกชมสินค้าทั้งหมดได้ที่หน้าร้านค้า'
                : 'The product search system is currently undergoing development. We apologize for the inconvenience. You can browse all items in the store.'}
            </p>

            {/* Actions */}
            <div className="flex items-center justify-center gap-2.5">
              <Link
                href="/store"
                onClick={() => {
                  playClick();
                  setIsSearchModalOpen(false);
                }}
                className="px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 transition-all shadow-[0_0_20px_rgba(var(--theme-accent-rgb),0.35)] hover:scale-[1.02] flex items-center gap-1.5"
              >
                <span>{lang === 'th' ? 'ไปที่หน้าร้านค้า' : 'Go to Store'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>

              <button
                type="button"
                onClick={() => {
                  playClick();
                  setIsSearchModalOpen(false);
                }}
                className="px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all hover:scale-[1.02]"
              >
                {lang === 'th' ? 'ตกลง' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Coupon / Code Redeem Modal ("กรอกโค้ด") */}
      {isCouponModalOpen && (
        <div
          className="fixed inset-0 z-[1200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150"
          onClick={() => setIsCouponModalOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl bg-[color:var(--arx-dk-08090e)] border border-cyan-500/30 shadow-[0_20px_60px_rgba(0,0,0,0.95),0_0_30px_rgba(var(--theme-accent-rgb),0.2)] overflow-hidden p-6 relative animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setIsCouponModalOpen(false)}
              className="absolute top-3.5 right-3.5 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="w-12 h-12 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 text-cyan-400 flex items-center justify-center mx-auto mb-3 shadow-[0_0_20px_rgba(var(--theme-accent-rgb),0.25)]">
              <Gift className="w-6 h-6 text-cyan-400" />
            </div>

            <h3 className="text-base font-bold text-white text-center mb-1">
              {lang === 'th' ? 'กรอกโค้ดส่วนลด & Point' : 'Redeem Coupon Code'}
            </h3>
            <p className="text-xs text-slate-400 text-center mb-4 leading-relaxed">
              {lang === 'th'
                ? 'ใส่โค้ดส่วนลดของคุณเพื่อรับส่วนลดหรือตรวจสอบสิทธิ์พิเศษ'
                : 'Enter your coupon code to check special discounts or bonus credits'}
            </p>

            <form onSubmit={handleCheckCoupon} className="space-y-3">
              <div className="relative">
                <input
                  type="text"
                  value={couponInput}
                  onChange={(e) => {
                    setCouponInput(e.target.value.toUpperCase());
                    setCouponResult(null);
                  }}
                  placeholder="กรอกโค้ด เช่น ARX10, DISCOUNT..."
                  className="w-full bg-black/60 border border-white/10 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 rounded-xl px-4 py-2.5 text-xs text-white placeholder:text-slate-500 font-mono tracking-wider outline-none uppercase transition-colors"
                />
              </div>

              {couponResult && (
                <div className={`p-2.5 rounded-xl text-xs flex items-center gap-2 ${
                  couponResult.success
                    ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
                    : 'bg-rose-500/10 border border-rose-500/30 text-rose-300'
                }`}>
                  <span className="leading-relaxed">{couponResult.message}</span>
                </div>
              )}

              <div className="flex gap-2 pt-1">
                <button
                  type="submit"
                  disabled={isCheckingCoupon || !couponInput.trim()}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 via-[var(--theme-accent)] to-cyan-500 hover:from-cyan-300 hover:to-cyan-400 text-slate-950 font-black text-xs shadow-lg shadow-cyan-500/25 disabled:opacity-50 transition-all cursor-pointer"
                >
                  {isCheckingCoupon ? 'กำลังตรวจสอบ...' : 'ตรวจสอบโค้ด'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsCouponModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 font-semibold text-xs transition-colors cursor-pointer"
                >
                  ปิด
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 5. Profile Edit Modal */}
      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />
    </header>
  );
}
