'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import { Product } from '@/types';
import {
  Trophy,
  Flame,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Play,
  Pause,
  ShoppingBag,
  Star,
  Check
} from 'lucide-react';
import ProductHoverLoader from '@/components/common/ProductHoverLoader';

export default function PopularCarousel() {
  const router = useRouter();
  const { products, openBuyModal, playClick } = useStore();

  // Filter top 3 popular products
  const popularProducts = products
    .filter(p => p.isPopular || (p.rank && p.rank <= 3))
    .sort((a, b) => (a.rank || 99) - (b.rank || 99))
    .slice(0, 3);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoplay, setIsAutoplay] = useState(true);

  // Autoplay timer
  useEffect(() => {
    if (!isAutoplay || popularProducts.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % popularProducts.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [isAutoplay, popularProducts.length]);

  if (popularProducts.length === 0) return null;

  const currentItem = popularProducts[currentIndex];

  const rankBadges = [
    { label: '#1 อันดับสูงสุด', color: 'from-amber-400 to-yellow-600', text: 'text-amber-300' },
    { label: '#2 ยอดนิยม', color: 'from-slate-300 to-slate-500', text: 'text-slate-200' },
    { label: '#3 แนะนำ', color: 'from-amber-600 to-orange-700', text: 'text-amber-400' }
  ];

  return (
    <section className="py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest mb-1">
              <Trophy className="w-4 h-4" />
              <span>3 อันดับจากยอดขายของร้าน</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              สินค้ายอดนิยม
            </h2>
          </div>

          {/* Autoplay & Navigation Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                playClick();
                setIsAutoplay(!isAutoplay);
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1.5 transition"
              title={isAutoplay ? 'หยุดเล่นอัตโนมัติ' : 'เล่นอัตโนมัติ'}
            >
              {isAutoplay ? (
                <>
                  <Pause className="w-3 h-3 text-cyan-400" />
                  <span>หยุดสลับ</span>
                </>
              ) : (
                <>
                  <Play className="w-3 h-3 text-slate-400" />
                  <span>เล่นอัตโนมัติ</span>
                </>
              )}
            </button>

            <button
              onClick={() => {
                playClick();
                setCurrentIndex((prev) => (prev - 1 + popularProducts.length) % popularProducts.length);
              }}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition"
              title="ก่อนหน้า"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                playClick();
                setCurrentIndex((prev) => (prev + 1) % popularProducts.length);
              }}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition"
              title="ถัดไป"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Carousel Showcase Card */}
        <div className="cyber-card rounded-3xl p-6 sm:p-8 bg-gradient-to-r from-slate-950 via-slate-900 to-purple-950/40 border border-purple-500/30 shadow-2xl relative overflow-hidden">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Image Showcase */}
            <div
              onClick={() => {
                playClick();
                router.push(`/products/${currentItem.id}`);
              }}
              className="lg:col-span-6 relative rounded-2xl overflow-hidden aspect-square bg-slate-900 border border-purple-500/20 shadow-xl group cursor-pointer"
            >
              <img
                src={currentItem.image}
                alt={currentItem.name}
                className="w-full h-full object-cover group-hover:scale-105 group-hover:brightness-75 group-hover:blur-[1px] transition-all duration-500"
                onError={(e) => {
                  const target = e.currentTarget;
                  if (!target.src.includes('46ebc6a271269458ec9b.webp')) {
                    target.src = '/catalog/imported/46ebc6a271269458ec9b.webp';
                  }
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

              {/* ARX Cyber HUD Product Hover Loader */}
              <ProductHoverLoader
                label="คลิกเพื่อดูรายละเอียด"
                isSoldOut={currentItem.packages.every(pkg => !pkg.inStock || pkg.stock <= 0) || currentItem.status === 'out_of_stock'}
              />

              {/* Rank Badge */}
              <div className="absolute top-4 left-4 group-hover:opacity-0 transition-opacity duration-200">
                <span className={`px-3 py-1 rounded-xl text-xs font-black uppercase text-white shadow-lg bg-gradient-to-r ${rankBadges[currentIndex]?.color || 'from-purple-600 to-indigo-600'}`}>
                  อันดับ {currentIndex + 1}
                </span>
              </div>

              {/* Sold Counter */}
              <div className="absolute bottom-4 left-4 flex items-center gap-2 group-hover:opacity-0 transition-opacity duration-200">
                <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-black/70 backdrop-blur-md text-cyan-300 border border-cyan-500/30">
                  ขายแล้ว {currentItem.salesCount.toLocaleString()} ชิ้น
                </span>
              </div>

              {/* Out of Stock Badge */}
              {(currentItem.packages.every(pkg => !pkg.inStock || pkg.stock <= 0) || currentItem.status === 'out_of_stock') && (
                <div className="absolute top-4 right-4">
                  <span className="px-3 py-1 rounded-xl text-xs font-black uppercase text-white shadow-lg bg-red-600 border border-red-400">
                    OUT OF STOCK
                  </span>
                </div>
              )}
            </div>

            {/* Details & Actions */}
            <div className="lg:col-span-6 space-y-4">
              <div className="flex items-center gap-2">
                <span className="text-xs px-2.5 py-0.5 rounded-full font-bold uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  {currentItem.categoryName}
                </span>
                <span className="flex items-center gap-1 text-xs text-amber-400 font-semibold">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  {currentItem.rating} / 5.0
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl font-black text-white leading-tight">
                {currentItem.name}
              </h3>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {currentItem.description}
              </p>

              {/* Feature Tags */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {currentItem.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-300 font-medium"
                  >
                    #{tag}
                  </span>
                ))}
              </div>

              {/* Price & Buy Button */}
              <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400">ราคาเริ่มต้น</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black text-cyan-300 font-mono">
                      ฿{currentItem.packages[0]?.price.toLocaleString()}
                    </span>
                    {currentItem.packages[0]?.originalPrice && (
                      <span className="text-xs text-slate-500 line-through">
                        ฿{currentItem.packages[0]?.originalPrice.toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>

                {currentItem.packages.every(pkg => !pkg.inStock || pkg.stock <= 0) || currentItem.status === 'out_of_stock' ? (
                  <button
                    onClick={() => {
                      playClick();
                      router.push(`/products/${currentItem.id}`);
                    }}
                    className="px-6 py-3 rounded-xl bg-red-500/20 text-red-400 border border-red-500/40 font-black text-xs sm:text-sm flex items-center gap-2 cursor-pointer hover:bg-red-500/30 uppercase tracking-wider"
                  >
                    OUT OF STOCK
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      playClick();
                      router.push(`/products/${currentItem.id}`);
                    }}
                    className="px-6 py-3 rounded-xl cyber-btn-primary font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-cyan-500/30 cursor-pointer"
                  >
                    <ShoppingBag className="w-4 h-4" /> สั่งซื้อเลย
                  </button>
                )}
              </div>

            </div>

          </div>

          {/* Carousel Indicator Dots */}
          <div className="flex items-center justify-center gap-2 mt-6 pt-4 border-t border-slate-800/80">
            {popularProducts.map((p, idx) => (
              <button
                key={p.id}
                onClick={() => {
                  playClick();
                  setCurrentIndex(idx);
                }}
                className={`h-2 rounded-full transition-all ${
                  currentIndex === idx ? 'w-8 bg-purple-500' : 'w-2 bg-slate-800 hover:bg-slate-700'
                }`}
                title={`อันดับ ${idx + 1}`}
              />
            ))}
          </div>

        </div>

      </div>
    </section>
  );
}
