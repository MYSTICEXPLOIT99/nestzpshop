'use client';

import React from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { Tag, ChevronRight } from 'lucide-react';

interface Props {
  onSelectCategory?: (id: string) => void;
  activeCategory?: string;
}

const DEFAULT_BANNER_FALLBACKS = [
  '/catalog/imported/cat-android.png',
  '/catalog/imported/cat-ios.png',
  '/catalog/imported/cat-pc.png',
  '/catalog/imported/cat-idcode.png'
];

export default function OriginalCategoryBanners({ onSelectCategory, activeCategory }: Props) {
  const { categories, playClick, closeBuyModal, closeAuthModal } = useStore();

  const handleSelect = (e: React.MouseEvent, catId: string, customLink?: string) => {
    playClick();
    closeBuyModal();
    closeAuthModal();

    if (customLink && (customLink.startsWith('http://') || customLink.startsWith('https://') || (!customLink.includes('category=') && !customLink.startsWith('/store')))) {
      return;
    }

    if (onSelectCategory) {
      e.preventDefault();
      onSelectCategory(catId);

      if (typeof window !== 'undefined') {
        const url = new URL(window.location.href);
        if (catId === 'all') {
          url.searchParams.delete('category');
        } else {
          url.searchParams.set('category', catId);
        }
        window.history.replaceState({}, '', url.toString());

        const catalogEl = document.getElementById('products-catalog');
        if (catalogEl) {
          const navHeader = document.querySelector('.store-nav-header');
          const navHeight = navHeader ? navHeader.getBoundingClientRect().height : 75;
          const targetY = catalogEl.getBoundingClientRect().top + window.pageYOffset - navHeight - 16;
          window.scrollTo({
            top: Math.max(0, targetY),
            behavior: 'smooth'
          });
        }
      }
    }
  };

  if (!categories || categories.length === 0) {
    return null;
  }

  return (
    <section className="w-full pt-2 pb-1 space-y-3">
      {/* Header matching reference image: 🏷️ หมวดหมู่แนะนำ / Recommended Categories */}
      <div className="flex items-center justify-between px-1">
        <div>
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-[color:var(--theme-main)] fill-[color:var(--theme-main)]/20" />
            <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
              หมวดหมู่แนะนำ
            </h2>
          </div>
          <span className="text-[11px] sm:text-xs text-zinc-500 font-medium block mt-0.5">
            Recommended Categories
          </span>
        </div>

        <Link
          href="/store"
          onClick={(e) => handleSelect(e, 'all')}
          className="text-xs text-zinc-400 hover:text-blue-400 font-medium flex items-center gap-1 transition-colors"
        >
          <span>ดูทั้งหมด</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      {/* 2-Column Grid matching reference image */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 sm:gap-4">
        {categories.map((cat, idx) => {
          const targetLink = cat.linkUrl || `/store?category=${cat.id}#products-catalog`;
          const fallbackBanner = DEFAULT_BANNER_FALLBACKS[idx % DEFAULT_BANNER_FALLBACKS.length];
          const bannerImage = cat.image || fallbackBanner;

          return (
            <Link
              key={cat.id}
              href={targetLink}
              onClick={(e) => handleSelect(e, cat.id, targetLink)}
              className={`group relative overflow-hidden rounded-xl border border-white/[0.08] hover:border-[color:var(--theme-main)]/60 transition-all duration-300 hover:shadow-[0_0_24px_rgba(var(--theme-main-rgb),0.3)] bg-[color:var(--arx-dk-0e0f14)] block aspect-[700/195] ${
                activeCategory === cat.id ? 'ring-2 ring-[color:var(--theme-main)] shadow-[0_0_20px_rgba(var(--theme-main-rgb),0.4)]' : ''
              }`}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={bannerImage}
                alt={cat.name}
                className="w-full h-full object-contain sm:object-cover group-hover:scale-[1.02] transition-transform duration-300"
                onError={(e) => {
                  const target = e.currentTarget;
                  if (!target.src.includes('cat-android.png')) {
                    target.src = fallbackBanner;
                  }
                }}
              />
            </Link>
          );
        })}
      </div>
    </section>
  );
}
