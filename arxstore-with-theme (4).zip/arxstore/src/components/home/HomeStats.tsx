'use client';

import React from 'react';
import { useStore } from '@/context/StoreContext';
import { User, Coins, Box, ShoppingCart } from 'lucide-react';

export default function HomeStats() {
  const { displayStats, siteStats, t } = useStore();

  const totalUsersCount = displayStats?.users ?? siteStats?.users ?? 0;
  const totalTopupAmount = displayStats?.topup ?? siteStats?.topup ?? 0;
  const totalStockCount = displayStats?.stock ?? siteStats?.stock ?? 0;
  const totalSalesCount = displayStats?.sales ?? siteStats?.sales ?? 0;

  const stats = [
    {
      id: 'stat-users',
      label: t('stats_users'),
      value: totalUsersCount.toLocaleString(),
      unit: t('stats_users_unit'),
      icon: User,
      theme: {
        dot: 'bg-cyan-400 shadow-[0_0_8px_var(--theme-accent)]',
        topGlow: 'via-cyan-400/50',
        badgeBg: 'bg-[#061826]/90 border border-cyan-500/35 text-cyan-400 shadow-[0_0_12px_rgba(var(--theme-accent-rgb),0.18)]',
        cardHover: 'hover:border-cyan-500/40 hover:shadow-[0_4px_20px_rgba(var(--theme-accent-rgb),0.15)]',
        glow: 'rgba(var(--theme-accent-rgb), 0.25)'
      }
    },
    {
      id: 'stat-topup',
      label: t('stats_topup'),
      value: totalTopupAmount.toLocaleString('th-TH', {
        minimumFractionDigits: totalTopupAmount % 1 === 0 ? 0 : 2,
        maximumFractionDigits: 2
      }),
      unit: t('stats_topup_unit'),
      icon: Coins,
      theme: {
        dot: 'bg-emerald-400 shadow-[0_0_8px_#10b981]',
        topGlow: 'via-emerald-400/50',
        badgeBg: 'bg-[color:#062016]/90 border border-emerald-500/35 text-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.18)]',
        cardHover: 'hover:border-emerald-500/40 hover:shadow-[0_4px_20px_rgba(16,185,129,0.15)]',
        glow: 'rgba(16, 185, 129, 0.25)'
      }
    },
    {
      id: 'stat-stock',
      label: t('stats_stock'),
      value: totalStockCount.toLocaleString(),
      unit: t('stats_stock_unit'),
      icon: Box,
      theme: {
        dot: 'bg-indigo-400 shadow-[0_0_8px_#6366f1]',
        topGlow: 'via-indigo-400/50',
        badgeBg: 'bg-[color:var(--arx-dk-121029)]/90 border border-indigo-500/35 text-indigo-400 shadow-[0_0_12px_rgba(99,102,241,0.18)]',
        cardHover: 'hover:border-indigo-500/40 hover:shadow-[0_4px_20px_rgba(99,102,241,0.15)]',
        glow: 'rgba(99, 102, 241, 0.25)'
      }
    },
    {
      id: 'stat-sales',
      label: t('stats_sales'),
      value: totalSalesCount.toLocaleString(),
      unit: t('stats_sales_unit'),
      icon: ShoppingCart,
      theme: {
        dot: 'bg-cyan-400 shadow-[0_0_8px_var(--theme-accent)]',
        topGlow: 'via-cyan-400/50',
        badgeBg: 'bg-[#061826]/90 border border-cyan-500/35 text-cyan-400 shadow-[0_0_12px_rgba(var(--theme-accent-rgb),0.18)]',
        cardHover: 'hover:border-cyan-500/40 hover:shadow-[0_4px_20px_rgba(var(--theme-accent-rgb),0.15)]',
        glow: 'rgba(var(--theme-accent-rgb), 0.25)'
      }
    }
  ];

  return (
    <section className="w-full pt-2 pb-1.5 sm:pt-3 sm:pb-2">
      {/* 4 Cyberpunk Stats Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-2.5">
        {stats.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.id}
              className={`group relative overflow-hidden rounded-xl sm:rounded-2xl bg-white dark:bg-[color:var(--arx-dk-070b14)]/95 border border-slate-200 dark:border-white/[0.08] p-3 sm:p-3.5 transition-all duration-300 hover:-translate-y-0.5 flex items-center justify-between cursor-default backdrop-blur-xl shadow-md dark:shadow-lg dark:shadow-black/50 min-h-[64px] sm:min-h-[70px] ${item.theme.cardHover}`}
            >
              {/* Top border colored glow line */}
              <div className={`absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent ${item.theme.topGlow} to-transparent pointer-events-none opacity-85`} />

              {/* Corner Brackets (Cyber HUD marks) */}
              <span className="absolute top-1.5 left-1.5 w-1.5 h-1.5 border-t border-l border-slate-300 dark:border-white/25 pointer-events-none" />
              <span className="absolute bottom-1.5 right-1.5 w-1.5 h-1.5 border-b border-r border-slate-300 dark:border-white/25 pointer-events-none" />

              {/* Subtle Ambient Hover Glow */}
              <div
                className="absolute -top-10 -right-10 w-20 h-20 rounded-full blur-xl opacity-0 group-hover:opacity-40 transition-opacity duration-300 pointer-events-none"
                style={{ backgroundColor: item.theme.glow }}
              />

              {/* Stat Info: Top Colored Dot + Label & Bottom Bold Number + Unit */}
              <div className="relative z-10 min-w-0 pr-1.5">
                <div className="flex items-center gap-1.5 mb-1">
                  <span className={`w-1.5 h-1.5 rounded-full ${item.theme.dot} inline-block shrink-0`} />
                  <span className="text-xs text-slate-600 dark:text-slate-300 font-bold tracking-wide block truncate group-hover:text-slate-900 dark:group-hover:text-white transition-colors">
                    {item.label}
                  </span>
                </div>

                <div className="flex items-baseline gap-1.5 flex-wrap">
                  <span className="text-base sm:text-lg lg:text-xl font-black text-slate-900 dark:text-white font-mono tracking-tight drop-shadow-none dark:drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
                    {item.value}
                  </span>
                  <span className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                    {item.unit}
                  </span>
                </div>
              </div>

              {/* Squircle Icon Badge on the Right */}
              <div className={`relative z-10 w-10 h-10 sm:w-10.5 sm:h-10.5 rounded-xl flex items-center justify-center shrink-0 transition-transform duration-200 group-hover:scale-105 bg-slate-100 dark:bg-[#061826]/90 border border-slate-200 dark:border-cyan-500/35 text-cyan-600 dark:text-cyan-400 shadow-sm dark:shadow-[0_0_12px_rgba(var(--theme-accent-rgb),0.18)]`}>
                <Icon className="w-5 h-5 stroke-[2]" />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
