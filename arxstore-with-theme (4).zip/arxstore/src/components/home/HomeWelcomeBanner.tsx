'use client';

import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ShoppingBag, Wallet } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function HomeWelcomeBanner() {
  const router = useRouter();
  const { welcomeBanner, playClick } = useStore();

  // If disabled in admin panel, do not render
  if (!welcomeBanner || welcomeBanner.enabled === false) {
    return null;
  }

  const prefix = welcomeBanner.titlePrefix || 'ยินดีต้อนรับสู่ร้าน';
  const highlight = welcomeBanner.titleHighlight || 'ARXSTORE.XYZ';
  const description =
    welcomeBanner.description ||
    'ร้านบริการจำหน่ายโปรแกรมช่วยเล่น Fivem / ปลดแบนFivem ราคาถูกและปลอดภัยต่อผู้ใช้ ตอบโจทย์ทุกการใช้งาน ต่างๆ ไม่ว่าจะเป็นโปรแกรม External / Unban / Internal / CMD';
  const btn1Text = welcomeBanner.button1Text || 'ซื้อเลย';
  const btn1Link = welcomeBanner.button1Link || '#products-catalog';
  const btn2Text = welcomeBanner.button2Text || 'วิธีใช้งาน';
  const btn2Link = welcomeBanner.button2Link || '/how-to';
  const highlightColor = welcomeBanner.highlightColor || '#00e5ff';

  const handleBtn1Click = (e: React.MouseEvent) => {
    playClick();
    if (btn1Link.startsWith('#')) {
      e.preventDefault();
      const targetId = btn1Link.replace('#', '');
      const targetEl = document.getElementById(targetId) || document.getElementById('products-catalog');
      if (targetEl) {
        const navHeader = document.querySelector('.store-nav-header');
        const navHeight = navHeader ? navHeader.getBoundingClientRect().height : 75;
        const targetY = targetEl.getBoundingClientRect().top + window.pageYOffset - navHeight - 16;
        window.scrollTo({
          top: Math.max(0, targetY),
          behavior: 'smooth'
        });
      }
    } else {
      router.push(btn1Link);
    }
  };

  const handleBtn2Click = (e: React.MouseEvent) => {
    playClick();
    if (btn2Link.startsWith('#')) {
      e.preventDefault();
      const targetId = btn2Link.replace('#', '');
      const targetEl = document.getElementById(targetId);
      if (targetEl) {
        targetEl.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      router.push(btn2Link);
    }
  };

  // Determine button 1 gradient based on highlight color
  const isRedTheme = highlightColor.toLowerCase().includes('ef4444') || highlightColor.toLowerCase().includes('red') || highlightColor.toLowerCase().includes('dc2626');

  return (
    <section className="relative w-full pt-1 pb-2 sm:pt-2 sm:pb-3 px-1 sm:px-0">
      {/* Main Container */}
      <div className="flex flex-col items-start text-left space-y-2.5 sm:space-y-3">
        
        {/* Main Headline */}
        <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-[40px] font-black tracking-tight leading-tight text-slate-900 dark:text-white select-none">
          <span>{prefix} </span>
          <span
            className="inline-block transition-all duration-300 drop-shadow-[0_0_24px_rgba(var(--theme-accent-rgb),0.45)]"
            style={{ color: highlightColor }}
          >
            {highlight}
          </span>
        </h1>

        {/* Subtitle / Description Text */}
        {description && (
          <p className="text-xs sm:text-[13px] md:text-sm text-slate-700 dark:text-slate-300/90 leading-relaxed font-normal max-w-4xl select-none">
            {description}
          </p>
        )}
      </div>
    </section>
  );
}
