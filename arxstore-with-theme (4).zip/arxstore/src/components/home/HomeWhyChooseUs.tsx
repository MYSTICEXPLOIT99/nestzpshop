'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import {
  ShieldCheck,
  Headphones,
  ShoppingBag,
  Wallet,
  Bell,
  Sparkles
} from 'lucide-react';

export default function HomeWhyChooseUs() {
  const router = useRouter();
  const { siteContent, playClick } = useStore();

  const siteName = siteContent?.branding?.siteName || 'ARX STORE';
  const discordUrl = siteContent?.branding?.discordUrl || 'https://discord.gg';

  const handleNav = (url: string, isExternal = false) => {
    playClick();
    if (isExternal) {
      window.open(url, '_blank', 'noopener,noreferrer');
    } else if (url.startsWith('#')) {
      const el = document.querySelector(url);
      if (el) {
        const navHeader = document.querySelector('.store-nav-header');
        const navHeight = navHeader ? navHeader.getBoundingClientRect().height : 75;
        const targetY = el.getBoundingClientRect().top + window.pageYOffset - navHeight - 16;
        window.scrollTo({
          top: Math.max(0, targetY),
          behavior: 'smooth'
        });
      } else {
        router.push('/store');
      }
    } else {
      router.push(url);
    }
  };

  const navCards = [
    {
      title: 'สินค้า',
      subtitle: 'STORE PRODUCTS',
      icon: ShoppingBag,
      link: '/store',
      external: false
    },
    {
      title: 'เติมเงิน',
      subtitle: 'TOPUP PAYMENT',
      icon: Wallet,
      link: '/topup',
      external: false
    },
    {
      title: 'ติดตาม',
      subtitle: 'SOCIAL MEDIA',
      icon: Bell,
      link: discordUrl,
      external: true
    },
    {
      title: 'ติดต่อ',
      subtitle: 'ADMIN CONTACT',
      icon: Headphones,
      link: discordUrl,
      external: true
    }
  ];

  return (
    <section className="w-full space-y-3.5 sm:space-y-4 pt-1 select-none">
      {/* Section Title */}
      <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-white tracking-tight flex items-center gap-2">
        <span>ทำไมต้องเลือก</span>
        <span className="text-[color:var(--theme-main)]">{siteName}</span>
      </h2>

      {/* Row 1: 2 Main Feature Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 sm:gap-4">
        {/* Card 1: ปลอดภัย รวดเร็ว */}
        <div className="rounded-2xl bg-[color:var(--arx-dk-0a0a0f)] border border-[color:var(--theme-main)]/30 hover:border-[color:var(--theme-main)]/70 p-5 sm:p-6 transition-all duration-300 hover:shadow-[0_0_25px_rgba(var(--theme-main-rgb),0.25)] flex items-start gap-4 group">
          <div className="w-12 h-12 rounded-2xl bg-[color:var(--theme-main)]/15 border border-[color:var(--theme-main)]/40 flex items-center justify-center shrink-0 shadow-[0_0_16px_rgba(var(--theme-main-rgb),0.3)] group-hover:scale-105 group-hover:border-[color:var(--theme-main)] transition-all">
            <ShieldCheck className="w-6 h-6 text-[color:var(--theme-main)] stroke-[2.2]" />
          </div>
          <div className="space-y-1.5 min-w-0">
            <h3 className="text-base sm:text-lg font-black text-white">
              ปลอดภัย รวดเร็ว
            </h3>
            <p className="text-xs sm:text-[13px] text-zinc-400 leading-relaxed font-normal">
              ใส่ใจในคุณภาพของสินค้าและบริการ ด้วยระบบรักษาความปลอดภัยที่ทันสมัย พร้อมการบริการที่รวดเร็วและเชื่อถือได้ตลอด 24 ชั่วโมง
            </p>
          </div>
        </div>

        {/* Card 2: บริการลูกค้า */}
        <div className="rounded-2xl bg-[color:var(--arx-dk-0a0a0f)] border border-[color:var(--theme-main)]/30 hover:border-[color:var(--theme-main)]/70 p-5 sm:p-6 transition-all duration-300 hover:shadow-[0_0_25px_rgba(var(--theme-main-rgb),0.25)] flex items-start gap-4 group">
          <div className="w-12 h-12 rounded-2xl bg-[color:var(--theme-main)]/15 border border-[color:var(--theme-main)]/40 flex items-center justify-center shrink-0 shadow-[0_0_16px_rgba(var(--theme-main-rgb),0.3)] group-hover:scale-105 group-hover:border-[color:var(--theme-main)] transition-all">
            <Headphones className="w-6 h-6 text-[color:var(--theme-main)] stroke-[2.2]" />
          </div>
          <div className="space-y-1.5 min-w-0">
            <h3 className="text-base sm:text-lg font-black text-white">
              บริการลูกค้า
            </h3>
            <p className="text-xs sm:text-[13px] text-zinc-400 leading-relaxed font-normal">
              ทีมงานมืออาชีพพร้อมให้คำปรึกษาและแก้ไขปัญหาตลอด 24 ชั่วโมง ด้วยใจที่ใส่ใจในทุกรายละเอียด เพื่อความพึงพอใจสูงสุดของลูกค้า
            </p>
          </div>
        </div>
      </div>

      {/* Row 2: 4 Action Navigation Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {navCards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <div
              key={idx}
              onClick={() => handleNav(card.link, card.external)}
              className="relative overflow-hidden rounded-2xl bg-[color:var(--arx-dk-0a0a0f)] border border-[color:var(--theme-main)]/30 hover:border-[color:var(--theme-main)]/70 p-3.5 sm:p-4.5 cursor-pointer transition-all duration-300 hover:shadow-[0_0_24px_rgba(var(--theme-main-rgb),0.3)] hover:-translate-y-0.5 group flex flex-col justify-between"
            >
              {/* Top Tag: [ ✦ SITE_NAME ] */}
              <div className="flex items-center justify-between mb-3">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-[color:var(--theme-main)]/15 border border-[color:var(--theme-main)]/35 text-[10px] font-bold text-blue-300 tracking-wider uppercase">
                  <Sparkles className="w-2.5 h-2.5 text-[color:var(--theme-main)]" />
                  <span>{siteName}</span>
                </span>
              </div>

              {/* Main Info Row: Icon Left + Info Right */}
              <div className="flex items-center gap-3 sm:gap-3.5 my-1">
                {/* Large Icon Box */}
                <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-white/[0.04] border border-white/10 group-hover:border-[color:var(--theme-main)]/60 group-hover:bg-[color:var(--theme-main)]/10 flex items-center justify-center shrink-0 transition-all">
                  <Icon className="w-6 h-6 text-white group-hover:text-blue-400 transition-colors stroke-[2]" />
                </div>

                {/* Text Info */}
                <div className="min-w-0 flex-1">
                  <h4 className="text-base sm:text-lg font-black text-white leading-tight group-hover:text-blue-300 transition-colors">
                    {card.title}
                  </h4>
                  <span className="text-[10px] sm:text-[11px] text-zinc-400 font-semibold uppercase tracking-wider block">
                    {card.subtitle}
                  </span>
                </div>
              </div>

              {/* Bottom Action Pill: คลิกเลย! */}
              <div className="mt-3 flex justify-end">
                <span className="px-3 py-1 rounded-lg bg-[color:var(--theme-main)] group-hover:bg-[color:var(--theme-sec)] text-white text-[10.5px] sm:text-xs font-black shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.45)] group-hover:shadow-[0_0_18px_rgba(var(--theme-main-rgb),0.7)] transition-all">
                  คลิกเลย!
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
