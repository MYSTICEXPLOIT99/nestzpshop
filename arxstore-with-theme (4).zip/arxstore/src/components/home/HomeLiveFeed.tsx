'use client';

import React, { useRef } from 'react';
import { useStore } from '@/context/StoreContext';
import { ChevronLeft, ChevronRight, ShoppingCart } from 'lucide-react';

interface FeedItem {
  id: string;
  username: string;
  productName: string;
  price: number;
  time: string;
  badge: string;
  badgeColor?: string;
  image: string;
}

function formatFeedDate(dateStr?: string): string {
  if (!dateStr) return 'เมื่อสักครู่';
  if (/^\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/.test(dateStr)) return dateStr;
  try {
    const d = new Date(dateStr);
    if (!isNaN(d.getTime())) {
      const now = Date.now();
      const diffSec = Math.floor((now - d.getTime()) / 1000);
      if (diffSec < 60) return 'เมื่อสักครู่';
      if (diffSec < 3600) return `${Math.floor(diffSec / 60)} นาทีที่แล้ว`;
      if (diffSec < 86400) return `${Math.floor(diffSec / 3600)} ชั่วโมงที่แล้ว`;
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      return `${day}/${month}`;
    }
  } catch {
    // fallback
  }
  return dateStr;
}

export default function HomeLiveFeed() {
  const { orders, products, lang, playClick, recentOrdersFeedEnabled } = useStore();
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // If disabled in admin panel or if there are NO real orders in the database, DO NOT render
  if (!recentOrdersFeedEnabled || !orders || orders.length === 0) {
    return null;
  }

  const scroll = (direction: 'left' | 'right') => {
    playClick();
    if (scrollContainerRef.current) {
      const offset = direction === 'left' ? -320 : 320;
      scrollContainerRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  // Only real user orders from actual purchases
  const dynamicOrders: FeedItem[] = orders.map((o) => {
    const prod = products.find((p) => p.id === o.productId);
    return {
      id: o.id,
      username: o.username || (o.userId?.startsWith('usr-') ? 'User_' + o.userId.slice(-4) : o.userId) || 'Anonymous',
      productName: o.productName,
      price: o.price,
      time: formatFeedDate(o.createdAt),
      badge: prod?.categoryName?.toUpperCase() || 'PROGRAM PRO',
      image: prod?.image || '/catalog/imported/46ebc6a271269458ec9b.webp'
    };
  });

  if (dynamicOrders.length === 0) {
    return null;
  }

  // Duplicate items if needed for continuous CSS marquee loop
  let displayItems = [...dynamicOrders];
  while (displayItems.length < 8 && displayItems.length > 0) {
    displayItems = [...displayItems, ...displayItems];
  }

  return (
    <section className="w-full pt-1 pb-1 relative">
      {/* Header Section matching reference image: 🛒 สินค้าที่เพิ่งซื้อล่าสุด • Recent Purchases */}
      <div className="flex items-center gap-2 mb-2 px-1">
        <ShoppingCart className="w-4 h-4 text-blue-400" />
        <h2 className="text-xs sm:text-sm font-bold text-white tracking-wide">
          สินค้าที่เพิ่งซื้อล่าสุด <span className="text-zinc-500 font-normal ml-1">• Recent Purchases</span>
        </h2>
      </div>

      {/* Horizontal Continuous Looping Marquee */}
      <div className="live-feed-marquee-container pb-1 pt-0.5 select-none">
        <div className="live-feed-marquee-track">
          {displayItems.map((item, idx) => (
            <div
              key={`${item.id}-${idx}`}
              className="flex-shrink-0 rounded-xl bg-[color:var(--arx-dk-0e0f14)] hover:bg-[color:var(--arx-dk-13141a)] border border-white/[0.08] hover:border-[color:var(--theme-main)]/50 px-3 py-2 flex items-center gap-2.5 transition-colors duration-150 cursor-default group"
            >
              {/* Product Thumbnail */}
              <div className="w-8 h-8 rounded-lg overflow-hidden bg-black shrink-0 border border-white/10 group-hover:border-[color:var(--theme-main)]/50 transition-colors">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={item.image}
                  alt={item.productName}
                  className="w-full h-full object-cover"
                  loading="lazy"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (!target.src.includes('46ebc6a271269458ec9b.webp')) {
                      target.src = '/catalog/imported/46ebc6a271269458ec9b.webp';
                    }
                  }}
                />
              </div>

              {/* Info Column */}
              <div className="flex flex-col justify-center min-w-0 max-w-[130px] sm:max-w-[160px]">
                <div className="text-xs font-bold text-white tracking-wide truncate group-hover:text-blue-400 transition-colors leading-tight">
                  {item.productName}
                </div>
                <div className="text-[10px] text-zinc-400 truncate mt-0.5 leading-tight flex items-center gap-1 font-mono">
                  <span>👤</span>
                  <span>{item.username}</span>
                  <span>•</span>
                  <span>{item.time}</span>
                </div>
              </div>

              {/* Price badge */}
              <div className="text-xs font-black text-blue-400 font-mono tracking-tight shrink-0 pl-1">
                ฿{item.price.toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
