'use client';

import React from 'react';
import { useStore } from '@/context/StoreContext';

export default function HowToBuySection() {
  const { siteContent } = useStore();
  const { stepsSection } = siteContent || {};
  const steps = stepsSection?.steps || [
    { number: '01', title: 'เลือกสินค้า', description: 'ดูรายละเอียดและจำนวนคงเหลือก่อนซื้อสินค้า' },
    { number: '02', title: 'ชำระเงิน', description: 'มีเครดิตกดจ่ายได้เลย ไม่มีก็เติมเข้าบัญชีก่อน' },
    { number: '03', title: 'รับสินค้า', description: 'ข้อมูลขึ้นบนหน้าเว็บและส่งเข้าอีเมล เปิดดูย้อนหลังได้' },
    { number: '04', title: 'มีปัญหา ทักเลย', description: 'แจ้งเคลมเองได้จากหน้าคำสั่งซื้อภายในเวลารับประกัน' }
  ];

  return (
    <section className="w-full py-8 sm:py-12 select-none">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Heading */}
        <div className="lg:col-span-4 space-y-1 sm:space-y-1.5">
          <span className="text-xs sm:text-sm font-semibold tracking-wider text-slate-400 uppercase">
            {stepsSection?.subtitle || 'ขั้นตอน'}
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
            {stepsSection?.title || 'ซื้อยังไง'}
          </h2>
        </div>

        {/* Right Column: 2x2 Grid Container (Image 1 Style) */}
        <div className="lg:col-span-8">
          <div className="rounded-2xl border border-white/10 bg-[color:var(--arx-dk-070b13)]/85 backdrop-blur-md overflow-hidden shadow-[0_10px_35px_rgba(0,0,0,0.6)]">
            <div className="grid grid-cols-1 sm:grid-cols-2 divide-y sm:divide-y-0 sm:divide-x divide-white/10">
              {/* Step 1 */}
              <div className="p-5 sm:p-6 transition-colors hover:bg-white/[0.02]">
                <span className="text-cyan-400 font-mono font-black text-sm tracking-widest block mb-2">
                  {steps[0]?.number || '01'}
                </span>
                <h3 className="text-sm sm:text-base font-bold text-white mb-1.5">
                  {steps[0]?.title || 'เลือกสินค้า'}
                </h3>
                <p className="text-xs sm:text-[13px] text-slate-400 leading-relaxed">
                  {steps[0]?.description || 'ดูรายละเอียดและจำนวนคงเหลือก่อนซื้อสินค้า'}
                </p>
              </div>

              {/* Step 2 */}
              <div className="p-5 sm:p-6 transition-colors hover:bg-white/[0.02]">
                <span className="text-cyan-400 font-mono font-black text-sm tracking-widest block mb-2">
                  {steps[1]?.number || '02'}
                </span>
                <h3 className="text-sm sm:text-base font-bold text-white mb-1.5">
                  {steps[1]?.title || 'ชำระเงิน'}
                </h3>
                <p className="text-xs sm:text-[13px] text-slate-400 leading-relaxed">
                  {steps[1]?.description || 'มีเครดิตกดจ่ายได้เลย ไม่มีก็เติมเข้าบัญชีก่อน'}
                </p>
              </div>
            </div>

            {/* Middle Divider between row 1 and row 2 */}
            <div className="w-full border-t border-white/10" />

            <div className="grid grid-cols-1 sm:grid-cols-2 divide-y sm:divide-y-0 sm:divide-x divide-white/10">
              {/* Step 3 */}
              <div className="p-5 sm:p-6 transition-colors hover:bg-white/[0.02]">
                <span className="text-cyan-400 font-mono font-black text-sm tracking-widest block mb-2">
                  {steps[2]?.number || '03'}
                </span>
                <h3 className="text-sm sm:text-base font-bold text-white mb-1.5">
                  {steps[2]?.title || 'รับสินค้า'}
                </h3>
                <p className="text-xs sm:text-[13px] text-slate-400 leading-relaxed">
                  {steps[2]?.description || 'ข้อมูลขึ้นบนหน้าเว็บและส่งเข้าอีเมล เปิดดูย้อนหลังได้'}
                </p>
              </div>

              {/* Step 4 */}
              <div className="p-5 sm:p-6 transition-colors hover:bg-white/[0.02]">
                <span className="text-cyan-400 font-mono font-black text-sm tracking-widest block mb-2">
                  {steps[3]?.number || '04'}
                </span>
                <h3 className="text-sm sm:text-base font-bold text-white mb-1.5">
                  {steps[3]?.title || 'มีปัญหา ทักเลย'}
                </h3>
                <p className="text-xs sm:text-[13px] text-slate-400 leading-relaxed">
                  {steps[3]?.description || 'แจ้งเคลมเองได้จากหน้าคำสั่งซื้อภายในเวลารับประกัน'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
