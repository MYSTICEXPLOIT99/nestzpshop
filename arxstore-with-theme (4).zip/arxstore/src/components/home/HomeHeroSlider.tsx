'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { ChevronLeft, ChevronRight, Sparkles, ShoppingBag, ArrowUpRight, Zap, ShieldCheck } from 'lucide-react';

interface Slide {
  id: string;
  badge: string;
  badgeColor?: string;
  title: string;
  subtitle: string[];
  description: string;
  ctaText: string;
  ctaAction: string;
  accentColor: string;
  image?: string;
  theme: 'arx-brand' | 'fivem' | 'windows';
  isActive?: boolean;
}

const SLIDES: Slide[] = [
  {
    id: 'slide-arx-brand',
    badge: 'ARX OFFICIAL',
    badgeColor: 'border-cyan-500/40 text-cyan-400 bg-cyan-500/10',
    title: 'ARX STORE',
    subtitle: [
      'จำหน่าย Setting - BoostFPS'
    ],
    description: 'Setting - BoostFPS - Windows - Custom',
    ctaText: 'Setting - BoostFPS - Windows - Custom',
    ctaAction: 'all',
    accentColor: '#00e5ff',
    image: '',
    theme: 'arx-brand'
  },
  {
    id: 'slide-fivem',
    badge: 'TOP SELLER',
    badgeColor: 'border-emerald-500/40 text-emerald-400 bg-emerald-500/10',
    title: 'Setting Product',
    subtitle: [
      'FULL SYSTEM / AIMBOT / ESP',
      'BYPASS & SPOOFER HWID',
      'อัปเดตแพตช์ 2026 พร้อมใช้งาน'
    ],
    description: 'ปลดแบน FiveM ผ่าน 100% · ปลอดภัย ไม่โดนแบน',
    ctaText: 'EXPLORE SETTING',
    ctaAction: 'cat-fivem',
    accentColor: '#10b981',
    image: '/catalog/imported/banner_fivem.webp',
    theme: 'fivem'
  },
  {
    id: 'slide-windows',
    badge: 'PRO PERFORMANCE',
    badgeColor: 'border-blue-500/40 text-blue-400 bg-blue-500/10',
    title: 'BoostFPS & CustomOS',
    subtitle: [
      'OPTIMIZATION / LOW LATENCY',
      'CUSTOM REGISTRY & DRIVERS',
      'เพิ่มเฟรมเรท ลดดีเลย์ขั้นสุด'
    ],
    description: 'บริการจำหน่าย Setting , BoostFPS , Windows ต่างๆ โดย ARX STORE',
    ctaText: 'GET BOOSTED',
    ctaAction: 'cat-cheat',
    accentColor: '#38bdf8',
    image: '/catalog/imported/banner_cheat.webp',
    theme: 'windows'
  }
];

export default function HomeHeroSlider() {
  const { slides, heroSliderEnabled, siteStats, displayStats, playClick, t, lang } = useStore();
  const rawSlides = (slides && slides.length > 0) ? slides : SLIDES;
  const activeSlides = (heroSliderEnabled === false) ? [] : rawSlides.filter(s => s.isActive !== false);

  const [currentSlide, setCurrentSlide] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Auto-slide every 5.5s, pause on hover
  useEffect(() => {
    if (isHovered || activeSlides.length <= 1) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % activeSlides.length);
    }, 5500);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isHovered, activeSlides.length]);

  const handleNext = () => {
    playClick();
    if (activeSlides.length > 0) {
      setCurrentSlide((prev) => (prev + 1) % activeSlides.length);
    }
  };

  const handlePrev = () => {
    playClick();
    if (activeSlides.length > 0) {
      setCurrentSlide((prev) => (prev - 1 + activeSlides.length) % activeSlides.length);
    }
  };

  const handleDotClick = (index: number) => {
    playClick();
    setCurrentSlide(index);
  };

  const scrollToCatalog = (categoryId?: string) => {
    playClick();
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      if (categoryId && categoryId !== 'all') {
        url.searchParams.set('category', categoryId);
      } else {
        url.searchParams.delete('category');
      }
      window.history.replaceState({}, '', url.toString());

      const catalogEl = document.getElementById('products-catalog');
      if (catalogEl) {
        const navHeader = document.querySelector('.store-nav-header');
        const navHeight = navHeader ? navHeader.getBoundingClientRect().height : 75;
        const targetY = catalogEl.getBoundingClientRect().top + window.pageYOffset - navHeight - 16;
        window.scrollTo({
          top: Math.max(0, targetY),
          behavior: 'smooth'
        });
      }
    }
  };

  // If hero slider is disabled or has no active slides, DO NOT render anything at all
  if (heroSliderEnabled === false || activeSlides.length === 0) {
    return null;
  }

  const safeSlideIndex = currentSlide % activeSlides.length;
  const slide = activeSlides[safeSlideIndex] || activeSlides[0];
  if (!slide) return null;

  return (
    <section 
      className="relative w-full py-0.5"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Outer Banner Card Container with Cyber Border and Glow */}
      <div className="relative overflow-hidden rounded-2xl bg-[color:var(--arx-dk-07090e)] border border-cyan-500/20 shadow-xl shadow-cyan-950/30 group">
        {/* Subtle Cyber Grid Background & Ambient Radial Glows */}
        <div 
          className="absolute inset-0 pointer-events-none opacity-20"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, rgba(var(--theme-accent-rgb), 0.25) 1px, transparent 0)`,
            backgroundSize: '24px 24px'
          }}
        />
        
        {/* Ambient Top Glow */}
        <div 
          className="absolute -top-32 left-1/4 w-96 h-96 rounded-full blur-3xl pointer-events-none transition-all duration-700 opacity-25"
          style={{ backgroundColor: slide.accentColor }}
        />
        <div 
          className="absolute -bottom-32 right-1/4 w-96 h-96 rounded-full blur-3xl pointer-events-none transition-all duration-700 opacity-20"
          style={{ backgroundColor: slide.accentColor }}
        />

        {/* Slide Banner Render: Full image banner or Mockup layout */}
        {slide.image ? (
          <div 
            onClick={() => scrollToCatalog(slide.ctaAction)}
            className="relative cursor-pointer w-full overflow-hidden flex items-center justify-center group rounded-2xl"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={slide.image}
              alt={slide.title || 'Hero Banner'}
              className="w-full h-auto block rounded-2xl select-none transition-transform duration-500 group-hover:scale-[1.005]"
              onError={(e) => {
                const target = e.currentTarget;
                if (!target.src.includes('banner_fivem.webp')) {
                  target.src = '/catalog/imported/banner_fivem.webp';
                }
              }}
            />
          </div>
        ) : (
          /* Slide Content Layout: Left 3D Gaming Laptop (Red Screen) & Right Welcome Brand Copy */
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 items-center min-h-[180px] sm:min-h-[210px] lg:min-h-[240px] p-3 sm:p-5 lg:p-6 gap-3 sm:gap-5 bg-gradient-to-r from-[#031526] via-[#062947] to-[#041a2e]">
            
            {/* Cyber Electric Streaks & Brush Background Accents */}
            <div className="absolute inset-0 pointer-events-none opacity-35 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-cyan-500/20 via-transparent to-transparent" />
            
            {/* Left Column: 3D Angled Gaming Laptop with Red Screen */}
            <div className="lg:col-span-6 flex items-center justify-center relative select-none">
              {/* Back Glow behind laptop */}
              <div 
                className="absolute w-36 h-36 sm:w-48 sm:h-48 rounded-full blur-2xl pointer-events-none opacity-40 transition-all duration-700 bg-cyan-500/30"
              />

              {/* Laptop 3D Perspective Container */}
              <div className="relative w-full max-w-[190px] sm:max-w-[230px] lg:max-w-[260px] transform transition-transform duration-500 hover:scale-[1.02] [perspective:900px]">
                
                {/* 3D Angled Frame */}
                <div className="transform [transform:rotateY(14deg)_rotateX(6deg)] transition-all duration-500">
                  {/* Laptop Display Lid Frame */}
                  <div className="rounded-xl p-1 sm:p-1.5 bg-gradient-to-b from-[#2a303c] via-[var(--arx-dk-1a1f29)] to-[var(--arx-dk-0d1017)] border border-slate-600/70 shadow-2xl shadow-black relative overflow-hidden">
                    {/* Top Webcam Dot */}
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-950 mx-auto mb-1 border border-slate-700" />
                    
                    {/* Screen Bezel & Vibrant Cyan Display (Signature Look) */}
                    <div className="rounded-lg overflow-hidden bg-gradient-to-br from-cyan-400 via-[#00c8e6] to-[#04334a] aspect-[16/10] relative flex items-center justify-center shadow-[inset_0_0_20px_rgba(0,0,0,0.5)] border border-cyan-400/30">
                      {/* Gloss Screen Glare Reflection */}
                      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent pointer-events-none" />
                      
                      {/* Inner Cyan Screen Subtle Texture */}
                      <div className="w-full h-full opacity-30 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/20 via-transparent to-transparent pointer-events-none" />
                    </div>
                  </div>

                  {/* Laptop Keyboard Base / Lower Chassis with Side Ports */}
                  <div className="relative -mt-0.5 mx-auto w-[98%] h-3.5 sm:h-4 bg-gradient-to-b from-[var(--arx-dk-242b36)] via-[var(--arx-dk-171d27)] to-[var(--arx-dk-0c1017)] rounded-b-lg border-x border-b border-slate-600 shadow-lg flex items-center justify-between px-2">
                    {/* Left Side Ports (USB / 3.5mm) */}
                    <div className="flex items-center gap-1">
                      <div className="w-1.5 h-1 rounded-sm bg-slate-950 border border-slate-700" />
                      <div className="w-2 h-1 rounded-sm bg-slate-950 border border-slate-700" />
                    </div>
                    {/* Center Thumb Indentation */}
                    <div className="w-8 sm:w-10 h-1 rounded-full bg-slate-950/90" />
                    {/* Right Side Status LED */}
                    <div className="w-1 h-1 rounded-full bg-cyan-400 shadow-[0_0_6px_var(--theme-accent)]" />
                  </div>
                  {/* Laptop Cast Shadow */}
                  <div className="mx-auto w-[92%] h-1.5 bg-black/90 blur-sm rounded-full" />
                </div>
              </div>
            </div>

            {/* Right Column: Thai Welcome, ARX STORE Big Headline, Subtitle, Pill Badge */}
            <div className="lg:col-span-6 flex flex-col justify-center items-center lg:items-start text-center lg:text-left space-y-1 sm:space-y-1.5 z-10">
              
              {/* "ยินดีต้อนรับ" Thai Stylized Headline */}
              <div className="inline-block">
                <span className="text-xs sm:text-sm lg:text-base font-extrabold text-white tracking-wide drop-shadow-[0_0_8px_rgba(var(--theme-accent-rgb),0.7)]">
                  ยินดีต้อนรับ
                </span>
              </div>

              {/* Main Glowing Brand "ARX STORE" */}
              <div>
                <h1 className="text-xl sm:text-2xl lg:text-3xl font-black text-white tracking-wider uppercase drop-shadow-[0_0_16px_rgba(var(--theme-accent-rgb),0.85)]">
                  ARX STORE
                </h1>
              </div>

              {/* Slogan: "จำหน่าย Setting - BoostFPS" */}
              <div>
                <p className="text-xs sm:text-[13px] lg:text-sm font-bold text-cyan-200 tracking-wide drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
                  จำหน่าย Setting - BoostFPS
                </p>
              </div>

              {/* Pill Badge: "Setting - BoostFPS - Windows - Custom" */}
              <div className="pt-1">
                <div 
                  onClick={() => scrollToCatalog(slide.ctaAction)}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#051425]/90 hover:bg-[#08223d] border border-cyan-400/40 hover:border-cyan-300 text-[10px] sm:text-xs text-cyan-200 hover:text-white font-medium tracking-wide shadow-md shadow-cyan-950/50 cursor-pointer transition-all duration-200"
                >
                  <span>Setting - BoostFPS - Windows - Custom</span>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* Carousel Navigation Arrows (Visible only when more than 1 slide) */}
        {activeSlides.length > 1 && (
          <>
            <button
              type="button"
              onClick={handlePrev}
              aria-label="Previous slide"
              className="absolute left-2.5 top-1/2 -translate-y-1/2 w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-black/60 hover:bg-[color:var(--theme-accent)] text-slate-300 hover:text-slate-950 border border-white/10 hover:border-cyan-400 flex items-center justify-center transition-all duration-200 z-20 backdrop-blur-md cursor-pointer opacity-70 hover:opacity-100"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleNext}
              aria-label="Next slide"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-black/60 hover:bg-[color:var(--theme-accent)] text-slate-300 hover:text-slate-950 border border-white/10 hover:border-cyan-400 flex items-center justify-center transition-all duration-200 z-20 backdrop-blur-md cursor-pointer opacity-70 hover:opacity-100"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </>
        )}

            {/* Carousel Dot Indicators */}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
              {activeSlides.map((s, idx) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => handleDotClick(idx)}
                  aria-label={`Go to slide ${idx + 1}`}
                  className={`transition-all duration-300 rounded-full cursor-pointer ${
                    safeSlideIndex === idx
                      ? 'w-7 h-2 bg-[color:var(--theme-accent)] shadow-[0_0_10px_rgba(var(--theme-accent-rgb),0.7)]'
                      : 'w-2 h-2 bg-white/20 hover:bg-white/40'
                  }`}
                />
              ))}
            </div>

      </div>
    </section>
  );
}
