'use client';

import React from 'react';
import { useStore } from '@/context/StoreContext';
import { Server, Crosshair, Cpu, MessageSquare, ArrowRight, Layers, Zap, Monitor } from 'lucide-react';
import Link from 'next/link';

export default function CategoryGrid({ onSelectCategory }: { onSelectCategory?: (id: string) => void }) {
  const { categories, playClick } = useStore();

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Server':
        return <Server className="w-6 h-6 text-purple-400" />;
      case 'Zap':
        return <Zap className="w-6 h-6 text-amber-400" />;
      case 'Monitor':
        return <Monitor className="w-6 h-6 text-cyan-400" />;
      case 'Crosshair':
        return <Crosshair className="w-6 h-6 text-cyan-400" />;
      case 'Cpu':
        return <Cpu className="w-6 h-6 text-emerald-400" />;
      case 'MessageSquare':
        return <MessageSquare className="w-6 h-6 text-indigo-400" />;
      default:
        return <Layers className="w-6 h-6 text-purple-400" />;
    }
  };

  return (
    <section className="py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="text-xs font-bold text-cyan-400 uppercase tracking-widest mb-1 flex items-center gap-1.5">
              <Layers className="w-4 h-4" /> หมวดหมู่สินค้า
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              เลือกตามหมวดหมู่
            </h2>
          </div>
          <Link
            href="/store"
            onClick={playClick}
            className="text-xs font-semibold text-purple-400 hover:text-purple-300 flex items-center gap-1 transition"
          >
            ดูทั้งหมด <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {/* Categories Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {categories.map((cat, idx) => (
            <div
              key={cat.id}
              onClick={() => {
                playClick();
                if (onSelectCategory) {
                  onSelectCategory(cat.id);
                }
              }}
              className="cyber-card rounded-2xl p-5 border border-purple-500/20 bg-slate-950/70 hover:border-purple-500/50 cursor-pointer group transition-all"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 group-hover:scale-110 transition-transform">
                  {getIcon(cat.iconName)}
                </div>
                {cat.badge && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    {cat.badge}
                  </span>
                )}
              </div>

              <span className="text-xs font-mono font-bold text-slate-500">
                0{idx + 1}
              </span>
              <h3 className="text-base font-bold text-white group-hover:text-purple-300 transition-colors mt-0.5">
                {cat.name}
              </h3>
              <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                {cat.description}
              </p>

              <div className="mt-4 pt-3 border-t border-slate-900 flex items-center justify-between text-xs">
                <span className="text-slate-400 font-medium">
                  {cat.itemCount} รายการสินค้า
                </span>
                <span className="text-cyan-400 font-semibold group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  ดูสินค้า <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
