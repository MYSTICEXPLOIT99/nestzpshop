'use client';

import React, { useState } from 'react';
import { useStore } from '@/context/StoreContext';
import { Plus, Minus } from 'lucide-react';

export default function FaqSection() {
  const { siteContent, playClick } = useStore();
  const { faqSection } = siteContent || {};
  const faqs = faqSection?.faqs || [
    {
      id: 'faq-1',
      question: 'ต้องสมัครสมาชิกไหม',
      answer: 'สมัครสมาชิกง่ายๆ เพียงกรอกชื่อผู้ใช้และรหัสผ่าน ไม่จำเป็นต้องใช้อีเมลจริง เพื่อเก็บประวัติการสั่งซื้อ ดูรหัสคีย์ย้อนหลังได้ตลอดเวลา'
    },
    {
      id: 'faq-2',
      question: 'ได้ของเมื่อไหร่',
      answer: 'ได้รับสินค้าทันทีหลังชำระเงินเสร็จสิ้น ระบบทำงานจัดส่งอัตโนมัติ 24 ชม. ข้อมูลจะแสดงบนหน้าจอและบันทึกลงบัญชีของคุณทันที'
    },
    {
      id: 'faq-3',
      question: 'ถ้าสินค้าใช้ไม่ได้ทำยังไง',
      answer: 'สินค้าทุกตัวมีคลิปสอนและวิธีใช้งานอย่างละเอียด หากติดขัดสามารถกดปุ่มติดต่อเพื่อส่งข้อความให้แอดมินช่วยตรวจสอบและเคลมสินค้าได้ตลอดเวลา'
    },
    {
      id: 'faq-4',
      question: 'เติมเงินได้ทางไหนบ้าง',
      answer: 'รองรับระบบสแกน QR Code พร้อมเพย์ และ TrueMoney Wallet ยอดเงินเข้าบัญชีอัตโนมัติทันที สะดวก ปลอดภัย 100%'
    }
  ];

  const [openIds, setOpenIds] = useState<string[]>([]);

  const toggleFaq = (id: string) => {
    playClick();
    setOpenIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  return (
    <section className="w-full py-8 sm:py-12 select-none">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Heading */}
        <div className="lg:col-span-4 space-y-1 sm:space-y-1.5">
          <span className="text-xs sm:text-sm font-semibold tracking-wider text-slate-400 uppercase">
            {faqSection?.subtitle || 'คำถามที่พบบ่อย'}
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
            {faqSection?.title || 'สงสัยอะไรไหม'}
          </h2>
        </div>

        {/* Right Column: Accordion List (Image 1 Style) */}
        <div className="lg:col-span-8">
          <div className="divide-y divide-white/10 border-t border-b border-white/10">
            {faqs.map(faq => {
              const isOpen = openIds.includes(faq.id);
              return (
                <div key={faq.id} className="transition-colors hover:bg-white/[0.015]">
                  <button
                    type="button"
                    onClick={() => toggleFaq(faq.id)}
                    className="w-full py-4 sm:py-5 flex items-center justify-between gap-4 text-left cursor-pointer group"
                  >
                    <span className="text-sm sm:text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                      {faq.question}
                    </span>
                    <span className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-slate-400 group-hover:text-cyan-400 transition-colors">
                      {isOpen ? (
                        <Minus className="w-4 h-4 text-cyan-400" />
                      ) : (
                        <Plus className="w-4 h-4" />
                      )}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="pb-5 pt-1 text-xs sm:text-sm text-slate-300 leading-relaxed animate-in fade-in slide-in-from-top-1 duration-150 pr-8">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
