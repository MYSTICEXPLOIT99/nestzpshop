'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import {
  Flame,
  Crosshair,
  Server,
  Shield,
  Gamepad2,
  Swords,
  Ban,
  PackageOpen,
  ArrowRight,
  Layers,
  Sparkles
} from 'lucide-react';

interface Props {
  selectedCategory?: string;
  onSelectCategory?: (id: string) => void;
}

export default function ModernCatalogSection({
  selectedCategory = 'all',
  onSelectCategory
}: Props) {
  const router = useRouter();
  const {
    products,
    categories,
    playClick,
    searchQuery,
    setSearchQuery
  } = useStore();

  const [activeTab, setActiveTab] = useState<string>(selectedCategory || 'all');

  const handleTabChange = (catId: string) => {
    playClick();
    setActiveTab(catId);
    if (onSelectCategory) {
      onSelectCategory(catId);
    }
  };

  // Get icon for category
  const getCategoryIcon = (slugOrName: string) => {
    const s = slugOrName.toLowerCase();
    if (s.includes('fivem')) return <Server className="w-3.5 h-3.5 text-blue-400" />;
    if (s.includes('pubg')) return <Crosshair className="w-3.5 h-3.5 text-orange-400" />;
    if (s.includes('freefire') || s.includes('free fire')) return <Flame className="w-3.5 h-3.5 text-[color:var(--theme-main)]" />;
    if (s.includes('manager')) return <Shield className="w-3.5 h-3.5 text-sky-400" />;
    if (s.includes('roblox')) return <Gamepad2 className="w-3.5 h-3.5 text-blue-400" />;
    if (s.includes('rov')) return <Swords className="w-3.5 h-3.5 text-rose-400" />;
    if (s.includes('unban')) return <Ban className="w-3.5 h-3.5 text-red-400" />;
    return <Layers className="w-3.5 h-3.5 text-cyan-400" />;
  };

  // Filter products by category and search
  const filteredProducts = products.filter((p) => {
    const matchCategory =
      activeTab === 'all' ||
      p.categoryId === activeTab ||
      p.categoryName?.toLowerCase().includes(activeTab.toLowerCase());

    const matchSearch =
      !searchQuery ||
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.categoryName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tags?.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchCategory && matchSearch;
  });

  return (
    <section className="w-full space-y-6 pt-3 pb-8" id="products-catalog">
      
      {/* 1. Category Filter Pills Bar (เลือกตามหมวด - Matching Image 2) */}
      <div className="space-y-2">
        <label className="text-xs text-zinc-400 font-semibold block">
          เลือกตามหมวด
        </label>

        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1.5 scroll-smooth">
          {/* "ทั้งหมด" Pill */}
          <button
            type="button"
            onClick={() => handleTabChange('all')}
            className={`px-4 py-2 rounded-full text-xs font-semibold flex items-center gap-2 shrink-0 transition-all cursor-pointer ${
              activeTab === 'all'
                ? 'bg-[color:var(--theme-main)]/20 border border-[color:var(--theme-main)]/60 text-blue-300 shadow-[0_0_15px_rgba(var(--theme-main-rgb),0.35)]'
                : 'bg-[color:var(--arx-dk-111217)] hover:bg-[color:var(--arx-dk-181920)] border border-white/10 text-zinc-300 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>ทั้งหมด</span>
            <span className="text-[10px] text-zinc-500 font-mono px-1.5 py-0.2 rounded-full bg-white/5">
              {products.length}
            </span>
          </button>

          {/* Categories Pills */}
          {categories.map((cat) => {
            const isSelected = activeTab === cat.id;
            const catCount = products.filter((p) => p.categoryId === cat.id).length;
            const badgeText = cat.badge || (catCount > 0 ? catCount.toString() : '');

            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => handleTabChange(cat.id)}
                className={`px-3.5 py-2 rounded-full text-xs font-semibold flex items-center gap-2 shrink-0 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[color:var(--theme-main)]/20 border border-[color:var(--theme-main)]/60 text-blue-300 shadow-[0_0_15px_rgba(var(--theme-main-rgb),0.35)]'
                    : 'bg-[color:var(--arx-dk-111217)] hover:bg-[color:var(--arx-dk-181920)] border border-white/10 text-zinc-300 hover:text-white'
                }`}
              >
                {cat.image ? (
                  <div className="w-4 h-4 rounded-full overflow-hidden shrink-0 border border-white/20 bg-black/40">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={cat.image} alt={cat.name} className="w-full h-full object-cover rounded-full" />
                  </div>
                ) : (
                  getCategoryIcon(cat.slug || cat.name)
                )}
                <span>{cat.name}</span>
                {badgeText && (
                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                      badgeText === 'HOT'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold'
                        : 'bg-white/5 text-zinc-400'
                    }`}
                  >
                    {badgeText}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Catalog Section Header (คลังสินค้า / มาใหม่ล่าสุด - Matching Image 2) */}
      <div className="flex items-end justify-between pt-2 pb-1">
        <div>
          <span className="text-[11px] text-zinc-500 font-bold uppercase tracking-wider block">
            คลังสินค้า
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-0.5">
            มาใหม่ล่าสุด
          </h2>
        </div>

        <button
          type="button"
          onClick={() => {
            playClick();
            handleTabChange('all');
            setSearchQuery('');
          }}
          className="px-4 py-2 rounded-full bg-[color:var(--arx-dk-111217)] hover:bg-[color:var(--arx-dk-181920)] border border-white/10 text-xs text-zinc-300 hover:text-white font-medium transition cursor-pointer flex items-center gap-1.5 shadow-sm"
        >
          <span>ดูทั้งหมด {products.length} รายการ</span>
        </button>
      </div>

      {/* 3. Empty State if no products */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-16 px-4 rounded-3xl bg-[color:var(--arx-dk-0b0c10)] border border-white/5">
          <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto mb-3">
            <PackageOpen className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-white mb-1">
            ไม่พบสินค้าในหมวดหมู่นี้
          </h3>
          <p className="text-xs text-zinc-400 mb-4">
            ลองเลือกดูสินค้าทั้งหมด หรือเปลี่ยนหมวดหมู่อื่น
          </p>
          <button
            type="button"
            onClick={() => handleTabChange('all')}
            className="px-4 py-2 rounded-xl bg-cyan-400 text-slate-950 font-bold text-xs"
          >
            ดูสินค้าทั้งหมด
          </button>
        </div>
      ) : (
        /* 4. Product Cards Grid (Responsive 5 to 6 column layout) */
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 2xl:grid-cols-6 gap-3 sm:gap-4">
          {filteredProducts.map((product) => {
            const packages = product.packages || [];
            const isSingle = packages.length <= 1;
            const primaryPackage = packages[0];

            // Lowest and highest price
            const minPrice = packages.length > 0
              ? Math.min(...packages.map((p) => p.price))
              : 0;
            const originalPrice = primaryPackage?.originalPrice;

            // Total stock
            const totalStock = packages.reduce((sum, p) => sum + (p.stock || 0), 0);
            const isOutOfStock = totalStock <= 0 || product.status === 'out_of_stock';

            // Discount Badge (e.g. -40% or -60%)
            const discountBadge = product.discountBadge || (
              originalPrice && originalPrice > minPrice
                ? `-${Math.round(((originalPrice - minPrice) / originalPrice) * 100)}%`
                : null
            );

            return (
              <div
                key={product.id}
                onClick={() => {
                  playClick();
                  router.push(`/products/${product.id}`);
                }}
                className="rounded-2xl bg-[color:var(--arx-dk-0c0d12)] border border-white/[0.08] hover:border-[color:var(--theme-main)]/60 p-3 sm:p-3.5 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-blue-500/15 group cursor-pointer"
              >
                {/* Top Image Box */}
                <div>
                  <div className="relative aspect-square rounded-xl overflow-hidden bg-black/60 mb-2.5">
                    {/* Badge: ขายดี */}
                    <div className="absolute top-2 left-2 z-10 flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded-full bg-[color:var(--theme-main)] text-white font-black text-[9.5px] uppercase tracking-wider shadow-md">
                        {product.badge || 'ขายดี'}
                      </span>
                    </div>

                    {/* Discount Badge */}
                    {discountBadge && (
                      <div className="absolute top-2 right-2 z-10">
                        <span className="px-2 py-0.5 rounded-full bg-[color:var(--theme-main)] text-white font-black text-[9.5px] tracking-wider shadow-md">
                          {discountBadge}
                        </span>
                      </div>
                    )}

                    {/* Image */}
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={product.image}
                      alt={product.name}
                      className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 ${
                        isOutOfStock ? 'grayscale contrast-125' : ''
                      }`}
                      loading="lazy"
                      onError={(e) => {
                        const target = e.currentTarget;
                        if (!target.src.includes('sasuke_cover.webp')) {
                          target.src = '/catalog/imported/sasuke_cover.webp';
                        }
                      }}
                    />

                    {/* Out of Stock Overlay */}
                    {isOutOfStock && (
                      <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                        <span className="px-3 py-1 rounded bg-red-600 text-white font-black text-[10px] uppercase">
                          สินค้าหมด
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Category Name */}
                  <span className="text-zinc-500 text-[10.5px] font-bold uppercase tracking-wider block mb-1">
                    {product.categoryName || 'โค้ดไก่เวล'}
                  </span>

                  {/* Product Title */}
                  <h3
                    className="text-xs sm:text-[13px] font-bold text-white group-hover:text-blue-400 transition-colors line-clamp-2 min-h-[36px] leading-snug"
                    title={product.name}
                  >
                    {product.name}
                  </h3>
                </div>

                {/* Bottom: Price, Stock Bar, Buy Button */}
                <div className="mt-3 pt-2">
                  {/* Price & Stock Row */}
                  <div className="flex items-center justify-between gap-1 mb-2">
                    {/* Price */}
                    <div className="flex items-baseline gap-1.5 flex-wrap">
                      <span className="text-sm sm:text-base font-black text-white font-mono">
                        {!isSingle && <span className="text-xs text-zinc-400 font-sans mr-0.5 font-normal">เริ่ม </span>}
                        {minPrice.toLocaleString()} ฿
                      </span>
                      {originalPrice && originalPrice > minPrice && (
                        <span className="text-[11px] text-zinc-500 line-through font-mono">
                          {originalPrice} ฿
                        </span>
                      )}
                    </div>

                    {/* Stock Bar + Text */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <div className="w-8 sm:w-10 h-1 bg-[color:var(--theme-main)] rounded-full shadow-[0_0_8px_rgba(var(--theme-main-rgb),0.6)]" />
                      <span className="text-zinc-400 text-[10.5px] font-mono">
                        มี {totalStock}
                      </span>
                    </div>
                  </div>

                  {/* Action Button: ซื้อทันที (Electric Blue Full Width) */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      playClick();
                      router.push(`/products/${product.id}`);
                    }}
                    disabled={isOutOfStock}
                    className={`w-full py-2.5 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer text-center ${
                      isOutOfStock
                        ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                        : 'bg-[color:var(--theme-main)] hover:bg-[color:var(--theme-sec)] active:scale-[0.98] text-white shadow-[0_0_16px_rgba(var(--theme-main-rgb),0.4)] hover:shadow-[0_0_24px_rgba(var(--theme-main-rgb),0.6)]'
                    }`}
                  >
                    {isOutOfStock ? 'สินค้าหมด' : 'ซื้อทันที'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </section>
  );
}
