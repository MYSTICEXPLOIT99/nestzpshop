'use client';

import React from 'react';
import { useStore } from '@/context/StoreContext';
import {
  Sparkles,
  Zap,
  ShieldCheck,
  Users,
  MessageSquare,
  ArrowRight,
  ShoppingBag,
  ExternalLink,
  Flame,
  WalletCards
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function HeroSection() {
  const router = useRouter();
  const { playClick, products, displayStats } = useStore();

  const topProduct = products.find(p => p.rank === 1) || products[0];

  return (
    <section className="relative pt-6 pb-12 overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-full max-w-5xl h-96 bg-purple-600/10 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Hero Content */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            
            {/* Top Tagline Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/25 text-cyan-300 text-xs font-semibold backdrop-blur-md">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_var(--theme-accent)]" />
              ARX STORE · Setting , BoostFPS , Windows ต่างๆ
              <span className="text-slate-400">|</span>
              <span className="text-cyan-400 flex items-center gap-1 font-mono">
                <Flame className="w-3.5 h-3.5 fill-cyan-400" /> OFFICIAL
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
              ARX STORE <br />
              <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500 bg-clip-text text-transparent glow-cyan">
                บริการจำหน่าย Setting , BoostFPS , Windows ต่างๆ
              </span>
            </h1>

            {/* Description */}
            <p className="text-sm sm:text-base text-slate-300 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              บริการจำหน่าย Setting , BoostFPS , Windows ต่างๆ ซอฟต์แวร์เพิ่มประสิทธิภาพคอมพิวเตอร์และเกมมิ่ง ส่งมอบคีย์และลิงก์ดาวน์โหลดอัตโนมัติ 24 ชม. พร้อมระบบเติมเงินและรีเซ็ต HWID ทันใจ
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3.5 pt-2">
              <Link
                href="/store"
                onClick={playClick}
                className="px-6 py-3.5 rounded-2xl cyber-btn-primary font-bold text-sm tracking-wide flex items-center gap-2 shadow-xl shadow-cyan-500/30 group"
              >
                <ShoppingBag className="w-4 h-4" />
                สำรวจร้านค้าทั้งหมด
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>

              <Link
                href="/topup"
                onClick={playClick}
                className="px-6 py-3.5 rounded-2xl cyber-btn-secondary font-semibold text-sm flex items-center gap-2"
              >
                <WalletCards className="w-4 h-4 text-cyan-400" />
                เติมเงินเข้าระบบ
              </Link>
            </div>

            {/* Store Stats */}
            <div className="pt-6 grid grid-cols-3 gap-4 border-t border-slate-800/80 max-w-lg mx-auto lg:mx-0">
              <div className="text-center lg:text-left">
                <p className="text-xl sm:text-2xl font-black text-white font-mono">{(displayStats?.sales ?? 0).toLocaleString()}</p>
                <p className="text-xs text-slate-400">ออเดอร์จัดส่งแล้ว</p>
              </div>
              <div className="text-center lg:text-left">
                <p className="text-xl sm:text-2xl font-black text-cyan-400 font-mono">99.9%</p>
                <p className="text-xs text-slate-400">ระบบพร้อมใช้งาน</p>
              </div>
              <div className="text-center lg:text-left">
                <p className="text-xl sm:text-2xl font-black text-purple-400 font-mono">24/7</p>
                <p className="text-xs text-slate-400">จัดส่งคีย์อัตโนมัติ</p>
              </div>
            </div>

          </div>

          {/* Right Hero Banner & Community Card */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* Featured Product Banner Card */}
            <div className="relative rounded-3xl overflow-hidden border border-purple-500/30 group shadow-2xl bg-slate-900">
              <div className="aspect-[16/10] w-full overflow-hidden relative">
                <img
                  src={topProduct?.image || '/catalog/imported/banner_fivem.webp'}
                  alt={topProduct?.name || 'ARX STORE Featured'}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (!target.src.includes('banner_fivem.webp')) {
                      target.src = '/catalog/imported/banner_fivem.webp';
                    }
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                
                {/* Floating Badge */}
                <div className="absolute top-4 left-4 flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-purple-600/90 text-white backdrop-blur-md shadow-md border border-purple-400/40 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    สินค้าขายดีอันดับ 1
                  </span>
                </div>

                {/* Banner Content overlay */}
                <div className="absolute bottom-4 inset-x-4">
                  <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest font-bold">
                    FIVE M & PC SOFTWARE
                  </span>
                  <h3 className="text-lg sm:text-xl font-bold text-white leading-snug">
                    {topProduct.name}
                  </h3>
                  <div className="mt-2 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-400">ราคาเริ่มต้น</span>
                      <p className="text-base sm:text-lg font-black text-cyan-300 font-mono">
                        ฿{topProduct.packages[0]?.price.toLocaleString()}
                      </p>
                    </div>
                    {topProduct.packages.every(pkg => !pkg.inStock || pkg.stock <= 0) || topProduct.status === 'out_of_stock' ? (
                      <button
                        onClick={() => {
                          playClick();
                          router.push(`/products/${topProduct.id}`);
                        }}
                        className="px-3.5 py-2 rounded-xl bg-red-500/20 text-red-400 border border-red-500/40 font-black text-xs uppercase tracking-wider cursor-pointer hover:bg-red-500/30"
                      >
                        OUT OF STOCK
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          playClick();
                          router.push(`/products/${topProduct.id}`);
                        }}
                        className="px-4 py-2 rounded-xl cyber-btn-primary font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-cyan-500/30 cursor-pointer"
                      >
                        ซื้อเลย <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Discord Community Widget (Matching DEMOxSHOP) */}
            <div className="cyber-card rounded-2xl p-4 sm:p-5 flex items-center justify-between gap-4 border border-indigo-500/30 bg-indigo-950/20">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/40 shrink-0">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-white">
                      เจอกันใน Discord ของร้าน
                    </h4>
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      482 คนออนไลน์
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    พูดคุย สอบถาม รีวิวสินค้า และอัปเดตข่าวสารก่อนใคร
                  </p>
                </div>
              </div>

              <a
                href="#"
                onClick={(e) => {
                  playClick();
                  e.preventDefault();
                }}
                className="shrink-0 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 transition shadow-md shadow-indigo-600/30 cursor-pointer"
              >
                เข้าร่วม Discord
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
