'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import {
  Search,
  Tag,
  ArrowUpRight,
  ShoppingBag,
  PackageOpen
} from 'lucide-react';
import ProductHoverLoader from '@/components/common/ProductHoverLoader';

interface ProductGridProps {
  initialCategory?: string;
  selectedCategory?: string;
  onSelectCategory?: (id: string) => void;
}

export default function ProductGrid({
  initialCategory = 'all',
  selectedCategory: controlledCategory,
  onSelectCategory
}: ProductGridProps) {
  const {
    products,
    categories,
    openBuyModal,
    closeBuyModal,
    closeAuthModal,
    playClick,
    t,
    lang,
    searchQuery,
    setSearchQuery
  } = useStore();

  const router = useRouter();

  const [internalCategory, setInternalCategory] = useState<string>(controlledCategory || initialCategory);
  const [previewHoverId, setPreviewHoverId] = useState<string | null>(null);

  // Sync internal state when controlledCategory or initialCategory changes
  useEffect(() => {
    if (controlledCategory) {
      setInternalCategory(controlledCategory);
    } else if (initialCategory) {
      setInternalCategory(initialCategory);
    }
  }, [controlledCategory, initialCategory]);

  // Sync with URL query parameter ?category=... on mount and popstate
  useEffect(() => {
    const handleUrlSync = () => {
      if (typeof window !== 'undefined') {
        const params = new URLSearchParams(window.location.search);
        const cat = params.get('category');
        if (cat) {
          setInternalCategory(cat);
          if (onSelectCategory) onSelectCategory(cat);
        }
        const searchParam = params.get('search');
        if (searchParam) {
          setSearchQuery(searchParam);
        }
        const hoverId = params.get('hover_product');
        if (hoverId) setPreviewHoverId(hoverId);
      }
    };

    handleUrlSync();
    window.addEventListener('popstate', handleUrlSync);
    return () => window.removeEventListener('popstate', handleUrlSync);
  }, [onSelectCategory]);

  const activeCategory = controlledCategory || internalCategory;

  const handleCategoryChange = (catId: string) => {
    playClick();
    closeBuyModal();
    closeAuthModal();
    setInternalCategory(catId);
    if (onSelectCategory) onSelectCategory(catId);

    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      if (catId === 'all') {
        url.searchParams.delete('category');
      } else {
        url.searchParams.set('category', catId);
      }
      window.history.replaceState({}, '', url.toString());
    }
  };

  // Group products by category
  const categoriesToDisplay = activeCategory === 'all'
    ? categories
    : categories.filter(c => c.id === activeCategory);

  const totalFilteredCount = categoriesToDisplay.reduce((total, cat) => {
    const count = products
      .filter(p => p.categoryId === cat.id)
      .filter(p => {
        if (!searchQuery) return true;
        return (
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.shortDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()))
        );
      }).length;
    return total + count;
  }, 0);

  return (
    <section className="py-2 sm:py-3 w-full scroll-mt-28" id="products-catalog">

      {/* Empty State when no results */}
      {totalFilteredCount === 0 && (
        <div className="text-center py-16 px-4 rounded-3xl bg-slate-950/60 border border-white/5 my-6">
          <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto mb-4">
            <PackageOpen className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-white mb-1">
            {lang === 'th' ? 'ไม่พบสินค้าที่ตรงกับการค้นหา' : 'No products found'}
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-5">
            {lang === 'th'
              ? 'ลองค้นหาด้วยคำอื่น หรือเลือกดูสินค้าทั้งหมดในร้าน'
              : 'Try different search keywords or browse all available products'}
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              handleCategoryChange('all');
            }}
            className="px-5 py-2 rounded-full bg-cyan-500/20 hover:bg-cyan-500 text-cyan-200 hover:text-slate-950 border border-cyan-500/30 text-xs font-bold transition shadow-sm"
          >
            {t('catalog_all')}
          </button>
        </div>
      )}

      {/* Render Category Groups with smooth animated transition */}
      <div key={`${activeCategory}-${searchQuery}`} className="space-y-12 arx-products-enter" suppressHydrationWarning>
        {categoriesToDisplay.map((cat) => {
          const catProducts = products
            .filter(p => p.categoryId === cat.id)
            .filter(p => {
              if (!searchQuery) return true;
              return (
                p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                p.shortDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
                p.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()))
              );
            });

          if (catProducts.length === 0) return null;

          return (
            <div key={cat.id} className="store-catalog-group">
              {/* Category Group Header */}
              <header className="flex items-center justify-between pb-2.5 mb-4 border-b border-cyan-500/15">
                <h2 className="flex items-center gap-2.5 text-base sm:text-lg lg:text-xl font-bold text-slate-900 dark:text-white tracking-wide">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src="/brand/logo.png"
                    alt="ARX Logo"
                    className="w-6 h-6 object-contain drop-shadow-[0_0_6px_rgba(var(--theme-accent-rgb),0.7)]"
                    onError={(e) => {
                      const target = e.currentTarget;
                      if (!target.src.includes('arx-default-logo.png')) {
                        target.src = '/brand/arx-default-logo.png';
                      }
                    }}
                  />
                  <span className="text-slate-900 dark:text-white">{cat.name}</span>
                </h2>
                <span className="text-xs sm:text-[13px] text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-white/5 px-2.5 py-1 rounded border border-slate-200 dark:border-white/5">
                  <strong className="text-cyan-600 dark:text-cyan-300 font-bold">{catProducts.length}</strong> {t('items_count')}
                </span>
              </header>

              {/* Product Cards Grid: 5 columns matching reference */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-3.5">
                {catProducts.map((product) => {
                  const totalStock = product.packages.reduce((sum, p) => sum + (p.stock || 0), 0);
                  const isSoldOut = product.packages.every(pkg => !pkg.inStock || pkg.stock <= 0) || totalStock <= 0 || product.status === 'out_of_stock';
                  const minPrice = Math.min(...product.packages.map(p => p.price));
                  const maxPrice = Math.max(...product.packages.map(p => p.price));

                  return (
                    <div
                      key={product.id}
                      id={`product-card-${product.id}`}
                      data-product-id={product.id}
                      onClick={() => {
                        playClick();
                        router.push(`/products/${product.id}`);
                      }}
                      className={`group cursor-pointer rounded-2xl bg-[color:var(--arx-dk-0a0d16)]/90 border border-cyan-500/15 hover:border-cyan-400/50 p-2.5 sm:p-3 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-cyan-500/15 flex flex-col relative arx-product-card ${
                        previewHoverId === product.id ? 'hovered border-cyan-400/50 -translate-y-1 shadow-xl shadow-cyan-500/15' : ''
                      }`}
                    >
                      {/* Product Thumbnail (1500x1500 Square 1:1 Aspect Ratio) */}
                      <div className="relative aspect-square rounded-xl overflow-hidden bg-black mb-2">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={product.image}
                          alt={product.name}
                          className={`arx-card-thumb w-full h-full object-cover transition-all duration-400 group-hover:scale-105 group-hover:brightness-75 group-hover:blur-[1px] ${
                            isSoldOut ? 'grayscale contrast-125' : ''
                          }`}
                          loading="lazy"
                          onError={(e) => {
                            const target = e.currentTarget;
                            if (!target.src.includes('46ebc6a271269458ec9b.webp')) {
                              target.src = '/catalog/imported/46ebc6a271269458ec9b.webp';
                            }
                          }}
                        />

                        {/* ARX Cyber HUD Product Hover Loader with Shop Logo */}
                        <ProductHoverLoader
                          label={t('details') || 'CLICK TO VIEW'}
                          isSoldOut={isSoldOut}
                        />

                        {/* Sold Out / Out of Stock Overlay Stamp (when not hovered) */}
                        {isSoldOut && (
                          <div className="absolute inset-0 bg-black/65 backdrop-blur-[2px] flex items-center justify-center group-hover:opacity-0 transition-opacity duration-200">
                            <span className="px-2.5 py-0.5 rounded bg-red-600/95 text-white font-black text-[10px] tracking-wider uppercase border border-red-400/60 rotate-[-8deg] shadow-lg">
                              OUT OF STOCK
                            </span>
                          </div>
                        )}

                        {/* Badge if available (hide if sold out or on hover to keep HUD clean) */}
                        {!isSoldOut && product.badge && product.badge !== 'OUT OF STOCK' && product.badge !== 'สินค้าหมด' && (
                          <div className="absolute top-1.5 right-1.5 group-hover:opacity-0 group-[.hovered]:opacity-0 transition-opacity duration-200">
                            <span className="px-2 py-0.5 rounded-full text-[9.5px] font-black backdrop-blur-md shadow-md bg-[color:var(--theme-accent)] text-slate-950 shadow-cyan-500/30">
                              {product.badge}
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Product Title (1 line truncate matching reference) */}
                      <h3 className="text-xs sm:text-[13px] font-bold text-white tracking-wide group-hover:text-cyan-300 transition-colors truncate mb-1 px-0.5" title={product.name}>
                        {product.name}
                      </h3>

                      {/* Price (Bold font-mono matching reference) */}
                      <div className="text-sm sm:text-base font-bold text-cyan-400 tracking-tight font-mono mb-1 px-0.5">
                        {minPrice === maxPrice ? `฿${minPrice.toLocaleString()}` : `฿${minPrice.toLocaleString()} - ฿${maxPrice.toLocaleString()}`}
                      </div>

                      {/* Stock Row (Green dot indicator matching reference) */}
                      <div className="flex items-center justify-between text-[10px] sm:text-[11px] text-slate-400 mb-2 px-0.5">
                        <div className="flex items-center gap-1.5 truncate">
                          <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${isSoldOut ? 'bg-red-400' : 'bg-emerald-400 shadow-[0_0_6px_#10b981]'}`} />
                          <span className={isSoldOut ? 'text-red-400 font-bold uppercase truncate' : 'text-slate-400 truncate'}>
                            {isSoldOut ? 'OUT OF STOCK' : `${t('in_stock')} · ${totalStock} ${t('items_suffix')}`}
                          </span>
                        </div>
                      </div>

                      {/* Full-width Buy / View Details Button at bottom (Exact Match with Reference Card) */}
                      <div className="mt-auto pt-1">
                        {isSoldOut ? (
                          <button
                            type="button"
                            disabled
                            className="w-full py-1.5 sm:py-2 rounded-xl bg-red-500/15 text-red-400 border border-red-500/30 text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-1 cursor-not-allowed"
                          >
                            OUT OF STOCK
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              playClick();
                              router.push(`/products/${product.id}`);
                            }}
                            className="w-full py-1.5 sm:py-2 rounded-xl bg-cyan-500/15 group-hover:bg-[color:var(--theme-accent)] text-cyan-300 group-hover:text-slate-950 border border-cyan-500/30 group-hover:border-cyan-400 text-xs font-bold flex items-center justify-center gap-1.5 transition-all duration-200 shadow-sm cursor-pointer"
                          >
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>{t('buy_now')}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

    </section>
  );
}
