'use client';

import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import {
  ArrowRight,
  ShieldCheck,
  Star,
  Headphones,
  Users,
  ShoppingBag,
  Box,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

export default function ModernHeroSection() {
  const router = useRouter();
  const {
    welcomeBanner,
    siteStats,
    displayStats,
    products,
    users,
    playClick,
    siteContent
  } = useStore();

  // Store title (e.g. REFLEXSTORE, ARXSTORE, etc.)
  const storeTitle =
    siteContent?.branding?.siteName ||
    (welcomeBanner?.titleHighlight
      ? welcomeBanner.titleHighlight.replace(/\.XYZ$/i, '').toUpperCase()
      : 'REFLEXSTORE');

  // Description from branding or welcome banner
  const storeDescription =
    siteContent?.branding?.slogan ||
    welcomeBanner?.description ||
    'จำหน่ายโปรแกรมช่วยเล่นราคาถูก (เว็บตัวแทน)';

  // 100% Real stats calculation from backend
  const stockCount = typeof displayStats?.stock === 'number'
    ? displayStats.stock
    : (typeof siteStats?.stock === 'number' ? siteStats.stock : 0);

  const salesCount = typeof displayStats?.sales === 'number'
    ? displayStats.sales
    : (typeof siteStats?.sales === 'number' ? siteStats.sales : 0);

  const usersCount = (users && users.length > 0)
    ? users.length
    : (typeof displayStats?.users === 'number' && displayStats.users > 0 ? displayStats.users : (typeof siteStats?.users === 'number' && siteStats.users > 0 ? siteStats.users : 158));

  const productsCount = products ? products.length : 0;

  const stockDisplay = stockCount.toLocaleString();
  const salesDisplay = salesCount.toLocaleString();
  const productsCountDisplay = productsCount.toLocaleString();
  const usersDisplay = usersCount.toLocaleString();

  const handleExploreClick = (e: React.MouseEvent) => {
    playClick();
    if (typeof window !== 'undefined') {
      const catalogEl = document.getElementById('products-catalog');
      if (catalogEl) {
        const navHeader = document.querySelector('.store-nav-header');
        const navHeight = navHeader ? navHeader.getBoundingClientRect().height : 75;
        const targetY = catalogEl.getBoundingClientRect().top + window.pageYOffset - navHeight - 16;
        window.scrollTo({
          top: Math.max(0, targetY),
          behavior: 'smooth'
        });
      } else {
        router.push('/store');
      }
    }
  };

  const handleHowToClick = (e: React.MouseEvent) => {
    playClick();
    const target = welcomeBanner?.button2Link || '/how-to';
    if (target.startsWith('/')) {
      router.push(target);
    } else if (target.startsWith('#')) {
      const el = document.querySelector(target);
      if (el) {
        const navHeader = document.querySelector('.store-nav-header');
        const navHeight = navHeader ? navHeader.getBoundingClientRect().height : 75;
        const targetY = el.getBoundingClientRect().top + window.pageYOffset - navHeight - 16;
        window.scrollTo({
          top: Math.max(0, targetY),
          behavior: 'smooth'
        });
      } else {
        router.push('/how-to');
      }
    } else {
      router.push(target);
    }
  };

  const heroBannerSrc =
    welcomeBanner?.bannerUrl ||
    siteContent?.branding?.heroBannerUrl ||
    '/brand/hero-reflex-banner.png';

  return (
    <section className="w-full pt-1 pb-2 sm:pt-3 sm:pb-3 space-y-4">
      {/* 1. Top Row: Title, Subtitle, CTA Buttons (Left) & 3 Feature Badges (Right) */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 px-1">
        {/* Left Side */}
        <div className="flex flex-col items-start text-left max-w-2xl">
          {/* Badge: ✦ REFLEXSTORE */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[color:var(--theme-main)]/15 text-blue-400 border border-[color:var(--theme-main)]/40 mb-3 shadow-[0_0_14px_rgba(var(--theme-main-rgb),0.25)]">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span className="uppercase tracking-wider">{storeTitle}</span>
          </div>

          {/* Heading */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-wider uppercase leading-none drop-shadow-md select-none">
            {storeTitle}
          </h1>

          {/* Subtitle / Description */}
          <p className="text-xs sm:text-sm text-zinc-400 font-normal leading-relaxed mt-2.5 select-none">
            {storeDescription}
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-4 mt-5">
            {/* Primary: เริ่มต้นใช้งาน */}
            <button
              type="button"
              onClick={handleExploreClick}
              className="px-6 py-2.5 sm:py-3 rounded-xl bg-[color:var(--theme-main)] hover:bg-[color:var(--theme-sec)] active:scale-[0.98] text-white font-extrabold text-sm sm:text-base flex items-center gap-2 shadow-[0_0_24px_rgba(var(--theme-main-rgb),0.4)] hover:shadow-[0_0_32px_rgba(var(--theme-main-rgb),0.6)] transition-all cursor-pointer group"
            >
              <ShoppingBag className="w-4 h-4 stroke-[2.5]" />
              <span>{welcomeBanner?.button1Text || 'เริ่มต้นใช้งาน'}</span>
            </button>

            {/* Secondary: วิธีใช้งาน */}
            <button
              type="button"
              onClick={handleHowToClick}
              className="px-6 py-2.5 sm:py-3 rounded-xl bg-[color:var(--arx-dk-111216)] hover:bg-[color:var(--arx-dk-181920)] border border-white/10 hover:border-[color:var(--theme-main)]/50 active:scale-[0.98] text-white font-bold text-sm sm:text-base transition-all cursor-pointer shadow-sm flex items-center gap-2 group"
            >
              <span>{welcomeBanner?.button2Text || 'วิธีใช้งาน'}</span>
              <ArrowRight className="w-4 h-4 text-zinc-400 group-hover:translate-x-1 group-hover:text-blue-400 transition-all" />
            </button>
          </div>
        </div>

        {/* Right Side: 3 Features Stacked Vertically */}
        <div className="flex flex-col gap-2.5 sm:gap-3 lg:items-end justify-center">
          <div className="flex items-center gap-2.5 text-xs sm:text-sm font-bold text-zinc-200">
            <Star className="w-4 h-4 text-[color:var(--theme-main)] fill-[color:var(--theme-main)] shrink-0" />
            <span>สินค้าคุณภาพสูง</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs sm:text-sm font-bold text-zinc-200">
            <ShieldCheck className="w-4 h-4 text-[color:var(--theme-main)] shrink-0" />
            <span>ปลอดภัย 100%</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs sm:text-sm font-bold text-zinc-200">
            <Headphones className="w-4 h-4 text-[color:var(--theme-main)] shrink-0" />
            <span>บริการตลอด 24 ชั่วโมง</span>
          </div>
        </div>
      </div>

      {/* 2. Hero Main Grid: Left Banner (lg:col-span-8) + Right 4 Stat Cards (lg:col-span-4) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 sm:gap-4 items-stretch mt-2">
        {/* Left: Big Hero Banner */}
        <div
          onClick={handleExploreClick}
          className="lg:col-span-8 xl:col-span-9 relative rounded-2xl overflow-hidden border border-[color:var(--theme-main)]/35 hover:border-[color:var(--theme-main)]/70 shadow-2xl group cursor-pointer transition-all duration-300 hover:shadow-[0_0_30px_rgba(var(--theme-main-rgb),0.35)] bg-[color:var(--arx-dk-0d0e12)] flex items-center justify-center aspect-[1100/375] w-full"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={heroBannerSrc}
            alt={storeTitle}
            className="w-full h-full object-contain group-hover:scale-[1.01] transition-transform duration-300"
            onError={(e) => {
              const target = e.currentTarget;
              if (!target.src.includes('hero-reflex-banner.png')) {
                target.src = '/brand/hero-reflex-banner.png';
              }
            }}
          />
        </div>

        {/* Right: 4 Stat Cards (2 columns on mobile/tablet, vertically stacked next to banner on desktop) */}
        <div className="lg:col-span-4 xl:col-span-3 grid grid-cols-2 lg:flex lg:flex-col justify-between gap-2.5">
          {/* Card 1: ผู้ใช้งาน */}
          <div className="relative overflow-hidden bg-[color:var(--arx-dk-0a0a0f)] border border-[color:var(--theme-main)]/30 hover:border-[color:var(--theme-main)]/70 rounded-2xl p-2.5 sm:p-3.5 flex items-center gap-2.5 sm:gap-3.5 transition-all duration-300 hover:shadow-[0_0_20px_rgba(var(--theme-main-rgb),0.3)] group shadow-md flex-1">
            {/* Left Icon Box */}
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-[color:var(--theme-main)]/15 border border-[color:var(--theme-main)]/40 flex items-center justify-center shrink-0 shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.25)] group-hover:border-[color:var(--theme-main)] group-hover:scale-105 transition-all">
              <Users className="w-5 h-5 sm:w-5.5 sm:h-5.5 text-[color:var(--theme-main)] group-hover:text-blue-300 transition-colors stroke-[2]" />
            </div>

            {/* Middle Text */}
            <div className="min-w-0 z-10 flex-1">
              <span className="text-[11px] sm:text-xs text-white font-bold block tracking-wide">
                ผู้ใช้งาน
              </span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-lg sm:text-2xl font-black text-white font-mono leading-none tracking-tight">
                  {usersDisplay}
                </span>
                <span className="text-[11px] sm:text-xs text-zinc-400 font-semibold ml-0.5">
                  คน
                </span>
              </div>
            </div>

            {/* Right Watermark Icon */}
            <Users className="absolute -right-2 -bottom-2 w-14 h-14 sm:w-16 sm:h-16 text-[color:var(--theme-main)]/[0.08] group-hover:text-[color:var(--theme-main)]/[0.15] transition-colors pointer-events-none stroke-[1.2]" />
          </div>

          {/* Card 2: สินค้า */}
          <div className="relative overflow-hidden bg-[color:var(--arx-dk-0a0a0f)] border border-[color:var(--theme-main)]/30 hover:border-[color:var(--theme-main)]/70 rounded-2xl p-2.5 sm:p-3.5 flex items-center gap-2.5 sm:gap-3.5 transition-all duration-300 hover:shadow-[0_0_20px_rgba(var(--theme-main-rgb),0.3)] group shadow-md flex-1">
            {/* Left Icon Box */}
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-[color:var(--theme-main)]/15 border border-[color:var(--theme-main)]/40 flex items-center justify-center shrink-0 shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.25)] group-hover:border-[color:var(--theme-main)] group-hover:scale-105 transition-all">
              <ShoppingBag className="w-5 h-5 sm:w-5.5 sm:h-5.5 text-[color:var(--theme-main)] group-hover:text-blue-300 transition-colors stroke-[2]" />
            </div>

            {/* Middle Text */}
            <div className="min-w-0 z-10 flex-1">
              <span className="text-[11px] sm:text-xs text-white font-bold block tracking-wide">
                สินค้า
              </span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-lg sm:text-2xl font-black text-white font-mono leading-none tracking-tight">
                  {productsCountDisplay}
                </span>
                <span className="text-[11px] sm:text-xs text-zinc-400 font-semibold ml-0.5">
                  รายการ
                </span>
              </div>
            </div>

            {/* Right Watermark Icon */}
            <ShoppingBag className="absolute -right-2 -bottom-2 w-14 h-14 sm:w-16 sm:h-16 text-[color:var(--theme-main)]/[0.08] group-hover:text-[color:var(--theme-main)]/[0.15] transition-colors pointer-events-none stroke-[1.2]" />
          </div>

          {/* Card 3: คลังสินค้า */}
          <div className="relative overflow-hidden bg-[color:var(--arx-dk-0a0a0f)] border border-[color:var(--theme-main)]/30 hover:border-[color:var(--theme-main)]/70 rounded-2xl p-2.5 sm:p-3.5 flex items-center gap-2.5 sm:gap-3.5 transition-all duration-300 hover:shadow-[0_0_20px_rgba(var(--theme-main-rgb),0.3)] group shadow-md flex-1">
            {/* Left Icon Box */}
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-[color:var(--theme-main)]/15 border border-[color:var(--theme-main)]/40 flex items-center justify-center shrink-0 shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.25)] group-hover:border-[color:var(--theme-main)] group-hover:scale-105 transition-all">
              <Box className="w-5 h-5 sm:w-5.5 sm:h-5.5 text-[color:var(--theme-main)] group-hover:text-blue-300 transition-colors stroke-[2]" />
            </div>

            {/* Middle Text */}
            <div className="min-w-0 z-10 flex-1">
              <span className="text-[11px] sm:text-xs text-white font-bold block tracking-wide">
                คลังสินค้า
              </span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-lg sm:text-2xl font-black text-white font-mono leading-none tracking-tight">
                  {stockDisplay}
                </span>
                <span className="text-[11px] sm:text-xs text-zinc-400 font-semibold ml-0.5">
                  ชิ้น
                </span>
              </div>
            </div>

            {/* Right Watermark Icon */}
            <Box className="absolute -right-2 -bottom-2 w-14 h-14 sm:w-16 sm:h-16 text-[color:var(--theme-main)]/[0.08] group-hover:text-[color:var(--theme-main)]/[0.15] transition-colors pointer-events-none stroke-[1.2]" />
          </div>

          {/* Card 4: ขายแล้ว */}
          <div className="relative overflow-hidden bg-[color:var(--arx-dk-0a0a0f)] border border-[color:var(--theme-main)]/30 hover:border-[color:var(--theme-main)]/70 rounded-2xl p-2.5 sm:p-3.5 flex items-center gap-2.5 sm:gap-3.5 transition-all duration-300 hover:shadow-[0_0_20px_rgba(var(--theme-main-rgb),0.3)] group shadow-md flex-1">
            {/* Left Icon Box */}
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-[color:var(--theme-main)]/15 border border-[color:var(--theme-main)]/40 flex items-center justify-center shrink-0 shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.25)] group-hover:border-[color:var(--theme-main)] group-hover:scale-105 transition-all">
              <CheckCircle2 className="w-5 h-5 sm:w-5.5 sm:h-5.5 text-[color:var(--theme-main)] group-hover:text-blue-300 transition-colors stroke-[2]" />
            </div>

            {/* Middle Text */}
            <div className="min-w-0 z-10 flex-1">
              <span className="text-[11px] sm:text-xs text-white font-bold block tracking-wide">
                ขายแล้ว
              </span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-lg sm:text-2xl font-black text-white font-mono leading-none tracking-tight">
                  {salesDisplay}
                </span>
                <span className="text-[11px] sm:text-xs text-zinc-400 font-semibold ml-0.5">
                  ชิ้น
                </span>
              </div>
            </div>

            {/* Right Watermark Icon */}
            <CheckCircle2 className="absolute -right-2 -bottom-2 w-14 h-14 sm:w-16 sm:h-16 text-[color:var(--theme-main)]/[0.08] group-hover:text-[color:var(--theme-main)]/[0.15] transition-colors pointer-events-none stroke-[1.2]" />
          </div>
        </div>
      </div>
    </section>
  );
}
