'use client';

// WelcomePortal disabled and removed per user request
export default function WelcomePortal() {
  return null;
}

