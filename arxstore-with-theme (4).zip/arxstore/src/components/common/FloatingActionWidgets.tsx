'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import { MessageCircle } from 'lucide-react';

export default function FloatingActionWidgets() {
  const pathname = usePathname();
  const { playClick, openContactModal } = useStore();

  // Hide on admin routes
  if (pathname?.startsWith('/admin')) {
    return null;
  }

  // Requirement: ถ้ากดตรง เติมเงินแล้วมันไปหน้าเติมเงิน ปุ่มเติมเงินจะหายไปแต่หากไปอยู่หน้าอื่นปุ่มจะขึ้นปกติ
  const isTopupPage = pathname === '/topup';

  return (
    <aside
      aria-label="เมนูลอยด่วน"
      className="fixed bottom-4 right-4 z-[9990] flex flex-col items-end gap-2.5 pointer-events-auto select-none"
    >
      {/* 1. Golden Topup Button (Hide when on /topup) */}
      {!isTopupPage && (
        <Link
          href="/topup"
          onClick={playClick}
          className="flex items-center gap-2 px-4 py-2 sm:px-4.5 sm:py-2.5 rounded-full bg-[color:var(--theme-main)] hover:bg-[color:var(--theme-sec)] text-white font-black text-xs sm:text-sm tracking-wide shadow-[0_4px_20px_rgba(var(--theme-main-rgb),0.45)] hover:shadow-[0_6px_25px_rgba(var(--theme-main-rgb),0.65)] hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer animate-in fade-in slide-in-from-bottom-2"
        >
          <div className="w-4 h-4 rounded-full bg-white text-[color:var(--theme-main)] flex items-center justify-center font-bold text-[10px] leading-none shrink-0">
            ฿
          </div>
          <span>เติมเงิน</span>
        </Link>
      )}

      {/* 2. Cyan Contact Button (Opens Contact Channels Modal matching Image 2) */}
      <button
        type="button"
        onClick={() => {
          playClick();
          openContactModal();
        }}
        className="flex items-center gap-2 px-4 py-2 sm:px-4.5 sm:py-2.5 rounded-full bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-black text-xs sm:text-sm tracking-wide shadow-[0_4px_20px_rgba(var(--theme-accent-rgb),0.4)] hover:shadow-[0_6px_25px_rgba(var(--theme-accent-rgb),0.6)] hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer"
      >
        <MessageCircle className="w-4 h-4 text-slate-950 fill-current shrink-0" />
        <span>ติดต่อแอดมิน</span>
      </button>
    </aside>
  );
}
