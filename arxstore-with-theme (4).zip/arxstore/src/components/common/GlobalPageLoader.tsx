'use client';

import React, { useState, useEffect } from 'react';

export default function GlobalPageLoader() {
  const [isLoading, setIsLoading] = useState(true);
  const [isFadingOut, setIsFadingOut] = useState(false);

  useEffect(() => {
    // Lock body scroll while loader is visible
    document.body.style.overflow = 'hidden';
    setIsLoading(true);
    setIsFadingOut(false);

    // Total duration: exactly 1 second (1000ms) with smooth 300ms fade-out
    const targetDuration = 1000;
    const fadeDuration = 300;

    const timer = setTimeout(() => {
      setIsFadingOut(true);
      setTimeout(() => {
        setIsLoading(false);
        document.body.style.overflow = '';
      }, fadeDuration);
    }, targetDuration);

    // Cover screen immediately when user presses F5 or reloads in browser
    const handleBeforeUnload = () => {
      setIsFadingOut(false);
      setIsLoading(true);
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      clearTimeout(timer);
      document.body.style.overflow = '';
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  if (!isLoading) return null;

  return (
    <div
      className={`fixed inset-0 z-[9999999] flex items-center justify-center bg-black select-none transition-opacity duration-300 ease-out ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100 pointer-events-auto'
      }`}
      aria-label="Loading"
      role="status"
    >
      {/* 3D Atom Orbital Container */}
      <div className="arx-atom-container">
        {/* Soft Radial Ambient Glow in Center */}
        <div className="arx-atom-glow" />

        {/* Orbit 1 - Horizontal / Equatorial Track & Spinning Arc */}
        <div className="arx-atom-ring-track arx-atom-orbit-1-track" />
        <div className="arx-atom-ring-spin arx-atom-orbit-1-spin">
          <div className="arx-atom-arc" />
          <div className="arx-atom-electron" />
        </div>

        {/* Orbit 2 - Tilted 60 deg Track & Spinning Arc */}
        <div className="arx-atom-ring-track arx-atom-orbit-2-track" />
        <div className="arx-atom-ring-spin arx-atom-orbit-2-spin">
          <div className="arx-atom-arc" />
          <div className="arx-atom-electron" />
        </div>

        {/* Orbit 3 - Tilted 120 deg Track & Spinning Arc */}
        <div className="arx-atom-ring-track arx-atom-orbit-3-track" />
        <div className="arx-atom-ring-spin arx-atom-orbit-3-spin">
          <div className="arx-atom-arc" />
          <div className="arx-atom-electron" />
        </div>

        {/* Center Store Logo */}
        <div className="relative z-10 w-11 h-11 sm:w-12 sm:h-12 flex items-center justify-center">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/brand/logo.png"
            alt="Logo"
            className="w-full h-full object-contain select-none drop-shadow-[0_0_12px_rgba(var(--theme-accent-rgb),0.7)]"
            onError={(e) => {
              const target = e.currentTarget;
              if (!target.src.includes('arx-default-logo.png')) {
                target.src = '/brand/arx-default-logo.png';
              }
            }}
          />
        </div>
      </div>
    </div>
  );
}
