'use client';

import React, { useEffect } from 'react';
import { useStore } from '@/context/StoreContext';
import { soundEffects } from '@/lib/sound';

export default function SoundWidget() {
  const { isSoundEnabled, toggleSound, t } = useStore();

  // Play a click sound whenever key is pressed if enabled
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isSoundEnabled) return;
      // Don't trigger on meta/ctrl alone
      if (['Control', 'Shift', 'Alt', 'Meta'].includes(e.key)) return;
      soundEffects.keyClick();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSoundEnabled]);

  const handleToggle = () => {
    toggleSound();
    if (!isSoundEnabled) {
      soundEffects.success();
    }
  };

  return (
    <aside
      className="store-soundWidget"
      data-on={isSoundEnabled}
      aria-label={t('sound_title')}
    >
      <svg viewBox="0 0 132 84" className="store-soundWidget-art" aria-hidden="true">
        <defs>
          <linearGradient id="store-soundWidget-top" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#0b243b" />
            <stop offset="1" stopColor="#06121f" />
          </linearGradient>
          <linearGradient id="store-soundWidget-cap" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#e0f7ff" />
            <stop offset="0.45" stopColor="#38bdf8" />
            <stop offset="1" stopColor="#0284c7" />
          </linearGradient>
          <radialGradient id="store-soundWidget-glow" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#00e5ff" stopOpacity={isSoundEnabled ? '0.85' : '0.2'} />
            <stop offset="1" stopColor="#00e5ff" stopOpacity="0" />
          </radialGradient>
          <filter id="store-soundWidget-blur" x="-30%" y="-80%" width="160%" height="260%">
            <feGaussianBlur stdDeviation="3" />
          </filter>
        </defs>
        <ellipse
          className="store-soundWidget-glowLight"
          cx="66"
          cy="70"
          rx="46"
          ry="7"
          fill="url(#store-soundWidget-glow)"
          filter="url(#store-soundWidget-blur)"
        />
        <g fill="none" strokeLinecap="round">
          <path d="M104 44 C118 44 122 56 114 62 S100 74 112 78 L124 78" stroke="#0d1f33" strokeWidth="4" />
          <path d="M104 44 C118 44 122 56 114 62 S100 74 112 78 L124 78" stroke="#0284c7" strokeWidth="2" />
          <path d="M104 43.2 C116 43.4 120 52 114 58" stroke="#38bdf8" strokeWidth="0.8" opacity="0.7" />
        </g>
        <rect x="123" y="75" width="6" height="6" rx="1.2" fill="#0284c7" stroke="#081b2e" strokeWidth="1" />
        <g transform="skewX(-14)">
          <rect x="40" y="40" width="72" height="26" rx="4" fill="#040b14" />
          <rect x="40" y="36" width="72" height="26" rx="4" fill="url(#store-soundWidget-top)" stroke="rgba(var(--theme-accent-rgb),0.25)" strokeWidth="1" />
          <g className="store-soundWidget-keys" fill="url(#store-soundWidget-cap)" stroke="#040b14" strokeWidth="0.8">
            <rect x="34" y="39" width="6" height="5" rx="1.2" />
            <rect x="42" y="39" width="6" height="5" rx="1.2" />
            <rect x="50" y="39" width="6" height="5" rx="1.2" />
            <rect x="58" y="39" width="6" height="5" rx="1.2" />
            <rect x="66" y="39" width="6" height="5" rx="1.2" />
            <rect x="74" y="39" width="6" height="5" rx="1.2" />
            <rect x="82" y="39" width="6" height="5" rx="1.2" />
            <rect x="90" y="39" width="8" height="5" rx="1.2" />
            <rect x="36" y="46" width="6" height="5" rx="1.2" />
            <rect x="44" y="46" width="6" height="5" rx="1.2" />
            <rect x="52" y="46" width="6" height="5" rx="1.2" />
            <rect x="60" y="46" width="6" height="5" rx="1.2" />
            <rect x="68" y="46" width="6" height="5" rx="1.2" />
            <rect x="76" y="46" width="6" height="5" rx="1.2" />
            <rect x="84" y="46" width="12" height="5" rx="1.2" />
            <rect x="34" y="53" width="8" height="5" rx="1.2" />
            <rect x="44" y="53" width="34" height="5" rx="1.2" />
            <rect x="80" y="53" width="8" height="5" rx="1.2" />
            <rect x="90" y="53" width="8" height="5" rx="1.2" />
          </g>
          <circle className="store-soundWidget-led" cx="107" cy="39.5" r="1.4" fill={isSoundEnabled ? '#00e5ff' : '#475569'} />
        </g>
        {isSoundEnabled && (
          <g className="store-soundWidget-waves" fill="none" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round">
            <path d="M88 24 q3 5 0 10" />
            <path d="M93 20 q6 9 0 18" />
            <path d="M98 16 q9 13 0 26" />
          </g>
        )}
        <path className="store-soundWidget-spark" d="M24 18l1.4 3.6 3.6 1.4-3.6 1.4-1.4 3.6-1.4-3.6-3.6-1.4 3.6-1.4z" fill="#00e5ff" />
        <path className="store-soundWidget-spark store-soundWidget-spark2" d="M14 34l0.9 2.3 2.3 0.9-2.3 0.9-0.9 2.3-0.9-2.3-2.3-0.9 2.3-0.9z" fill="#7dd3fc" />
      </svg>
      <div className="store-soundWidget-control">
        <small>{t('sound_title')}</small>
        <button
          type="button"
          role="switch"
          aria-checked={isSoundEnabled}
          aria-label={t('sound_title')}
          className="store-soundWidget-switch"
          onClick={handleToggle}
        >
          <span className="store-soundWidget-knob" />
        </button>
      </div>
    </aside>
  );
}
