'use client';

import React, { useState } from 'react';

export interface BankConfig {
  code: string;
  name: string;
  shortName: string;
  color: string;
  gradient: string;
}

export const THAI_BANKS: BankConfig[] = [
  {
    code: 'kbank',
    name: 'กสิกรไทย (KBANK / K+)',
    shortName: 'KBank (K+)',
    color: '#138f47',
    gradient: 'from-[#138f47] to-[#0c6b33]'
  },
  {
    code: 'scb',
    name: 'ไทยพาณิชย์ (SCB / SCB EASY)',
    shortName: 'SCB Easy',
    color: '#4e2e7f',
    gradient: 'from-[#5a3494] to-[#3a1d68]'
  },
  {
    code: 'ktb',
    name: 'กรุงไทย (KTB / Krungthai NEXT)',
    shortName: 'Krungthai NEXT',
    color: '#00a5e5',
    gradient: 'from-[#00b2f6] to-[#007dae]'
  },
  {
    code: 'bbl',
    name: 'กรุงเทพ (BBL / Bangkok Bank)',
    shortName: 'Bangkok Bank (BBL)',
    color: '#1e3a8a',
    gradient: 'from-[#1e40af] to-[#0c2461]'
  },
  {
    code: 'bay',
    name: 'กรุงศรีอยุธยา (BAY / Krungsri)',
    shortName: 'Krungsri (BAY)',
    color: '#fec43b',
    gradient: 'from-[#ffcf55] to-[#d99806]'
  },
  {
    code: 'ttb',
    name: 'ทหารไทยธนชาต (TTB / ttb touch)',
    shortName: 'ttb touch',
    color: '#00247d',
    gradient: 'from-[#0038a8] to-[#001c60]'
  },
  {
    code: 'gsb',
    name: 'ออมสิน (GSB / MyMo)',
    shortName: 'ออมสิน (GSB)',
    color: '#eb198b',
    gradient: 'from-[#f7259c] to-[#c21875]'
  },
  {
    code: 'baac',
    name: 'ธ.ก.ส. (BAAC / A-Mobile)',
    shortName: 'ธ.ก.ส. (BAAC)',
    color: '#006633',
    gradient: 'from-[#008040] to-[#004d26]'
  },
  {
    code: 'cimb',
    name: 'ซีไอเอ็มบี ไทย (CIMB)',
    shortName: 'CIMB Thai',
    color: '#7e0000',
    gradient: 'from-[#9b0a17] to-[#600000]'
  },
  {
    code: 'uob',
    name: 'ยูโอบี (UOB / TMRW)',
    shortName: 'UOB Thailand',
    color: '#0b2f64',
    gradient: 'from-[#0e3c7e] to-[#071f42]'
  },
  {
    code: 'kkp',
    name: 'เกียรตินาคินภัทร (KKP / Dime)',
    shortName: 'KKP / Dime',
    color: '#6a2c91',
    gradient: 'from-[#7c34aa] to-[#501e70]'
  },
  {
    code: 'lhb',
    name: 'แลนด์ แอนด์ เฮ้าส์ (LH Bank)',
    shortName: 'LH Bank',
    color: '#00778b',
    gradient: 'from-[#008ca4] to-[#005e6e]'
  }
];

export function getBankInfo(bankNameOrCode?: string): BankConfig {
  if (!bankNameOrCode) return THAI_BANKS[0];
  const q = bankNameOrCode.toLowerCase().trim();

  if (q.includes('kbank') || q.includes('กสิกร') || q.includes('k+') || q.includes('kasikorn')) return THAI_BANKS[0];
  if (q.includes('scb') || q.includes('ไทยพาณิชย์') || q.includes('siam commercial') || q.includes('easy')) return THAI_BANKS[1];
  if (q.includes('ktb') || q.includes('กรุงไทย') || q.includes('krungthai') || q.includes('next')) return THAI_BANKS[2];
  if (q.includes('bbl') || q.includes('กรุงเทพ') || q.includes('bangkok bank') || q.includes('bualuang')) return THAI_BANKS[3];
  if (q.includes('bay') || q.includes('กรุงศรี') || q.includes('krungsri') || q.includes('kma')) return THAI_BANKS[4];
  if (q.includes('ttb') || q.includes('ทหารไทย') || q.includes('ธนชาต')) return THAI_BANKS[5];
  if (q.includes('gsb') || q.includes('ออมสิน') || q.includes('mymo')) return THAI_BANKS[6];
  if (q.includes('baac') || q.includes('ธ.ก.ส') || q.includes('เพื่อการเกษตร') || q.includes('a-mobile')) return THAI_BANKS[7];
  if (q.includes('cimb') || q.includes('ซีไอเอ็มบี')) return THAI_BANKS[8];
  if (q.includes('uob') || q.includes('ยูโอบี') || q.includes('tmrw')) return THAI_BANKS[9];
  if (q.includes('kkp') || q.includes('เกียรตินาคิน') || q.includes('dime')) return THAI_BANKS[10];
  if (q.includes('lhb') || q.includes('แลนด์ แอนด์ เฮ้าส์') || q.includes('lh bank')) return THAI_BANKS[11];

  return THAI_BANKS[0];
}

export function PromptPayIcon({ className = 'w-5 h-5' }: { className?: string }) {
  const [imgErr, setImgErr] = useState(false);
  if (imgErr) {
    return (
      <div className={`flex items-center justify-center bg-[#003b70] text-white font-black text-[10px] rounded ${className}`}>
        PP
      </div>
    );
  }
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src="https://upload.wikimedia.org/wikipedia/commons/c/c5/PromptPay-logo.png"
      alt="PromptPay"
      className={`object-contain ${className}`}
      onError={() => setImgErr(true)}
    />
  );
}

export function KPlusIcon({ className = 'w-full h-full' }: { className?: string }) {
  const [imgErr, setImgErr] = useState(false);
  if (imgErr) {
    return (
      <div className={`flex items-center justify-center bg-gradient-to-br from-[#138f47] to-[#0c6b33] text-white font-black text-[11px] rounded-xl shadow-md ${className}`}>
        K+
      </div>
    );
  }
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src="/images/kplus.png"
      alt="K+ Kasikorn Bank"
      className={`w-full h-full object-contain select-none pointer-events-none transition-transform ${className}`}
      onError={() => setImgErr(true)}
    />
  );
}

export function TrueMoneyIcon({ className = 'w-5 h-5' }: { className?: string }) {
  const [imgErr, setImgErr] = useState(false);
  if (imgErr) {
    return (
      <div className={`flex items-center justify-center bg-[#ea580c] text-white font-black text-[10px] rounded ${className}`}>
        TM
      </div>
    );
  }
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src="https://files.catbox.moe/k3n8a6.png"
      alt="TrueMoney"
      className={`object-contain ${className}`}
      onError={() => setImgErr(true)}
    />
  );
}

/**
 * Dynamic Bank Icon component supporting all major Thai banks
 * Automatically detects bank from name string or code
 */
export function BankIcon({
  bankName,
  className = 'w-full h-full'
}: {
  bankName?: string;
  className?: string;
}) {
  const bank = getBankInfo(bankName);

  switch (bank.code) {
    case 'kbank':
      return <KPlusIcon className={className} />;

    case 'scb':
      return (
        <svg viewBox="0 0 48 48" className={`select-none pointer-events-none ${className}`}>
          <rect width="48" height="48" rx="12" fill="url(#scbGrad)" />
          <defs>
            <linearGradient id="scbGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#5d3599" />
              <stop offset="100%" stopColor="#3d1f6b" />
            </linearGradient>
          </defs>
          {/* SCB Crystal / Diamond motif */}
          <path
            d="M24 10 L31 18 L24 23 L17 18 Z"
            fill="#fbbf24"
          />
          <path
            d="M17 18 L24 23 L24 28 L14 20 Z"
            fill="#f59e0b"
          />
          <path
            d="M31 18 L24 23 L24 28 L34 20 Z"
            fill="#d97706"
          />
          {/* SCB Text */}
          <text
            x="24"
            y="40"
            fill="#ffffff"
            fontSize="11"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            letterSpacing="0.8"
          >
            SCB
          </text>
        </svg>
      );

    case 'ktb':
      return (
        <svg viewBox="0 0 48 48" className={`select-none pointer-events-none ${className}`}>
          <rect width="48" height="48" rx="12" fill="url(#ktbGrad)" />
          <defs>
            <linearGradient id="ktbGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00baff" />
              <stop offset="100%" stopColor="#008ec6" />
            </linearGradient>
          </defs>
          {/* Krungthai Bird Symbol */}
          <path
            d="M24 12 C26 15 28 17 34 16 C30 20 28 23 24 26 C20 23 18 20 14 16 C20 17 22 15 24 12 Z"
            fill="#ffffff"
          />
          <path
            d="M24 26 L27 30 L24 29 L21 30 Z"
            fill="#ffffff"
            opacity="0.9"
          />
          {/* KTB Text */}
          <text
            x="24"
            y="41"
            fill="#ffffff"
            fontSize="11.5"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            letterSpacing="0.5"
          >
            KTB
          </text>
        </svg>
      );

    case 'bbl':
      return (
        <svg viewBox="0 0 48 48" className={`select-none pointer-events-none ${className}`}>
          <rect width="48" height="48" rx="12" fill="url(#bblGrad)" />
          <defs>
            <linearGradient id="bblGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1e3a8a" />
              <stop offset="100%" stopColor="#0f172a" />
            </linearGradient>
          </defs>
          {/* Bangkok Bank Bualuang Lotus Logo */}
          <path
            d="M24 11 L31 23 C28 25 25 25 24 25 C23 25 20 25 17 23 Z"
            fill="#ffffff"
          />
          <circle cx="24" cy="20" r="3.2" fill="#f97316" />
          <path
            d="M24 26 L29 27 L24 29 L19 27 Z"
            fill="#ffffff"
            opacity="0.8"
          />
          {/* BBL Text */}
          <text
            x="24"
            y="41"
            fill="#ffffff"
            fontSize="11.5"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            letterSpacing="0.8"
          >
            BBL
          </text>
        </svg>
      );

    case 'bay':
      return (
        <svg viewBox="0 0 48 48" className={`select-none pointer-events-none ${className}`}>
          <rect width="48" height="48" rx="12" fill="url(#bayGrad)" />
          <defs>
            <linearGradient id="bayGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fec43b" />
              <stop offset="100%" stopColor="#eab308" />
            </linearGradient>
          </defs>
          {/* Krungsri 3-Pagoda Roof Motif */}
          <path
            d="M24 10 L29 16 L27 16 L24 13 L21 16 L19 16 Z"
            fill="#2d251e"
          />
          <path
            d="M17 16 L22 22 L20 22 L17 19 L14 22 L12 22 Z"
            fill="#2d251e"
          />
          <path
            d="M31 16 L36 22 L34 22 L31 19 L28 22 L26 22 Z"
            fill="#2d251e"
          />
          <rect x="15" y="23" width="18" height="2" rx="1" fill="#2d251e" />
          {/* BAY Text */}
          <text
            x="24"
            y="39"
            fill="#2d251e"
            fontSize="11"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            letterSpacing="0.5"
          >
            BAY
          </text>
        </svg>
      );

    case 'ttb':
      return (
        <svg viewBox="0 0 48 48" className={`select-none pointer-events-none ${className}`}>
          <rect width="48" height="48" rx="12" fill="url(#ttbGrad)" />
          <defs>
            <linearGradient id="ttbGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#002d9c" />
              <stop offset="100%" stopColor="#001859" />
            </linearGradient>
          </defs>
          {/* ttb red dynamic curve */}
          <path
            d="M26 12 C33 12 37 15 37 20 C37 20 35 17 30 17 C26 17 25 18 25 18 Z"
            fill="#ef4444"
          />
          {/* ttb Text */}
          <text
            x="24"
            y="32"
            fill="#ffffff"
            fontSize="18"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            letterSpacing="-0.5"
          >
            ttb
          </text>
        </svg>
      );

    case 'gsb':
      return (
        <svg viewBox="0 0 48 48" className={`select-none pointer-events-none ${className}`}>
          <rect width="48" height="48" rx="12" fill="url(#gsbGrad)" />
          <defs>
            <linearGradient id="gsbGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f43f9e" />
              <stop offset="100%" stopColor="#be185d" />
            </linearGradient>
          </defs>
          {/* GSB Tiered Umbrella Motif */}
          <path
            d="M24 10 L25 13 L23 13 Z M24 13 L28 17 L20 17 Z M24 17 L31 22 L17 22 Z M23 22 L23 26 L25 26 L25 22 Z"
            fill="#ffffff"
          />
          {/* GSB Text */}
          <text
            x="24"
            y="39"
            fill="#ffffff"
            fontSize="11.5"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            letterSpacing="0.8"
          >
            GSB
          </text>
        </svg>
      );

    case 'baac':
      return (
        <svg viewBox="0 0 48 48" className={`select-none pointer-events-none ${className}`}>
          <rect width="48" height="48" rx="12" fill="url(#baacGrad)" />
          <defs>
            <linearGradient id="baacGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#007a3d" />
              <stop offset="100%" stopColor="#004724" />
            </linearGradient>
          </defs>
          {/* BAAC Rice / Crest Motif */}
          <circle cx="24" cy="18" r="7" fill="none" stroke="#facc15" strokeWidth="2" />
          <path d="M24 13 L24 23 M20 16 L24 19 L28 16" stroke="#ffffff" strokeWidth="1.5" fill="none" />
          {/* BAAC Text */}
          <text
            x="24"
            y="38"
            fill="#ffffff"
            fontSize="10"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            letterSpacing="0.5"
          >
            BAAC
          </text>
        </svg>
      );

    case 'cimb':
      return (
        <svg viewBox="0 0 48 48" className={`select-none pointer-events-none ${className}`}>
          <rect width="48" height="48" rx="12" fill="url(#cimbGrad)" />
          <defs>
            <linearGradient id="cimbGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#9b111e" />
              <stop offset="100%" stopColor="#5a0008" />
            </linearGradient>
          </defs>
          {/* CIMB Forward Arrow Motif */}
          <polygon points="17,14 27,20 17,26" fill="#ffffff" />
          <rect x="29" y="14" width="3" height="12" fill="#ffffff" />
          {/* CIMB Text */}
          <text
            x="24"
            y="39"
            fill="#ffffff"
            fontSize="10"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            letterSpacing="0.5"
          >
            CIMB
          </text>
        </svg>
      );

    case 'uob':
      return (
        <svg viewBox="0 0 48 48" className={`select-none pointer-events-none ${className}`}>
          <rect width="48" height="48" rx="12" fill="url(#uobGrad)" />
          <defs>
            <linearGradient id="uobGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0b2f64" />
              <stop offset="100%" stopColor="#041838" />
            </linearGradient>
          </defs>
          {/* UOB 5 Stripes */}
          <rect x="15" y="14" width="2.5" height="10" rx="1" fill="#ef4444" />
          <rect x="19.5" y="14" width="2.5" height="10" rx="1" fill="#ef4444" />
          <rect x="24" y="14" width="2.5" height="10" rx="1" fill="#ef4444" />
          <rect x="28.5" y="14" width="2.5" height="10" rx="1" fill="#ef4444" />
          {/* UOB Text */}
          <text
            x="24"
            y="39"
            fill="#ffffff"
            fontSize="11"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            letterSpacing="0.8"
          >
            UOB
          </text>
        </svg>
      );

    case 'kkp':
      return (
        <svg viewBox="0 0 48 48" className={`select-none pointer-events-none ${className}`}>
          <rect width="48" height="48" rx="12" fill="url(#kkpGrad)" />
          <defs>
            <linearGradient id="kkpGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#7c34aa" />
              <stop offset="100%" stopColor="#48146e" />
            </linearGradient>
          </defs>
          <circle cx="24" cy="18" r="6" fill="none" stroke="#ffffff" strokeWidth="2" opacity="0.85" />
          <text
            x="24"
            y="38"
            fill="#ffffff"
            fontSize="11"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            letterSpacing="0.8"
          >
            KKP
          </text>
        </svg>
      );

    case 'lhb':
      return (
        <svg viewBox="0 0 48 48" className={`select-none pointer-events-none ${className}`}>
          <rect width="48" height="48" rx="12" fill="url(#lhbGrad)" />
          <defs>
            <linearGradient id="lhbGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#008ca4" />
              <stop offset="100%" stopColor="#005060" />
            </linearGradient>
          </defs>
          <path d="M24 12 L31 19 L17 19 Z M20 19 L20 25 L28 25 L28 19" fill="#ffffff" />
          <text
            x="24"
            y="39"
            fill="#ffffff"
            fontSize="9.5"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            letterSpacing="0.5"
          >
            LH BANK
          </text>
        </svg>
      );

    default:
      return (
        <div
          className={`flex items-center justify-center font-black text-white text-[11px] rounded-xl shadow-md bg-gradient-to-br ${bank.gradient} ${className}`}
        >
          {bank.code.toUpperCase()}
        </div>
      );
  }
}
