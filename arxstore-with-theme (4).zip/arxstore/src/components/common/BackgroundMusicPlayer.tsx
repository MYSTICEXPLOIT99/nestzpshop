'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { usePathname } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import { extractYouTubeId } from '@/lib/youtube';
import {
  Volume2,
  VolumeX,
  Volume1,
  Disc3,
  Play,
  Pause,
  Maximize2,
  Minimize2
} from 'lucide-react';

declare global {
  interface Window {
    onYouTubeIframeAPIReady?: () => void;
    YT?: any;
  }
}

export default function BackgroundMusicPlayer() {
  const pathname = usePathname();
  const isAdmin = pathname?.startsWith('/admin');
  const { bgmSettings, playClick } = useStore();

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('arx_bgm_vol');
      if (saved !== null) {
        const parsed = Number(saved);
        if (!isNaN(parsed) && parsed >= 0 && parsed <= 100) return parsed;
      }
    }
    return bgmSettings?.volume ?? 50;
  });
  const [isCollapsed, setIsCollapsed] = useState<boolean>(true);
  const [needsInteraction, setNeedsInteraction] = useState<boolean>(false);

  // References
  const isPlayingRef = useRef<boolean>(false);
  const htmlAudioRef = useRef<HTMLAudioElement | null>(null);
  const ytPlayerRef = useRef<any>(null);
  const isYtReadyRef = useRef<boolean>(false);
  const isPendingPlayRef = useRef<boolean>(false);

  // Current Track Info
  const youtubeId = extractYouTubeId(bgmSettings?.url);
  const isYouTube = Boolean(youtubeId);

  // Sync volume change with audio engines
  const applyVolume = useCallback((vol: number, muted: boolean) => {
    const effectiveVol = muted ? 0 : vol;

    // Apply to HTML5 Audio
    if (htmlAudioRef.current) {
      htmlAudioRef.current.volume = Math.max(0, Math.min(1, effectiveVol / 100));
      htmlAudioRef.current.muted = muted;
    }

    // Apply to YouTube Player
    if (ytPlayerRef.current && isYtReadyRef.current) {
      try {
        if (muted) {
          if (typeof ytPlayerRef.current.mute === 'function') ytPlayerRef.current.mute();
        } else {
          if (typeof ytPlayerRef.current.unMute === 'function') ytPlayerRef.current.unMute();
          if (typeof ytPlayerRef.current.setVolume === 'function') ytPlayerRef.current.setVolume(effectiveVol);
        }
      } catch {}
    }
  }, []);

  // Update volume
  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    if (isMuted && newVol > 0) {
      setIsMuted(false);
      applyVolume(newVol, false);
    } else {
      applyVolume(newVol, isMuted);
    }
    if (typeof window !== 'undefined') {
      localStorage.setItem('arx_bgm_vol', String(newVol));
    }
  };

  const toggleMute = () => {
    playClick();
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    applyVolume(volume, nextMuted);
  };

  // Play audio across engine
  const startPlayback = useCallback(() => {
    isPendingPlayRef.current = true;
    isPlayingRef.current = true;
    setIsPlaying(true);
    setNeedsInteraction(false);

    if (isYouTube) {
      if (ytPlayerRef.current && isYtReadyRef.current) {
        try {
          applyVolume(volume, isMuted);
          if (typeof ytPlayerRef.current.unMute === 'function' && !isMuted) {
            ytPlayerRef.current.unMute();
          }
          if (typeof ytPlayerRef.current.playVideo === 'function') {
            ytPlayerRef.current.playVideo();
          }
        } catch {
          // If unmuted playback is blocked by browser, try muted then wait for next interaction
          try {
            if (typeof ytPlayerRef.current.mute === 'function') ytPlayerRef.current.mute();
            if (typeof ytPlayerRef.current.playVideo === 'function') ytPlayerRef.current.playVideo();
          } catch {}
          setNeedsInteraction(true);
        }
      }
    } else if (htmlAudioRef.current) {
      applyVolume(volume, isMuted);
      htmlAudioRef.current
        .play()
        .then(() => {
          setIsPlaying(true);
          isPlayingRef.current = true;
          setNeedsInteraction(false);
        })
        .catch(() => {
          setNeedsInteraction(true);
        });
    }
  }, [isYouTube, volume, isMuted, applyVolume]);

  // Pause audio across engine
  const pausePlayback = useCallback(() => {
    isPendingPlayRef.current = false;
    isPlayingRef.current = false;
    setIsPlaying(false);

    if (isYouTube && ytPlayerRef.current && isYtReadyRef.current) {
      try {
        if (typeof ytPlayerRef.current.pauseVideo === 'function') {
          ytPlayerRef.current.pauseVideo();
        }
      } catch {}
    } else if (htmlAudioRef.current) {
      try {
        htmlAudioRef.current.pause();
      } catch {}
    }
  }, [isYouTube]);

  const togglePlay = useCallback(() => {
    playClick();
    if (isPlayingRef.current) {
      pausePlayback();
    } else {
      startPlayback();
    }
  }, [pausePlayback, startPlayback, playClick]);

  // Setup YouTube IFrame API (Always pre-initialize when enabled so it is instantly ready)
  useEffect(() => {
    if (!bgmSettings?.enabled || !isYouTube || !youtubeId) return;

    let destroyed = false;

    const createPlayer = () => {
      if (destroyed || !window.YT || !window.YT.Player) return;

      const container = document.getElementById('arx-yt-bgm-iframe');
      if (!container) return;

      try {
        if (ytPlayerRef.current && typeof ytPlayerRef.current.destroy === 'function') {
          ytPlayerRef.current.destroy();
        }
      } catch {}

      ytPlayerRef.current = new window.YT.Player('arx-yt-bgm-iframe', {
        height: '240',
        width: '240',
        videoId: youtubeId,
        playerVars: {
          autoplay: bgmSettings.autoplay ? 1 : 0,
          loop: bgmSettings.loop ? 1 : 0,
          playlist: youtubeId,
          controls: 0,
          disablekb: 1,
          enablejsapi: 1,
          fs: 0,
          iv_load_policy: 3,
          modestbranding: 1,
          playsinline: 1,
          rel: 0
        },
        events: {
          onReady: (event: any) => {
            if (destroyed) return;
            isYtReadyRef.current = true;

            const effectiveVol = isMuted ? 0 : volume;
            try {
              if (isMuted) {
                event.target.mute();
              } else {
                event.target.unMute();
                event.target.setVolume(effectiveVol);
              }
            } catch {}

            if (bgmSettings.autoplay || isPendingPlayRef.current) {
              try {
                event.target.playVideo();
                setIsPlaying(true);
                isPlayingRef.current = true;
              } catch {
                setNeedsInteraction(true);
              }
            }
          },
          onStateChange: (event: any) => {
            if (destroyed) return;
            // 1 = PLAYING, 2 = PAUSED, 0 = ENDED
            if (event.data === 1) {
              setIsPlaying(true);
              isPlayingRef.current = true;
              setNeedsInteraction(false);
            } else if (event.data === 2) {
              setIsPlaying(false);
              isPlayingRef.current = false;
            } else if (event.data === 0) {
              if (bgmSettings.loop) {
                try {
                  event.target.seekTo(0);
                  event.target.playVideo();
                } catch {}
              } else {
                setIsPlaying(false);
                isPlayingRef.current = false;
              }
            }
          },
          onError: (event: any) => {
            console.warn('YouTube BGM Player notice:', event?.data);
          }
        }
      });
    };

    if (!window.YT || !window.YT.Player) {
      const existingScript = document.getElementById('yt-iframe-api-script');
      if (!existingScript) {
        const tag = document.createElement('script');
        tag.id = 'yt-iframe-api-script';
        tag.src = 'https://www.youtube.com/iframe_api';
        document.body.appendChild(tag);
      }

      const prevCallback = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        if (prevCallback) prevCallback();
        createPlayer();
      };
    } else {
      createPlayer();
    }

    return () => {
      destroyed = true;
      isYtReadyRef.current = false;
      try {
        if (ytPlayerRef.current && typeof ytPlayerRef.current.destroy === 'function') {
          ytPlayerRef.current.destroy();
        }
      } catch {}
    };
  }, [youtubeId, isYouTube, bgmSettings?.enabled, bgmSettings?.loop, bgmSettings?.autoplay]);

  // Setup HTML5 Audio element for direct audio links
  useEffect(() => {
    if (!bgmSettings?.enabled || isYouTube || !bgmSettings?.url) return;

    if (!htmlAudioRef.current) {
      htmlAudioRef.current = new Audio(bgmSettings.url);
    } else {
      htmlAudioRef.current.src = bgmSettings.url;
    }

    const audio = htmlAudioRef.current;
    audio.loop = bgmSettings.loop;
    audio.volume = isMuted ? 0 : volume / 100;
    audio.muted = isMuted;

    if (bgmSettings.autoplay) {
      audio
        .play()
        .then(() => {
          setIsPlaying(true);
          isPlayingRef.current = true;
          setNeedsInteraction(false);
        })
        .catch(() => {
          setNeedsInteraction(true);
        });
    }

    const handleEnded = () => {
      if (!bgmSettings.loop) {
        setIsPlaying(false);
        isPlayingRef.current = false;
      }
    };

    const handlePause = () => {
      setIsPlaying(false);
      isPlayingRef.current = false;
    };
    const handlePlay = () => {
      setIsPlaying(true);
      isPlayingRef.current = true;
    };

    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('play', handlePlay);

    return () => {
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('play', handlePlay);
      audio.pause();
    };
  }, [bgmSettings?.url, isYouTube, bgmSettings?.enabled, bgmSettings?.loop, bgmSettings?.autoplay]);

  // One-time global user-gesture trigger to unlock & start audio playback on first interaction
  useEffect(() => {
    if (!bgmSettings?.enabled) return;

    const handleFirstUserInteraction = () => {
      if (!isPlayingRef.current) {
        startPlayback();
      }
      window.removeEventListener('pointerdown', handleFirstUserInteraction);
      window.removeEventListener('keydown', handleFirstUserInteraction);
      window.removeEventListener('touchstart', handleFirstUserInteraction);
      window.removeEventListener('click', handleFirstUserInteraction);
    };

    window.addEventListener('pointerdown', handleFirstUserInteraction, { passive: true });
    window.addEventListener('keydown', handleFirstUserInteraction, { passive: true });
    window.addEventListener('touchstart', handleFirstUserInteraction, { passive: true });
    window.addEventListener('click', handleFirstUserInteraction, { passive: true });

    return () => {
      window.removeEventListener('pointerdown', handleFirstUserInteraction);
      window.removeEventListener('keydown', handleFirstUserInteraction);
      window.removeEventListener('touchstart', handleFirstUserInteraction);
      window.removeEventListener('click', handleFirstUserInteraction);
    };
  }, [bgmSettings?.enabled, startPlayback]);

  // If disabled in settings, do not render
  if (!bgmSettings || !bgmSettings.enabled) {
    return null;
  }

  // On admin page, don't show the floating widget
  if (isAdmin) {
    return isYouTube ? (
      <div
        className="fixed -bottom-[320px] -right-[320px] w-[240px] h-[240px] pointer-events-none opacity-[0.001] -z-[9999] overflow-hidden"
        aria-hidden="true"
      >
        <div id="arx-yt-bgm-iframe" />
      </div>
    ) : null;
  }

  const positionClass =
    bgmSettings.position === 'bottom-right'
      ? 'bottom-3 right-3 sm:bottom-4 sm:right-4'
      : 'bottom-3 left-3 sm:bottom-4 sm:left-4';

  return (
    <>
      {/* Hidden YouTube IFrame Player Anchor (240x240 safe off-screen container) */}
      {isYouTube && (
        <div
          className="fixed -bottom-[320px] -right-[320px] w-[240px] h-[240px] pointer-events-none opacity-[0.001] -z-[9999] overflow-hidden"
          aria-hidden="true"
        >
          <div id="arx-yt-bgm-iframe" />
        </div>
      )}

      {/* Floating Cyber Music Player Widget */}
      <div
        className={`fixed z-[9990] transition-all duration-300 select-none ${positionClass}`}
      >
        {isCollapsed ? (
          /* ======================================================== */
          /* 🎵 COMPACT MINI PILL STATE (Exact Image 1 "เปิดเพลง")   */
          /* ======================================================== */
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={togglePlay}
              className="group flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[color:var(--arx-dk-070b13)]/90 hover:bg-[color:var(--arx-dk-0c1220)] border border-white/10 hover:border-cyan-500/50 shadow-[0_4px_16px_rgba(0,0,0,0.7)] backdrop-blur-xl text-slate-200 hover:text-white transition-all cursor-pointer text-xs font-semibold"
              title={isPlaying ? 'คลิกเพื่อปิดเพลง' : 'คลิกเพื่อเปิดเพลง'}
            >
              {isPlaying ? (
                <Volume2 className="w-3.5 h-3.5 text-cyan-400 animate-pulse shrink-0" />
              ) : (
                <VolumeX className="w-3.5 h-3.5 text-slate-400 group-hover:text-cyan-300 shrink-0" />
              )}
              <span>{isPlaying ? 'ปิดเพลง' : 'เปิดเพลง'}</span>
            </button>

            {/* Micro Expand Settings Button */}
            <button
              type="button"
              onClick={() => setIsCollapsed(false)}
              className="w-7 h-7 rounded-full bg-[color:var(--arx-dk-070b13)]/80 hover:bg-[color:var(--arx-dk-0c1220)] border border-white/10 flex items-center justify-center text-slate-400 hover:text-white transition cursor-pointer"
              title="ตั้งค่าระดับเสียง"
            >
              <Maximize2 className="w-3 h-3" />
            </button>
          </div>
        ) : (
          /* ======================================================== */
          /* 🎛️ ULTRA-SLEEK COMPACT CYBER PLAYER CARD                */
          /* ======================================================== */
          <div className="relative w-[195px] sm:w-[210px] rounded-xl bg-[color:var(--arx-dk-060913)]/92 border border-cyan-500/30 hover:border-cyan-400/60 shadow-[0_4px_24px_rgba(0,0,0,0.85),0_0_15px_rgba(var(--theme-accent-rgb),0.12)] backdrop-blur-2xl p-2.5 transition-all duration-300 group">
            {/* Top Cyan Neon Accent Line */}
            <div className="absolute -top-[1px] left-3 right-3 h-[1px] bg-gradient-to-r from-transparent via-cyan-400/80 to-transparent pointer-events-none" />

            {/* Micro HUD Corner Brackets */}
            <div className="absolute top-1 left-1 w-1 h-1 border-t border-l border-cyan-400/30 pointer-events-none" />
            <div className="absolute top-1 right-1 w-1 h-1 border-t border-r border-cyan-400/30 pointer-events-none" />
            <div className="absolute bottom-1 left-1 w-1 h-1 border-b border-l border-cyan-400/30 pointer-events-none" />
            <div className="absolute bottom-1 right-1 w-1 h-1 border-b border-r border-cyan-400/30 pointer-events-none" />

            {/* Row 1: Vinyl Disc + Track Info + Equalizer + Controls */}
            <div className="flex items-center gap-2">
              {/* Spinning Cyber Vinyl Disc (Interactive Click to Play/Pause) */}
              <button
                type="button"
                onClick={togglePlay}
                className="relative w-7 h-7 rounded-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-900 border border-cyan-500/40 hover:border-cyan-400 shrink-0 flex items-center justify-center shadow-inner cursor-pointer hover:scale-105 active:scale-95 transition-all group/disc"
                title={isPlaying ? 'คลิกเพื่อหยุดเพลง' : 'คลิกเพื่อเล่นเพลง'}
              >
                <Disc3 className={`w-4 h-4 text-cyan-400 transition-transform ${isPlaying ? 'animate-[spin_4s_linear_infinite]' : ''}`} />
                {/* Center Core Dot or Play/Pause Icon */}
                <div className="absolute inset-0 flex items-center justify-center">
                  {isPlaying ? (
                    <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 border border-black group-hover/disc:scale-0 transition-transform" />
                  ) : (
                    <Play className="w-2.5 h-2.5 text-cyan-300 fill-cyan-300 ml-0.5 drop-shadow-[0_0_4px_var(--theme-accent)]" />
                  )}
                  {isPlaying && (
                    <Pause className="w-2.5 h-2.5 text-slate-950 fill-cyan-400 opacity-0 group-hover/disc:opacity-100 transition-opacity absolute" />
                  )}
                </div>
              </button>

              {/* Title & Subtitle */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1">
                  <span className={`w-1 h-1 rounded-full shrink-0 ${isPlaying ? 'bg-cyan-400 shadow-[0_0_4px_#22d3ee] animate-pulse' : 'bg-slate-500'}`} />
                  <span className="text-[7.5px] uppercase font-bold tracking-wider text-cyan-400/80 truncate">
                    {bgmSettings.subtitle || '9tokyo'}
                  </span>
                  {/* Dancing Wave Equalizer */}
                  {bgmSettings.showVisualizer && (
                    <div className="flex items-end gap-[1px] h-1.5 ml-auto shrink-0">
                      <span className={`w-[1px] rounded-full bg-cyan-400 transition-all ${isPlaying ? 'animate-[bounce_0.6s_ease-in-out_infinite] h-1.5' : 'h-1 opacity-40'}`} />
                      <span className={`w-[1px] rounded-full bg-cyan-300 transition-all ${isPlaying ? 'animate-[bounce_0.8s_ease-in-out_0.2s_infinite] h-2' : 'h-1 opacity-40'}`} />
                      <span className={`w-[1px] rounded-full bg-cyan-400 transition-all ${isPlaying ? 'animate-[bounce_0.5s_ease-in-out_0.1s_infinite] h-1.5' : 'h-1 opacity-40'}`} />
                    </div>
                  )}
                </div>
                <p className="text-[9px] font-bold text-white/95 truncate leading-tight group-hover:text-cyan-200 transition-colors" title={bgmSettings.title}>
                  {bgmSettings.title || '9tokyo - สายไป feat. BLVCKHEART'}
                </p>
                {needsInteraction && !isPlaying && (
                  <p className="text-[7px] text-cyan-400 font-medium animate-pulse leading-none mt-0.5">
                    คลิกหน้าจอเพื่อเริ่มเล่นเสียง ♫
                  </p>
                )}
              </div>

              {/* Quick Play/Pause Button */}
              <button
                type="button"
                onClick={togglePlay}
                className="w-5 h-5 rounded-md bg-cyan-500/15 hover:bg-cyan-500/30 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0 transition-all hover:scale-105 active:scale-95 cursor-pointer"
                title={isPlaying ? 'หยุดชั่วคราว' : 'เล่นเพลง'}
              >
                {isPlaying ? (
                  <Pause className="w-2.5 h-2.5 fill-cyan-400" />
                ) : (
                  <Play className="w-2.5 h-2.5 fill-cyan-400 ml-0.5" />
                )}
              </button>

              {/* Minimize Button */}
              <button
                type="button"
                onClick={() => {
                  playClick();
                  setIsCollapsed(true);
                }}
                className="p-0.5 rounded text-slate-400 hover:text-white hover:bg-white/10 transition cursor-pointer shrink-0"
                title="ย่อขนาด"
              >
                <Minimize2 className="w-2.5 h-2.5" />
              </button>
            </div>

            {/* Row 2: Sleek Volume Slider & Mute Toggle */}
            <div className="flex items-center gap-1.5 mt-1.5 pt-1.5 border-t border-white/5">
              {/* Volume Icon Button (Click to Mute/Unmute) */}
              <button
                type="button"
                onClick={toggleMute}
                className="text-slate-400 hover:text-cyan-400 transition cursor-pointer shrink-0 p-0.5"
                title={isMuted ? 'เปิดเสียง' : 'ปิดเสียง'}
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-3 h-3 text-slate-400" />
                ) : volume < 50 ? (
                  <Volume1 className="w-3 h-3 text-cyan-400/80" />
                ) : (
                  <Volume2 className="w-3 h-3 text-cyan-400" />
                )}
              </button>

              {/* Ultra-Sleek Custom Styled Slider */}
              <div className="flex-1 flex items-center">
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={isMuted ? 0 : volume}
                  onChange={(e) => handleVolumeChange(Number(e.target.value))}
                  className="arx-bgm-slider w-full focus:outline-none"
                  title={`ระดับเสียง: ${volume}%`}
                />
              </div>

              {/* Volume % Value Badge */}
              <span className="text-[8px] font-mono font-semibold text-cyan-300/80 w-6 text-right shrink-0 select-none">
                {isMuted ? '0%' : `${volume}%`}
              </span>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
