'use client';

export default function SolarEclipseTransition() {
  return null;
}
