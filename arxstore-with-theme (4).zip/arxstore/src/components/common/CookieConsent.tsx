'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Cookie, Check, X } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false);
  const { playClick, t } = useStore();

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const consent = localStorage.getItem('arx_cookie_consent') || localStorage.getItem('demox_cookie_consent');
      if (!consent) {
        // Show after a brief delay so page loads smoothly first
        const timer = setTimeout(() => setIsVisible(true), 1200);
        return () => clearTimeout(timer);
      }
    } catch {}
  }, []);

  const handleAcceptAll = () => {
    playClick();
    try {
      localStorage.setItem('arx_cookie_consent', 'true');
      localStorage.setItem('demox_cookie_consent', 'true');
    } catch {}
    setIsVisible(false);
  };

  const handleNecessaryOnly = () => {
    playClick();
    try {
      localStorage.setItem('arx_cookie_consent', 'necessary');
    } catch {}
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <aside
      aria-label="การขอความยินยอมการใช้คุกกี้"
      className="fixed bottom-5 left-5 right-5 sm:left-6 sm:right-auto sm:max-w-md z-[999990] bg-[color:var(--arx-dk-070b14)]/95 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-4 sm:p-5 shadow-[0_10px_40px_rgba(0,0,0,0.85),0_0_25px_rgba(var(--theme-accent-rgb),0.2)] animate-in fade-in slide-in-from-bottom-5 duration-300"
    >
      <div className="flex items-start gap-3.5">
        <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center shrink-0 text-cyan-400 shadow-[0_0_12px_rgba(var(--theme-accent-rgb),0.25)]">
          <Cookie className="w-5 h-5" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-1">
            <h4 className="text-sm font-bold text-white tracking-wide">
              นโยบายการใช้งานคุกกี้ (Cookies)
            </h4>
            <button
              type="button"
              onClick={handleNecessaryOnly}
              aria-label="ปิดหน้าต่างคุกกี้"
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors -mr-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed mb-3.5">
            เว็บไซต์ ARX STORE ใช้คุกกี้เพื่อจัดเก็บเซสชันการเข้าสู่ระบบ บันทึกตะกร้าสินค้า และเพิ่มประสิทธิภาพความปลอดภัยของบัญชีคุณ{' '}
            <Link
              href="/privacy"
              className="text-cyan-400 underline hover:text-cyan-300 transition-colors font-medium"
            >
              อ่านนโยบายความเป็นส่วนตัว
            </Link>
          </p>

          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={handleAcceptAll}
              className="flex-1 inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-cyan-400 to-cyan-300 hover:from-cyan-300 hover:to-cyan-200 shadow-[0_0_15px_rgba(var(--theme-accent-rgb),0.4)] transition-all active:scale-95"
            >
              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>ยอมรับทั้งหมด</span>
            </button>
            <button
              type="button"
              onClick={handleNecessaryOnly}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all active:scale-95"
            >
              จำเป็นเท่านั้น
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}
