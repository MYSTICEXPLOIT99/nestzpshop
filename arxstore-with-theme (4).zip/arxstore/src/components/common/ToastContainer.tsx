'use client';

import React from 'react';
import { useStore } from '@/context/StoreContext';
import {
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  Info,
  Sparkles,
  ShoppingBag,
  X
} from 'lucide-react';

export default function ToastContainer() {
  const { toasts, removeToast } = useStore();

  if (!toasts || toasts.length === 0) return null;

  return (
    <div
      role="region"
      aria-label="การแจ้งเตือน"
      className="fixed bottom-5 right-5 z-[999999] pointer-events-none flex flex-col-reverse gap-3 max-w-sm sm:max-w-md w-[calc(100%-2.5rem)]"
    >
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        const isError = toast.type === 'error';
        const isWarning = toast.type === 'warning';
        const isPurchase = toast.type === 'purchase';
        const isInfo = toast.type === 'info' || !toast.type;

        let borderColor = 'border-cyan-500/30';
        let glowShadow = 'shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_20px_rgba(var(--theme-accent-rgb),0.2)]';
        let iconBg = 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30';
        let IconComponent = Info;

        if (isSuccess) {
          borderColor = 'border-emerald-500/35';
          glowShadow = 'shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_20px_rgba(16,185,129,0.2)]';
          iconBg = 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
          IconComponent = CheckCircle2;
        } else if (isError) {
          borderColor = 'border-rose-500/40';
          glowShadow = 'shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_20px_rgba(244,63,94,0.25)]';
          iconBg = 'bg-rose-500/15 text-rose-400 border-rose-500/30';
          IconComponent = AlertCircle;
        } else if (isWarning) {
          borderColor = 'border-amber-500/40';
          glowShadow = 'shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_20px_rgba(245,158,11,0.25)]';
          iconBg = 'bg-amber-500/15 text-amber-400 border-amber-500/30';
          IconComponent = AlertTriangle;
        } else if (isPurchase) {
          borderColor = 'border-fuchsia-500/40';
          glowShadow = 'shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_25px_rgba(217,70,239,0.25)]';
          iconBg = 'bg-fuchsia-500/15 text-fuchsia-400 border-fuchsia-500/30';
          IconComponent = ShoppingBag;
        }

        return (
          <div
            key={toast.id}
            role="alert"
            className={`pointer-events-auto relative w-full bg-[color:var(--arx-dk-070b14)]/95 backdrop-blur-xl border ${borderColor} rounded-2xl p-4 ${glowShadow} transition-all duration-300 animate-in fade-in slide-in-from-bottom-4`}
          >
            <div className="flex items-start gap-3.5">
              {/* Image or Icon */}
              {toast.productImage ? (
                <div className="w-11 h-11 rounded-xl bg-black/50 border border-white/10 overflow-hidden shrink-0 flex items-center justify-center">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={toast.productImage}
                    alt={toast.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src = '/brand/logo.png';
                    }}
                  />
                </div>
              ) : toast.avatar ? (
                <div className="w-10 h-10 rounded-full bg-black/50 border border-white/10 overflow-hidden shrink-0">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={toast.avatar}
                    alt={toast.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : (
                <div
                  className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${iconBg}`}
                >
                  <IconComponent className="w-5 h-5" />
                </div>
              )}

              {/* Text info */}
              <div className="flex-1 min-w-0 pr-2">
                <div className="flex items-center gap-2 mb-0.5">
                  <h4 className="text-sm font-bold text-white tracking-wide truncate">
                    {toast.title}
                  </h4>
                  {isPurchase && (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-500/30 shrink-0">
                      <Sparkles className="w-2.5 h-2.5" />
                      คำสั่งซื้อ
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                  {toast.message}
                </p>

                {(toast.packageName || toast.price !== undefined) && (
                  <div className="flex items-center gap-2 mt-2">
                    {toast.packageName && (
                      <span className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-slate-300">
                        {toast.packageName}
                      </span>
                    )}
                    {toast.price !== undefined && (
                      <span className="text-[11px] font-bold text-cyan-400">
                        ฿{toast.price.toLocaleString()}
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Close button */}
              <button
                type="button"
                onClick={() => removeToast(toast.id)}
                aria-label="ปิดการแจ้งเตือน"
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors shrink-0 -mr-1 -mt-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
