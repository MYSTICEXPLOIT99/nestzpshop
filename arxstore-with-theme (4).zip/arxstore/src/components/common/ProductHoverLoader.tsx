'use client';

import React from 'react';

interface ProductHoverLoaderProps {
  label?: string;
  isSoldOut?: boolean;
}

export default function ProductHoverLoader({
  isSoldOut = false
}: ProductHoverLoaderProps) {
  const accentGlow = isSoldOut ? 'rgba(244, 63, 94, 0.5)' : 'rgba(var(--theme-accent-rgb), 0.5)';
  const borderLaser = isSoldOut ? 'border-rose-500' : 'border-cyan-400';
  const shadowGlow = isSoldOut ? 'shadow-[0_0_14px_rgba(244,63,94,0.7)]' : 'shadow-[0_0_14px_rgba(var(--theme-accent-rgb),0.7)]';

  return (
    <div
      className="arx-hover-loader absolute inset-0 z-20 flex items-center justify-center bg-black/65 backdrop-blur-[2.5px] opacity-0 group-hover:opacity-100 group-[.hovered]:opacity-100 transition-all duration-300 pointer-events-none select-none overflow-hidden rounded-lg"
      aria-hidden="true"
    >
      {/* 1. Ambient Radial Core Glow Aura */}
      <div
        className="absolute w-32 h-32 rounded-full blur-2xl pointer-events-none arx-logo-glow-pulse opacity-75"
        style={{
          background: `radial-gradient(circle, ${accentGlow} 0%, transparent 70%)`
        }}
      />

      {/* 2. Concentric Spinning Cyber Rings Container */}
      <div className="arx-hud-center relative w-26 h-26 sm:w-28 sm:h-28 flex items-center justify-center transform transition-transform duration-300 group-hover:scale-100 group-[.hovered]:scale-100 scale-85">
        
        {/* Layer A: Outermost Slow Dashed Orbital Track (Clockwise 10s) */}
        <div
          className={`absolute w-24 h-24 sm:w-25 sm:h-25 rounded-full border border-dashed ${
            isSoldOut ? 'border-rose-500/35' : 'border-cyan-400/35'
          } arx-spin-slow pointer-events-none`}
        />

        {/* Layer B: Main Fast Glowing Laser Arc with Orbiting Satellite Bead (Clockwise 2.2s) */}
        <div
          className={`absolute w-20 h-20 sm:w-21 sm:h-21 rounded-full border-2 border-transparent border-t-current border-r-current/80 ${
            isSoldOut ? 'text-rose-400' : 'text-cyan-400'
          } ${shadowGlow} arx-spin-fast pointer-events-none flex items-start justify-center`}
        >
          {/* Orbiting Satellite Dot */}
          <span
            className={`w-1.5 h-1.5 -mt-0.5 rounded-full ${
              isSoldOut ? 'bg-rose-200 shadow-[0_0_8px_#f43f5e]' : 'bg-white shadow-[0_0_8px_var(--theme-accent)]'
            }`}
          />
        </div>

        {/* Layer C: Counter-Rotating Secondary Laser Arc with Satellite (Counter-Clockwise 3s) */}
        <div
          className={`absolute w-16 h-16 sm:w-17 sm:h-17 rounded-full border-2 border-transparent border-b-current border-l-current/85 ${
            isSoldOut ? 'text-rose-400' : 'text-sky-300'
          } arx-spin-reverse-fast pointer-events-none flex items-end justify-center`}
        >
          {/* Orbiting Satellite Dot */}
          <span
            className={`w-1.5 h-1.5 -mb-0.5 rounded-full ${
              isSoldOut ? 'bg-rose-300 shadow-[0_0_6px_#fb7185]' : 'bg-cyan-300 shadow-[0_0_6px_#38bdf8]'
            }`}
          />
        </div>

        {/* Layer D: Inner Segmented Dashed Ring (Counter-Clockwise 6s) */}
        <div
          className={`absolute w-13 h-13 sm:w-14 sm:h-14 rounded-full border border-dashed ${
            isSoldOut ? 'border-rose-400/40' : 'border-cyan-300/40'
          } arx-spin-reverse-medium pointer-events-none`}
        />

        {/* Layer E: Center Cyber Shield Housing the ARX Logo Only */}
        <div
          className={`relative z-10 w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-[color:var(--arx-dk-050811)]/95 border ${
            isSoldOut ? 'border-rose-500/70 shadow-[0_0_18px_rgba(244,63,94,0.6)]' : 'border-cyan-400/70 shadow-[0_0_18px_rgba(var(--theme-accent-rgb),0.6)]'
          } p-1.5 flex items-center justify-center arx-logo-glow-pulse`}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/brand/logo.png"
            alt="ARX STORE"
            className="w-full h-full object-contain filter drop-shadow-[0_0_10px_rgba(var(--theme-accent-rgb),0.95)]"
            onError={(e) => {
              const target = e.currentTarget;
              if (!target.src.includes('arx-default-logo.png')) {
                target.src = '/brand/arx-default-logo.png';
              }
            }}
          />
        </div>
      </div>
    </div>
  );
}
