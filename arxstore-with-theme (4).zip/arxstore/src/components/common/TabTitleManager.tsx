'use client';

import { useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { useStore } from '@/context/StoreContext';

interface TabTitleManagerProps {
  title?: string;
}

export default function TabTitleManager({ title }: TabTitleManagerProps) {
  const pathname = usePathname();
  const { siteContent } = useStore();

  const activeTitle =
    siteContent?.branding?.siteTitle ||
    siteContent?.branding?.siteName ||
    title ||
    'ARX STORE';

  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.title = activeTitle;

      const favicon = siteContent?.branding?.faviconUrl;
      if (favicon) {
        let link: HTMLLinkElement | null = document.querySelector("link[rel*='icon']");
        if (link) {
          link.href = favicon;
        } else {
          link = document.createElement('link');
          link.rel = 'icon';
          link.href = favicon;
          document.head.appendChild(link);
        }
      }
    }
  }, [pathname, activeTitle, siteContent?.branding?.faviconUrl]);

  return null;
}
