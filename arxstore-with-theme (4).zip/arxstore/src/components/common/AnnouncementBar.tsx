'use client';

import React, { useState } from 'react';
import { useStore } from '@/context/StoreContext';
import { Flame, X } from 'lucide-react';
import Link from 'next/link';

export default function AnnouncementBar() {
  const { announcements, playClick } = useStore();
  const [dismissed, setDismissed] = useState(false);

  const activeAnn = announcements.find(a => a.active);
  if (!activeAnn || dismissed) return null;

  return (
    <div className="relative z-40 bg-gradient-to-r from-cyan-950/90 via-slate-900/90 to-blue-950/90 border-b border-cyan-500/25 py-2.5 px-4 backdrop-blur-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5 text-xs sm:text-sm text-cyan-100 flex-1 overflow-hidden">
          <span className="flex items-center justify-center p-1 rounded bg-[color:var(--theme-main)]/20 text-blue-400 shrink-0 animate-pulse">
            <Flame className="w-3.5 h-3.5" />
          </span>
          <span className="font-semibold text-blue-300 shrink-0">
            {activeAnn.title}
          </span>
          <span className="text-slate-300 truncate hidden md:inline">
            — {activeAnn.content}
          </span>
          <Link
            href="/topup"
            onClick={playClick}
            className="text-cyan-300 hover:text-cyan-200 underline font-medium shrink-0 ml-1 text-xs"
          >
            เติมเงินรับโบนัสทันที &rarr;
          </Link>
        </div>

        <button
          onClick={() => {
            playClick();
            setDismissed(true);
          }}
          className="text-cyan-300 hover:text-white p-1 transition shrink-0"
          title="ปิดประกาศ"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
