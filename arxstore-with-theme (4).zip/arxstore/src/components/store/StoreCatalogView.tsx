'use client';

import React, { useState, useMemo, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import { Product, Category, SubCategory } from '@/types';
import {
  Search,
  ChevronDown,
  Sparkles,
  Flame,
  Tag,
  ShoppingBag,
  Layers,
  ArrowUpDown,
  X,
  Server,
  Crosshair,
  Shield,
  Gamepad2,
  Swords,
  Ban,
  PackageCheck
} from 'lucide-react';

interface StoreCatalogViewProps {
  initialCategory?: string;
}

export default function StoreCatalogView({ initialCategory = 'all' }: StoreCatalogViewProps) {
  const router = useRouter();
  const { products, categories, openBuyModal, playClick } = useStore();

  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [selectedSubCategory, setSelectedSubCategory] = useState<string | null>(null);
  const [expandedCategories, setExpandedCategories] = useState<string[]>(['cat-freefire']);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'newest' | 'price-asc' | 'price-desc' | 'popular'>('popular');
  const [isPopularOnly, setIsPopularOnly] = useState<boolean>(true);

  // Sync initialCategory
  useEffect(() => {
    if (initialCategory && initialCategory !== 'all') {
      setSelectedCategory(initialCategory);
      setExpandedCategories(prev => (prev.includes(initialCategory) ? prev : [...prev, initialCategory]));
    }
  }, [initialCategory]);

  // Toggle category expansion
  const toggleExpand = (catId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    playClick();
    setExpandedCategories(prev =>
      prev.includes(catId) ? prev.filter(id => id !== catId) : [...prev, catId]
    );
  };

  // Select category
  const handleSelectCategory = (catId: string) => {
    playClick();
    setSelectedCategory(catId);
    setSelectedSubCategory(null);
    setIsPopularOnly(false);
    if (!expandedCategories.includes(catId)) {
      setExpandedCategories(prev => [...prev, catId]);
    }
  };

  // Select subcategory
  const handleSelectSubCategory = (catId: string, subId: string) => {
    playClick();
    setSelectedCategory(catId);
    setSelectedSubCategory(subId);
    setIsPopularOnly(false);
  };

  // Render category circular icon/image (Matching Image 1)
  const renderCategoryIcon = (cat: Category) => {
    if (cat.image) {
      return (
        <div className="w-6 h-6 rounded-full overflow-hidden shrink-0 border border-white/15 bg-slate-900 shadow-sm flex items-center justify-center group-hover:scale-105 transition-transform">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={cat.image}
            alt={cat.name}
            className="w-full h-full object-cover rounded-full"
            onError={(e) => {
              (e.currentTarget as HTMLElement).style.display = 'none';
            }}
          />
        </div>
      );
    }

    switch (cat.iconName?.toLowerCase()) {
      case 'server':
        return <div className="w-6 h-6 rounded-full bg-orange-500/20 border border-orange-500/30 text-orange-400 flex items-center justify-center shrink-0 shadow-sm"><Server className="w-3.5 h-3.5" /></div>;
      case 'crosshair':
        return <div className="w-6 h-6 rounded-full bg-[color:var(--theme-main)]/20 border border-[color:var(--theme-main)]/30 text-blue-400 flex items-center justify-center shrink-0 shadow-sm"><Crosshair className="w-3.5 h-3.5" /></div>;
      case 'flame':
        return <div className="w-6 h-6 rounded-full bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center shrink-0 shadow-sm"><Flame className="w-3.5 h-3.5" /></div>;
      case 'shield':
        return <div className="w-6 h-6 rounded-full bg-blue-500/20 border border-blue-500/30 text-blue-400 flex items-center justify-center shrink-0 shadow-sm"><Shield className="w-3.5 h-3.5" /></div>;
      case 'gamepad2':
        return <div className="w-6 h-6 rounded-full bg-indigo-500/20 border border-indigo-500/30 text-indigo-400 flex items-center justify-center shrink-0 shadow-sm"><Gamepad2 className="w-3.5 h-3.5" /></div>;
      case 'swords':
        return <div className="w-6 h-6 rounded-full bg-red-500/20 border border-red-500/30 text-red-400 flex items-center justify-center shrink-0 shadow-sm"><Swords className="w-3.5 h-3.5" /></div>;
      case 'ban':
        return <div className="w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0 shadow-sm"><Ban className="w-3.5 h-3.5" /></div>;
      default:
        return <div className="w-6 h-6 rounded-full bg-[color:var(--theme-main)]/20 border border-[color:var(--theme-main)]/30 text-blue-400 flex items-center justify-center shrink-0 shadow-sm"><Layers className="w-3.5 h-3.5" /></div>;
    }
  };

  // Filter & sort products
  const filteredProducts = useMemo(() => {
    return products
      .filter(p => {
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchName = p.name.toLowerCase().includes(q);
          const matchDesc = p.description.toLowerCase().includes(q);
          const matchTag = p.tags?.some(t => t.toLowerCase().includes(q));
          const matchSub = p.subCategoryName?.toLowerCase().includes(q);
          if (!matchName && !matchDesc && !matchTag && !matchSub) return false;
        }

        // Popular filter
        if (isPopularOnly && !p.isPopular) {
          return false;
        }

        // Category filter
        if (selectedCategory !== 'all' && p.categoryId !== selectedCategory) {
          return false;
        }

        // Subcategory filter
        if (selectedSubCategory && p.subCategoryId !== selectedSubCategory) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'popular') return (b.salesCount || 0) - (a.salesCount || 0);
        if (sortBy === 'newest') return (b.rank || 0) - (a.rank || 0);
        const priceA = a.packages?.[0]?.price ?? 0;
        const priceB = b.packages?.[0]?.price ?? 0;
        if (sortBy === 'price-asc') return priceA - priceB;
        if (sortBy === 'price-desc') return priceB - priceA;
        return 0;
      });
  }, [products, searchQuery, isPopularOnly, selectedCategory, selectedSubCategory, sortBy]);

  // Current active header title
  const currentHeaderTitle = useMemo(() => {
    if (isPopularOnly) return 'ขายดี';
    if (selectedSubCategory) {
      const activeCat = categories.find(c => c.id === selectedCategory);
      const activeSub = activeCat?.subCategories?.find(s => s.id === selectedSubCategory);
      if (activeSub) return activeSub.name;
    }
    if (selectedCategory !== 'all') {
      const activeCat = categories.find(c => c.id === selectedCategory);
      if (activeCat) return activeCat.name;
    }
    return 'สินค้าทั้งหมด';
  }, [isPopularOnly, selectedSubCategory, selectedCategory, categories]);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 select-none">
      {/* 1. Top Header Banner (Image 1 Style) */}
      <div className="w-full rounded-2xl border border-white/10 bg-[color:var(--arx-dk-080b14)]/90 p-5 sm:p-6 mb-6 shadow-[0_10px_35px_rgba(0,0,0,0.6)] backdrop-blur-md">
        <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
          <span>ARX STORE</span>
          <span className="w-2 h-2 rounded-full bg-[color:var(--theme-main)] shadow-[0_0_8px_var(--theme-main)] animate-pulse" />
        </h1>
        <p className="text-xs sm:text-[13px] text-slate-400 mt-1 font-medium">
          สินค้าทั้งหมด · {products.length} รายการ
        </p>
      </div>

      {/* 2. Main 2-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Category Tree Sidebar (Image 1 Style) */}
        <aside className="lg:col-span-3 space-y-2">
          <div className="rounded-2xl border border-white/10 bg-[color:var(--arx-dk-070912)]/95 p-3 space-y-1.5 shadow-[0_8px_25px_rgba(0,0,0,0.5)]">
            {/* "ทุกหมวด" button */}
            <button
              type="button"
              onClick={() => {
                playClick();
                setSelectedCategory('all');
                setSelectedSubCategory(null);
                setIsPopularOnly(false);
              }}
              className={`w-full py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                selectedCategory === 'all' && !isPopularOnly
                  ? 'bg-[color:var(--theme-main)]/20 text-blue-300 border-[color:var(--theme-main)]/50 shadow-sm'
                  : 'bg-white/[0.03] text-slate-300 hover:text-white hover:bg-white/[0.06] border-white/5'
              }`}
            >
              <span>ทุกหมวด</span>
              <span className="text-[10px] font-mono text-slate-400 font-bold">
                {products.length}
              </span>
            </button>

            {/* Category Items List */}
            <div className="space-y-1 pt-1">
              {categories.map((cat) => {
                const isSelected = selectedCategory === cat.id && !isPopularOnly;
                const isExpanded = expandedCategories.includes(cat.id);
                const hasSubs = cat.subCategories && cat.subCategories.length > 0;

                // Live product count
                const catProductCount = products.filter(p => p.categoryId === cat.id).length;
                const isOutOfStock = cat.badge === 'หมด' || (catProductCount === 0 && cat.itemCount === 0);

                return (
                  <div key={cat.id} className="space-y-1">
                    {/* Main Category Row */}
                    <button
                      type="button"
                      onClick={() => handleSelectCategory(cat.id)}
                      className={`w-full py-2 px-2.5 rounded-xl border text-xs font-bold flex items-center justify-between transition-all cursor-pointer group ${
                        isSelected && !selectedSubCategory
                          ? 'bg-[color:var(--theme-main)]/20 text-blue-300 border-[color:var(--theme-main)]/50 shadow-sm'
                          : 'bg-transparent text-slate-300 hover:text-white hover:bg-white/[0.04] border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        {renderCategoryIcon(cat)}
                        <span className="truncate">{cat.name}</span>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {/* Out of stock or count badge */}
                        {isOutOfStock ? (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                            หมด
                          </span>
                        ) : (
                          <span className="text-[10px] font-mono text-slate-500 font-bold group-hover:text-slate-300">
                            {catProductCount || cat.itemCount || 0}
                          </span>
                        )}

                        {/* Expand Caret */}
                        {hasSubs && (
                          <span
                            onClick={(e) => toggleExpand(cat.id, e)}
                            className="p-1 rounded text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                          >
                            <ChevronDown
                              className={`w-3.5 h-3.5 transition-transform duration-200 ${
                                isExpanded ? 'rotate-180 text-blue-400' : ''
                              }`}
                            />
                          </span>
                        )}
                      </div>
                    </button>

                    {/* Subcategories (Expanded Tree List - Matching Image 1) */}
                    {hasSubs && isExpanded && (
                      <div className="pl-6 pr-1 space-y-0.5 animate-in slide-in-from-top-1 duration-150 border-l border-white/5 ml-3.5 my-1">
                        {cat.subCategories!.map((sub) => {
                          const isSubSelected =
                            selectedCategory === cat.id && selectedSubCategory === sub.id;
                          const subCount = products.filter(
                            p => p.categoryId === cat.id && p.subCategoryId === sub.id
                          ).length;

                          return (
                            <button
                              key={sub.id}
                              type="button"
                              onClick={() => handleSelectSubCategory(cat.id, sub.id)}
                              className={`w-full py-1.5 px-2 rounded-lg text-[11px] font-medium flex items-center justify-between transition-colors cursor-pointer ${
                                isSubSelected
                                  ? 'bg-[color:var(--theme-main)]/25 text-blue-300 font-bold'
                                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
                              }`}
                            >
                              <div className="flex items-center gap-2 min-w-0">
                                {sub.image || sub.icon ? (
                                  <div className="w-5 h-5 rounded-full overflow-hidden shrink-0 border border-[color:var(--theme-main)]/40 bg-slate-900 shadow-sm flex items-center justify-center">
                                    {/* eslint-disable-next-line @next/next/no-img-element */}
                                    <img src={sub.image || sub.icon} alt={sub.name} className="w-full h-full object-cover rounded-full" />
                                  </div>
                                ) : (
                                  <div className="w-5 h-5 rounded-full bg-[color:var(--theme-main)]/20 border border-[color:var(--theme-main)]/40 flex items-center justify-center shrink-0 text-blue-300 text-[9px] font-black shadow-sm">
                                    {sub.name.charAt(0)}
                                  </div>
                                )}
                                <span className="truncate">{sub.name}</span>
                              </div>
                              <span className="text-[9.5px] font-mono text-slate-500 font-bold">
                                {subCount || sub.itemCount || 0}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </aside>

        {/* Right Column: Search, Sort, Pills & 5-Column Product Grid */}
        <main className="lg:col-span-9 space-y-4">
          {/* Row 1: Search & Sort Bar (Image 1 Style) */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ค้นหาสินค้า... พิมพ์แล้วเห็นผลทันที"
                className="w-full pl-9 pr-8 py-2.5 rounded-xl bg-[color:var(--arx-dk-070912)]/95 border border-white/10 text-white text-xs sm:text-sm placeholder:text-slate-500 focus:outline-none focus:border-[color:var(--theme-main)] focus:shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.35)] transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Sort Dropdown */}
            <div className="relative shrink-0 sm:w-44">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full appearance-none pl-3.5 pr-8 py-2.5 rounded-xl bg-[color:var(--arx-dk-070912)]/95 border border-white/10 text-slate-300 text-xs sm:text-sm font-semibold focus:outline-none focus:border-[color:var(--theme-main)] cursor-pointer"
              >
                <option value="popular">เรียง: ขายดีที่สุด</option>
                <option value="newest">เรียง: มาใหม่</option>
                <option value="price-asc">เรียง: ราคาต่ำ - สูง</option>
                <option value="price-desc">เรียง: ราคาสูง - ต่ำ</option>
              </select>
              <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {/* Row 2: Horizontal Category Pills (Image 1 Style) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {/* "ขายดี" Pill */}
            <button
              type="button"
              onClick={() => {
                playClick();
                setIsPopularOnly(true);
                setSelectedCategory('all');
                setSelectedSubCategory(null);
              }}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all shrink-0 cursor-pointer border ${
                isPopularOnly
                  ? 'bg-[color:var(--theme-main)]/25 text-blue-300 border-[color:var(--theme-main)]/60 shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.35)]'
                  : 'bg-white/[0.04] text-slate-400 hover:text-white hover:bg-white/[0.08] border-white/10'
              }`}
            >
              ขายดี
            </button>

            {/* Category Pills */}
            {categories.map((cat) => {
              const isActive = !isPopularOnly && selectedCategory === cat.id && !selectedSubCategory;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => handleSelectCategory(cat.id)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all shrink-0 cursor-pointer border ${
                    isActive
                      ? 'bg-[color:var(--theme-main)]/25 text-blue-300 border-[color:var(--theme-main)]/60 shadow-[0_0_12px_rgba(var(--theme-main-rgb),0.35)]'
                      : 'bg-white/[0.04] text-slate-400 hover:text-white hover:bg-white/[0.08] border-white/10'
                  }`}
                >
                  {cat.name}
                </button>
              );
            })}
          </div>

          {/* Row 3: Section Title Header */}
          <div className="pt-2 pb-1">
            <h2 className="text-base sm:text-lg font-black text-white tracking-wide">
              {currentHeaderTitle}
            </h2>
          </div>

          {/* Row 4: 5-Column Product Grid (Image 1 Style) */}
          {filteredProducts.length === 0 ? (
            <div className="rounded-2xl border border-white/10 bg-[color:var(--arx-dk-070912)]/80 p-12 text-center space-y-3">
              <ShoppingBag className="w-10 h-10 text-slate-600 mx-auto" />
              <h3 className="text-sm font-bold text-white">ไม่พบสินค้าในหมวดหมู่นี้</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                ลองค้นหาด้วยคำอื่น หรือกดดูสินค้าทั้งหมดในร้าน
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('all');
                  setSelectedSubCategory(null);
                  setIsPopularOnly(false);
                }}
                className="px-4 py-2 rounded-xl bg-[color:var(--theme-main)] text-white font-bold text-xs hover:bg-[color:var(--theme-sec)] transition cursor-pointer"
              >
                ดูสินค้าทั้งหมด
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 2xl:grid-cols-6 gap-3 sm:gap-4">
              {filteredProducts.map((product) => {
                const firstPackage = product.packages?.[0];
                const price = firstPackage?.price ?? 0;
                const originalPrice = firstPackage?.originalPrice;
                const isSingleOption = product.optionType === 'single';

                return (
                  <div
                    key={product.id}
                    onClick={() => {
                      playClick();
                      router.push(`/products/${product.id}`);
                    }}
                    className="rounded-2xl border border-white/10 bg-[color:var(--arx-dk-0c0d12)] hover:border-[color:var(--theme-main)]/60 shadow-lg hover:shadow-[0_8px_25px_rgba(0,0,0,0.8),0_0_15px_rgba(var(--theme-main-rgb),0.25)] transition-all duration-200 overflow-hidden flex flex-col group cursor-pointer"
                  >
                    {/* Card Banner Image */}
                    <div className="relative aspect-square w-full overflow-hidden bg-slate-950">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={product.image || '/catalog/imported/banner_cheat.webp'}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = '/catalog/imported/banner_cheat.webp';
                        }}
                      />

                      {/* Top Badges */}
                      <div className="absolute top-2 left-2 flex items-center gap-1 z-10">
                        {product.badge && (
                          <span className="px-2 py-0.5 rounded-full text-[9.5px] font-black bg-[color:var(--theme-main)] text-white shadow-sm">
                            {product.badge}
                          </span>
                        )}
                      </div>

                      {product.discountBadge && (
                        <div className="absolute top-2 right-2 z-10">
                          <span className="px-2 py-0.5 rounded-full text-[9.5px] font-black bg-[color:var(--theme-main)] text-white shadow-sm">
                            {product.discountBadge}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Card Info Body */}
                    <div className="p-3 flex-1 flex flex-col justify-between space-y-2.5">
                      <div className="space-y-1">
                        {/* Category / Subcategory Label */}
                        <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block truncate">
                          {product.subCategoryName || product.categoryName}
                        </span>

                        {/* Title */}
                        <Link
                          href={`/products/${product.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            playClick();
                          }}
                          className="text-xs sm:text-[12.5px] font-bold text-white leading-snug line-clamp-2 group-hover:text-blue-400 transition-colors block min-h-[32px]"
                          title={product.name}
                        >
                          {product.name}
                        </Link>
                      </div>

                      {/* Pricing & Stock/Sold Info */}
                      <div className="pt-1">
                        <div className="flex items-baseline justify-between gap-1">
                          <div className="flex items-baseline gap-1">
                            {!isSingleOption && (
                              <span className="text-[10px] text-slate-400 font-medium">เริ่ม</span>
                            )}
                            <span className="text-blue-400 font-mono font-black text-sm sm:text-base leading-none">
                              {price} ฿
                            </span>
                            {originalPrice && (
                              <span className="text-slate-500 font-mono text-[10px] line-through">
                                {originalPrice} ฿
                              </span>
                            )}
                          </div>

                          {/* Sold Count or Status Note */}
                          <div className="text-[9.5px] font-mono text-slate-400 truncate">
                            {product.statusNote ? (
                              <span className="text-emerald-400 font-bold">{product.statusNote}</span>
                            ) : (
                              <span>🗂 {product.salesCount.toLocaleString()}</span>
                            )}
                          </div>
                        </div>

                        {/* Buy Button */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            playClick();
                            router.push(`/products/${product.id}`);
                          }}
                          className="w-full mt-2.5 py-2 rounded-xl bg-[color:var(--theme-main)] hover:bg-[color:var(--theme-sec)] text-white font-black text-xs text-center shadow-[0_0_14px_rgba(var(--theme-main-rgb),0.4)] hover:shadow-[0_0_20px_rgba(var(--theme-main-rgb),0.6)] transition-all cursor-pointer active:scale-95"
                        >
                          ซื้อทันที
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
