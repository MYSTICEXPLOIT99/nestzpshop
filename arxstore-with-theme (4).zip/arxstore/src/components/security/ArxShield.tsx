'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { usePathname } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import { sound } from '@/lib/sound';

export interface AntiDevtoolSettings {
  enabled: boolean;
  blockF12: boolean;
  blockRightClick: boolean;
  detectWindowResize: boolean;
  debuggerTrap: boolean;
  clearConsole: boolean;
  adminBypass: boolean;
}

const DEFAULT_SETTINGS: AntiDevtoolSettings = {
  enabled: true,
  blockF12: true,
  blockRightClick: true,
  detectWindowResize: true,
  debuggerTrap: true,
  clearConsole: true,
  adminBypass: true
};

export default function ArxShield() {
  const pathname = usePathname();
  const { user } = useStore();
  const [isOpen, setIsOpen] = useState(false);
  const [settings, setSettings] = useState<AntiDevtoolSettings>(DEFAULT_SETTINGS);
  const [isShaking, setIsShaking] = useState(false);
  const [stillOpenWarning, setStillOpenWarning] = useState<string | null>(null);

  const cooldownRef = useRef<number>(0);
  const isDevToolsOpenRef = useRef<boolean>(false);

  // Check if current user has Admin bypass rights
  const isAdmin = (settings.adminBypass && user?.role === 'admin') || pathname?.startsWith('/admin');

  // 1. Fetch & Hydrate Anti-Devtools Settings
  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Load from localStorage cache first
    try {
      const saved = localStorage.getItem('arx_antidevtool_settings');
      if (saved) {
        setSettings(prev => ({ ...prev, ...JSON.parse(saved) }));
      }
    } catch {}

    // Fetch authoritative settings from server
    fetch('/api/security/settings')
      .then(res => res.json())
      .then(json => {
        if (json.success && json.data) {
          setSettings(json.data);
          try {
            localStorage.setItem('arx_antidevtool_settings', JSON.stringify(json.data));
          } catch {}
        }
      })
      .catch(() => {});

    // Listen to admin changes in real time
    const handleCustomChange = (e: Event) => {
      const customEvent = e as CustomEvent<Partial<AntiDevtoolSettings>>;
      if (customEvent.detail && typeof customEvent.detail === 'object') {
        setSettings(prev => {
          const next = { ...prev, ...customEvent.detail };
          try {
            localStorage.setItem('arx_antidevtool_settings', JSON.stringify(next));
          } catch {}
          return next;
        });
      }
    };

    window.addEventListener('arx:shield:change', handleCustomChange);
    return () => {
      window.removeEventListener('arx:shield:change', handleCustomChange);
    };
  }, []);

  // 2. Active Probe to Detect if DevTools is Open
  const probeDevTools = useCallback((): boolean => {
    if (typeof window === 'undefined') return false;

    // A. Window size threshold probe (Docked DevTools on side or bottom)
    if (settings.detectWindowResize) {
      const threshold = 160;
      const widthDiff = window.outerWidth - window.innerWidth > threshold;
      const heightDiff = window.outerHeight - window.innerHeight > threshold;
      if (widthDiff || heightDiff) {
        return true;
      }
    }

    // B. Debugger timing probe (Paused execution when DevTools has debugger attached)
    if (settings.debuggerTrap) {
      try {
        const start = performance.now();
        // eslint-disable-next-line no-new-func
        const debugProbe = new Function('debugger');
        debugProbe();
        const elapsed = performance.now() - start;
        if (elapsed > 100) {
          return true;
        }
      } catch {}
    }

    return false;
  }, [settings.detectWindowResize, settings.debuggerTrap]);

  // 3. Trigger Modal when DevTools activity is detected
  const triggerShield = useCallback((reason = 'SHORTCUT') => {
    if (!settings.enabled || isAdmin) return;
    if (Date.now() < cooldownRef.current) return;

    isDevToolsOpenRef.current = true;
    setIsOpen(true);
    setStillOpenWarning(null);

    try {
      sound.playErrorBuzz();
    } catch {}
  }, [settings.enabled, isAdmin]);

  // 4. Modal Acknowledge Action (checks if DevTools was actually closed!)
  const handleAcknowledge = useCallback(() => {
    try {
      sound.playKeyClick();
    } catch {}

    // Verify if DevTools is STILL open in the browser
    const stillOpen = probeDevTools();

    if (stillOpen) {
      // Trigger Shake animation & warning
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 500);
      try {
        sound.playErrorBuzz();
      } catch {}
      setStillOpenWarning('⚠️ ตรวจพบว่า DevTools ยังคงเปิดอยู่! กรุณากด F12 หรือปิดหน้าต่าง DevTools ก่อนใช้งานต่อ');
      return;
    }

    // DevTools is closed, smooth close
    setStillOpenWarning(null);
    setIsOpen(false);
    isDevToolsOpenRef.current = false;
    cooldownRef.current = Date.now() + 2000; // Small 2s buffer before re-check
  }, [probeDevTools]);

  // 5. Lock Body Scroll while warning is open
  useEffect(() => {
    if (typeof document === 'undefined') return;
    if (isOpen) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalOverflow;
      };
    }
  }, [isOpen]);

  // 6. Console Security Banner & Console Clearing
  useEffect(() => {
    if (typeof window === 'undefined' || isAdmin || !settings.enabled) return;

    if (settings.clearConsole) {
      try {
        console.clear();
        console.log(
          '%c🛡️ ARX CYBERSHIELD · ANTI-DEVTOOLS ACTIVATED %c\nระบบความปลอดภัยสูงสุดของ ARX STORE\nห้ามเปิด DevTools / F12 / ตรวจสอบสคริปต์บนหน้าเว็บเด็ดขาด',
          'background: #e11d48; color: #ffffff; font-size: 13px; font-weight: 900; padding: 6px 12px; border-radius: 6px;',
          'color: #f43f5e; font-size: 11px; font-weight: 700; line-height: 1.6;'
        );
      } catch {}
    }
  }, [isAdmin, settings.enabled, settings.clearConsole]);

  // 7. Active Real-Time Probe Polling Loop
  useEffect(() => {
    if (!settings.enabled || isAdmin || typeof window === 'undefined') return;

    const interval = setInterval(() => {
      const detected = probeDevTools();
      if (detected) {
        if (!isOpen) {
          triggerShield('ACTIVE_PROBE');
        }
      }
    }, 800);

    return () => clearInterval(interval);
  }, [settings.enabled, isAdmin, isOpen, probeDevTools, triggerShield]);

  // 8. Keyboard & Context Menu Protection Interceptors
  useEffect(() => {
    if (!settings.enabled || isAdmin || typeof window === 'undefined') return;

    const isInput = (target: EventTarget | null) => {
      const el = target as HTMLElement | null;
      if (!el) return false;
      const tag = el.tagName;
      return tag === 'INPUT' || tag === 'TEXTAREA' || el.isContentEditable;
    };

    // Keyboard Shortcuts Interceptor
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        handleAcknowledge();
        return;
      }

      if (!settings.blockF12) return;

      // F12
      if (e.key === 'F12' || e.keyCode === 123) {
        e.preventDefault();
        e.stopPropagation();
        triggerShield('F12');
        return false;
      }

      const isModifier = e.ctrlKey || e.metaKey;

      // Ctrl + Shift + (I, J, C, K, E) / Cmd + Option + (I, J, C)
      if (isModifier && (e.shiftKey || e.altKey)) {
        const k = e.key.toUpperCase();
        if (k === 'I' || k === 'J' || k === 'C' || k === 'K' || k === 'E' || e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67) {
          e.preventDefault();
          e.stopPropagation();
          triggerShield('DEVTOOLS_SHORTCUT');
          return false;
        }
      }

      // Ctrl + U (View Source)
      if (isModifier && (e.key === 'u' || e.key === 'U' || e.keyCode === 85)) {
        e.preventDefault();
        e.stopPropagation();
        triggerShield('VIEW_SOURCE');
        return false;
      }

      // Ctrl + S (Save Page)
      if (isModifier && (e.key === 's' || e.key === 'S' || e.keyCode === 83)) {
        e.preventDefault();
        e.stopPropagation();
        triggerShield('SAVE_PAGE');
        return false;
      }

      // Ctrl + P (Print / Dump)
      if (isModifier && (e.key === 'p' || e.key === 'P' || e.keyCode === 80)) {
        e.preventDefault();
        e.stopPropagation();
        triggerShield('PRINT');
        return false;
      }
    };

    // Right-Click Context Menu Interceptor
    const handleContextMenu = (e: MouseEvent) => {
      if (!settings.blockRightClick) return;
      if (!isInput(e.target)) {
        e.preventDefault();
        e.stopPropagation();
        triggerShield('RIGHT_CLICK');
        return false;
      }
    };

    // Drag-start Interceptor (Prevent dragging assets/scripts)
    const handleDragStart = (e: DragEvent) => {
      if (!isInput(e.target)) {
        e.preventDefault();
        return false;
      }
    };

    // Custom Trigger Listener for Admin testing
    const handleCustomTrigger = () => triggerShield('ADMIN_TEST');

    window.addEventListener('keydown', handleKeyDown, true);
    window.addEventListener('contextmenu', handleContextMenu, true);
    window.addEventListener('dragstart', handleDragStart, true);
    window.addEventListener('arx:shield:trigger', handleCustomTrigger);

    (window as unknown as { triggerArxShield?: () => void }).triggerArxShield = () => triggerShield('MANUAL');

    return () => {
      window.removeEventListener('keydown', handleKeyDown, true);
      window.removeEventListener('contextmenu', handleContextMenu, true);
      window.removeEventListener('dragstart', handleDragStart, true);
      window.removeEventListener('arx:shield:trigger', handleCustomTrigger);
      delete (window as unknown as { triggerArxShield?: () => void }).triggerArxShield;
    };
  }, [settings.enabled, settings.blockF12, settings.blockRightClick, isAdmin, isOpen, triggerShield, handleAcknowledge]);

  if (!isOpen || isAdmin || !settings.enabled) return null;

  return (
    <div
      id="arx-shield-modal"
      className="fixed inset-0 z-[999999] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md select-none animate-in fade-in duration-200"
      role="alertdialog"
      aria-modal="true"
    >
      <div
        className={`relative w-full max-w-[340px] rounded-2xl p-6 bg-[color:var(--arx-dk-0e0e17)] border border-white/10 shadow-[0_0_40px_rgba(239,68,68,0.25),0_20px_50px_rgba(0,0,0,0.95)] flex flex-col items-center text-center overflow-hidden transition-transform duration-200 ${
          isShaking ? 'arx-shake' : ''
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Subtle Ambient Cyan Glow Accent Line */}
        <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-400/80 to-transparent pointer-events-none" />

        {/* Store Logo with Cyan Cyber Glow */}
        <div className="mb-3.5">
          <div className="w-14 h-14 rounded-2xl bg-[color:var(--arx-dk-061824)] border border-cyan-500/40 p-2.5 flex items-center justify-center shadow-lg shadow-cyan-500/20">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/brand/logo.png"
              alt="ARX STORE"
              className="w-full h-full object-contain drop-shadow-[0_0_10px_rgba(var(--theme-accent-rgb),0.5)]"
              onError={(e) => {
                const target = e.currentTarget as HTMLImageElement;
                if (!target.src.includes('arx-default-logo.png')) {
                  target.src = '/brand/arx-default-logo.png';
                }
              }}
            />
          </div>
        </div>

        {/* Header: ARX SHIELD ANTI-DEVTOOL */}
        <h2 className="text-[11px] font-black text-cyan-400 tracking-[0.2em] uppercase font-mono mb-1.5 flex items-center gap-1 justify-center">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping"></span>
          <span>ARX SHIELD · ANTI-DEVTOOLS</span>
        </h2>

        {/* Warning Headline */}
        <h3 className="text-[15px] font-bold text-white tracking-wide leading-snug mb-1">
          ตรวจพบการเปิด Developer Tools
        </h3>

        {/* Subtitle / Instruction */}
        <p className="text-xs text-slate-400 leading-relaxed max-w-[270px] mb-4">
          ไม่อนุญาตให้เปิด F12 หรือตรวจสอบโค้ดหน้าเว็บ กรุณาปิด DevTools ในเบราว์เซอร์ให้เรียบร้อย แล้วกดรับทราบ
        </p>

        {/* Warning Banner if DevTools is still detected as open */}
        {stillOpenWarning && (
          <div className="w-full py-1.5 px-2.5 rounded-lg bg-cyan-950/60 border border-cyan-500/50 text-cyan-300 text-[10.5px] font-bold mb-3 animate-in fade-in duration-150 leading-relaxed text-center">
            {stillOpenWarning}
          </div>
        )}

        {/* Cyan Button: รับทราบ */}
        <button
          type="button"
          id="arx-shield-acknowledge-btn"
          onClick={handleAcknowledge}
          className="min-w-[130px] py-2.5 px-6 rounded-xl bg-gradient-to-r from-cyan-400 via-[var(--theme-accent)] to-cyan-500 hover:from-cyan-300 hover:to-cyan-400 active:scale-95 text-slate-950 font-black text-xs sm:text-sm tracking-wide shadow-md shadow-cyan-500/30 transition-all cursor-pointer inline-flex items-center justify-center"
        >
          รับทราบ
        </button>
      </div>
    </div>
  );
}
