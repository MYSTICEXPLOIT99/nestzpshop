'use client';

import React, { useState, useEffect } from 'react';
import { useStore } from '@/context/StoreContext';
import { Order, ProductPackage } from '@/types';
import {
  X,
  Check,
  Copy,
  Download,
  ShoppingBag,
  Clock,
  Tag,
  ExternalLink
} from 'lucide-react';
import Link from 'next/link';
import { getProductYouTubeId } from '@/lib/youtube';

export default function BuyModal() {
  const {
    isBuyModalOpen,
    closeBuyModal,
    selectedProduct,
    user,
    openAuthModal,
    purchasePackage,
    playClick,
    playSuccess,
    t,
    lang
  } = useStore();

  const [selectedPackageId, setSelectedPackageId] = useState<string>('');
  const [couponCode, setCouponCode] = useState<string>('');
  const [couponApplied, setCouponApplied] = useState<boolean>(false);
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [isPurchasing, setIsPurchasing] = useState<boolean>(false);
  const [purchaseResult, setPurchaseResult] = useState<Order | null>(null);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  // Smooth entrance & exit transition state
  const [mounted, setMounted] = useState<boolean>(false);
  const [isClosing, setIsClosing] = useState<boolean>(false);

  useEffect(() => {
    if (isBuyModalOpen && selectedProduct) {
      setMounted(true);
      setIsClosing(false);
    } else if (mounted) {
      setIsClosing(true);
      const timer = setTimeout(() => {
        setMounted(false);
        setIsClosing(false);
      }, 230);
      return () => clearTimeout(timer);
    }
  }, [isBuyModalOpen, selectedProduct, mounted]);

  const handleSmoothClose = () => {
    if (isClosing) return;
    setIsClosing(true);
    setTimeout(() => {
      closeBuyModal();
    }, 220);
  };

  // Set default package when modal opens
  useEffect(() => {
    const pkgs = selectedProduct?.packages && Array.isArray(selectedProduct.packages) ? selectedProduct.packages : [];
    if (selectedProduct && pkgs.length > 0) {
      setSelectedPackageId(pkgs[0].id);
      setPurchaseResult(null);
      setCouponCode('');
      setCouponApplied(false);
      setDiscountPercent(0);
      setIsCopied(false);
    }
  }, [selectedProduct, isBuyModalOpen]);

  // Close on Escape key with smooth transition
  useEffect(() => {
    if (!isBuyModalOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleSmoothClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isBuyModalOpen]);

  if (!mounted || !selectedProduct) return null;

  const packages = selectedProduct?.packages && Array.isArray(selectedProduct.packages) ? selectedProduct.packages : [];
  const currentPkg: ProductPackage | undefined = packages.find(
    (p) => p.id === selectedPackageId
  ) || packages[0];

  const youtubeVideoId = getProductYouTubeId(selectedProduct.youtubeUrl, selectedProduct.categoryId);

  const basePrice = currentPkg ? currentPkg.price : 0;
  const finalPrice = couponApplied ? Math.round(basePrice * (1 - discountPercent / 100)) : basePrice;
  const hasEnoughBalance = user ? user.balance >= finalPrice : false;

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    playClick();
    const cleanCode = couponCode.trim();
    if (!cleanCode) return;

    try {
      const res = await fetch('/api/coupons/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: cleanCode, price: basePrice })
      });
      const data = await res.json();
      if (data.success && data.discountPercent) {
        setCouponApplied(true);
        setDiscountPercent(data.discountPercent);
        playSuccess();
      } else {
        alert(data.message || 'โค้ดส่วนลดไม่ถูกต้องหรือหมดอายุ');
      }
    } catch {
      alert('เกิดข้อผิดพลาดในการตรวจสอบโค้ดส่วนลด');
    }
  };

  const handleBuy = async () => {
    if (!user) {
      openAuthModal('login');
      return;
    }

    if (!currentPkg) return;

    setIsPurchasing(true);
    const res = await purchasePackage(selectedProduct.id, currentPkg.id, couponApplied ? couponCode.trim() : undefined);
    setIsPurchasing(false);

    if (res.success && res.order) {
      setPurchaseResult(res.order);
    }
  };

  const copyLicenseKey = () => {
    playClick();
    if (purchaseResult?.licenseKey) {
      navigator.clipboard.writeText(purchaseResult.licenseKey);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  return (
    <div 
      className={`fixed inset-0 z-[9999] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md cursor-pointer ${
        isClosing ? 'arx-modal-backdrop-out' : 'arx-modal-backdrop-in'
      }`}
      onClick={handleSmoothClose}
    >
      <div 
        className={`relative w-full max-w-lg sm:max-w-xl cyber-card rounded-2xl p-4 sm:p-5 bg-slate-950/95 border border-cyan-500/40 shadow-2xl max-h-[92vh] overflow-y-auto cursor-default ${
          isClosing ? 'arx-modal-card-out' : 'arx-modal-card-in'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Brand Header */}
        <div className="flex items-center gap-2 mb-2.5 pb-2 border-b border-cyan-500/20">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/brand/logo.png"
            alt="ARX STORE"
            className="w-5 h-5 sm:w-6 sm:h-6 object-contain drop-shadow-[0_0_8px_rgba(var(--theme-accent-rgb),0.7)]"
            onError={(e) => {
              const target = e.currentTarget;
              if (!target.src.includes('arx-default-logo.png')) {
                target.src = '/brand/arx-default-logo.png';
              }
            }}
          />
          <div>
            <span className="text-[10px] sm:text-[11px] font-black tracking-widest text-cyan-400 uppercase block">ARX STORE OFFICIAL</span>
            <span className="text-[8.5px] sm:text-[9.5px] text-slate-400">ระบบจัดส่งสินค้าและ License Key อัตโนมัติ 24 ชม.</span>
          </div>
        </div>

        {/* Close Button */}
        <button
          type="button"
          onClick={handleSmoothClose}
          className="absolute top-3.5 right-3.5 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 transition cursor-pointer"
          title="ปิด"
        >
          <X className="w-4 h-4" />
        </button>

        {purchaseResult ? (
          /* SUCCESS STATE */
          <div className="text-center py-2 animate-in zoom-in-95 duration-200">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto mb-2.5 shadow-lg shadow-emerald-500/20">
              <Check className="w-6 h-6 stroke-[2.5]" />
            </div>

            <h3 className="text-lg sm:text-xl font-black text-white tracking-wide">
              {lang === 'th' ? 'สั่งซื้อสินค้าสำเร็จ!' : 'Purchase Successful!'}
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">
              {lang === 'th' ? 'ระบบจัดส่งสินค้าและ License Key ของคุณเรียบร้อยแล้ว' : 'Your license key and instructions have been delivered.'}
            </p>

            {/* License Box */}
            <div className="mt-4 p-3 rounded-xl bg-slate-900 border border-cyan-500/30 text-left">
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
                <span>{t('orders_id')}: <strong className="text-white font-mono">{purchaseResult.orderNumber}</strong></span>
                <span className="text-emerald-400 font-medium">{t('orders_delivered')}</span>
              </div>
              <p className="text-[11px] text-slate-400 mb-1">{t('orders_key')}:</p>
              <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 border border-cyan-500/40">
                <span className="font-mono text-xs sm:text-sm font-bold text-cyan-300 select-all tracking-wider">
                  {purchaseResult.licenseKey}
                </span>
                <button
                  type="button"
                  onClick={copyLicenseKey}
                  className="px-2.5 py-1 rounded-md bg-cyan-600/30 hover:bg-cyan-600 border border-cyan-400/40 text-cyan-200 text-[11px] font-semibold flex items-center gap-1 transition cursor-pointer"
                >
                  {isCopied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  {isCopied ? t('orders_copied') : t('orders_copy')}
                </button>
              </div>

              {/* Credentials / Notes */}
              {purchaseResult.credentials && (
                <div className="mt-2.5 p-2 rounded-lg bg-slate-950/80 border border-[color:var(--theme-main)]/35 text-left">
                  <div className="text-[10px] text-blue-400 font-bold mb-0.5 flex items-center gap-1">
                    <span>📌 ข้อมูลเพิ่มเติม / บันทึกคลัง:</span>
                  </div>
                  <div className="font-mono text-[11px] text-blue-200 break-all select-all whitespace-pre-line">
                    {purchaseResult.credentials}
                  </div>
                </div>
              )}

              {/* Instructions */}
              <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] text-slate-300">
                <p className="font-bold text-white mb-0.5">{t('buy_instructions')}:</p>
                <p className="whitespace-pre-line text-slate-400 leading-relaxed font-mono text-[10px]">
                  {purchaseResult.instructions}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-4 flex flex-col sm:flex-row items-center gap-2">
              {purchaseResult.downloadUrl && (
                <a
                  href={purchaseResult.downloadUrl}
                  target="_blank"
                  rel="noreferrer"
                  onClick={playClick}
                  className="w-full sm:flex-1 py-2.5 rounded-xl cyber-btn-primary font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" /> {t('orders_download')}
                </a>
              )}
              <Link
                href="/orders"
                onClick={() => {
                  playClick();
                  handleSmoothClose();
                }}
                className="w-full sm:flex-1 py-2.5 rounded-xl cyber-btn-secondary font-semibold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <ShoppingBag className="w-3.5 h-3.5" /> {t('nav_orders')}
              </Link>
            </div>
          </div>
        ) : (
          /* PURCHASE FORM STATE */
          <div className="transition-opacity duration-200">
            {/* Header info */}
            <div className="flex items-center gap-3 mb-3">
              <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-xl overflow-hidden bg-slate-900 border border-slate-800 shrink-0">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (!target.src.includes('46ebc6a271269458ec9b.webp')) {
                      target.src = '/catalog/imported/46ebc6a271269458ec9b.webp';
                    }
                  }}
                />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full font-bold uppercase bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                    {selectedProduct.categoryName}
                  </span>
                  {(packages.length === 0 || packages.every(pkg => !pkg.inStock || pkg.stock <= 0) || selectedProduct.status === 'out_of_stock') && (
                    <span className="text-[9px] px-1.5 py-0.5 rounded-full font-black uppercase bg-red-500/20 text-red-400 border border-red-500/40">
                      OUT OF STOCK
                    </span>
                  )}
                </div>
                <h3 className="text-sm sm:text-base font-bold text-white mt-0.5 leading-snug truncate">
                  {selectedProduct.name}
                </h3>
                <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                  {selectedProduct.shortDescription}
                </p>
              </div>
            </div>

            {/* Package Selection & YouTube Review Video Section (Side-by-Side) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3 mb-3 items-stretch">
              {/* Left Column: Select Package & Duration */}
              <div className="flex flex-col">
                <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  {t('buy_select_package')}:
                </label>
                <div className={`space-y-1.5 ${packages.length > 2 ? 'max-h-[160px] overflow-y-auto pr-1' : ''}`}>
                  {packages.map((pkg) => {
                    const isSelected = pkg.id === selectedPackageId;
                    const isPkgOutOfStock = !pkg.inStock || pkg.stock <= 0;
                    const displayDuration = lang === 'en'
                      ? pkg.duration
                          .replace('1 วัน', '1 Day')
                          .replace('7 วัน', '7 Days')
                          .replace('30 วัน', '30 Days')
                          .replace('ถาวร (Lifetime)', 'Lifetime')
                          .replace('ถาวร', 'Lifetime')
                      : pkg.duration;

                    return (
                      <button
                        key={pkg.id}
                        type="button"
                        onClick={() => {
                          playClick();
                          setSelectedPackageId(pkg.id);
                        }}
                        className={`p-2 sm:p-2.5 rounded-xl border text-left transition-all duration-200 cursor-pointer w-full ${
                          isSelected
                            ? 'bg-cyan-950/60 border-cyan-400 text-white shadow-md shadow-cyan-500/20 ring-1 ring-cyan-400/50'
                            : isPkgOutOfStock
                            ? 'bg-slate-900/40 border-red-500/20 text-slate-400 opacity-80'
                            : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-cyan-500/40 hover:bg-slate-900/90'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-0.5">
                          <span className="text-[11.5px] font-bold truncate pr-1">{pkg.name}</span>
                          {isPkgOutOfStock ? (
                            <span className="px-1.5 py-0.25 rounded text-[8.5px] font-black uppercase bg-red-500/20 text-red-400 border border-red-500/40 shrink-0">
                              OUT OF STOCK
                            </span>
                          ) : isSelected ? (
                            <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                          ) : (
                            <span className="text-[9.5px] text-slate-500 font-mono shrink-0">เหลือ {pkg.stock}</span>
                          )}
                        </div>
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-xs sm:text-[13px] font-extrabold text-white font-mono">
                            ฿{pkg.price.toLocaleString()}
                          </span>
                          {pkg.originalPrice && (
                            <span className="text-[10px] text-slate-500 line-through">
                              ฿{pkg.originalPrice.toLocaleString()}
                            </span>
                          )}
                        </div>
                        <span className="text-[9px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Clock className="w-2.5 h-2.5 text-cyan-400" /> {lang === 'th' ? 'ระยะเวลา:' : 'Duration:'} {displayDuration}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Right Column: YouTube Review Video Embed */}
              <div className="flex flex-col">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="flex items-center gap-1.5 text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_var(--theme-accent)] animate-pulse" />
                    <span className="text-white">วิดีโอรีวิวสินค้า:</span>
                  </label>
                  <a
                    href={`https://www.youtube.com/watch?v=${youtubeVideoId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="px-1.5 py-0.25 rounded-full bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-[8.5px] font-bold text-cyan-400 hover:text-cyan-300 font-mono tracking-wider flex items-center gap-1 transition cursor-pointer"
                    title="เปิดดูใน YouTube"
                  >
                    <span>YOUTUBE</span>
                    <ExternalLink className="w-2 h-2" />
                  </a>
                </div>

                {/* YouTube Video Player Container with Cyber Glow Frame */}
                <div className="relative rounded-xl overflow-hidden bg-black/95 border border-cyan-500/30 shadow-md shadow-cyan-950/40 aspect-video w-full flex-1 max-h-[120px] sm:max-h-[135px] flex items-center justify-center">
                  {youtubeVideoId ? (
                    <iframe
                      src={`https://www.youtube.com/embed/${youtubeVideoId}?rel=0&modestbranding=1&playsinline=1`}
                      title={`${selectedProduct.name} - Review Video`}
                      className="w-full h-full aspect-video border-0 rounded-xl"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
                      allowFullScreen
                    />
                  ) : (
                    <div className="p-3 text-center text-slate-500 flex flex-col items-center justify-center">
                      <span className="text-[11px]">ไม่มีคลิปรีวิว</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Coupon Code Input */}
            <form onSubmit={handleApplyCoupon} className="mb-2.5 flex gap-2">
              <div className="relative flex-1">
                <span className="absolute inset-y-0 left-0 flex items-center pl-2.5 text-slate-500">
                  <Tag className="w-3 h-3" />
                </span>
                <input
                  type="text"
                  placeholder="กรอกโค้ดส่วนลด เช่น ARXSTORE"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  disabled={couponApplied}
                  className="w-full pl-8 pr-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-white focus:outline-none focus:border-cyan-400 transition uppercase disabled:opacity-50"
                />
              </div>
              <button
                type="submit"
                disabled={couponApplied || !couponCode}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold transition disabled:opacity-50 cursor-pointer shrink-0"
              >
                {couponApplied ? 'ใช้แล้ว' : 'ใช้โค้ด'}
              </button>
            </form>

            {/* Pricing Summary */}
            <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900/80 border border-cyan-500/20 mb-3 space-y-1">
              <div className="flex justify-between text-[11px] text-slate-400">
                <span>ราคาแพ็กเกจ ({currentPkg?.duration})</span>
                <span className="font-mono">฿{basePrice.toLocaleString()}</span>
              </div>
              {couponApplied && (
                <div className="flex justify-between text-[11px] text-emerald-400">
                  <span>ส่วนลดโปรโมชัน ({discountPercent}%)</span>
                  <span className="font-mono">-฿{Math.round(basePrice * (discountPercent / 100)).toLocaleString()}</span>
                </div>
              )}
              <div className="pt-1.5 border-t border-slate-800 flex justify-between items-baseline">
                <span className="text-xs sm:text-[13px] font-bold text-white">ยอดชำระสุทธิ:</span>
                <span className="text-sm sm:text-base font-extrabold text-cyan-400 font-mono tracking-tight">
                  ฿{finalPrice.toLocaleString()}
                </span>
              </div>

              {/* Balance or Guest Status */}
              {user ? (
                <div className="pt-1 border-t border-slate-800/60 flex items-center justify-between text-[10px]">
                  <span className="text-slate-400">
                    ยอดเงินของคุณ: <strong className="text-white font-mono">฿{user.balance.toLocaleString()}</strong>
                  </span>
                  {!hasEnoughBalance && (
                    <Link
                      href="/topup"
                      onClick={() => {
                        playClick();
                        handleSmoothClose();
                      }}
                      className="text-cyan-400 hover:underline font-bold flex items-center gap-0.5"
                    >
                      เติมเงินเพิ่ม &rarr;
                    </Link>
                  )}
                </div>
              ) : (
                <div className="pt-1 text-[10px] text-amber-400 flex items-center gap-1">
                  <span>⚠️ ยังไม่ได้เข้าสู่ระบบ กรุณาเข้าสู่ระบบก่อนทำการสั่งซื้อ</span>
                </div>
              )}
            </div>

            {/* Submit Button */}
            {(() => {
              const isCurrentPkgOutOfStock = !currentPkg || !currentPkg.inStock || currentPkg.stock <= 0;
              return (
                <div className="space-y-1.5">
                  <button
                    type="button"
                    onClick={handleBuy}
                    disabled={isPurchasing || isCurrentPkgOutOfStock || (user ? !hasEnoughBalance : false)}
                    className={`w-full py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-lg flex items-center justify-center gap-1.5 ${
                      isCurrentPkgOutOfStock
                        ? 'bg-red-950/40 text-red-400 border border-red-500/40 cursor-not-allowed'
                        : !user
                        ? 'cyber-btn-primary cursor-pointer'
                        : hasEnoughBalance
                        ? 'cyber-btn-primary cursor-pointer'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                    }`}
                  >
                    {isPurchasing ? (
                      <span>กำลังดำเนินการสั่งซื้อ...</span>
                    ) : isCurrentPkgOutOfStock ? (
                      <span className="font-black uppercase tracking-wider">OUT OF STOCK</span>
                    ) : !user ? (
                      <span>{t('nav_login')}</span>
                    ) : hasEnoughBalance ? (
                      <span>{t('buy_now')} ฿{finalPrice.toLocaleString()}</span>
                    ) : (
                      <span>ยอดเงินคงเหลือไม่เพียงพอ</span>
                    )}
                  </button>

                  <div className="flex items-center justify-center gap-1 text-[10px] text-slate-500 text-center">
                    <Check className="w-3 h-3 text-cyan-400" />
                    <span>จัดส่งคีย์ทันทีอัตโนมัติ 24 ชม. ผ่านหน้าคำสั่งซื้อ</span>
                  </div>
                </div>
              );
            })()}
          </div>
        )}

      </div>
    </div>
  );
}
