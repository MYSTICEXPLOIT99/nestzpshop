'use client';

import React, { useState, useEffect } from 'react';
import { useStore } from '@/context/StoreContext';
import {
  X,
  Lock,
  User as UserIcon,
  Mail,
  Eye,
  EyeOff,
  ArrowRight,
  Check,
  Loader2
} from 'lucide-react';

export default function AuthModal() {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authModalMode,
    login,
    register,
    playClick,
    playSuccess,
    playError,
    showToast
  } = useStore();

  const [mode, setMode] = useState<'login' | 'register'>(authModalMode);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Cloudflare Turnstile simulation state
  const [turnstileVerified, setTurnstileVerified] = useState(true);
  const [isVerifyingTurnstile, setIsVerifyingTurnstile] = useState(false);

  // Anti-Spam Honeypot State
  const [honeypot, setHoneypot] = useState('');

  // Smooth entrance & exit transition state
  const [mounted, setMounted] = useState<boolean>(false);
  const [isClosing, setIsClosing] = useState<boolean>(false);

  useEffect(() => {
    if (isAuthModalOpen) {
      setMounted(true);
      setIsClosing(false);
      setHoneypot('');
      setErrorMsg('');
      setTurnstileVerified(true);
    } else if (mounted) {
      setIsClosing(true);
      const timer = setTimeout(() => {
        setMounted(false);
        setIsClosing(false);
      }, 230);
      return () => clearTimeout(timer);
    }
  }, [isAuthModalOpen, mounted]);

  const handleSmoothClose = () => {
    if (isClosing) return;
    setIsClosing(true);
    setTimeout(() => {
      closeAuthModal();
    }, 220);
  };

  // Sync mode with props when opened
  useEffect(() => {
    setMode(authModalMode);
    setErrorMsg('');
  }, [authModalMode, isAuthModalOpen]);

  // Close on Escape key
  useEffect(() => {
    if (!isAuthModalOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleSmoothClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAuthModalOpen]);

  const handleToggleTurnstile = () => {
    playClick();
    if (turnstileVerified) {
      setTurnstileVerified(false);
    } else {
      setIsVerifyingTurnstile(true);
      setTimeout(() => {
        setIsVerifyingTurnstile(false);
        setTurnstileVerified(true);
      }, 700);
    }
  };

  if (!mounted) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const cleanUser = username.trim();

    if (!cleanUser) {
      setErrorMsg('กรุณากรอกชื่อผู้ใช้');
      playError();
      return;
    }

    if (!turnstileVerified) {
      setErrorMsg('กรุณายืนยันการตรวจสอบความปลอดภัยของ Cloudflare');
      playError();
      return;
    }

    if (mode === 'register') {
      // 1. Honeypot check
      if (honeypot && honeypot.trim().length > 0) {
        setErrorMsg('ระบบตรวจพบบอทอัตโนมัติ (Automated bot spam blocked)');
        playError();
        return;
      }

      // 2. Strict Username validation
      const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
      if (!usernameRegex.test(cleanUser)) {
        setErrorMsg('ชื่อผู้ใช้ต้องเป็นตัวอักษรภาษาอังกฤษ ตัวเลข หรือขีดล่าง (_) ความยาว 3-20 ตัวอักษรเท่านั้น');
        playError();
        return;
      }

      // 3. Blocked reserved / spam names
      const blockedNames = ['arxstore', 'admin', 'administrator', 'root', 'bot', 'system', 'null', 'undefined', 'anonymous', 'moderator'];
      if (blockedNames.includes(cleanUser.toLowerCase())) {
        setErrorMsg('ชื่อผู้ใช้นี้ไม่อนุญาตให้ใช้งาน กรุณาตั้งชื่ออื่น');
        playError();
        return;
      }

      // 4. Password validation
      if (password.length < 4) {
        setErrorMsg('รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร');
        playError();
        return;
      }
      if (password !== confirmPassword) {
        setErrorMsg('รหัสผ่านยืนยันไม่ตรงกัน');
        playError();
        return;
      }

      // 5. Registration cooldown
      const lastRegStr = typeof window !== 'undefined' ? localStorage.getItem('arx_last_reg_timestamp') : null;
      if (lastRegStr) {
        const elapsedSecs = (Date.now() - Number(lastRegStr)) / 1000;
        if (elapsedSecs < 20) {
          const waitTime = Math.ceil(20 - elapsedSecs);
          setErrorMsg(`ระบบป้องกันสแปม: กรุณารออีก ${waitTime} วินาทีก่อนสมัครสมาชิกใหม่`);
          playError();
          return;
        }
      }

      setIsLoading(true);
      const res = await register(cleanUser, password, email.trim() || undefined);
      setIsLoading(false);
      if (res.success) {
        if (typeof window !== 'undefined') {
          localStorage.setItem('arx_last_reg_timestamp', String(Date.now()));
        }
        handleSmoothClose();
      } else {
        setErrorMsg(res.message);
      }
    } else {
      setIsLoading(true);
      const res = await login(cleanUser, password);
      setIsLoading(false);
      if (res.success) {
        handleSmoothClose();
      } else {
        setErrorMsg(res.message);
      }
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
      className={`fixed inset-0 z-[999999] overflow-y-auto overflow-x-hidden flex items-center justify-center p-3 sm:p-6 lg:p-10 bg-[color:var(--arx-dk-020408)]/90 backdrop-blur-2xl select-none ${
        isClosing ? 'arx-modal-backdrop-out' : 'arx-modal-backdrop-in'
      }`}
      onClick={handleSmoothClose}
    >
      {/* ========================================================
          CLEAN AMBIENT BACKGROUND (NO TILES / NO CARDS)
         ======================================================== */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none -z-10">
        {/* Subtle ambient cyan/blue glows */}
        <div className="absolute top-1/2 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] rounded-full bg-cyan-500/10 blur-[130px]" />
        <div className="absolute top-1/2 right-1/4 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-blue-600/10 blur-[140px]" />
        
        {/* Subtle light streak beams */}
        <div className="absolute top-1/4 -left-20 w-[120%] h-px bg-gradient-to-r from-transparent via-cyan-400/20 to-transparent rotate-[-15deg] blur-[1px]" />
        <div className="absolute bottom-1/3 -left-20 w-[120%] h-px bg-gradient-to-r from-transparent via-blue-500/15 to-transparent rotate-[-15deg] blur-[1px]" />

        {/* Deep Dark Radial Vignette */}
        <div
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(circle at center, rgba(2,4,8,0.75) 20%, rgba(2,4,8,0.95) 75%, #020408 100%)'
          }}
        />
      </div>

      {/* Top Right Close Button */}
      <button
        type="button"
        onClick={handleSmoothClose}
        aria-label="ปิดหน้าต่างเข้าสู่ระบบ"
        className="fixed top-5 right-5 z-50 p-2.5 rounded-full bg-black/60 border border-white/10 text-slate-400 hover:text-white hover:border-cyan-400/50 hover:bg-white/10 transition-all cursor-pointer shadow-lg active:scale-90"
        title="ปิด (Esc)"
      >
        <X className="w-5 h-5" />
      </button>

      {/* ========================================================
          MAIN MODAL CONTAINER: FORM CARD (CENTERED)
         ======================================================== */}
      <div
        className={`relative z-10 w-full max-w-[420px] mx-auto flex items-center justify-center py-6 cursor-default ${
          isClosing ? 'arx-modal-card-out' : 'arx-modal-card-in'
        }`}
        onClick={(e) => e.stopPropagation()}
      >

        {/* HIGH-TECH FORM CARD (LOGIN / REGISTER) */}
        <div className="w-full rounded-3xl p-6 sm:p-8 bg-[color:var(--arx-dk-090d16)]/95 border border-cyan-500/25 shadow-[0_20px_60px_rgba(0,0,0,0.95),0_0_40px_rgba(var(--theme-accent-rgb),0.14)] backdrop-blur-2xl relative">
          
          {/* Subtle top cyan neon glow line */}
          <div className="absolute -top-px left-8 right-8 h-px bg-gradient-to-r from-transparent via-cyan-400/60 to-transparent" />

          {/* Form Header */}
          <div className="text-center mb-6">
            <h2
              id="auth-modal-title"
              className="text-2xl sm:text-3xl font-black bg-gradient-to-r from-cyan-400 via-cyan-200 to-blue-500 bg-clip-text text-transparent drop-shadow-[0_0_20px_rgba(var(--theme-accent-rgb),0.5)] tracking-wide"
            >
              {mode === 'login' ? 'เข้าสู่ระบบ' : 'สมัครสมาชิก'}
            </h2>
            <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
              {mode === 'login'
                ? 'กรอกชื่อผู้ใช้และรหัสผ่านของคุณเพื่อเข้าใช้งาน'
                : 'สร้างบัญชีใหม่เพื่อเริ่มสั่งซื้อสินค้า'}
            </p>
          </div>

          {/* Error Message Display */}
          {errorMsg && (
            <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-2 animate-in fade-in-50">
              <span className="shrink-0">⚠️</span>
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Main Form Fields */}
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* 1. Username Field */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                ชื่อผู้ใช้
              </label>
              <div className="relative rounded-xl bg-black/60 border border-white/10 hover:border-white/20 focus-within:border-cyan-400 focus-within:shadow-[0_0_15px_rgba(var(--theme-accent-rgb),0.25)] transition-all">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500 pointer-events-none">
                  <UserIcon className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="ชื่อผู้ใช้"
                  className="w-full bg-transparent pl-10 pr-4 py-3 text-xs sm:text-sm text-white placeholder:text-slate-600 focus:outline-none font-sans"
                />
              </div>
            </div>

            {/* 2. Optional Email Field (Only in Register mode) */}
            {mode === 'register' && (
              <div className="animate-in fade-in duration-200">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  อีเมล (ถ้ามี)
                </label>
                <div className="relative rounded-xl bg-black/60 border border-white/10 hover:border-white/20 focus-within:border-cyan-400 focus-within:shadow-[0_0_15px_rgba(var(--theme-accent-rgb),0.25)] transition-all">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500 pointer-events-none">
                    <Mail className="w-4 h-4" />
                  </span>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com (ไม่บังคับ)"
                    className="w-full bg-transparent pl-10 pr-4 py-3 text-xs sm:text-sm text-white placeholder:text-slate-600 focus:outline-none font-sans"
                  />
                </div>
              </div>
            )}

            {/* 3. Password Field */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                รหัสผ่าน
              </label>
              <div className="relative rounded-xl bg-black/60 border border-white/10 hover:border-white/20 focus-within:border-cyan-400 focus-within:shadow-[0_0_15px_rgba(var(--theme-accent-rgb),0.25)] transition-all">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500 pointer-events-none">
                  <Lock className="w-4 h-4" />
                </span>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={mode === 'register' ? 'อย่างน้อย 6 ตัวอักษร' : 'รหัสผ่าน'}
                  className="w-full bg-transparent pl-10 pr-10 py-3 text-xs sm:text-sm text-white placeholder:text-slate-600 focus:outline-none font-sans"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'ซ่อนรหัสผ่าน' : 'แสดงรหัสผ่าน'}
                  className="absolute inset-y-0 right-0 flex items-center pr-3.5 text-slate-500 hover:text-cyan-400 transition-colors cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4 text-slate-400" />}
                </button>
              </div>
            </div>

            {/* 4. Confirm Password Field (Only in Register mode) */}
            {mode === 'register' && (
              <div className="animate-in fade-in duration-200">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  ยืนยันรหัสผ่าน
                </label>
                <div className="relative rounded-xl bg-black/60 border border-white/10 hover:border-white/20 focus-within:border-cyan-400 focus-within:shadow-[0_0_15px_rgba(var(--theme-accent-rgb),0.25)] transition-all">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-500 pointer-events-none">
                    <Lock className="w-4 h-4" />
                  </span>
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="ยืนยันรหัสผ่าน"
                    className="w-full bg-transparent pl-10 pr-10 py-3 text-xs sm:text-sm text-white placeholder:text-slate-600 focus:outline-none font-sans"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    aria-label={showConfirmPassword ? 'ซ่อนรหัสผ่าน' : 'แสดงรหัสผ่าน'}
                    className="absolute inset-y-0 right-0 flex items-center pr-3.5 text-slate-500 hover:text-cyan-400 transition-colors cursor-pointer"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4 text-slate-400" />}
                  </button>
                </div>
              </div>
            )}

            {/* 5. Cloudflare Turnstile Box (Exact Design Replica) */}
            <div className="rounded-xl bg-[color:var(--arx-dk-141722)]/90 border border-white/10 p-3 sm:p-3.5 flex items-center justify-between shadow-inner">
              <button
                type="button"
                onClick={handleToggleTurnstile}
                className="flex items-center gap-3 cursor-pointer group"
              >
                {isVerifyingTurnstile ? (
                  <div className="w-6 h-6 rounded-md bg-white/10 flex items-center justify-center">
                    <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
                  </div>
                ) : turnstileVerified ? (
                  <div className="w-6 h-6 rounded-md bg-emerald-500 flex items-center justify-center shadow-[0_0_10px_rgba(16,185,129,0.5)]">
                    <Check className="w-4 h-4 text-white stroke-[3]" />
                  </div>
                ) : (
                  <div className="w-6 h-6 rounded-md border-2 border-slate-500 group-hover:border-cyan-400 transition-colors" />
                )}
                <span className="text-xs sm:text-sm font-bold text-white tracking-wide">
                  {turnstileVerified ? 'สำเร็จ!' : 'ยืนยันว่าคุณไม่ใช่บอท'}
                </span>
              </button>

              {/* Cloudflare Branding Badge */}
              <div className="flex flex-col items-end text-right">
                <div className="flex items-center gap-1">
                  {/* Cloudflare cloud shape icon */}
                  <svg viewBox="0 0 48 48" className="w-4 h-4 fill-[#f38020]">
                    <path d="M38.8 24.3c-.6-3.8-3.9-6.8-7.9-6.8-1.5 0-2.8.4-4 1.1-1.3-3.6-4.7-6.2-8.8-6.2-5 0-9.2 3.8-9.8 8.8-4.1.7-7.3 4.3-7.3 8.6 0 4.8 3.9 8.8 8.8 8.8h28c4.4 0 8-3.6 8-8 0-3.5-2.3-6.6-5.6-7.7-.2-.2-.5-.4-.7-.6z"/>
                  </svg>
                  <span className="text-[10px] font-black tracking-wider text-slate-300">
                    CLOUDFLARE
                  </span>
                </div>
                <span className="text-[9px] text-slate-500 mt-0.5">
                  ความเป็นส่วนตัว • ข้อกำหนด
                </span>
              </div>
            </div>

            {/* Invisible Honeypot Trap */}
            <div className="absolute opacity-0 -z-50 pointer-events-none select-none h-0 w-0 overflow-hidden" aria-hidden="true">
              <input
                type="text"
                name="hp_security_check"
                value={honeypot}
                onChange={e => setHoneypot(e.target.value)}
                tabIndex={-1}
                autoComplete="off"
              />
            </div>

            {/* 6. Vibrant Cyan Gradient Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 rounded-xl font-black text-xs sm:text-sm text-black bg-gradient-to-r from-cyan-400 via-cyan-300 to-blue-500 hover:from-cyan-300 hover:to-blue-400 shadow-[0_0_25px_rgba(var(--theme-accent-rgb),0.5)] hover:shadow-[0_0_35px_rgba(var(--theme-accent-rgb),0.7)] transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98] mt-2"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-black" />
                  <span>กำลังดำเนินการ...</span>
                </>
              ) : mode === 'login' ? (
                <>
                  <span>เข้าสู่ระบบ</span>
                  <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                </>
              ) : (
                <>
                  <span>สร้างบัญชี</span>
                  <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                </>
              )}
            </button>
          </form>

          {/* Footer Switch Mode Link */}
          <div className="mt-5 text-center text-xs text-slate-400">
            {mode === 'login' ? (
              <p>
                ยังไม่มีบัญชี?{' '}
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setMode('register');
                    setErrorMsg('');
                  }}
                  className="font-bold text-cyan-400 hover:text-cyan-300 underline transition-colors cursor-pointer"
                >
                  สมัครสมาชิก
                </button>
              </p>
            ) : (
              <p>
                มีบัญชีอยู่แล้ว?{' '}
                <button
                  type="button"
                  onClick={() => {
                    playClick();
                    setMode('login');
                    setErrorMsg('');
                  }}
                  className="font-bold text-cyan-400 hover:text-cyan-300 underline transition-colors cursor-pointer"
                >
                  เข้าสู่ระบบ
                </button>
              </p>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
