'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '@/context/StoreContext';
import {
  User,
  Camera,
  Upload,
  Check,
  X,
  Sparkles,
  ShieldCheck,
  Wallet,
  AlertCircle,
  Loader2,
  RefreshCw,
  Image as ImageIcon
} from 'lucide-react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PRESET_AVATARS = [
  '/brand/logo.png',
  'https://api.dicebear.com/7.x/bottts/svg?seed=arx_cyber',
  'https://api.dicebear.com/7.x/bottts/svg?seed=arx_titan',
  'https://api.dicebear.com/7.x/bottts/svg?seed=arx_ghost',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Shadow',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Valkyrie',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Neo'
];

export default function ProfileModal({ isOpen, onClose }: ProfileModalProps) {
  const { user, siteContent, updateUserProfile, playClick, playSuccess, playError } = useStore();

  const storeLogo = siteContent?.branding?.logoUrl || '/brand/logo.png';
  const [username, setUsername] = useState('');
  const [avatar, setAvatar] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync state whenever modal opens or user changes
  useEffect(() => {
    if (user && isOpen) {
      setUsername(user.username || '');
      const eff = (!user.avatar || user.avatar === '/brand/logo.png' || user.avatar === '/brand/arx-default-logo.png' || user.avatar.includes('placeholder'))
        ? storeLogo
        : user.avatar;
      setAvatar(eff);
      setErrorMessage('');
    }
  }, [user, isOpen, storeLogo]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !user) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMessage('กรุณาเลือกไฟล์รูปภาพเท่านั้น (PNG, JPG, WEBP)');
      return;
    }

    if (file.size > 3 * 1024 * 1024) {
      setErrorMessage('ขนาดรูปภาพต้องไม่เกิน 3 MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setAvatar(reader.result);
        setErrorMessage('');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const cleanUsername = username.trim();
    if (!cleanUsername) {
      setErrorMessage('กรุณากรอกชื่อผู้ใช้');
      playError();
      return;
    }

    if (cleanUsername.length < 3 || cleanUsername.length > 25) {
      setErrorMessage('ชื่อผู้ใช้ต้องมีความยาว 3 - 25 ตัวอักษร');
      playError();
      return;
    }

    setIsSaving(true);
    try {
      const res = await updateUserProfile({
        username: cleanUsername,
        avatar: avatar.trim() || undefined
      });

      if (res.success) {
        playSuccess();
        onClose();
      } else {
        setErrorMessage(res.message || 'บันทึกไม่สำเร็จ');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'เกิดข้อผิดพลาดในการบันทึกข้อมูล');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity"
        onClick={() => {
          playClick();
          onClose();
        }}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-md bg-[color:var(--arx-dk-0a0c12)] border border-cyan-500/30 rounded-2xl shadow-[0_0_50px_rgba(var(--theme-accent-rgb),0.25)] overflow-hidden z-10 flex flex-col">
        {/* Glow header bar */}
        <div className="h-1 w-full bg-gradient-to-r from-cyan-400 via-[var(--theme-accent)] to-cyan-500" />

        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10 bg-white/[0.02]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shadow-[0_0_12px_rgba(var(--theme-accent-rgb),0.2)]">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-wide">
                จัดการข้อมูลโปรไฟล์
              </h2>
              <span className="text-[11px] text-slate-400 block leading-tight">
                เปลี่ยนรูปโปรไฟล์และชื่อผู้ใช้
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* User Status / Role Pill */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-[color:var(--arx-dk-0e121e)] border border-white/5">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">สถานะบัญชี:</span>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-cyan-950/50 text-cyan-300 border border-cyan-500/30">
                {user.role === 'admin' ? (
                  <>
                    <ShieldCheck className="w-3 h-3 text-cyan-400" />
                    <span>ADMIN</span>
                  </>
                ) : (
                  <span>MEMBER</span>
                )}
              </span>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-slate-300">
              <Wallet className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-mono font-bold text-cyan-300">
                {user.balance.toFixed(2)} ฿
              </span>
            </div>
          </div>

          {/* Avatar Section */}
          <div className="flex flex-col items-center justify-center space-y-3 pt-1">
            <div className="relative group">
              <div className="w-20 h-20 rounded-2xl bg-cyan-950/40 border-2 border-cyan-500/50 overflow-hidden shadow-[0_0_25px_rgba(var(--theme-accent-rgb),0.3)] flex items-center justify-center">
                {avatar ? (
                  <img
                    key={avatar}
                    src={avatar}
                    alt="Preview avatar"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = storeLogo;
                    }}
                  />
                ) : (
                  <User className="w-10 h-10 text-cyan-400" />
                )}
              </div>

              {/* Upload trigger overlay button */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 rounded-2xl bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-cyan-300 text-[10px] font-bold cursor-pointer"
                title="คลิกเพื่ออัปโหลดรูป"
              >
                <Camera className="w-5 h-5 mb-0.5" />
                <span>เปลี่ยนรูป</span>
              </button>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              onChange={handleFileUpload}
              className="hidden"
            />

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5 text-cyan-400" />
                <span>อัปโหลดรูปจากเครื่อง</span>
              </button>
            </div>

            {/* Preset Avatars Chips */}
            <div className="w-full">
              <span className="text-[11px] text-slate-400 block mb-1.5 text-center">
                หรือเลือกรูปภาพแนะนำ:
              </span>
              <div className="flex items-center justify-center gap-2 flex-wrap">
                {PRESET_AVATARS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      playClick();
                      setAvatar(preset);
                    }}
                    className={`w-9 h-9 rounded-xl border p-0.5 overflow-hidden transition-all cursor-pointer ${
                      avatar === preset
                        ? 'border-cyan-400 ring-2 ring-cyan-500/50 scale-105 shadow-[0_0_12px_rgba(var(--theme-accent-rgb),0.4)]'
                        : 'border-white/10 hover:border-cyan-500/40 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={preset}
                      alt={`Preset ${idx}`}
                      className="w-full h-full object-cover rounded-lg"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Avatar URL Input */}
            <div className="w-full space-y-1">
              <label className="text-[11px] text-slate-400 font-medium block">
                ลิงก์รูปภาพ (Image URL)
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={avatar.startsWith('data:') ? 'รูปภาพที่อัปโหลดจากไฟล์ (Base64)' : avatar}
                  onChange={(e) => setAvatar(e.target.value)}
                  placeholder="https://example.com/avatar.png"
                  disabled={avatar.startsWith('data:')}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-colors"
                />
                {avatar.startsWith('data:') && (
                  <button
                    type="button"
                    onClick={() => setAvatar('')}
                    className="absolute right-2 top-2 text-[10px] text-rose-400 hover:underline cursor-pointer"
                  >
                    รีเซ็ต
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Username Section */}
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-white flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-cyan-400" />
                <span>ชื่อผู้ใช้ (Username)</span>
              </label>
              <span className="text-[10px] text-slate-400">
                {username.length}/25 ตัวอักษร
              </span>
            </div>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="กรอกชื่อผู้ใช้..."
              maxLength={25}
              className="w-full px-3.5 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white text-xs sm:text-sm placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-colors font-semibold"
            />
            <p className="text-[10.5px] text-slate-400">
              ชื่อผู้ใช้จะแสดงผลในแถบผู้ใช้และประวัติการสั่งซื้อ
            </p>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2.5 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={() => {
                playClick();
                onClose();
              }}
              disabled={isSaving}
              className="py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
            >
              ยกเลิก
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 via-[var(--theme-accent)] to-cyan-500 hover:brightness-110 text-slate-950 text-xs font-black shadow-[0_0_20px_rgba(var(--theme-accent-rgb),0.4)] flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>กำลังบันทึก...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>บันทึกข้อมูล</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
