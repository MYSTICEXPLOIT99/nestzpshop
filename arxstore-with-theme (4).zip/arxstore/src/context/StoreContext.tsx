'use client';

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  Product,
  Category,
  User,
  Order,
  TopupTransaction,
  HwidResetRecord,
  ServiceStatusItem,
  Announcement,
  HeroSlide,
  SiteStats,
  RealSiteStats,
  SlipApiConfig,
  DiscordWebhookSettings,
  WebhookLogItem,
  ProductStatus,
  ProductPackage,
  ServiceHealthStatus,
  DigitalStockItem,
  BgmSettings,
  WelcomeBannerSettings,
  SiteContent
} from '@/types';
import {
  INITIAL_CATEGORIES,
  INITIAL_PRODUCTS,
  INITIAL_SERVICE_STATUSES,
  INITIAL_ANNOUNCEMENTS,
  DEMO_USERS
} from '@/lib/data';
import { sound } from '@/lib/sound';
import { Language, TranslationKey, getTranslation } from '@/lib/i18n';
import { getClientDeviceInfo } from '@/lib/device';

export const DEFAULT_SLIDES: HeroSlide[] = [
  {
    id: 'slide-arx-brand',
    badge: 'ARX OFFICIAL',
    badgeColor: 'border-cyan-500/40 text-cyan-400 bg-cyan-500/10',
    title: 'ARX STORE',
    subtitle: [
      'PROGRAM / SETTING',
      'VALORANT / BOOST FPS',
      'จำหน่ายสินค้าราคาถูก'
    ],
    description: 'WEBSITE : arxstore.com',
    ctaText: 'SHOP CLICK',
    ctaAction: 'all',
    accentColor: '#00e5ff',
    image: '',
    theme: 'arx-brand',
    isActive: true
  },
  {
    id: 'slide-fivem',
    badge: 'TOP SELLER',
    badgeColor: 'border-emerald-500/40 text-emerald-400 bg-emerald-500/10',
    title: 'Setting Product',
    subtitle: [
      'FULL SYSTEM / AIMBOT / ESP',
      'BYPASS & SPOOFER HWID',
      'อัปเดตแพตช์ 2026 พร้อมใช้งาน'
    ],
    description: 'ปลดแบน FiveM ผ่าน 100% · ปลอดภัย ไม่โดนแบน',
    ctaText: 'EXPLORE SETTING',
    ctaAction: 'cat-fivem',
    accentColor: '#10b981',
    image: '/catalog/imported/banner_fivem.webp',
    theme: 'fivem',
    isActive: true
  },
  {
    id: 'slide-windows',
    badge: 'PRO PERFORMANCE',
    badgeColor: 'border-blue-500/40 text-blue-400 bg-blue-500/10',
    title: 'BoostFPS & CustomOS',
    subtitle: [
      'OPTIMIZATION / LOW LATENCY',
      'CUSTOM REGISTRY & DRIVERS',
      'เพิ่มเฟรมเรท ลดดีเลย์ขั้นสุด'
    ],
    description: 'บริการจำหน่าย Setting , BoostFPS , Windows ต่างๆ โดย ARX STORE',
    ctaText: 'GET BOOSTED',
    ctaAction: 'cat-cheat',
    accentColor: '#38bdf8',
    image: '/catalog/imported/banner_cheat.webp',
    theme: 'windows',
    isActive: true
  }
];

export const DEFAULT_SITE_STATS: SiteStats = {
  users: 0,
  topup: 0,
  stock: 0,
  sales: 0,
  isCustom: false,
  mode: 'direct'
};

export const DEFAULT_SLIP_CONFIG: SlipApiConfig = {
  provider: 'slipok',
  apiKey: '',
  branchId: '',
  promptPayNumber: '5160906053',
  accountName: 'ณัฐพงศ์ แซ่หลู่',
  bankName: 'กสิกรไทย (KBANK / K+)',
  trueMoneyPhone: '098-XXX-XXXX',
  autoApprove: true,
  channelPromptPayEnabled: true,
  channelBankTransferEnabled: true,
  channelAngpaoEnabled: true,
  channelTrueMoneyWalletEnabled: true,
  angpaoFeePercent: 2.9
};

export const DEFAULT_WEBHOOK_SETTINGS: DiscordWebhookSettings = {
  registerEnabled: true,
  registerUrl: '',
  topupEnabled: true,
  topupUrl: '',
  orderEnabled: true,
  orderUrl: '',
  stockEnabled: true,
  stockUrl: '',
  botName: 'ARX STORE BOT',
  botAvatarUrl: 'https://files.catbox.moe/haszlm.png'
};

export const DEFAULT_BGM_SETTINGS: BgmSettings = {
  enabled: true,
  title: '9tokyo - สายไป feat. BLVCKHEART (Official Music Video)',
  subtitle: '9tokyo',
  url: 'https://www.youtube.com/watch?v=j1qw79H4eHU',
  volume: 50,
  autoplay: true,
  loop: true,
  showVisualizer: true,
  position: 'bottom-left'
};

export const DEFAULT_WELCOME_BANNER: WelcomeBannerSettings = {
  enabled: true,
  titlePrefix: 'ยินดีต้อนรับสู่ร้าน',
  titleHighlight: 'ARXSTORE.XYZ',
  highlightColor: '#00e5ff',
  description: 'ร้านบริการจำหน่ายโปรแกรมช่วยเล่น Fivem / ปลดแบนFivem ราคาถูกและปลอดภัยต่อผู้ใช้ ตอบโจทย์ทุกการใช้งาน ต่างๆ ไม่ว่าจะเป็นโปรแกรม External / Unban / Internal / CMD',
  button1Text: 'ซื้อเลย',
  button1Link: '#products-catalog',
  button2Text: 'วิธีใช้งาน',
  button2Link: '/how-to'
};

export const DEFAULT_SITE_CONTENT: SiteContent = {
  branding: {
    siteName: 'ARX STORE',
    siteTitle: 'ARX STORE | บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ',
    slogan: 'บริการจำหน่าย Setting, BoostFPS, Windows ต่างๆ ซื้อขายระบบอัตโนมัติ 24 ชม.',
    logoUrl: '/brand/logo.png',
    faviconUrl: '/icon.png'
  },
  stepsSection: {
    subtitle: 'ขั้นตอน',
    title: 'ซื้อยังไง',
    steps: [
      { number: '01', title: 'เลือกสินค้า', description: 'ดูรายละเอียดและจำนวนคงเหลือก่อนซื้อสินค้า' },
      { number: '02', title: 'ชำระเงิน', description: 'มีเครดิตกดจ่ายได้เลย ไม่มีก็เติมเข้าบัญชีก่อน' },
      { number: '03', title: 'รับสินค้า', description: 'ข้อมูลขึ้นบนหน้าเว็บและส่งเข้าอีเมล เปิดดูย้อนหลังได้' },
      { number: '04', title: 'มีปัญหา ทักเลย', description: 'แจ้งเคลมเองได้จากหน้าคำสั่งซื้อภายในเวลารับประกัน' }
    ]
  },
  faqSection: {
    subtitle: 'คำถามที่พบบ่อย',
    title: 'สงสัยอะไรไหม',
    faqs: [
      { id: 'faq-1', question: 'ต้องสมัครสมาชิกไหม', answer: 'สมัครสมาชิกง่ายๆ เพียงกรอกชื่อผู้ใช้และรหัสผ่าน ไม่จำเป็นต้องใช้อีเมลจริง เพื่อเก็บประวัติการสั่งซื้อ ดูรหัสคีย์ย้อนหลังได้ตลอดเวลา' },
      { id: 'faq-2', question: 'ได้ของเมื่อไหร่', answer: 'ได้รับสินค้าทันทีหลังชำระเงินเสร็จสิ้น ระบบทำงานจัดส่งอัตโนมัติ 24 ชม. ข้อมูลจะแสดงบนหน้าจอและบันทึกลงบัญชีของคุณทันที' },
      { id: 'faq-3', question: 'ถ้าสินค้าใช้ไม่ได้ทำยังไง', answer: 'สินค้าทุกตัวมีคลิปสอนและวิธีใช้งานอย่างละเอียด หากติดขัดสามารถกดปุ่มติดต่อเพื่อส่งข้อความให้แอดมินช่วยตรวจสอบและเคลมสินค้าได้ตลอดเวลา' },
      { id: 'faq-4', question: 'เติมเงินได้ทางไหนบ้าง', answer: 'รองรับระบบสแกน QR Code พร้อมเพย์ และ TrueMoney Wallet ยอดเงินเข้าบัญชีอัตโนมัติทันที สะดวก ปลอดภัย 100%' }
    ]
  },
  contactModal: {
    title: 'ARX STORE',
    subtitle: 'ช่องทางติดต่อและติดตามเรา',
    channels: [
      { id: 'facebook', platform: 'facebook', label: 'Facebook', url: '#', color: '#1877F2', enabled: true },
      { id: 'discord', platform: 'discord', label: 'Discord', url: '#', color: '#5865F2', enabled: true },
      { id: 'instagram', platform: 'instagram', label: 'Instagram', url: '#', color: '#E1306C', enabled: true }
    ]
  },
  footer: {
    description: 'ซื้อไปแล้วกลัวใช้ไม่ได้? ไม่ต้องกังวลครับ ทุกโปรแกรมมีคลิปสอนให้ ใช้งานง่ายไม่ต้องเซ็ตเอง พร้อมแลกและมีแอดมินคอยให้คำปรึกษาตลอดการใช้งาน',
    reportText: 'ติดต่อร้านค้าไม่ได้ หรือต้องการรายงานปัญหาร้านค้าขี้โกง? แจ้งเรื่องกับทีมงานกลาง',
    reportUrl: '#',
    copyright: '© 2026 ARX STORE',
    currencyNote: 'ราคาทั้งหมดเป็นเงินบาท'
  }
};



export interface ToastMessage {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'purchase' | 'error';
  avatar?: string;
  timeAgo?: string;
  productName?: string;
  productImage?: string;
  packageName?: string;
  price?: number;
  dateStr?: string;
  username?: string;
}

interface StoreContextType {
  user: User | null;
  users: User[];
  isHydrated: boolean;
  isSoundEnabled: boolean;
  toggleSound: () => void;
  playClick: () => void;
  playSuccess: () => void;
  playError: () => void;

  // Language & i18n
  lang: Language;
  setLang: (lang: Language) => void;
  toggleLang: () => void;
  t: (key: TranslationKey) => string;

  // Theme & Global Search
  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;
  toggleTheme: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  products: Product[];
  categories: Category[];
  serviceStatuses: ServiceStatusItem[];
  orders: Order[];
  topups: TopupTransaction[];
  hwidRecords: HwidResetRecord[];
  announcements: Announcement[];

  // Auth
  login: (username: string, pass?: string) => Promise<{ success: boolean; message: string }>;
  logout: () => void;
  register: (username: string, pass?: string, email?: string) => Promise<{ success: boolean; message: string }>;
  switchUser: (role: 'user' | 'admin') => void;
  updateUserProfile: (data: { username?: string; avatar?: string }) => Promise<{ success: boolean; message: string }>;

  // Modals
  isBuyModalOpen: boolean;
  selectedProduct: Product | null;
  openBuyModal: (product: Product) => void;
  closeBuyModal: () => void;

  isAuthModalOpen: boolean;
  authModalMode: 'login' | 'register';
  openAuthModal: (mode?: 'login' | 'register') => void;
  closeAuthModal: () => void;

  isCookieModalOpen: boolean;
  cookieConsentGiven: boolean;
  acceptAllCookies: () => void;
  closeCookieModal: () => void;

  // Actions
  purchasePackage: (productId: string, packageId: string, couponCode?: string) => Promise<{ success: boolean; message: string; order?: Order }>;
  topupAngpao: (voucherUrl: string, amount?: number) => Promise<{ success: boolean; amount: number; message: string }>;
  topupSlip: (amount?: number, senderName?: string, bank?: string, slipBase64?: string) => Promise<{ success: boolean; message: string; amount?: number }>;
  requestHwidReset: (productId: string, licenseKey: string) => Promise<{ success: boolean; message: string; wasFree: boolean }>;

  // Hero Slides
  slides: HeroSlide[];
  heroSliderEnabled: boolean;
  toggleHeroSlider: (enabled?: boolean) => void;
  updateSlide: (id: string, slide: Partial<HeroSlide>) => void;
  addSlide: (slide: Omit<HeroSlide, 'id'>) => void;
  deleteSlide: (id: string) => void;
  moveSlide: (slideId: string, direction: 'up' | 'down') => void;

  // Hero Welcome Banner (ข้อความต้อนรับด้านบนภาพสไลด์)
  welcomeBanner: WelcomeBannerSettings;
  updateWelcomeBanner: (updates: Partial<WelcomeBannerSettings>) => Promise<boolean>;


  // Recent Purchases Feed (แถบประวัติการสั่งซื้อล่าสุดหน้าหลัก)
  recentOrdersFeedEnabled: boolean;
  toggleRecentOrdersFeed: (enabled?: boolean) => void;

  // Site Stats (ระบบปลอมยอด / กำหนดสถิติหน้าเว็บ)
  siteStats: SiteStats;
  displayStats: SiteStats;
  realStats: RealSiteStats;
  updateSiteStats: (stats: Partial<SiteStats>, silent?: boolean) => void;

  // Slip API Config (เชื่อมต่อระบบตรวจสอบสลิป)
  slipConfig: SlipApiConfig;
  updateSlipConfig: (config: Partial<SlipApiConfig>) => void;

  // Discord Webhook Settings (ระบบส่ง Log เข้า Discord)
  webhookSettings: DiscordWebhookSettings;
  updateWebhookSettings: (settings: Partial<DiscordWebhookSettings>, silent?: boolean) => void;
  webhookLogs: WebhookLogItem[];
  testDiscordWebhook: (type: 'register' | 'topup_bank' | 'topup_truemoney' | 'order' | 'stock', customUrl?: string) => Promise<{ success: boolean; message: string }>;
  clearWebhookLogs: () => void;

  // Background Music (ระบบเพลงพื้นหลัง BGM)
  bgmSettings: BgmSettings;
  updateBgmSettings: (settings: Partial<BgmSettings>, silent?: boolean) => void;

  // Site Content & FAQ & Contact Modal
  siteContent: SiteContent;
  updateSiteContent: (updates: Partial<SiteContent>) => Promise<boolean>;
  isContactModalOpen: boolean;
  openContactModal: () => void;
  closeContactModal: () => void;

  // Admin Actions
  updateServiceStatus: (id: string, newStatus: 'online' | 'updating' | 'maintenance') => void;
  approveTopup: (id: string) => void;
  rejectTopup: (id: string) => void;
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  applyGlobalPromotion: (discountPercent: number, badgeText?: string, categoryId?: string) => void;
  clearGlobalPromotion: (categoryId?: string) => void;
  updateProductPackages: (productId: string, packages: ProductPackage[]) => void;
  updateProductStatus: (productId: string, status: ProductStatus, note?: string) => void;
  updateProductStatusNote: (productId: string, note: string) => void;
  moveProduct: (productId: string, direction: 'up' | 'down', categoryFilter?: string) => void;
  reorderProducts: (newProducts: Product[]) => void;
  moveCategory: (categoryId: string, direction: 'up' | 'down') => void;
  reorderCategories: (newCategories: Category[]) => void;
  updateCategory: (id: string, updated: Partial<Category>) => void;
  deleteCategory: (id: string) => void;
  addCategory: (category: Category) => void;
  restoreDefaultCatalog: () => void;

  // Digital Stock Management (จัดการสต็อก: คีย์, ลิงก์ดาวน์โหลด, ไฟล์, บัญชี/หมายเหตุ)
  addStockItem: (productId: string, packageId: string, item: Omit<DigitalStockItem, 'id' | 'createdAt'>) => void;
  addBulkStockItems: (productId: string, packageId: string, items: Array<Omit<DigitalStockItem, 'id' | 'createdAt'>>) => void;
  deleteStockItem: (productId: string, packageId: string, itemId: string) => void;
  clearSoldStockItems: (productId: string, packageId: string) => void;
  updatePackageStockItems: (productId: string, packageId: string, items: DigitalStockItem[]) => void;

  // User Management (จัดการผู้ใช้งาน: ชื่อ, รูป, ยอดเงิน, สินค้า)
  refreshUsers: () => Promise<void>;
  adminUpdateUser: (userId: string, data: Partial<User>) => Promise<void>;
  adminAddUserProduct: (userId: string, productId: string, packageId: string, customKey?: string) => void;
  adminUpdateUserOrder: (orderId: string, data: Partial<Order>) => void;
  adminDeleteUserOrder: (orderId: string) => void;
  adminDeleteUser: (userId: string) => Promise<void>;
  adminCreateUser: (userData: Partial<User>) => Promise<User>;

// Toast
  toasts: ToastMessage[];
  showToast: (toast: Omit<ToastMessage, 'id'>) => void;
  removeToast: (id: string) => void;
}

// Synchronize and auto-generate digital stock keys if a package has stock > 0 but missing stockItems
export const syncStockItemsForProducts = (prods: Product[]): Product[] => {
  const nowStr = new Date().toLocaleString('th-TH');
  return prods.map(p => {
    const nextPackages = p.packages.map(pkg => {
      let currentItems: DigitalStockItem[] = Array.isArray(pkg.stockItems) ? [...pkg.stockItems] : [];
      const unusedCount = currentItems.filter(s => !s.isUsed).length;
      const targetStock = typeof pkg.stock === 'number' ? pkg.stock : 0;

      if (targetStock > unusedCount) {
        const needed = targetStock - unusedCount;
        for (let i = 0; i < needed; i++) {
          const randChunk = () => Math.random().toString(36).substring(2, 6).toUpperCase();
          const cleanProdName = (p.name || 'ARX_PRODUCT').replace(/[^a-zA-Z0-9ก-๙]/g, '_');
          const cleanPkgDuration = (pkg.duration || 'Package').replace(/[^a-zA-Z0-9ก-๙]/g, '_');
          currentItems.push({
            id: 'stk-' + Date.now() + '-' + i + '-' + Math.random().toString(36).substring(2, 6),
            key: `ARX-${randChunk()}-${randChunk()}-${randChunk()}`,
            downloadUrl: p.downloadUrl || 'https://cdn.arxstore.com/download/latest.zip',
            fileName: `${cleanProdName}_${cleanPkgDuration}.zip`,
            note: 'คลังสินค้าพร้อมส่ง (Real-time Key)',
            isUsed: false,
            createdAt: nowStr
          });
        }
      }

      const finalAvailable = currentItems.filter(s => !s.isUsed).length;
      return {
        ...pkg,
        stockItems: currentItems,
        stock: finalAvailable,
        inStock: finalAvailable > 0
      };
    });

    return { ...p, packages: nextPackages };
  });
};

const StoreContext = createContext<StoreContextType | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  // Safe initial state: guest visitor (authenticated via server session on mount)
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(DEMO_USERS);
  const [isHydrated, setIsHydrated] = useState<boolean>(false);
  const [products, setProducts] = useState<Product[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const rawDel = localStorage.getItem('arx_deleted_product_ids');
        const deletedIds: string[] = rawDel ? JSON.parse(rawDel) : [];
        const saved = localStorage.getItem('arx_products');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            return syncStockItemsForProducts(parsed.filter((p: Product) => !deletedIds.includes(p.id)));
          }
        }
        return syncStockItemsForProducts(INITIAL_PRODUCTS.filter((p: Product) => !deletedIds.includes(p.id)));
      } catch (e) {
        console.error('Error initializing products from localStorage:', e);
      }
    }
    return syncStockItemsForProducts(INITIAL_PRODUCTS);
  });
  const [categories, setCategories] = useState<Category[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const rawDel = localStorage.getItem('arx_deleted_category_ids');
        const deletedIds: string[] = rawDel ? JSON.parse(rawDel) : [];
        const saved = localStorage.getItem('arx_categories');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            return parsed.filter((c: Category) => !deletedIds.includes(c.id));
          }
        }
        return INITIAL_CATEGORIES.filter((c: Category) => !deletedIds.includes(c.id));
      } catch {}
    }
    return INITIAL_CATEGORIES;
  });
  const [serviceStatuses, setServiceStatuses] = useState<ServiceStatusItem[]>(INITIAL_SERVICE_STATUSES);
  const [announcements, setAnnouncements] = useState<Announcement[]>(INITIAL_ANNOUNCEMENTS);
  const [orders, setOrders] = useState<Order[]>([]);
  const [topups, setTopups] = useState<TopupTransaction[]>([]);
  const [hwidRecords, setHwidRecords] = useState<HwidResetRecord[]>([]);

  // Hero Slides, Site Stats & Slip API Configuration
  const [slides, setSlides] = useState<HeroSlide[]>(DEFAULT_SLIDES);
  const [heroSliderEnabled, setHeroSliderEnabled] = useState<boolean>(true);
  const [welcomeBanner, setWelcomeBanner] = useState<WelcomeBannerSettings>(DEFAULT_WELCOME_BANNER);
  const [recentOrdersFeedEnabled, setRecentOrdersFeedEnabled] = useState<boolean>(true);
  const [siteStats, setSiteStats] = useState<SiteStats>(DEFAULT_SITE_STATS);

  // 1. Calculate Real Site Statistics from actual users, topups, products, and orders
  const realStats: RealSiteStats = useMemo(() => {
    const realUsers = users.length;
    const realTopup = topups.reduce((sum, t) => {
      if (t.status === 'approved') return sum + t.amount;
      return sum;
    }, 0);
    const realStock = products.reduce((acc, p) => acc + p.packages.reduce((pAcc, pkg) => {
      const avail = pkg.stockItems ? pkg.stockItems.filter(s => !s.isUsed).length : (pkg.inStock ? pkg.stock : 0);
      return pAcc + (avail > 0 ? avail : 0);
    }, 0), 0);
    const realSales = orders.length;

    return {
      users: realUsers,
      topup: realTopup,
      stock: realStock,
      sales: realSales
    };
  }, [users, topups, products, orders]);

  // 2. Final Displayed Site Statistics (Direct Display Mode, Boost Mode, or 100% Real Stats)
  const displayStats: SiteStats = useMemo(() => {
    if (!siteStats?.isCustom) {
      return {
        users: realStats.users,
        topup: realStats.topup,
        stock: realStats.stock,
        sales: realStats.sales,
        isCustom: false,
        mode: siteStats?.mode || 'direct'
      };
    }

    const isBoost = siteStats?.mode === 'boost';
    const sUsers = Number(siteStats?.users) || 0;
    const sTopup = Number(siteStats?.topup) || 0;
    const sStock = Number(siteStats?.stock) || 0;
    const sSales = Number(siteStats?.sales) || 0;

    if (isBoost) {
      return {
        users: realStats.users + sUsers,
        topup: realStats.topup + sTopup,
        stock: realStats.stock + sStock,
        sales: realStats.sales + sSales,
        isCustom: true,
        mode: 'boost'
      };
    }

    // Direct mode: The configured numbers are exactly what will be displayed on the website
    return {
      users: sUsers,
      topup: sTopup,
      stock: sStock,
      sales: sSales,
      isCustom: true,
      mode: 'direct'
    };
  }, [realStats, siteStats]);

  const [slipConfig, setSlipConfig] = useState<SlipApiConfig>(DEFAULT_SLIP_CONFIG);
  const [webhookSettings, setWebhookSettings] = useState<DiscordWebhookSettings>(DEFAULT_WEBHOOK_SETTINGS);
  const [webhookLogs, setWebhookLogs] = useState<WebhookLogItem[]>([]);
  const [bgmSettings, setBgmSettings] = useState<BgmSettings>(DEFAULT_BGM_SETTINGS);
  const [siteContent, setSiteContent] = useState<SiteContent>(DEFAULT_SITE_CONTENT);
  const [isContactModalOpen, setIsContactModalOpen] = useState<boolean>(false);

  const openContactModal = useCallback(() => setIsContactModalOpen(true), []);
  const closeContactModal = useCallback(() => setIsContactModalOpen(false), []);

  // Preferences & Modals
  const [isSoundEnabled, setIsSoundEnabled] = useState<boolean>(true);
  const [isBuyModalOpen, setIsBuyModalOpen] = useState<boolean>(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');
  const [isCookieModalOpen, setIsCookieModalOpen] = useState<boolean>(false);
  const [cookieConsentGiven, setCookieConsentGiven] = useState<boolean>(true);

  // Hydrate from localStorage on client
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      // 1. Read deleted IDs so they are permanently excluded from ever reviving
      let deletedProductIds: string[] = [];
      try {
        const raw = localStorage.getItem('arx_deleted_product_ids');
        if (raw) deletedProductIds = JSON.parse(raw);
      } catch {}

      let deletedCategoryIds: string[] = [];
      try {
        const raw = localStorage.getItem('arx_deleted_category_ids');
        if (raw) deletedCategoryIds = JSON.parse(raw);
      } catch {}

      let deletedSlideIds: string[] = [];
      try {
        const raw = localStorage.getItem('arx_deleted_slide_ids');
        if (raw) deletedSlideIds = JSON.parse(raw);
      } catch {}

      let deletedServiceIds: string[] = [];
      try {
        const raw = localStorage.getItem('arx_deleted_service_ids');
        if (raw) deletedServiceIds = JSON.parse(raw);
      } catch {}

      // 2. Hydrate Products (Respect user deletions - NEVER re-inject deleted products)
      const savedProducts = localStorage.getItem('arx_products');
      if (savedProducts !== null) {
        try {
          let parsed: Product[] = JSON.parse(savedProducts);
          if (Array.isArray(parsed)) {
            // Exclude any product ID that was explicitly deleted
            parsed = parsed.filter((p: Product) => !deletedProductIds.includes(p.id));
            parsed = parsed.map((p: Product) => {
              let badge = p.badge;
              if (badge === 'สินค้าหมด') badge = 'OUT OF STOCK';
              if (p.categoryId === 'cat-fivem') return { ...p, categoryName: 'Setting Product', badge };
              if (p.categoryId === 'cat-cheat') return { ...p, categoryName: 'BoostFPS Product', badge };
              return { ...p, badge };
            });
            parsed = syncStockItemsForProducts(parsed);
            setProducts(parsed);
            localStorage.setItem('arx_products', JSON.stringify(parsed));
          }
        } catch (e) {
          console.error('Error parsing saved products:', e);
        }
      } else {
        const initial = INITIAL_PRODUCTS.filter(p => !deletedProductIds.includes(p.id));
        const synced = syncStockItemsForProducts(initial);
        setProducts(synced);
        localStorage.setItem('arx_products', JSON.stringify(synced));
      }

      // Sync with server disk catalog via /api/products
      fetch('/api/products', { cache: 'no-store' })
        .then(res => res.json())
        .then(res => {
          if (res && res.success && Array.isArray(res.data)) {
            const serverDelIds: string[] = Array.isArray(res.deletedProductIds) ? res.deletedProductIds : [];
            const mergedDelIds = Array.from(new Set([...deletedProductIds, ...serverDelIds]));
            if (mergedDelIds.length > deletedProductIds.length) {
              localStorage.setItem('arx_deleted_product_ids', JSON.stringify(mergedDelIds));
            }
            const validServerProducts = (res.data as Product[]).filter((p: Product) => !mergedDelIds.includes(p.id));
            const synced = syncStockItemsForProducts(validServerProducts);
            setProducts(synced);
            localStorage.setItem('arx_products', JSON.stringify(synced));
          }
        })
        .catch(() => {});


      // 3. Hydrate Slides (Respect user deletions)
      const savedSlides = localStorage.getItem('arx_slides');
      if (savedSlides !== null) {
        try {
          let parsedSlides: HeroSlide[] = JSON.parse(savedSlides);
          if (Array.isArray(parsedSlides)) {
            parsedSlides = parsedSlides.filter(s => !deletedSlideIds.includes(s.id));
            parsedSlides = parsedSlides.map((s: HeroSlide) => {
              if (s.id === 'slide-arx-brand') {
                const img = (s.image === '/catalog/imported/banner_fivem.webp') ? '' : (s.image || '');
                return { ...s, image: img };
              }
              let img = s.image;
              if (!img) {
                if (s.id === 'slide-fivem') img = '/catalog/imported/banner_fivem.webp';
                else if (s.id === 'slide-windows') img = '/catalog/imported/banner_cheat.webp';
                else img = '/catalog/imported/banner_fivem.webp';
              }
              if (s.title === 'FIVEM PROJECT') {
                return { ...s, image: img, title: 'Setting Product', ctaText: 'EXPLORE SETTING' };
              }
              if (s.id === 'slide-windows' && s.title === 'WINDOWS & BOOST FPS') {
                return { ...s, image: img, title: 'BoostFPS & CustomOS' };
              }
              return { ...s, image: img };
            });
            setSlides(parsedSlides);
            localStorage.setItem('arx_slides', JSON.stringify(parsedSlides));
          }
        } catch {}
      } else {
        const initialSlides = DEFAULT_SLIDES.filter(s => !deletedSlideIds.includes(s.id));
        setSlides(initialSlides);
        localStorage.setItem('arx_slides', JSON.stringify(initialSlides));
      }

      const savedSliderEnabled = localStorage.getItem('arx_hero_slider_enabled');
      if (savedSliderEnabled !== null) {
        setHeroSliderEnabled(savedSliderEnabled === 'true');
      }

      // Hydrate Welcome Banner
      const savedWelcomeBanner = localStorage.getItem('arx_welcome_banner');
      if (savedWelcomeBanner) {
        try {
          const parsed = JSON.parse(savedWelcomeBanner);
          if (parsed && typeof parsed === 'object') {
            setWelcomeBanner(prev => ({ ...prev, ...parsed }));
          }
        } catch {}
      }
      fetch('/api/welcome-banner')
        .then(res => res.json())
        .then(res => {
          if (res?.success && res?.data) {
            setWelcomeBanner(res.data);
            localStorage.setItem('arx_welcome_banner', JSON.stringify(res.data));
          }
        })
        .catch(() => {});


      const savedOrdersFeedEnabled = localStorage.getItem('arx_recent_orders_feed_enabled');
      if (savedOrdersFeedEnabled !== null) {
        setRecentOrdersFeedEnabled(savedOrdersFeedEnabled === 'true');
      }

      const savedSiteStats = localStorage.getItem('arx_site_stats');
      if (savedSiteStats) {
        try {
          const parsedStats = JSON.parse(savedSiteStats);
          if (parsedStats && typeof parsedStats === 'object') {
            setSiteStats({
              users: !isNaN(Number(parsedStats.users)) ? Number(parsedStats.users) : DEFAULT_SITE_STATS.users,
              topup: !isNaN(Number(parsedStats.topup)) ? Number(parsedStats.topup) : DEFAULT_SITE_STATS.topup,
              stock: !isNaN(Number(parsedStats.stock)) ? Number(parsedStats.stock) : DEFAULT_SITE_STATS.stock,
              sales: !isNaN(Number(parsedStats.sales)) ? Number(parsedStats.sales) : DEFAULT_SITE_STATS.sales,
              isCustom: typeof parsedStats.isCustom === 'boolean' ? parsedStats.isCustom : false,
              mode: parsedStats.mode === 'boost' ? 'boost' : 'direct'
            });
          }
        } catch {
          setSiteStats(DEFAULT_SITE_STATS);
        }
      }

      const savedSlipConfig = localStorage.getItem('arx_slip_config');
      if (savedSlipConfig) {
        try { setSlipConfig(prev => ({ ...prev, ...JSON.parse(savedSlipConfig) })); } catch {}
      }
      fetch('/api/slip-config', { cache: 'no-store' })
        .then(r => r.json())
        .then(d => {
          if (d?.success && d?.data) {
            setSlipConfig(prev => ({ ...prev, ...d.data }));
            localStorage.setItem('arx_slip_config', JSON.stringify(d.data));
          }
        })
        .catch(() => {});

      const savedWebhooks = localStorage.getItem('arx_webhook_settings');
      if (savedWebhooks) {
        const parsed = JSON.parse(savedWebhooks);
        if (parsed.botAvatarUrl && typeof parsed.botAvatarUrl === 'string') {
          let av = parsed.botAvatarUrl.trim();
          if (av.includes('83pZpGj.png') || !av) {
            av = 'https://files.catbox.moe/haszlm.png';
          } else {
            if (av.startsWith('//')) av = 'https:' + av;
            else if (!av.startsWith('http://') && !av.startsWith('https://')) av = 'https://' + av;
          }
          parsed.botAvatarUrl = av;
        } else {
          parsed.botAvatarUrl = 'https://files.catbox.moe/haszlm.png';
        }
        setWebhookSettings(prev => ({ ...prev, ...parsed }));
      }

      const savedWebhookLogs = localStorage.getItem('arx_webhook_logs');
      if (savedWebhookLogs) setWebhookLogs(JSON.parse(savedWebhookLogs));

      // 4. Hydrate Service Statuses (Remove deleted products & services)
      const savedStatuses = localStorage.getItem('arx_service_statuses');
      if (savedStatuses !== null) {
        try {
          let parsedStatuses: ServiceStatusItem[] = JSON.parse(savedStatuses);
          if (Array.isArray(parsedStatuses)) {
            parsedStatuses = parsedStatuses.filter((s: ServiceStatusItem) => {
              if (s.productId && deletedProductIds.includes(s.productId)) return false;
              if (deletedProductIds.includes(s.id.replace('srv-', ''))) return false;
              if (deletedServiceIds.includes(s.id)) return false;
              return true;
            });
            parsedStatuses = parsedStatuses.map((s: ServiceStatusItem) => {
              if (s.category === 'FIVEM PROJECT') return { ...s, category: 'Setting Product' };
              if (s.category === 'CHEAT GAME') return { ...s, category: 'BoostFPS Product' };
              return s;
            });
            setServiceStatuses(parsedStatuses);
            localStorage.setItem('arx_service_statuses', JSON.stringify(parsedStatuses));
          }
        } catch {}
      } else {
        const initialStatuses = INITIAL_SERVICE_STATUSES.filter(s => {
          if (s.productId && deletedProductIds.includes(s.productId)) return false;
          if (deletedProductIds.includes(s.id.replace('srv-', ''))) return false;
          if (deletedServiceIds.includes(s.id)) return false;
          return true;
        });
        setServiceStatuses(initialStatuses);
        localStorage.setItem('arx_service_statuses', JSON.stringify(initialStatuses));
      }

      // 5. Hydrate Categories (Respect user deletions - NEVER re-inject deleted categories)
      const savedCategories = localStorage.getItem('arx_categories');
      if (savedCategories !== null) {
        try {
          let parsedCats: Category[] = JSON.parse(savedCategories);
          if (Array.isArray(parsedCats)) {
            parsedCats = parsedCats.filter(c => !deletedCategoryIds.includes(c.id));
            setCategories(parsedCats);
            localStorage.setItem('arx_categories', JSON.stringify(parsedCats));
          }
        } catch {}
      } else {
        const initialCats = INITIAL_CATEGORIES.filter(c => !deletedCategoryIds.includes(c.id));
        setCategories(initialCats);
        localStorage.setItem('arx_categories', JSON.stringify(initialCats));
      }

      // Sync categories with server disk data
      fetch('/api/categories', { cache: 'no-store' })
        .then(res => res.json())
        .then(res => {
          if (res && res.success && Array.isArray(res.data)) {
            const serverDelCatIds: string[] = Array.isArray(res.deletedCategoryIds) ? res.deletedCategoryIds : [];
            const mergedDelCatIds = Array.from(new Set([...deletedCategoryIds, ...serverDelCatIds]));
            if (mergedDelCatIds.length > deletedCategoryIds.length) {
              localStorage.setItem('arx_deleted_category_ids', JSON.stringify(mergedDelCatIds));
            }
            const validCats = (res.data as Category[]).filter((c: Category) => !mergedDelCatIds.includes(c.id));
            setCategories(validCats);
            localStorage.setItem('arx_categories', JSON.stringify(validCats));
          }
        })
        .catch(() => {});


      const savedBgm = localStorage.getItem('arx_bgm_settings');
      if (savedBgm) {
        try {
          const parsed = JSON.parse(savedBgm);
          setBgmSettings(prev => ({ ...prev, ...parsed }));
        } catch {}
      }
      fetch('/api/bgm', { cache: 'no-store' })
        .then(res => res.json())
        .then(res => {
          if (res?.success && res?.data) {
            setBgmSettings(res.data);
            localStorage.setItem('arx_bgm_settings', JSON.stringify(res.data));
          }
        })
        .catch(() => {});

      const savedSiteContent = localStorage.getItem('arx_site_content');
      if (savedSiteContent) {
        try {
          const parsed = JSON.parse(savedSiteContent);
          setSiteContent(prev => ({ ...prev, ...parsed }));
        } catch {}
      }
      fetch('/api/site-content', { cache: 'no-store' })
        .then(res => res.json())
        .then(res => {
          if (res?.success && res?.data) {
            setSiteContent(res.data);
            localStorage.setItem('arx_site_content', JSON.stringify(res.data));
          }
        })
        .catch(() => {});
    } catch (e) {
      console.error('Error hydrating localStorage state in StoreContext:', e);
    }
  }, []);

  // Synchronize Site Stats and catalog across all open tabs and windows in real-time
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'arx_site_stats' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (parsed && typeof parsed === 'object') {
            setSiteStats({
              users: !isNaN(Number(parsed.users)) ? Number(parsed.users) : DEFAULT_SITE_STATS.users,
              topup: !isNaN(Number(parsed.topup)) ? Number(parsed.topup) : DEFAULT_SITE_STATS.topup,
              stock: !isNaN(Number(parsed.stock)) ? Number(parsed.stock) : DEFAULT_SITE_STATS.stock,
              sales: !isNaN(Number(parsed.sales)) ? Number(parsed.sales) : DEFAULT_SITE_STATS.sales,
              isCustom: true,
              mode: parsed.mode === 'boost' ? 'boost' : 'direct'
            });
          }
        } catch {}
      }
      if (e.key === 'arx_recent_orders_feed_enabled' && e.newValue !== null) {
        setRecentOrdersFeedEnabled(e.newValue === 'true');
      }
      if (e.key === 'arx_products' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (Array.isArray(parsed)) setProducts(parsed);
        } catch {}
      }
      if (e.key === 'arx_categories' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (Array.isArray(parsed)) setCategories(parsed);
        } catch {}
      }
      if (e.key === 'arx_slides' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (Array.isArray(parsed)) setSlides(parsed);
        } catch {}
      }
      if (e.key === 'arx_service_statuses' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (Array.isArray(parsed)) setServiceStatuses(parsed);
        } catch {}
      }
      if (e.key === 'arx_current_user') {
        if (!e.newValue) {
          setUser(null);
        } else {
          try { setUser(JSON.parse(e.newValue)); } catch {}
        }
      }
      if (e.key === 'arx_orders' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (Array.isArray(parsed)) setOrders(parsed);
        } catch {}
      }
      if (e.key === 'arx_session_token') {
        if (!e.newValue) {
          setUser(null);
          setOrders([]);
        } else {
          fetch('/api/auth', { headers: { 'x-session-token': e.newValue } })
            .then(r => r.json())
            .then(d => { if (d.authenticated && d.user) setUser(d.user); })
            .catch(() => {});
          fetch('/api/orders', { headers: { 'x-session-token': e.newValue } })
            .then(r => r.json())
            .then(d => { if (d.success && Array.isArray(d.data)) setOrders(d.data); })
            .catch(() => {});
        }
      }
    };

    let bc: BroadcastChannel | null = null;
    try {
      if ('BroadcastChannel' in window) {
        bc = new BroadcastChannel('arx_store_sync_channel');
        bc.onmessage = (event) => {
          const msg = event.data;
          if (!msg) return;
          if (msg.type === 'SYNC_ALL') {
            const token = localStorage.getItem('arx_session_token');
            if (token) {
              fetch('/api/auth', { headers: { 'x-session-token': token } })
                .then(r => r.json())
                .then(d => { if (d.authenticated && d.user) setUser(d.user); })
                .catch(() => {});
              fetch('/api/orders', { headers: { 'x-session-token': token } })
                .then(r => r.json())
                .then(d => { if (d.success && Array.isArray(d.data)) setOrders(d.data); })
                .catch(() => {});
            }
          } else if (msg.type === 'ORDER_CREATED') {
            if (msg.order) setOrders(prev => [msg.order, ...prev.filter(o => o.id !== msg.order.id)]);
            if (typeof msg.newBalance === 'number') {
              setUser(prev => prev ? { ...prev, balance: msg.newBalance } : null);
            }
          } else if (msg.type === 'USER_UPDATED') {
            if (msg.user) {
              setUsers(prev => prev.map(u => u.id === msg.userId ? { ...u, ...msg.user } : u));
              setUser(prev => {
                if (prev && prev.id === msg.userId) {
                  return { ...prev, ...msg.user };
                }
                return prev;
              });
            }
          } else if (msg.type === 'LOGOUT') {
            setUser(null);
            setOrders([]);
          } else if (msg.type === 'LOGIN' && msg.user) {
            setUser(msg.user);
          }
        };
      }
    } catch {}

    const handleCustomChange = (e: Event) => {
      const customEvent = e as CustomEvent<SiteStats>;
      if (customEvent.detail && typeof customEvent.detail === 'object') {
        setSiteStats(customEvent.detail);
      }
    };

    const handleFeedChange = (e: Event) => {
      const customEvent = e as CustomEvent<boolean>;
      if (typeof customEvent.detail === 'boolean') {
        setRecentOrdersFeedEnabled(customEvent.detail);
      }
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('arx:site_stats:change', handleCustomChange);
    window.addEventListener('arx:recent_orders_feed:change', handleFeedChange);

    return () => {
      if (bc) bc.close();
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('arx:site_stats:change', handleCustomChange);
      window.removeEventListener('arx:recent_orders_feed:change', handleFeedChange);
    };
  }, []);

  // Language State
  const [lang, setLangState] = useState<Language>('th');

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Sound triggers
  const playClick = useCallback(() => {
    sound.playKeyClick();
  }, []);

  const playSuccess = useCallback(() => {
    sound.playSuccessChime();
  }, []);

  const playError = useCallback(() => {
    sound.playErrorBuzz();
  }, []);

  // Global click sound: plays crisp mechanical keyboard sound on any interactive element click
  useEffect(() => {
    if (typeof window === 'undefined') return;
    sound.setEnabled(true);

    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;

      const clickable = target.closest(
        'a, button, input, select, textarea, [role="button"], [tabindex], .cursor-pointer, .store-home-category, label, summary'
      );
      if (clickable) {
        sound.playKeyClick();
      }
    };

    document.addEventListener('click', handleGlobalClick, { capture: true, passive: true });
    return () => document.removeEventListener('click', handleGlobalClick, { capture: true });
  }, []);

  const toggleSound = useCallback(() => {
    setIsSoundEnabled(true);
    sound.setEnabled(true);
  }, []);

  // Language helpers
  const setLang = useCallback((newLang: Language) => {
    setLangState(newLang);
    sound.playKeyClick();
    if (typeof window !== 'undefined') {
      localStorage.setItem('arx_lang', newLang);
    }
  }, []);

  const toggleLang = useCallback(() => {
    setLangState(prev => {
      const next = prev === 'th' ? 'en' : 'th';
      sound.playKeyClick();
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_lang', next);
      }
      return next;
    });
  }, []);

  const t = useCallback((key: TranslationKey) => {
    return getTranslation(key, lang);
  }, [lang]);

  // Show Toast Notification (Interactive Cyberpunk Toast System)
  const showToast = useCallback((t: Omit<ToastMessage, 'id'>) => {
    const id = 'toast-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7);
    const newToast: ToastMessage = { ...t, id };
    setToasts(prev => [newToast, ...prev.slice(0, 4)]);
    setTimeout(() => {
      setToasts(prev => prev.filter(item => item.id !== id));
    }, 4500);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(item => item.id !== id));
  }, []);

  // Persistent Save and Synchronize Products (Both client storage and server disk)
  const saveAndSyncProducts = useCallback((nextList: Product[], additionalDeletedId?: string) => {
    let currentDeletedIds: string[] = [];
    if (typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem('arx_deleted_product_ids');
        currentDeletedIds = raw ? JSON.parse(raw) : [];
        if (additionalDeletedId && !currentDeletedIds.includes(additionalDeletedId)) {
          currentDeletedIds.push(additionalDeletedId);
          localStorage.setItem('arx_deleted_product_ids', JSON.stringify(currentDeletedIds));
        }
      } catch {}
    }

    const filtered = nextList.filter(p => !currentDeletedIds.includes(p.id));
    const synced = syncStockItemsForProducts(filtered);

    // Synchronously write to localStorage
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('arx_products', JSON.stringify(synced));
      } catch {}
    }

    // Update state immediately
    setProducts(synced);

    // Persist to server disk via /api/products
    try {
      const token = typeof window !== 'undefined'
        ? (localStorage.getItem('arx_session_token') || localStorage.getItem('arx_admin_token'))
        : null;
      fetch('/api/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-session-token': token } : {}),
          'x-admin-key': 'arx_admin_secret_key'
        },
        body: JSON.stringify({
          action: 'save_all',
          products: synced,
          deletedProductIds: currentDeletedIds
        })
      }).catch(err => console.error('Error persisting products to server:', err));
    } catch {}

    return synced;
  }, []);

  const saveAndSyncCategories = useCallback((nextList: Category[], additionalDeletedId?: string) => {
    let currentDeletedIds: string[] = [];
    if (typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem('arx_deleted_category_ids');
        currentDeletedIds = raw ? JSON.parse(raw) : [];
        if (additionalDeletedId && !currentDeletedIds.includes(additionalDeletedId)) {
          currentDeletedIds.push(additionalDeletedId);
          localStorage.setItem('arx_deleted_category_ids', JSON.stringify(currentDeletedIds));
        }
      } catch {}
    }

    const filtered = nextList.filter(c => !currentDeletedIds.includes(c.id));

    // Update state immediately
    setCategories(filtered);

    // Synchronously write to localStorage
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('arx_categories', JSON.stringify(filtered));
      } catch {}
    }

    // Persist to server disk via /api/categories
    try {
      fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'save_all',
          categories: filtered,
          deletedCategoryIds: currentDeletedIds
        })
      }).catch(err => console.error('Error persisting categories to server:', err));
    } catch {}

    return filtered;
  }, []);

  // Theme State ('dark' | 'light')
  const [theme, setThemeState] = useState<'dark' | 'light'>('dark');

  // Global Search Query State
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Rehydrate Theme from localStorage on mount
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const savedTheme = localStorage.getItem('arx_theme') as 'dark' | 'light' | null;
      if (savedTheme === 'light' || savedTheme === 'dark') {
        setThemeState(savedTheme);
        if (savedTheme === 'light') {
          document.documentElement.classList.remove('dark');
          document.documentElement.classList.add('light');
        } else {
          document.documentElement.classList.remove('light');
          document.documentElement.classList.add('dark');
        }
      } else {
        document.documentElement.classList.add('dark');
        document.documentElement.classList.remove('light');
      }
    } catch {
      // ignore
    }
  }, []);

  const setTheme = useCallback((newTheme: 'dark' | 'light') => {
    setThemeState(newTheme);
    sound.playKeyClick();
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('arx_theme', newTheme);
        if (newTheme === 'light') {
          document.documentElement.classList.remove('dark');
          document.documentElement.classList.add('light');
        } else {
          document.documentElement.classList.remove('light');
          document.documentElement.classList.add('dark');
        }
      } catch {
        // ignore
      }
    }
  }, []);

  const toggleTheme = useCallback(() => {
    setThemeState(prev => {
      const next = prev === 'dark' ? 'light' : 'dark';
      sound.playKeyClick();
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('arx_theme', next);
          if (next === 'light') {
            document.documentElement.classList.remove('dark');
            document.documentElement.classList.add('light');
          } else {
            document.documentElement.classList.remove('light');
            document.documentElement.classList.add('dark');
          }
        } catch {
          // ignore
        }
      }
      return next;
    });
  }, []);

  // Refresh full users list from central server database (Admin only)
  const refreshUsers = useCallback(async () => {
    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
      if (!token) return;
      const res = await fetch('/api/admin/users', {
        headers: { 'x-session-token': token }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.data)) {
          setUsers(data.data);
          if (typeof window !== 'undefined') {
            localStorage.setItem('arx_registered_users', JSON.stringify(data.data));
            localStorage.setItem('demox_users', JSON.stringify(data.data));
          }
        }
      }
    } catch (e) {
      console.error('Failed to fetch users from server:', e);
    }
  }, []);

  // Load User, Registered Users & Transaction data from LocalStorage if available
  useEffect(() => {
    if (typeof window === 'undefined') return;

    try {
      // 1. Rehydrate all registered users list
      let deletedUserIds: string[] = [];
      try {
        const rawDel = localStorage.getItem('arx_deleted_user_ids');
        if (rawDel) deletedUserIds = JSON.parse(rawDel);
      } catch {}

      let currentUsers = DEMO_USERS.filter(u => !deletedUserIds.includes(u.id));
      const savedUsers = localStorage.getItem('arx_registered_users') || localStorage.getItem('demox_users');
      if (savedUsers !== null) {
        try {
          let parsedUsers: User[] = JSON.parse(savedUsers);
          if (Array.isArray(parsedUsers)) {
            parsedUsers = parsedUsers.filter(u => !deletedUserIds.includes(u.id));
            parsedUsers = parsedUsers.map(u => ({
              ...u,
              avatar: (!u.avatar || u.avatar.includes('unsplash.com') || u.avatar.includes('placeholder')) ? '/brand/logo.png' : u.avatar
            }));
            // NEVER forcibly re-add deleted DEMO_USERS!
            // Only ensure demo admin exists if no admin account is found and not deleted
            if (!parsedUsers.some(u => u.role === 'admin') && !deletedUserIds.includes(DEMO_USERS[0].id)) {
              parsedUsers.unshift(DEMO_USERS[0]);
            }
            currentUsers = parsedUsers;
            setUsers(parsedUsers);
            localStorage.setItem('arx_registered_users', JSON.stringify(parsedUsers));
            localStorage.setItem('demox_users', JSON.stringify(parsedUsers));
          }
        } catch (e) {
          console.error('Error parsing saved registered users:', e);
        }
      } else {
        localStorage.setItem('arx_registered_users', JSON.stringify(currentUsers));
        localStorage.setItem('demox_users', JSON.stringify(currentUsers));
      }

      // 2. Rehydrate authenticated user session from Central Server Database
      const savedToken = localStorage.getItem('arx_session_token');
      const isLoggedOut = localStorage.getItem('arx_logged_out') === 'true';

      if (savedToken && !isLoggedOut) {
        // Synchronously restore cached user to avoid unauthenticated flash on reload
        const cachedUserStr = localStorage.getItem('arx_current_user') || localStorage.getItem('demox_user');
        if (cachedUserStr) {
          try {
            const cachedUser = JSON.parse(cachedUserStr);
            setUser(cachedUser);
          } catch {}
        }

        fetch('/api/auth', { headers: { 'x-session-token': savedToken } })
          .then(res => res.json())
          .then(data => {
            if (data.authenticated && data.user) {
              setUser(data.user);
              localStorage.setItem('arx_current_user', JSON.stringify(data.user));
              // Fetch user orders directly from Central Server DB
              fetch('/api/orders', { headers: { 'x-session-token': savedToken } })
                .then(r => r.json())
                .then(ordData => {
                  if (ordData.success && Array.isArray(ordData.data)) {
                    setOrders(ordData.data);
                    localStorage.setItem('arx_orders', JSON.stringify(ordData.data));
                  }
                })
                .catch(() => {});

              if (data.user.role === 'admin') {
                refreshUsers();
              }
            } else {
              localStorage.removeItem('arx_session_token');
              setUser(null);
            }
          })
          .catch(() => {
            const savedUser = localStorage.getItem('arx_current_user');
            if (savedUser) {
              try { setUser(JSON.parse(savedUser)); } catch {}
            }
          });
      } else {
        setUser(null);
      }

      // 3. Orders, Topups, HWID
      let deletedOrderIds: string[] = [];
      try {
        const rawDel = localStorage.getItem('arx_deleted_order_ids');
        if (rawDel) deletedOrderIds = JSON.parse(rawDel);
      } catch {}

      const savedOrders = localStorage.getItem('arx_orders') || localStorage.getItem('demox_orders');
      if (savedOrders !== null) {
        try {
          let parsedOrders: Order[] = JSON.parse(savedOrders);
          if (Array.isArray(parsedOrders)) {
            parsedOrders = parsedOrders.filter(o => !deletedOrderIds.includes(o.id));
            setOrders(parsedOrders);
            localStorage.setItem('arx_orders', JSON.stringify(parsedOrders));
            localStorage.setItem('demox_orders', JSON.stringify(parsedOrders));
          }
        } catch {}
      }

      const savedSessionToken = localStorage.getItem('arx_session_token');
      const savedUser = localStorage.getItem('arx_current_user') || localStorage.getItem('demox_user');
      if (savedSessionToken && savedUser) {
        const savedTopups = localStorage.getItem('arx_topups') || localStorage.getItem('demox_topups');
        if (savedTopups) {
          try {
            setTopups(JSON.parse(savedTopups));
          } catch {}
        }
      } else {
        setTopups([]);
      }

      const savedHwid = localStorage.getItem('arx_hwid') || localStorage.getItem('demox_hwid');
      if (savedHwid) {
        try {
          setHwidRecords(JSON.parse(savedHwid));
        } catch {}
      }

      setCookieConsentGiven(true);
      setIsCookieModalOpen(false);

      setIsSoundEnabled(true);
      sound.setEnabled(true);
      localStorage.setItem('demox_sound', 'true');

      const savedLang = localStorage.getItem('arx_lang');
      if (savedLang === 'th' || savedLang === 'en') {
        setLangState(savedLang);
      }

      // Quick modal & lang opener for previewing
      const urlParams = new URLSearchParams(window.location.search);
      const urlLang = urlParams.get('lang');
      if (urlLang === 'th' || urlLang === 'en') {
        setLangState(urlLang);
        localStorage.setItem('arx_lang', urlLang);
      }

      if (urlParams.get('modal') === 'auth') {
        setIsAuthModalOpen(true);
      } else if (urlParams.get('modal') === 'buy') {
        const prodId = urlParams.get('product');
        const allProds = INITIAL_PRODUCTS;
        const targetProd = (prodId ? allProds.find(p => p.id === prodId) : null) || allProds[1] || allProds[0];
        setSelectedProduct(targetProd);
        setIsBuyModalOpen(true);
      }
    } catch {
      // LocalStorage access issue
    } finally {
      setIsHydrated(true);
    }
  }, []);

  // Save changes to LocalStorage (Guarded by isHydrated so initial empty state NEVER overwrites storage)
  useEffect(() => {
    if (!isHydrated || typeof window === 'undefined') return;
    try {
      if (user) {
        localStorage.setItem('arx_current_user', JSON.stringify(user));
        localStorage.setItem('demox_user', JSON.stringify(user));
        localStorage.removeItem('arx_logged_out');
      } else if (localStorage.getItem('arx_logged_out') === 'true') {
        localStorage.removeItem('arx_current_user');
        localStorage.removeItem('demox_user');
      }

      if (users && users.length > 0) {
        localStorage.setItem('arx_registered_users', JSON.stringify(users));
        localStorage.setItem('demox_users', JSON.stringify(users));
      }

      localStorage.setItem('arx_orders', JSON.stringify(orders));
      localStorage.setItem('demox_orders', JSON.stringify(orders));
      localStorage.setItem('arx_topups', JSON.stringify(topups));
      localStorage.setItem('demox_topups', JSON.stringify(topups));
      localStorage.setItem('arx_hwid', JSON.stringify(hwidRecords));
      localStorage.setItem('demox_hwid', JSON.stringify(hwidRecords));
      localStorage.setItem('demox_sound', String(isSoundEnabled));
    } catch {
      // LocalStorage access issue
    }
  }, [isHydrated, user, users, orders, topups, hwidRecords, isSoundEnabled]);

  // Extra safety on beforeunload: ensure current session, products and categories are flushed immediately
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const handleBeforeUnload = () => {
      try {
        if (products && products.length > 0) {
          localStorage.setItem('arx_products', JSON.stringify(products));
        }
        if (categories && categories.length > 0) {
          localStorage.setItem('arx_categories', JSON.stringify(categories));
        }
        if (user) {
          localStorage.setItem('arx_current_user', JSON.stringify(user));
          localStorage.setItem('demox_user', JSON.stringify(user));
        }
        if (users && users.length > 0) {
          localStorage.setItem('arx_registered_users', JSON.stringify(users));
          localStorage.setItem('demox_users', JSON.stringify(users));
        }
      } catch {}
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [products, categories, user, users]);



  // Auth functions
  // Auth functions - Connected to Central Server API (PBKDF2 Hashing & Server Sessions)
  const login = async (username: string, pass?: string) => {
    playClick();
    const cleanUser = username.trim();
    const cleanPass = pass?.trim() || '';

    if (!cleanUser || !cleanPass) {
      playError();
      return { success: false, message: 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน' };
    }

    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'login',
          username: cleanUser,
          password: cleanPass
        })
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        playError();
        return { success: false, message: data.message || 'เข้าสู่ระบบไม่สำเร็จ' };
      }

      const loggedUser = data.user;
      const token = data.token;

      setUser(loggedUser);
      if (typeof window !== 'undefined') {
        localStorage.removeItem('arx_logged_out');
        localStorage.setItem('arx_session_token', token);
        localStorage.setItem('arx_current_user', JSON.stringify(loggedUser));
        localStorage.setItem('demox_user', JSON.stringify(loggedUser));
      }

      // Re-fetch orders for this user from server
      try {
        const ordRes = await fetch('/api/orders', {
          headers: { 'x-session-token': token }
        });
        const ordData = await ordRes.json();
        if (ordData.success && Array.isArray(ordData.data)) {
          setOrders(ordData.data);
          if (typeof window !== 'undefined') {
            localStorage.setItem('arx_orders', JSON.stringify(ordData.data));
            localStorage.setItem('demox_orders', JSON.stringify(ordData.data));
          }
        }
      } catch {}

      // Re-fetch topups if available
      try {
        const topupRes = await fetch('/api/topup', {
          headers: { 'x-session-token': token }
        });
        const topupData = await topupRes.json();
        if (topupData.success && Array.isArray(topupData.data)) {
          setTopups(topupData.data);
          if (typeof window !== 'undefined') {
            localStorage.setItem('arx_topups', JSON.stringify(topupData.data));
          }
        }
      } catch {}

      // If admin, fetch fresh user list from server
      if (loggedUser.role === 'admin') {
        refreshUsers();
      }

      // Broadcast multi-tab login
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        try {
          const bc = new BroadcastChannel('arx_store_sync_channel');
          bc.postMessage({ type: 'USER_LOGIN', user: loggedUser, token });
          bc.close();
        } catch {}
      }

      playSuccess();
      showToast({
        title: 'เข้าสู่ระบบสำเร็จ',
        message: `ยินดีต้อนรับ คุณ ${loggedUser.username} (${loggedUser.role === 'admin' ? 'ผู้ดูแลระบบ' : 'สมาชิก'})`,
        type: 'success'
      });
      return { success: true, message: 'เข้าสู่ระบบสำเร็จ' };
    } catch {
      playError();
      return { success: false, message: 'เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์' };
    }
  };

  const logout = async () => {
    playClick();
    const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
    if (token) {
      try {
        fetch('/api/auth', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-session-token': token },
          body: JSON.stringify({ action: 'logout', token })
        }).catch(() => {});
      } catch {}
    }

    setUser(null);
    setOrders([]);
    setTopups([]);
    if (typeof window !== 'undefined') {
      localStorage.setItem('arx_logged_out', 'true');
      localStorage.removeItem('arx_session_token');
      localStorage.removeItem('arx_current_user');
      localStorage.removeItem('demox_user');
      localStorage.removeItem('arx_topups');
      localStorage.removeItem('demox_topups');
      localStorage.removeItem('arx_orders');
      localStorage.removeItem('demox_orders');
    }

    // Broadcast multi-tab logout
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        const bc = new BroadcastChannel('arx_store_sync_channel');
        bc.postMessage({ type: 'USER_LOGOUT' });
        bc.close();
      } catch {}
    }

    showToast({
      title: 'ออกจากระบบแล้ว',
      message: 'คุณได้ออกจากระบบเรียบร้อยแล้ว',
      type: 'info'
    });
  };

  const register = async (username: string, pass?: string, email?: string) => {
    playClick();
    const clean = username.trim();
    const cleanPass = pass?.trim() || '';

    if (!clean) {
      playError();
      return { success: false, message: 'กรุณากรอกชื่อผู้ใช้' };
    }
    if (cleanPass.length < 4) {
      playError();
      return { success: false, message: 'รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร' };
    }

    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'register',
          username: clean,
          password: cleanPass,
          email: email?.trim() || undefined
        })
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        playError();
        return { success: false, message: data.message || 'สมัครสมาชิกไม่สำเร็จ' };
      }

      const newUser = data.user;
      const token = data.token;

      setUser(newUser);
      if (typeof window !== 'undefined') {
        localStorage.removeItem('arx_logged_out');
        localStorage.setItem('arx_session_token', token);
        localStorage.setItem('arx_current_user', JSON.stringify(newUser));
        localStorage.setItem('demox_user', JSON.stringify(newUser));
      }

      // Broadcast multi-tab register
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        try {
          const bc = new BroadcastChannel('arx_store_sync_channel');
          bc.postMessage({ type: 'USER_LOGIN', user: newUser, token });
          bc.close();
        } catch {}
      }

      playSuccess();
      showToast({
        title: 'สมัครสมาชิกสำเร็จ!',
        message: `ยินดีต้อนรับคุณ ${clean} เข้าสู่ระบบ ARX STORE เรียบร้อยแล้ว`,
        type: 'success'
      });

      return { success: true, message: 'สมัครสมาชิกสำเร็จ' };
    } catch {
      playError();
      return { success: false, message: 'เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์' };
    }
  };

  const switchUser = (role: 'user' | 'admin') => {
    playClick();
    showToast({
      title: 'ระบบรักษาความปลอดภัย',
      message: 'ไม่อนุญาตให้สลับสิทธิ์โดยตรง กรุณาเข้าสู่ระบบด้วยบัญชีที่ถูกต้อง',
      type: 'warning'
    });
    openAuthModal('login');
  };

  const updateUserProfile = async (data: { username?: string; avatar?: string }): Promise<{ success: boolean; message: string }> => {
    playClick();
    if (!user) {
      playError();
      return { success: false, message: 'กรุณาเข้าสู่ระบบก่อนทำรายการ' };
    }

    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-session-token': token } : {})
        },
        body: JSON.stringify({
          action: 'update_profile',
          token,
          userId: user.id,
          username: data.username,
          avatar: data.avatar
        })
      });

      const resData = await res.json();
      if (!res.ok || !resData.success) {
        playError();
        showToast({
          title: 'อัปเดตโปรไฟล์ไม่สำเร็จ',
          message: resData.message || 'เกิดข้อผิดพลาดในการบันทึกข้อมูล',
          type: 'error'
        });
        return { success: false, message: resData.message || 'เกิดข้อผิดพลาด' };
      }

      const updatedUser: User = resData.user;
      setUser(updatedUser);
      setUsers(prev => prev.map(u => u.id === updatedUser.id ? { ...u, ...updatedUser } : u));

      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_current_user', JSON.stringify(updatedUser));
        localStorage.setItem('demox_user', JSON.stringify(updatedUser));
      }

      if (data.username && data.username !== user.username) {
        setOrders(prevOrders => prevOrders.map(o => o.userId === user.id ? { ...o, username: data.username! } : o));
      }

      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        try {
          const bc = new BroadcastChannel('arx_store_sync_channel');
          bc.postMessage({ type: 'USER_UPDATED', userId: user.id, user: updatedUser });
          bc.close();
        } catch {}
      }

      playSuccess();
      showToast({
        title: 'อัปเดตโปรไฟล์สำเร็จ!',
        message: 'บันทึกรูปโปรไฟล์และชื่อผู้ใช้เรียบร้อยแล้ว',
        type: 'success'
      });

      return { success: true, message: 'บันทึกข้อมูลสำเร็จ' };
    } catch (err: any) {
      playError();
      showToast({
        title: 'เกิดข้อผิดพลาด',
        message: 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้',
        type: 'error'
      });
      return { success: false, message: 'เชื่อมต่อเซิร์ฟเวอร์ไม่สำเร็จ' };
    }
  };

  // Modals
  const openBuyModal = useCallback((p: Product) => {
    playClick();
    setSelectedProduct(p);
    setIsBuyModalOpen(true);
  }, [playClick]);

  const closeBuyModal = useCallback(() => {
    setIsBuyModalOpen(false);
  }, []);

  const openAuthModal = useCallback((mode: 'login' | 'register' = 'login') => {
    playClick();
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  }, [playClick]);

  const closeAuthModal = useCallback(() => {
    setIsAuthModalOpen(false);
  }, []);

  const acceptAllCookies = useCallback(() => {
    playClick();
    setCookieConsentGiven(true);
    setIsCookieModalOpen(false);
    if (typeof window !== 'undefined') {
      localStorage.setItem('demox_cookie_consent', 'true');
    }
  }, [playClick]);

  const closeCookieModal = useCallback(() => {
    playClick();
    setIsCookieModalOpen(false);
  }, [playClick]);

  // Purchase Package Flow - Connected to Central Server API & Central DB
  const purchasePackage = async (productId: string, packageId: string, couponCode?: string): Promise<{ success: boolean; message: string; order?: Order }> => {
    playClick();
    if (!user) {
      playError();
      openAuthModal('login');
      return { success: false, message: 'กรุณาเข้าสู่ระบบก่อนทำรายการสั่งซื้อ' };
    }

    const prod = products.find(p => p.id === productId);
    if (!prod) {
      playError();
      return { success: false, message: 'ไม่พบข้อมูลสินค้า' };
    }

    const pkg = prod.packages.find(p => p.id === packageId);
    if (!pkg) {
      playError();
      return { success: false, message: 'ไม่พบแพ็กเกจที่เลือก' };
    }

    const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
    if (!token) {
      playError();
      openAuthModal('login');
      return { success: false, message: 'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่อีกครั้ง' };
    }

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session-token': token
        },
        body: JSON.stringify({
          productId: prod.id,
          productName: prod.name,
          packageId: pkg.id,
          packageName: pkg.name,
          price: pkg.price,
          couponCode: couponCode || undefined,
          downloadUrl: prod.downloadUrl || 'https://arxstore.xyz/download/loader.exe',
          instructions: prod.instructions || 'เปิดโปรแกรมแล้วใส่ License Key เพื่อเปิดใช้งาน',
          idempotencyKey: `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`
        })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        playError();
        return {
          success: false,
          message: data.message || 'การสั่งซื้อไม่สำเร็จ กรุณาตรวจสอบยอดเงินคงเหลือ'
        };
      }

      const newOrder: Order = data.order;
      const updatedBalance = typeof data.newBalance === 'number' ? data.newBalance : Math.max(0, user.balance - pkg.price);

      // Update state & persist immediately
      const updatedUser: User = {
        ...user,
        balance: updatedBalance,
        totalSpent: user.totalSpent + (newOrder.price || pkg.price)
      };

      setUser(updatedUser);
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_current_user', JSON.stringify(updatedUser));
        localStorage.setItem('demox_user', JSON.stringify(updatedUser));
      }

      setOrders(prev => {
        const next = [newOrder, ...prev.filter(o => o.id !== newOrder.id)];
        if (typeof window !== 'undefined') {
          localStorage.setItem('arx_orders', JSON.stringify(next));
          localStorage.setItem('demox_orders', JSON.stringify(next));
        }
        return next;
      });

      // Update product stock and sales count in local state
      setProducts(prev => {
        const next = prev.map(p => {
          if (p.id === productId) {
            const nextPackages = p.packages.map(itemPkg => {
              if (itemPkg.id === packageId) {
                const remaining = Math.max(0, itemPkg.stock - 1);
                return {
                  ...itemPkg,
                  stock: remaining,
                  inStock: remaining > 0
                };
              }
              return itemPkg;
            });
            return { ...p, packages: nextPackages, salesCount: p.salesCount + 1 };
          }
          return p;
        });
        if (typeof window !== 'undefined') {
          localStorage.setItem('arx_products', JSON.stringify(next));
        }
        return next;
      });

      playSuccess();
      showToast({
        title: 'สั่งซื้อสำเร็จ!',
        message: `ได้รับสินค้า ${prod.name} (${pkg.duration}) เรียบร้อยแล้ว`,
        type: 'success'
      });

      // Broadcast real live purchase notification to other tabs
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('arx_latest_real_purchase', JSON.stringify({
            username: user.username,
            productName: prod.name,
            productImage: prod.image || '/brand/logo.png',
            packageName: pkg.name || pkg.duration,
            price: newOrder.price || pkg.price,
            dateStr: new Date().toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) + ' น.',
            timestamp: Date.now()
          }));
        } catch {}
      }

      return { success: true, message: 'สั่งซื้อสำเร็จ!', order: newOrder };
    } catch {
      playError();
      return { success: false, message: 'เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์' };
    }
  };

  // Topup TrueMoney Angpao - Dynamic Voucher Amount
  const topupAngpao = async (voucherUrl: string, amount?: number) => {
    playClick();
    if (!user) {
      playError();
      return { success: false, amount: 0, message: 'กรุณาเข้าสู่ระบบก่อนเติมเงิน' };
    }

    if (!voucherUrl.includes('gift.truemoney.com') && !voucherUrl.includes('demox')) {
      playError();
      return { success: false, amount: 0, message: 'ลิงก์ซองของขวัญไม่ถูกต้อง (ต้องเป็นลิงก์ gift.truemoney.com)' };
    }

    const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
    if (!token) {
      playError();
      return { success: false, amount: 0, message: 'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่' };
    }

    // Support dynamic amount from caller or default to 100
    const finalAmount = amount && amount > 0 ? amount : 100;

    try {
      const res = await fetch('/api/topup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session-token': token
        },
        body: JSON.stringify({
          method: 'angpao',
          amount: finalAmount,
          refCode: voucherUrl.slice(-16),
          bankName: 'TrueMoney Angpao'
        })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        playError();
        return { success: false, amount: 0, message: data.message || 'ส่งข้อมูลซองของขวัญไม่สำเร็จ' };
      }

      const transaction: TopupTransaction = data.data;
      setTopups(prev => [transaction, ...prev]);

      playSuccess();
      showToast({
        title: 'ส่งซองของขวัญแล้ว',
        message: 'ระบบได้รับข้อมูลซองของขวัญแล้ว กำลังรอแอดมินตรวจสอบยอดเงินและปรับเครดิตเข้าบัญชี',
        type: 'info'
      });

      return { success: true, amount: transaction.amount, message: 'ส่งข้อมูลเติมเงินแล้ว' };
    } catch {
      playError();
      return { success: false, amount: 0, message: 'เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์' };
    }
  };

  // Topup Bank Transfer Slip - Central Server Pending Workflow
  const topupSlip = async (amount?: number, senderName?: string, bank?: string, slipBase64?: string) => {
    playClick();
    if (!user) {
      playError();
      return { success: false, message: 'กรุณาเข้าสู่ระบบก่อนเติมเงิน', amount: 0 };
    }

    const finalAmount = (amount && amount > 0) ? amount : 300;
    const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;

    if (!token) {
      playError();
      return { success: false, message: 'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่', amount: 0 };
    }

    try {
      const res = await fetch('/api/topup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session-token': token
        },
        body: JSON.stringify({
          method: 'bank_transfer',
          amount: finalAmount,
          senderName: senderName || user.username,
          bankName: bank || 'ธนาคารไทย / พร้อมเพย์',
          slipUrl: slipBase64 || '/images/slip_sample.png',
          refCode: 'SLIP-' + Date.now()
        })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        playError();
        return { success: false, message: data.message || 'ไม่สามารถส่งข้อมูลสลิปได้', amount: 0 };
      }

      const transaction: TopupTransaction = data.data;
      setTopups(prev => [transaction, ...prev]);

      playSuccess();
      showToast({
        title: 'ส่งสลิปเติมเงินสำเร็จ!',
        message: `ส่งข้อมูล ฿${finalAmount.toLocaleString()} เรียบร้อยแล้ว อยู่ระหว่างรอแอดมินตรวจสอบยอดเงิน`,
        type: 'info'
      });

      return { success: true, message: 'ส่งข้อมูลเติมเงินสำเร็จ รอตรวจสอบ', amount: finalAmount };
    } catch {
      playError();
      return { success: false, message: 'เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์', amount: 0 };
    }
  };

  // HWID Reset Flow
  const requestHwidReset = async (productId: string, licenseKey: string) => {
    playClick();
    if (!user) {
      playError();
      return { success: false, message: 'กรุณาเข้าสู่ระบบก่อนรีเซ็ต HWID', wasFree: false };
    }

    const prod = products.find(p => p.id === productId);
    const prodName = prod ? prod.name : 'โปรแกรมเกมทั่วไป';

    if (!licenseKey.trim()) {
      playError();
      return { success: false, message: 'กรุณากรอก License Key ที่ต้องการรีเซ็ต', wasFree: false };
    }

    const cost = 25;
    const canUseFree = user.freeHwidResets > 0;

    if (!canUseFree && user.balance < cost) {
      playError();
      return {
        success: false,
        message: `คุณไม่มีสิทธิ์รีเซ็ตฟรี และยอดเงินคงเหลือไม่พอ (ค่าบริการ ฿${cost}, คุณมี ฿${user.balance})`,
        wasFree: false
      };
    }

    let updatedUser = { ...user };
    let wasFree = false;

    if (canUseFree) {
      updatedUser.freeHwidResets -= 1;
      wasFree = true;
    } else {
      updatedUser.balance -= cost;
      updatedUser.accumulatedHwidResets += 1;
      // If accumulated reaches 5, reward 1 free reset!
      if (updatedUser.accumulatedHwidResets >= 5) {
        updatedUser.freeHwidResets += 1;
        updatedUser.accumulatedHwidResets = 0;
      }
    }

    const record: HwidResetRecord = {
      id: 'hwid-' + Date.now(),
      userId: user.id,
      username: user.username,
      productId: productId,
      productName: prodName,
      licenseKey: licenseKey,
      status: 'completed',
      cost: wasFree ? 0 : cost,
      wasFree: wasFree,
      createdAt: new Date().toLocaleString('th-TH')
    };

    setUser(updatedUser);
    setUsers(prev => {
      const next = prev.map(u => u.id === updatedUser.id ? updatedUser : u);
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_registered_users', JSON.stringify(next));
        localStorage.setItem('demox_users', JSON.stringify(next));
      }
      return next;
    });
    if (typeof window !== 'undefined') {
      localStorage.setItem('arx_current_user', JSON.stringify(updatedUser));
      localStorage.setItem('demox_user', JSON.stringify(updatedUser));
    }
    setHwidRecords(prev => [record, ...prev]);
    playSuccess();

    showToast({
      title: 'รีเซ็ต HWID สำเร็จ!',
      message: wasFree
        ? `ใช้สิทธิ์ฟรี 1 รอบ รีเซ็ตฮาร์ดแวร์ไอดีสำหรับ ${prodName} แล้ว`
        : `ชำระ ฿${cost} รีเซ็ตฮาร์ดแวร์ไอดีเรียบร้อย พร้อมผูกเครื่องใหม่ได้ทันที`,
      type: 'success'
    });

    return { success: true, message: 'รีเซ็ต HWID สำเร็จ', wasFree };
  };

  // Admin Actions
  const updateServiceStatus = (id: string, newStatus: 'online' | 'updating' | 'maintenance') => {
    playClick();
    setServiceStatuses(prev => prev.map(s => s.id === id ? { ...s, status: newStatus, lastChecked: 'เมื่อสักครู่' } : s));
    showToast({
      title: 'อัปเดตสถานะบริการแล้ว',
      message: `เปลี่ยนสถานะเป็น ${newStatus.toUpperCase()}`,
      type: 'info'
    });
  };

  const approveTopup = async (id: string) => {
    playClick();
    const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
    try {
      const res = await fetch('/api/topup', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-session-token': token } : {})
        },
        body: JSON.stringify({ topupId: id, status: 'approved' })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        playError();
        showToast({ title: 'อนุมัติไม่สำเร็จ', message: data.message || 'เกิดข้อผิดพลาด', type: 'error' });
        return;
      }

      setTopups(prev => prev.map(t => t.id === id ? { ...t, status: 'approved' } : t));
      if (user && data.data && data.data.userId === user.id) {
        setUser(prev => prev ? { ...prev, balance: prev.balance + (data.data.amount || 0) } : null);
      }
      playSuccess();
      showToast({ title: 'อนุมัติการเติมเงินแล้ว', message: `อนุมัติรายการ #${id} สำเร็จ ยอดเงินเข้ากระเป๋าเรียบร้อย`, type: 'success' });
    } catch {
      playError();
      showToast({ title: 'ข้อผิดพลาด', message: 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้', type: 'error' });
    }
  };

  const rejectTopup = async (id: string) => {
    playClick();
    const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
    try {
      const res = await fetch('/api/topup', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-session-token': token } : {})
        },
        body: JSON.stringify({ topupId: id, status: 'rejected' })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        playError();
        showToast({ title: 'ปฏิเสธไม่สำเร็จ', message: data.message || 'เกิดข้อผิดพลาด', type: 'error' });
        return;
      }

      setTopups(prev => prev.map(t => t.id === id ? { ...t, status: 'rejected' } : t));
      showToast({ title: 'ปฏิเสธรายการแล้ว', message: `รายการ #${id} ถูกปฏิเสธแล้ว`, type: 'warning' });
    } catch {
      playError();
      showToast({ title: 'ข้อผิดพลาด', message: 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้', type: 'error' });
    }
  };

  const addProduct = (newP: Omit<Product, 'id'>) => {
    playClick();
    const p: Product = {
      ...newP,
      id: 'prod-' + Date.now()
    };
    if (typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem('arx_deleted_product_ids');
        if (raw) {
          const list: string[] = JSON.parse(raw);
          const nextList = list.filter(item => item !== p.id);
          localStorage.setItem('arx_deleted_product_ids', JSON.stringify(nextList));
        }
      } catch {}
    }
    const next = [p, ...products];
    saveAndSyncProducts(next);
    playSuccess();
    showToast({ title: 'เพิ่มสินค้าสำเร็จ', message: `เพิ่ม ${p.name} ลงในร้านแล้ว`, type: 'success' });
  };

  const updateProduct = (id: string, data: Partial<Product>) => {
    playClick();
    const next = products.map(p => p.id === id ? { ...p, ...data } : p);
    saveAndSyncProducts(next);
    showToast({ title: 'บันทึกข้อมูลสินค้าแล้ว', message: 'อัปเดตสินค้าเรียบร้อย (Real-time)', type: 'info' });
  };

  const deleteProduct = (id: string) => {
    playClick();

    // 1. Permanently record in localStorage deletedProductIds
    let nextDeletedIds: string[] = [];
    if (typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem('arx_deleted_product_ids');
        const list: string[] = raw ? JSON.parse(raw) : [];
        if (!list.includes(id)) {
          list.push(id);
        }
        nextDeletedIds = list;
        localStorage.setItem('arx_deleted_product_ids', JSON.stringify(list));
      } catch {}
    }

    // 2. Remove product from current list and save synchronously
    const next = products.filter(p => p.id !== id);
    saveAndSyncProducts(next, id);

    // 3. Persistently delete from server disk
    try {
      const token = typeof window !== 'undefined'
        ? (localStorage.getItem('arx_session_token') || localStorage.getItem('arx_admin_token'))
        : null;
      fetch('/api/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-session-token': token } : {}),
          'x-admin-key': 'arx_admin_secret_key'
        },
        body: JSON.stringify({
          action: 'delete',
          id,
          products: next,
          deletedProductIds: nextDeletedIds
        })
      }).catch(err => console.error('Error syncing deletion to server:', err));
    } catch {}

    // 4. Clean up linked service statuses
    setServiceStatuses(prev => {
      const nextStatuses = prev.filter(s => s.productId !== id && s.id !== 'srv-' + id);
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_service_statuses', JSON.stringify(nextStatuses));
      }
      return nextStatuses;
    });

    showToast({ title: 'ลบสินค้าแล้ว', message: 'นำสินค้าออกจากระบบเรียบร้อย (ไม่กลับมาเมื่อรีเฟรช)', type: 'warning' });
  };

  // Hero Slides Management
  const updateSlide = (id: string, updated: Partial<HeroSlide>) => {
    playClick();
    setSlides(prev => {
      const next = prev.map(s => s.id === id ? { ...s, ...updated } : s);
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_slides', JSON.stringify(next));
      }
      return next;
    });
    showToast({ title: 'บันทึกรูปสไลด์แล้ว', message: 'อัปเดตสไลด์หน้าหลักเรียบร้อย', type: 'success' });
  };

  const addSlide = (newSlide: Omit<HeroSlide, 'id'>) => {
    playClick();
    const slide: HeroSlide = { ...newSlide, id: 'slide-' + Date.now() };
    if (typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem('arx_deleted_slide_ids');
        if (raw) {
          const list: string[] = JSON.parse(raw);
          const nextList = list.filter(item => item !== slide.id);
          localStorage.setItem('arx_deleted_slide_ids', JSON.stringify(nextList));
        }
      } catch {}
    }
    setSlides(prev => {
      const next = [...prev, slide];
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_slides', JSON.stringify(next));
      }
      return next;
    });
    playSuccess();
    showToast({ title: 'เพิ่มสไลด์สำเร็จ', message: `เพิ่มสไลด์ ${slide.title} เรียบร้อย`, type: 'success' });
  };

  const deleteSlide = (id: string) => {
    playClick();
    setSlides(prev => {
      const next = prev.filter(s => s.id !== id);
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_slides', JSON.stringify(next));
      }
      return next;
    });
    if (typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem('arx_deleted_slide_ids');
        const list: string[] = raw ? JSON.parse(raw) : [];
        if (!list.includes(id)) {
          list.push(id);
          localStorage.setItem('arx_deleted_slide_ids', JSON.stringify(list));
        }
      } catch {}
    }
    showToast({ title: 'ลบสไลด์แล้ว', message: 'นำสไลด์ออกจากระบบเรียบร้อย', type: 'warning' });
  };

  const moveSlide = (slideId: string, direction: 'up' | 'down') => {
    playClick();
    setSlides(prev => {
      const idx = prev.findIndex(s => s.id === slideId);
      if (idx === -1) return prev;
      if (direction === 'up' && idx === 0) return prev;
      if (direction === 'down' && idx === prev.length - 1) return prev;

      const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
      const next = [...prev];
      const temp = next[idx];
      next[idx] = next[targetIdx];
      next[targetIdx] = temp;

      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_slides', JSON.stringify(next));
      }
      return next;
    });
    showToast({ title: 'จัดลำดับสไลด์แล้ว', message: 'อัปเดตลำดับรูปสไลด์เรียบร้อย', type: 'info' });
  };

  const toggleHeroSlider = (enabled?: boolean) => {
    playClick();
    setHeroSliderEnabled(prev => {
      const next = typeof enabled === 'boolean' ? enabled : !prev;
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_hero_slider_enabled', String(next));
      }
      showToast({
        title: next ? 'เปิดใช้งานภาพสไลด์แล้ว' : 'ปิดการแสดงภาพสไลด์แล้ว',
        message: next ? 'ภาพสไลด์หน้าหลักจะแสดงผลตามปกติ' : 'นำภาพสไลด์ออกจากหน้าหลักเรียบร้อย',
        type: next ? 'success' : 'warning'
      });
      return next;
    });
  };

  const updateWelcomeBanner = async (updates: Partial<WelcomeBannerSettings>): Promise<boolean> => {
    const next = { ...welcomeBanner, ...updates };
    setWelcomeBanner(next);
    if (typeof window !== 'undefined') {
      localStorage.setItem('arx_welcome_banner', JSON.stringify(next));
    }

    try {
      const token = typeof window !== 'undefined' ? (localStorage.getItem('arx_session_token') || localStorage.getItem('arx_admin_token')) : null;
      const res = await fetch('/api/welcome-banner', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-session-token': token, 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(next)
      });
      const data = await res.json();
      if (data?.success && data?.data) {
        setWelcomeBanner(data.data);
        if (typeof window !== 'undefined') {
          localStorage.setItem('arx_welcome_banner', JSON.stringify(data.data));
        }
        return true;
      }
    } catch (err) {
      console.error('Failed to update welcome banner:', err);
    }
    return true;
  };

  const toggleRecentOrdersFeed = (enabled?: boolean) => {
    playClick();
    setRecentOrdersFeedEnabled(prev => {
      const next = typeof enabled === 'boolean' ? enabled : !prev;
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('arx_recent_orders_feed_enabled', String(next));
          window.dispatchEvent(new CustomEvent('arx:recent_orders_feed:change', { detail: next }));
        } catch (e) {
          console.error('Failed to save arx_recent_orders_feed_enabled:', e);
        }
      }
      showToast({
        title: next ? 'เปิดแสดงประวัติซื้อล่าสุดแล้ว' : 'ปิดการแสดงประวัติซื้อล่าสุดแล้ว',
        message: next ? 'แถบประวัติการสั่งซื้อล่าสุดจะแสดงผลบนหน้าหลักของร้านค้า' : 'ซ่อนแถบประวัติการสั่งซื้อล่าสุดออกจากหน้าหลักเรียบร้อย',
        type: next ? 'success' : 'warning'
      });
      return next;
    });
  };

  // Site Stats Management (ระบบกำหนดสถิติร้านค้า Real-time)
  const updateSiteStats = (newStats: Partial<SiteStats>, silent: boolean = false) => {
    if (!silent) playClick();
    setSiteStats(prev => {
      const next: SiteStats = {
        ...prev,
        ...newStats,
        isCustom: newStats.isCustom !== undefined ? newStats.isCustom : (prev.isCustom ?? false),
        mode: newStats.mode ?? prev.mode ?? 'direct'
      };
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('arx_site_stats', JSON.stringify(next));
          window.dispatchEvent(new CustomEvent('arx:site_stats:change', { detail: next }));
        } catch (e) {
          console.error('Failed to save arx_site_stats:', e);
        }
      }
      return next;
    });
    if (!silent) {
      playSuccess();
      showToast({ title: 'บันทึกยอดสถิติแล้ว', message: 'อัปเดตยอดสถิติหน้าเว็บเรียบร้อย (Real-time)', type: 'success' });
    }
  };

  // Slip API Config (เชื่อมต่อระบบตรวจสอบสลิป & จัดการช่องทางชำระเงิน)
  const updateSlipConfig = (newCfg: Partial<SlipApiConfig>) => {
    playClick();
    setSlipConfig(prev => {
      const next = { ...prev, ...newCfg };
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_slip_config', JSON.stringify(next));
      }
      // Sync to server disk
      const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
      fetch('/api/slip-config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-session-token': token } : {})
        },
        body: JSON.stringify(next)
      }).catch(err => console.error('Failed to sync slip config to server', err));

      return next;
    });
    playSuccess();
    showToast({ title: 'บันทึกการตั้งค่าการชำระเงินแล้ว', message: 'อัปเดตช่องทางการชำระเงินและค่าธรรมเนียมเรียบร้อย', type: 'success' });
  };

  // Background Music Management (ระบบเพลงพื้นหลัง BGM)
  const updateBgmSettings = (newSettings: Partial<BgmSettings>, silent: boolean = false) => {
    if (!silent) playClick();

    // Auto-clean URL if accidentally concatenated
    let cleanUrl = newSettings.url;
    if (cleanUrl && typeof cleanUrl === 'string') {
      const trimmed = cleanUrl.trim();
      const secondHttp = trimmed.indexOf('http', 8);
      if (secondHttp > 0) {
        cleanUrl = trimmed.substring(0, secondHttp);
      }
    }

    setBgmSettings(prev => {
      const next: BgmSettings = {
        ...prev,
        ...newSettings,
        ...(cleanUrl ? { url: cleanUrl } : {})
      };
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('arx_bgm_settings', JSON.stringify(next));
          window.dispatchEvent(new CustomEvent('arx:bgm:change', { detail: next }));
          const token = localStorage.getItem('arx_session_token') || localStorage.getItem('arx_admin_token');
          fetch('/api/bgm', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              ...(token ? {
                'Authorization': `Bearer ${token}`,
                'x-session-token': token
              } : {})
            },
            body: JSON.stringify(next)
          })
            .then(async (res) => {
              if (!res.ok) {
                const errData = await res.json().catch(() => ({}));
                console.error('Server failed to save BGM:', res.status, errData);
              }
            })
            .catch((err) => {
              console.error('Network error saving /api/bgm:', err);
            });
        } catch (e) {
          console.error('Failed to save arx_bgm_settings:', e);
        }
      }
      return next;
    });
    if (!silent) {
      playSuccess();
      showToast({ title: 'บันทึกการตั้งค่าเพลงแล้ว', message: 'อัปเดตเพลงพื้นหลังเรียบร้อยแล้ว', type: 'success' });
    }
  };

  // Site Content & FAQ & Contact Modal Management
  const updateSiteContent = async (updates: Partial<SiteContent>): Promise<boolean> => {
    const next: SiteContent = {
      branding: updates.branding ? { ...(siteContent.branding || {}), ...updates.branding } : siteContent.branding,
      stepsSection: updates.stepsSection || siteContent.stepsSection,
      faqSection: updates.faqSection || siteContent.faqSection,
      contactModal: updates.contactModal || siteContent.contactModal,
      footer: updates.footer || siteContent.footer
    };
    setSiteContent(next);
    if (updates.branding?.logoUrl && user && (user.role === 'admin' || !user.avatar || user.avatar === '/brand/logo.png' || user.avatar === '/brand/arx-default-logo.png' || user.avatar === siteContent.branding?.logoUrl)) {
      const nextUser = { ...user, avatar: updates.branding.logoUrl };
      setUser(nextUser);
      setUsers(prev => prev.map(u => (u.id === user.id || u.role === 'admin') ? { ...u, avatar: updates.branding!.logoUrl! } : u));
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('arx_current_user', JSON.stringify(nextUser));
          localStorage.setItem('demox_user', JSON.stringify(nextUser));
        } catch {}
      }
    }
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('arx_site_content', JSON.stringify(next));
        if (next.branding?.siteTitle) {
          document.title = next.branding.siteTitle;
        }
      } catch {}
    }

    try {
      const token = typeof window !== 'undefined' ? (localStorage.getItem('arx_session_token') || localStorage.getItem('arx_admin_token')) : null;
      const res = await fetch('/api/site-content', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? {
            'Authorization': `Bearer ${token}`,
            'x-session-token': token
          } : {})
        },
        body: JSON.stringify(next)
      });
      const data = await res.json();
      if (data?.success && data?.data) {
        setSiteContent(data.data);
        if (typeof window !== 'undefined') {
          try {
            localStorage.setItem('arx_site_content', JSON.stringify(data.data));
          } catch {}
        }
        playSuccess();
        showToast({
          title: 'บันทึกสำเร็จ',
          message: 'บันทึกเนื้อหาเว็บไซต์และช่องทางติดต่อเรียบร้อยแล้ว',
          type: 'success'
        });
        return true;
      } else {
        playError();
        showToast({
          title: 'เกิดข้อผิดพลาด',
          message: data?.message || 'ไม่สามารถบันทึกข้อมูลได้',
          type: 'error'
        });
        return false;
      }
    } catch (err) {
      console.error('Failed to update site content:', err);
      playError();
      showToast({
        title: 'เกิดข้อผิดพลาด',
        message: 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้',
        type: 'error'
      });
      return false;
    }
  };

  // Discord Webhook Settings & Trigger Engine
  const addWebhookLog = (item: Omit<WebhookLogItem, 'id' | 'timestamp'>) => {
    const newLog: WebhookLogItem = {
      ...item,
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toLocaleString('th-TH')
    };
    setWebhookLogs(prev => {
      const next = [newLog, ...prev.slice(0, 49)];
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_webhook_logs', JSON.stringify(next));
      }
      return next;
    });
  };

  // Global throttle timestamp for Discord webhook pacing
  const lastWebhookSentTimeRef = useRef<number>(0);

  const triggerDiscordWebhook = async (
    type: 'register' | 'topup_bank' | 'topup_truemoney' | 'order' | 'stock' | 'test',
    data: any
  ) => {
    // Fallback to localStorage if state is somehow not yet synced
    let effectiveSettings = webhookSettings;
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('arx_webhook_settings');
        if (saved) {
          const parsed = JSON.parse(saved);
          effectiveSettings = { ...effectiveSettings, ...parsed };
        }
      } catch {}
    }

    let url = '';
    let isEnabled = false;

    if (type === 'register') {
      url = data?.customUrl || effectiveSettings.registerUrl;
      isEnabled = data?.customUrl ? true : effectiveSettings.registerEnabled;
    } else if (type === 'topup_bank' || type === 'topup_truemoney') {
      url = data?.customUrl || effectiveSettings.topupUrl;
      isEnabled = data?.customUrl ? true : effectiveSettings.topupEnabled;
    } else if (type === 'order') {
      url = data?.customUrl || effectiveSettings.orderUrl;
      isEnabled = data?.customUrl ? true : effectiveSettings.orderEnabled;
    } else if (type === 'stock') {
      url = data?.customUrl || effectiveSettings.stockUrl;
      isEnabled = data?.customUrl ? true : effectiveSettings.stockEnabled;
    } else if (type === 'test') {
      url = data?.customUrl || effectiveSettings.registerUrl || effectiveSettings.topupUrl || effectiveSettings.orderUrl || effectiveSettings.stockUrl;
      isEnabled = true;
    }

    if (!isEnabled || !url || !url.trim()) {
      return { success: false, message: 'Webhook ไม่ได้เปิดใช้งานหรือยังไม่ได้ระบุ URL' };
    }

    // Anti-Flood Webhook Throttle: pace consecutive requests by 2 seconds
    const now = Date.now();
    const timeSinceLast = now - lastWebhookSentTimeRef.current;
    if (timeSinceLast < 2000 && type !== 'test') {
      await new Promise(resolve => setTimeout(resolve, 2000 - timeSinceLast));
    }
    lastWebhookSentTimeRef.current = Date.now();

    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
      const res = await fetch('/api/discord-webhook', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-session-token': token } : {})
        },
        body: JSON.stringify({
          action: 'send',
          webhookUrl: url.trim(),
          type,
          data,
          botName: effectiveSettings.botName,
          botAvatarUrl: effectiveSettings.botAvatarUrl || 'https://files.catbox.moe/haszlm.png'
        })
      });

      const resData = await res.json().catch(() => ({}));
      if (res.ok && resData.success) {
        let logTitle = `ส่งแจ้งเตือน ${type.toUpperCase()} ไปยัง Discord สำเร็จ`;
        let logDetails = typeof data === 'object' ? JSON.stringify(data) : String(data);

        if (type === 'register') {
          logTitle = `👤 สมัครสมาชิก: ${data.username || '-'}`;
          logDetails = `รหัส ${data.userId || '-'} | เครดิตเริ่มต้น ฿${(data.balance ?? 0).toLocaleString()} | ${data.device || getClientDeviceInfo()}`;
        } else if (type === 'topup_bank') {
          logTitle = `💳 เติมเงินธนาคาร +฿${Number(data.amount || 0).toLocaleString()}: ${data.username || '-'}`;
          logDetails = `TxID: ${data.txNo || '-'} | ${data.bank || '-'} | สลิป: ${data.refCode || '-'}`;
        } else if (type === 'topup_truemoney') {
          logTitle = `🎁 เติมเงิน TrueMoney +฿${Number(data.amount || 0).toLocaleString()}: ${data.username || '-'}`;
          logDetails = `TxID: ${data.txNo || '-'} | ซองอั่งเปา: ${data.voucherCode || '-'} (โบนัส 5%)`;
        } else if (type === 'order') {
          logTitle = `🛒 คำสั่งซื้อใหม่ ${data.orderNumber || '-'}: ${data.productName || '-'}`;
          logDetails = `ผู้ซื้อ: ${data.username || '-'} | แพ็กเกจ: ${data.packageName || '-'} (฿${Number(data.price || 0).toLocaleString()}) | คีย์: ${data.licenseKey || '-'}`;
        } else if (type === 'stock') {
          logTitle = `📦 แจ้งเตือนเติมสต็อคสินค้า: ${data.productName || 'สินค้า'} (+${data.addedCount || 1} ชิ้น)`;
          logDetails = `หมวดหมู่: ${data.categoryName || '-'} | จำนวนที่เติม: ${data.addedCount || 1} ชิ้น | สต็อกคงเหลือ: ${data.currentStock || 0} ชิ้น | ผู้เติม: ${data.operator || 'Admin'}`;
        }

        addWebhookLog({
          type,
          title: logTitle,
          details: logDetails,
          status: 'success',
          httpStatus: res.status
        });
        return { success: true, message: 'ส่ง Discord Webhook สำเร็จ' };
      } else {
        addWebhookLog({
          type,
          title: `ส่งแจ้งเตือน ${type.toUpperCase()} ล้มเหลว`,
          details: resData.error || 'Discord ตอบกลับด้วยข้อผิดพลาด',
          status: 'failed',
          httpStatus: res.status,
          error: resData.error
        });
        return { success: false, message: resData.error || 'ส่ง Discord Webhook ไม่สำเร็จ' };
      }
    } catch (err: any) {
      addWebhookLog({
        type,
        title: `ส่งแจ้งเตือน ${type.toUpperCase()} ผิดพลาด`,
        details: err?.message || 'Network error',
        status: 'failed',
        error: err?.message
      });
      return { success: false, message: err?.message || 'ส่ง Discord Webhook ล้มเหลว' };
    }
  };

  const updateWebhookSettings = (newCfg: Partial<DiscordWebhookSettings>, silent = false) => {
    if (!silent) playClick();
    setWebhookSettings(prev => {
      const next = { ...prev, ...newCfg };
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_webhook_settings', JSON.stringify(next));
      }
      return next;
    });
    if (!silent) {
      playSuccess();
      showToast({ title: 'บันทึกการตั้งค่า Discord Webhook แล้ว', message: 'อัปเดตระบบ Log เรียบร้อย', type: 'success' });
    }
  };

  const testDiscordWebhook = async (
    type: 'register' | 'topup_bank' | 'topup_truemoney' | 'order' | 'stock',
    customUrl?: string
  ) => {
    let targetUrl = customUrl;
    let label = '';
    if (type === 'register') {
      targetUrl = targetUrl || webhookSettings.registerUrl;
      label = 'Log สมัครสมาชิก (Register Log)';
    } else if (type === 'topup_bank') {
      targetUrl = targetUrl || webhookSettings.topupUrl;
      label = 'Log เติมเงิน ธนาคาร (Bank Slip)';
    } else if (type === 'topup_truemoney') {
      targetUrl = targetUrl || webhookSettings.topupUrl;
      label = 'Log เติมเงิน TrueMoney (Angpao)';
    } else if (type === 'order') {
      targetUrl = targetUrl || webhookSettings.orderUrl;
      label = 'Log สั่งซื้อสินค้า (Order Log)';
    } else if (type === 'stock') {
      targetUrl = targetUrl || webhookSettings.stockUrl;
      label = 'Log เติมสต็อกสินค้า (Stock Refill Log)';
    }

    if (!targetUrl || !targetUrl.trim()) {
      showToast({
        title: 'ยังไม่ได้ระบุ Webhook URL',
        message: 'กรุณากรอก Discord Webhook URL ให้ถูกต้องก่อนกดทดสอบ',
        type: 'warning'
      });
      return { success: false, message: 'กรุณากรอก Discord Webhook URL' };
    }

    // Generate real, authentic test data with complete details
    const realisticUsernames = [
      'NightRider_TH',
      'ShadowZ99',
      'Krittin_Dev',
      'ArxProGamer',
      'Somchai_555',
      'ZeroByte_X',
      'NeoFiveM_TH',
      'Valkyrie_9'
    ];
    const pickedUser = user?.username && user.username !== 'admin'
      ? user.username
      : realisticUsernames[Math.floor(Math.random() * realisticUsernames.length)];

    let testData: any = {};

    if (type === 'register') {
      testData = {
        username: pickedUser,
        userId: 'USR-' + Math.floor(10000 + Math.random() * 90000),
        balance: 0,
        device: getClientDeviceInfo(),
        customUrl: targetUrl.trim()
      };
    } else if (type === 'topup_bank') {
      const bankAmounts = [150, 300, 350, 500, 1000, 1200];
      const pickedAmount = bankAmounts[Math.floor(Math.random() * bankAmounts.length)];
      testData = {
        username: pickedUser,
        amount: pickedAmount,
        newBalance: pickedAmount + 850,
        bank: 'ธนาคารกสิกรไทย (KBANK) / QR พร้อมเพย์',
        txNo: 'BNK' + Math.floor(100000 + Math.random() * 900000),
        refCode: '014285194829SCB' + Math.floor(1000 + Math.random() * 9000),
        senderName: `นาย กฤติน ส. (xxx-x-xx892-1)`,
        customUrl: targetUrl.trim()
      };
    } else if (type === 'topup_truemoney') {
      const tmAmounts = [100, 150, 300, 500];
      const pickedTmAmount = tmAmounts[Math.floor(Math.random() * tmAmounts.length)];
      testData = {
        username: pickedUser,
        amount: pickedTmAmount,
        newBalance: pickedTmAmount + 650,
        txNo: 'TM' + Math.floor(100000 + Math.random() * 900000),
        voucherCode: Math.random().toString(36).substring(2, 8),
        customUrl: targetUrl.trim()
      };
    } else if (type === 'order') {
      const catalog = products.length > 0 ? products : INITIAL_PRODUCTS;
      const randomProd = catalog[Math.floor(Math.random() * catalog.length)];
      const randomPkg = randomProd.packages && randomProd.packages.length > 0
        ? randomProd.packages[Math.floor(Math.random() * randomProd.packages.length)]
        : { name: 'เช่าใช้งาน 30 วัน', duration: '30 วัน', price: 350 };

      const keyPart1 = Math.random().toString(36).substring(2, 6).toUpperCase();
      const keyPart2 = Math.random().toString(36).substring(2, 6).toUpperCase();
      const keyPart3 = Math.random().toString(36).substring(2, 6).toUpperCase();
      const generatedLicenseKey = `ARX-${keyPart1}-${keyPart2}-${keyPart3}-PRO`;

      testData = {
        username: pickedUser,
        orderNumber: 'ARX' + Math.floor(100000 + Math.random() * 900000),
        productName: randomProd.name,
        packageName: randomPkg.name,
        duration: randomPkg.duration || '30 วัน',
        price: randomPkg.price || 350,
        licenseKey: generatedLicenseKey,
        downloadUrl: randomProd.downloadUrl || 'https://arxstore.com/download/loader.exe',
        customUrl: targetUrl.trim()
      };
    } else if (type === 'stock') {
      const catalog = products.length > 0 ? products : INITIAL_PRODUCTS;
      const targetProd = catalog.find(p => p.name.includes('TopInternet') || p.name.includes('SKYNET')) || catalog[0];
      const targetPkg = targetProd.packages && targetProd.packages.length > 0
        ? targetProd.packages[0]
        : { id: 'pkg-30d', name: 'เช่าใช้งาน 30 วัน', duration: '30 วัน', stock: 15 };

      testData = {
        productId: targetProd.id,
        productName: targetProd.name || 'Setting TopInternet',
        categoryName: targetProd.categoryName || 'SETTING FIVEM PRODUCT',
        productImage: targetProd.image || 'https://files.catbox.moe/haszlm.png',
        packageId: targetPkg.id,
        packageName: targetPkg.name,
        duration: targetPkg.duration || '30 วัน',
        addedCount: 46, // Exactly 46 as shown in reference screenshot
        currentStock: (targetPkg.stock || 15) + 46,
        stockType: 'key',
        operator: user?.username ? `${user.username} (Admin)` : 'arxstore (Admin)',
        customUrl: targetUrl.trim()
      };
    }

    const res = await triggerDiscordWebhook(type, testData);

    if (res.success) {
      playSuccess();
      showToast({
        title: 'ทดสอบส่งข้อมูลจริงสำเร็จ!',
        message: `ส่งข้อมูล (${label}) เสมือนผู้ใช้จริงเข้า Discord เรียบร้อย`,
        type: 'success'
      });
    } else {
      playError();
      showToast({
        title: 'ทดสอบส่ง Webhook ไม่สำเร็จ',
        message: res.message,
        type: 'warning'
      });
    }
    return res;
  };

  const clearWebhookLogs = () => {
    playClick();
    setWebhookLogs([]);
    if (typeof window !== 'undefined') {
      localStorage.removeItem('arx_webhook_logs');
    }
    showToast({ title: 'ล้างประวัติ Log แล้ว', message: 'ลบประวัติการส่ง Webhook ทั้งหมดเรียบร้อย', type: 'info' });
  };

  // Promotions Management (จัดโปรโมชั่นรวม / แยก)
  const applyGlobalPromotion = (discountPercent: number, badgeText = 'SALE', categoryId?: string) => {
    playClick();
    const next = products.map(p => {
      if (categoryId && categoryId !== 'all' && p.categoryId !== categoryId) return p;
      
      const updatedPackages = p.packages.map(pkg => {
        const original = pkg.originalPrice && pkg.originalPrice > pkg.price ? pkg.originalPrice : pkg.price;
        const discountedPrice = Math.max(1, Math.round(original * (1 - discountPercent / 100)));
        return {
          ...pkg,
          originalPrice: original,
          price: discountedPrice
        };
      });

      return {
        ...p,
        badge: badgeText || `ลด ${discountPercent}%`,
        packages: updatedPackages
      };
    });

    saveAndSyncProducts(next);
    playSuccess();
    showToast({ title: 'จัดโปรโมชั่นสำเร็จ!', message: `ปรับลดราคาสินค้า ${discountPercent}% เรียบร้อยแล้ว`, type: 'success' });
  };

  const clearGlobalPromotion = (categoryId?: string) => {
    playClick();
    const next = products.map(p => {
      if (categoryId && categoryId !== 'all' && p.categoryId !== categoryId) return p;
      
      const restoredPackages = p.packages.map(pkg => ({
        ...pkg,
        price: pkg.originalPrice || pkg.price,
        originalPrice: undefined
      }));

      return {
        ...p,
        badge: undefined,
        packages: restoredPackages
      };
    });

    saveAndSyncProducts(next);
    playSuccess();
    showToast({ title: 'ยกเลิกโปรโมชั่นแล้ว', message: 'คืนราคาและสถานะปกติของสินค้าเรียบร้อย', type: 'info' });
  };

  // Product Packages Management
  const updateProductPackages = (productId: string, packages: ProductPackage[]) => {
    playClick();
    const next = products.map(p => p.id === productId ? { ...p, packages } : p);
    saveAndSyncProducts(next);
    playSuccess();
    showToast({ title: 'บันทึกแพ็กเกจสินค้าแล้ว', message: 'อัปเดตตัวเลือกแพ็กเกจเรียบร้อย (Real-time)', type: 'success' });
  };

  // Digital Stock Management: Add single item (Key, Download Link, File, Note)
  const addStockItem = (productId: string, packageId: string, item: Omit<DigitalStockItem, 'id' | 'createdAt'>) => {
    playClick();
    const newItem: DigitalStockItem = {
      id: 'stk-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      ...item,
      createdAt: new Date().toLocaleString('th-TH')
    };

    let targetProductName = 'สินค้า';
    let targetCategoryName = 'SETTING FIVEM PRODUCT';
    let targetProductImage = '';
    let targetPackageName = 'แพ็กเกจ';
    let targetDuration = '-';
    let targetAvailableCount = 1;

    setProducts(prev => {
      const next = prev.map(p => {
        if (p.id === productId) {
          targetProductName = p.name;
          targetCategoryName = p.categoryName || 'SETTING FIVEM PRODUCT';
          targetProductImage = p.image || '';
          const nextPackages = p.packages.map(pkg => {
            if (pkg.id === packageId) {
              targetPackageName = pkg.name;
              targetDuration = pkg.duration || '-';
              const currentStockItems = pkg.stockItems || [];
              const nextStockItems = [...currentStockItems, newItem];
              const availableCount = nextStockItems.filter(s => !s.isUsed).length;
              targetAvailableCount = availableCount;
              return {
                ...pkg,
                stockItems: nextStockItems,
                stock: availableCount,
                inStock: availableCount > 0
              };
            }
            return pkg;
          });
          return { ...p, packages: nextPackages };
        }
        return p;
      });
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_products', JSON.stringify(next));
      }
      return next;
    });

    // Trigger Discord Webhook for Stock Refill Log
    triggerDiscordWebhook('stock', {
      productId,
      productName: targetProductName,
      categoryName: targetCategoryName,
      productImage: targetProductImage,
      packageId,
      packageName: targetPackageName,
      duration: targetDuration,
      addedCount: 1,
      currentStock: targetAvailableCount,
      stockType: item.downloadUrl ? 'link' : (item.fileName ? 'file' : 'key'),
      operator: user?.username ? `${user.username} (Admin)` : 'arxstore (Admin)'
    });

    playSuccess();
    showToast({
      title: 'เพิ่มสต็อกสำเร็จ!',
      message: `เพิ่มคีย์/ลิ้งก์เข้าระบบแล้ว (สต็อกอัพเดต Real-time)`,
      type: 'success'
    });
  };

  // Add bulk stock items
  const addBulkStockItems = (productId: string, packageId: string, items: Array<Omit<DigitalStockItem, 'id' | 'createdAt'>>) => {
    playClick();
    const nowStr = new Date().toLocaleString('th-TH');
    const newItems: DigitalStockItem[] = items.map((item, idx) => ({
      id: 'stk-' + Date.now() + '-' + idx + '-' + Math.random().toString(36).substring(2, 6),
      ...item,
      createdAt: nowStr
    }));

    let targetProductName = 'สินค้า';
    let targetCategoryName = 'SETTING FIVEM PRODUCT';
    let targetProductImage = '';
    let targetPackageName = 'แพ็กเกจ';
    let targetDuration = '-';
    let targetAvailableCount = items.length;

    setProducts(prev => {
      const next = prev.map(p => {
        if (p.id === productId) {
          targetProductName = p.name;
          targetCategoryName = p.categoryName || 'SETTING FIVEM PRODUCT';
          targetProductImage = p.image || '';
          const nextPackages = p.packages.map(pkg => {
            if (pkg.id === packageId) {
              targetPackageName = pkg.name;
              targetDuration = pkg.duration || '-';
              const currentStockItems = pkg.stockItems || [];
              const nextStockItems = [...currentStockItems, ...newItems];
              const availableCount = nextStockItems.filter(s => !s.isUsed).length;
              targetAvailableCount = availableCount;
              return {
                ...pkg,
                stockItems: nextStockItems,
                stock: availableCount,
                inStock: availableCount > 0
              };
            }
            return pkg;
          });
          return { ...p, packages: nextPackages };
        }
        return p;
      });
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_products', JSON.stringify(next));
      }
      return next;
    });

    // Trigger Discord Webhook for Bulk Stock Refill Log
    triggerDiscordWebhook('stock', {
      productId,
      productName: targetProductName,
      categoryName: targetCategoryName,
      productImage: targetProductImage,
      packageId,
      packageName: targetPackageName,
      duration: targetDuration,
      addedCount: newItems.length,
      currentStock: targetAvailableCount,
      stockType: items[0]?.downloadUrl ? 'link' : (items[0]?.fileName ? 'file' : 'key'),
      operator: user?.username ? `${user.username} (Admin)` : 'arxstore (Admin)'
    });

    playSuccess();
    showToast({
      title: 'นำเข้าสต็อกสำเร็จ!',
      message: `นำเข้าคีย์/ลิ้งก์จำนวน ${items.length} รายการเรียบร้อยแล้ว`,
      type: 'success'
    });
  };

  // Delete a stock item
  const deleteStockItem = (productId: string, packageId: string, itemId: string) => {
    playClick();
    setProducts(prev => {
      const next = prev.map(p => {
        if (p.id === productId) {
          const nextPackages = p.packages.map(pkg => {
            if (pkg.id === packageId) {
              const currentStockItems = pkg.stockItems || [];
              const nextStockItems = currentStockItems.filter(s => s.id !== itemId);
              const availableCount = nextStockItems.filter(s => !s.isUsed).length;
              return {
                ...pkg,
                stockItems: nextStockItems,
                stock: availableCount,
                inStock: availableCount > 0
              };
            }
            return pkg;
          });
          return { ...p, packages: nextPackages };
        }
        return p;
      });
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_products', JSON.stringify(next));
      }
      return next;
    });
    showToast({ title: 'ลบรายการสต็อกแล้ว', message: 'ลบรายการออกจากคลังเรียบร้อย', type: 'info' });
  };

  // Clear sold stock items
  const clearSoldStockItems = (productId: string, packageId: string) => {
    playClick();
    setProducts(prev => {
      const next = prev.map(p => {
        if (p.id === productId) {
          const nextPackages = p.packages.map(pkg => {
            if (pkg.id === packageId) {
              const currentStockItems = pkg.stockItems || [];
              const nextStockItems = currentStockItems.filter(s => !s.isUsed);
              return {
                ...pkg,
                stockItems: nextStockItems,
                stock: nextStockItems.length,
                inStock: nextStockItems.length > 0
              };
            }
            return pkg;
          });
          return { ...p, packages: nextPackages };
        }
        return p;
      });
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_products', JSON.stringify(next));
      }
      return next;
    });
    showToast({
      title: 'ล้างสต็อกที่ขายแล้ว',
      message: 'ลบประวัติรายการที่ขายแล้วออกจากคลังเรียบร้อย',
      type: 'info'
    });
  };

  // Update whole package stock items
  const updatePackageStockItems = (productId: string, packageId: string, items: DigitalStockItem[]) => {
    setProducts(prev => {
      const next = prev.map(p => {
        if (p.id === productId) {
          const nextPackages = p.packages.map(pkg => {
            if (pkg.id === packageId) {
              const availableCount = items.filter(s => !s.isUsed).length;
              return {
                ...pkg,
                stockItems: items,
                stock: availableCount,
                inStock: availableCount > 0
              };
            }
            return pkg;
          });
          return { ...p, packages: nextPackages };
        }
        return p;
      });
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_products', JSON.stringify(next));
      }
      return next;
    });
  };

  // Product Status Management
  const updateProductStatus = (productId: string, status: ProductStatus, note?: string) => {
    playClick();
    const nowStr = 'เมื่อสักครู่';
    const defaultNote = status === 'ready'
      ? 'สินค้าพร้อมใช้งาน'
      : status === 'updating'
        ? 'สินค้ากำลังอัพเดท'
        : 'สินค้าปิดใช้งาน';
    const effectiveNote = note !== undefined ? note : defaultNote;

    const next = products.map(p => {
      if (p.id === productId) {
        return {
          ...p,
          status,
          statusNote: effectiveNote,
          statusUpdatedAt: nowStr
        };
      }
      return p;
    });
    saveAndSyncProducts(next);

    setServiceStatuses(prev => {
      const healthStatus: ServiceHealthStatus = status === 'ready' ? 'online' : status === 'out_of_stock' ? 'maintenance' : 'updating';
      const existing = prev.find(s => s.productId === productId);
      let nextStatuses;
      if (existing) {
        nextStatuses = prev.map(s => s.productId === productId ? { ...s, status: healthStatus, lastChecked: nowStr, note: effectiveNote } : s);
      } else {
        const prod = products.find(p => p.id === productId);
        nextStatuses = [
          ...prev,
          {
            id: 'srv-' + productId,
            productId,
            name: prod?.name || 'บริการ',
            productName: prod?.name || 'บริการ',
            category: prod?.categoryName || 'ทั่วไป',
            status: healthStatus,
            image: prod?.image || '/brand/logo.png',
            lastChecked: nowStr,
            note: effectiveNote
          }
        ];
      }
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_service_statuses', JSON.stringify(nextStatuses));
      }
      return nextStatuses;
    });

    playSuccess();
    showToast({
      title: 'อัปเดตสถานะสินค้าแล้ว',
      message: `เปลี่ยนสถานะเป็น ${status === 'ready' ? 'สินค้าพร้อมใช้งาน (Online)' : status === 'updating' ? 'สินค้ากำลังอัพเดท' : 'สินค้าปิดใช้งาน'} (Real-time)`,
      type: 'info'
    });
  };

  const updateProductStatusNote = (productId: string, note: string) => {
    const nowStr = 'เมื่อสักครู่';
    const next = products.map(p => p.id === productId ? { ...p, statusNote: note, statusUpdatedAt: nowStr } : p);
    saveAndSyncProducts(next);

    setServiceStatuses(prev => {
      const nextStatuses = prev.map(s => s.productId === productId ? { ...s, note, lastChecked: nowStr } : s);
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_service_statuses', JSON.stringify(nextStatuses));
      }
      return nextStatuses;
    });
    showToast({ title: 'บันทึกข้อความอัปเดตแล้ว', message: 'ข้อความสถานะซิงค์ไปยังหน้าเว็บแบบ Real-time', type: 'info' });
  };

  // Reorder / Move Product (ขยับลำดับสินค้า)
  const moveProduct = (productId: string, direction: 'up' | 'down', categoryFilter?: string) => {
    playClick();
    let next = [...products];
    if (!categoryFilter || categoryFilter === 'all') {
      const idx = next.findIndex(p => p.id === productId);
      if (idx === -1) return;
      if (direction === 'up' && idx === 0) return;
      if (direction === 'down' && idx === next.length - 1) return;

      const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
      const temp = next[idx];
      next[idx] = next[targetIdx];
      next[targetIdx] = temp;
    } else {
      const catProducts = next.filter(p => p.categoryId === categoryFilter);
      const catIdx = catProducts.findIndex(p => p.id === productId);
      if (catIdx === -1) return;
      if (direction === 'up' && catIdx === 0) return;
      if (direction === 'down' && catIdx === catProducts.length - 1) return;

      const targetProduct = catProducts[direction === 'up' ? catIdx - 1 : catIdx + 1];
      const currentGlobalIdx = next.findIndex(p => p.id === productId);
      const targetGlobalIdx = next.findIndex(p => p.id === targetProduct.id);

      const temp = next[currentGlobalIdx];
      next[currentGlobalIdx] = next[targetGlobalIdx];
      next[targetGlobalIdx] = temp;
    }

    next = next.map((p, i) => ({ ...p, rank: i + 1 }));
    saveAndSyncProducts(next);
  };

  const reorderProducts = (newProducts: Product[]) => {
    playClick();
    const ranked = newProducts.map((p, i) => ({ ...p, rank: i + 1 }));
    saveAndSyncProducts(ranked);
  };

  // Reorder / Move Category (ขยับลำดับหมวดหมู่)
  const moveCategory = (categoryId: string, direction: 'up' | 'down') => {
    playClick();
    setCategories(prev => {
      const idx = prev.findIndex(c => c.id === categoryId);
      if (idx === -1) return prev;
      if (direction === 'up' && idx === 0) return prev;
      if (direction === 'down' && idx === prev.length - 1) return prev;

      const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
      const next = [...prev];
      const temp = next[idx];
      next[idx] = next[targetIdx];
      next[targetIdx] = temp;

      const updated = next.map((c, i) => ({
        ...c,
        badge: (i + 1 < 10 ? '0' : '') + (i + 1)
      }));

      saveAndSyncCategories(updated);
      return updated;
    });
    showToast({ title: 'จัดลำดับหมวดหมู่แล้ว', message: 'อัปเดตลำดับการแสดงผลเรียบร้อย', type: 'info' });
  };

  const reorderCategories = (newCategories: Category[]) => {
    playClick();
    const updated = newCategories.map((c, i) => ({
      ...c,
      badge: (i + 1 < 10 ? '0' : '') + (i + 1)
    }));
    saveAndSyncCategories(updated);
  };

  const updateCategory = (id: string, updated: Partial<Category>) => {
    playClick();
    setCategories(prev => {
      const next = prev.map(c => c.id === id ? { ...c, ...updated } : c);
      saveAndSyncCategories(next);
      return next;
    });
    showToast({ title: 'บันทึกหมวดหมู่แล้ว', message: 'อัปเดตข้อมูลหมวดหมู่เรียบร้อย', type: 'success' });
  };

  const addCategory = (newCat: Category) => {
    playClick();
    setCategories(prev => {
      const next = [...prev, newCat];
      saveAndSyncCategories(next);
      return next;
    });
    showToast({ title: 'เพิ่มหมวดหมู่สำเร็จ', message: 'บันทึกหมวดหมู่ใหม่เรียบร้อย', type: 'success' });
  };

  const deleteCategory = (id: string) => {
    playClick();
    setCategories(prev => {
      const next = prev.filter(c => c.id !== id);
      saveAndSyncCategories(next, id);
      return next;
    });
    // Extra safety: call delete endpoint directly
    try {
      fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', id })
      }).catch(err => console.error('Error deleting category from server:', err));
    } catch {}
    showToast({ title: 'ลบหมวดหมู่แล้ว', message: 'นำหมวดหมู่ออกจากระบบและเซิร์ฟเวอร์เรียบร้อย', type: 'warning' });
  };

  const restoreDefaultCatalog = () => {
    playClick();
    if (typeof window !== 'undefined') {
      localStorage.removeItem('arx_deleted_product_ids');
      localStorage.removeItem('arx_deleted_category_ids');
      localStorage.removeItem('arx_deleted_slide_ids');
      localStorage.removeItem('arx_deleted_service_ids');
      localStorage.removeItem('arx_deleted_user_ids');
      localStorage.removeItem('arx_deleted_order_ids');
    }
    const syncedProds = syncStockItemsForProducts(INITIAL_PRODUCTS);
    setProducts(syncedProds);
    setCategories(INITIAL_CATEGORIES);
    setSlides(DEFAULT_SLIDES);
    setServiceStatuses(INITIAL_SERVICE_STATUSES);
    if (typeof window !== 'undefined') {
      localStorage.setItem('arx_products', JSON.stringify(syncedProds));
      localStorage.setItem('arx_categories', JSON.stringify(INITIAL_CATEGORIES));
      localStorage.setItem('arx_slides', JSON.stringify(DEFAULT_SLIDES));
      localStorage.setItem('arx_service_statuses', JSON.stringify(INITIAL_SERVICE_STATUSES));
    }
    try {
      fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'restore_defaults' })
      }).catch(e => console.error('Error restoring defaults on server:', e));
    } catch {}
    try {
      fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'restore_defaults' })
      }).catch(e => console.error('Error restoring categories defaults on server:', e));
    } catch {}
    playSuccess();
    showToast({ title: 'คืนค่าเริ่มต้นสำเร็จ', message: 'รีเซ็ตสินค้าและหมวดหมู่กลับสู่ค่าเริ่มต้นเรียบร้อย', type: 'success' });
  };

  // ========================================================
  // 👥 USER MANAGEMENT (ระบบจัดการผู้ใช้: ชื่อ, รูป, ยอดเงิน, สินค้า)
  // ========================================================
  const adminUpdateUser = async (userId: string, data: Partial<User>) => {
    playClick();
    setUsers(prev => {
      const next = prev.map(u => {
        if (u.id === userId) {
          const updated = { ...u, ...data };
          if (data.username && data.username !== u.username) {
            setOrders(prevOrders => prevOrders.map(o => o.userId === userId ? { ...o, username: data.username! } : o));
          }
          return updated;
        }
        return u;
      });

      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_registered_users', JSON.stringify(next));
        localStorage.setItem('demox_users', JSON.stringify(next));
      }

      return next;
    });

    if (user && user.id === userId) {
      const updatedCurrentUser = { ...user, ...data };
      setUser(updatedCurrentUser);
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_current_user', JSON.stringify(updatedCurrentUser));
        localStorage.setItem('demox_user', JSON.stringify(updatedCurrentUser));
      }
    }

    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
      const res = await fetch('/api/admin/users', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-session-token': token } : {})
        },
        body: JSON.stringify({
          id: userId,
          username: data.username,
          avatar: data.avatar,
          balance: typeof data.balance === 'number' ? data.balance : undefined,
          role: data.role,
          email: data.email,
          newPassword: data.password
        })
      });

      const resData = await res.json();
      if (res.ok && resData.success && resData.data) {
        const serverUser: User = resData.data;
        setUsers(prev => {
          const next = prev.map(u => u.id === userId ? { ...u, ...serverUser } : u);
          if (typeof window !== 'undefined') {
            localStorage.setItem('arx_registered_users', JSON.stringify(next));
            localStorage.setItem('demox_users', JSON.stringify(next));
          }
          return next;
        });

        if (user && user.id === userId) {
          const nextCurrent = { ...user, ...serverUser };
          setUser(nextCurrent);
          if (typeof window !== 'undefined') {
            localStorage.setItem('arx_current_user', JSON.stringify(nextCurrent));
            localStorage.setItem('demox_user', JSON.stringify(nextCurrent));
          }
        }

        if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
          try {
            const bc = new BroadcastChannel('arx_store_sync_channel');
            bc.postMessage({
              type: 'USER_UPDATED',
              userId,
              user: serverUser
            });
            bc.close();
          } catch {}
        }

        playSuccess();
        showToast({
          title: 'อัปเดตข้อมูลผู้ใช้งานแล้ว',
          message: `บันทึกข้อมูลของ ${data.username || serverUser.username} เรียบร้อยแล้ว`,
          type: 'success'
        });
      } else {
        throw new Error(resData.message || 'บันทึกข้อมูลผู้ใช้ไม่สำเร็จ');
      }
    } catch (err: any) {
      console.error('Failed to update user on server:', err);
      showToast({
        title: 'บันทึกข้อมูลไม่สำเร็จ',
        message: err?.message || 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้',
        type: 'warning'
      });
    }
  };

  const adminAddUserProduct = (userId: string, productId: string, packageId: string, customKey?: string) => {
    playClick();
    const targetUser = users.find(u => u.id === userId);
    const prod = products.find(p => p.id === productId);
    if (!targetUser || !prod) {
      showToast({ title: 'เกิดข้อผิดพลาด', message: 'ไม่พบผู้ใช้หรือสินค้าที่ระบุ', type: 'warning' });
      return;
    }

    const pkg = prod.packages.find(pk => pk.id === packageId) || prod.packages[0] || {
      id: 'pkg-custom',
      name: 'สิทธิ์การใช้งานพิเศษ',
      duration: '30 วัน',
      price: 0
    };

    const assignedKey = customKey && customKey.trim()
      ? customKey.trim()
      : `ARX-${prod.name.substring(0, 4).toUpperCase().replace(/[^A-Z0-9]/g, 'X')}-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

    const newOrder: Order = {
      id: 'ord-' + Date.now(),
      orderNumber: 'ARX' + Math.floor(100000 + Math.random() * 900000),
      userId: targetUser.id,
      username: targetUser.username,
      productId: prod.id,
      productName: prod.name,
      packageId: pkg.id,
      packageName: pkg.name,
      price: pkg.price,
      status: 'delivered',
      licenseKey: assignedKey,
      downloadUrl: 'https://arxstore.com/download/loader.exe',
      instructions: prod.instructions || 'เปิด Loader และกรอก License Key เพื่อเริ่มใช้งาน',
      createdAt: new Date().toLocaleDateString('th-TH', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
    };

    setOrders(prev => {
      const next = [newOrder, ...prev];
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_orders', JSON.stringify(next));
        localStorage.setItem('demox_orders', JSON.stringify(next));
      }
      return next;
    });

    playSuccess();
    showToast({
      title: 'เพิ่มสินค้าให้ผู้ใช้สำเร็จ',
      message: `มอบ ${prod.name} (${pkg.name}) ให้แก่คุณ ${targetUser.username} เรียบร้อยแล้ว`,
      type: 'success'
    });
  };

  const adminUpdateUserOrder = (orderId: string, data: Partial<Order>) => {
    playClick();
    setOrders(prev => {
      const next = prev.map(o => o.id === orderId ? { ...o, ...data } : o);
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_orders', JSON.stringify(next));
        localStorage.setItem('demox_orders', JSON.stringify(next));
      }
      return next;
    });
    playSuccess();
    showToast({ title: 'อัปเดตคำสั่งซื้อแล้ว', message: 'บันทึกการแก้ไขสินค้าของผู้ใช้เรียบร้อย', type: 'success' });
  };

  const adminDeleteUserOrder = (orderId: string) => {
    playClick();
    setOrders(prev => {
      const next = prev.filter(o => o.id !== orderId);
      if (typeof window !== 'undefined') {
        localStorage.setItem('arx_orders', JSON.stringify(next));
        localStorage.setItem('demox_orders', JSON.stringify(next));
      }
      return next;
    });
    if (typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem('arx_deleted_order_ids');
        const list: string[] = raw ? JSON.parse(raw) : [];
        if (!list.includes(orderId)) {
          list.push(orderId);
          localStorage.setItem('arx_deleted_order_ids', JSON.stringify(list));
        }
      } catch {}
    }
    playSuccess();
    showToast({ title: 'ลบสินค้าสำเร็จ', message: 'เพิกถอนสินค้าออกจากผู้ใช้เรียบร้อย', type: 'info' });
  };

  const adminDeleteUser = async (userId: string): Promise<void> => {
    playClick();
    if (user && user.id === userId) {
      showToast({ title: 'ไม่อนุญาต', message: 'ไม่สามารถลบบัญชีแอดมินที่กำลังเข้าสู่ระบบอยู่ได้', type: 'warning' });
      return;
    }

    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
      const res = await fetch(`/api/admin/users?id=${encodeURIComponent(userId)}`, {
        method: 'DELETE',
        headers: token ? { 'x-session-token': token } : {}
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.message || 'ไม่สามารถลบผู้ใช้ได้');
      }

      setUsers(prev => {
        const next = prev.filter(u => u.id !== userId);
        if (typeof window !== 'undefined') {
          localStorage.setItem('arx_registered_users', JSON.stringify(next));
          localStorage.setItem('demox_users', JSON.stringify(next));
        }
        return next;
      });

      if (typeof window !== 'undefined') {
        try {
          const raw = localStorage.getItem('arx_deleted_user_ids');
          const list: string[] = raw ? JSON.parse(raw) : [];
          if (!list.includes(userId)) {
            list.push(userId);
            localStorage.setItem('arx_deleted_user_ids', JSON.stringify(list));
          }
        } catch {}
      }

      playSuccess();
      showToast({ title: 'ลบผู้ใช้สำเร็จ', message: 'นำบัญชีผู้ใช้ออกจากระบบเรียบร้อย', type: 'info' });
    } catch (err: any) {
      console.error('Failed to delete user:', err);
      showToast({ title: 'เกิดข้อผิดพลาด', message: err?.message || 'ไม่สามารถลบผู้ใช้ได้', type: 'warning' });
    }
  };

  const adminCreateUser = async (userData: Partial<User>): Promise<User> => {
    playClick();
    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('arx_session_token') : null;
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'x-session-token': token } : {})
        },
        body: JSON.stringify({
          username: userData.username,
          password: userData.password,
          role: userData.role || 'user',
          email: userData.email,
          avatar: userData.avatar,
          balance: userData.balance
        })
      });

      const data = await res.json();
      if (!res.ok || !data.success || !data.data) {
        throw new Error(data.message || 'ไม่สามารถสร้างผู้ใช้ได้');
      }

      const createdUser: User = data.data;
      setUsers(prev => {
        const next = [createdUser, ...prev.filter(u => u.id !== createdUser.id)];
        if (typeof window !== 'undefined') {
          localStorage.setItem('arx_registered_users', JSON.stringify(next));
          localStorage.setItem('demox_users', JSON.stringify(next));
        }
        return next;
      });

      playSuccess();
      showToast({ title: 'สร้างผู้ใช้ใหม่สำเร็จ', message: `สร้างบัญชีคุณ ${createdUser.username} เรียบร้อย`, type: 'success' });
      return createdUser;
    } catch (err: any) {
      console.error('Failed to create user on server:', err);
      showToast({ title: 'เกิดข้อผิดพลาด', message: err?.message || 'ไม่สามารถสร้างผู้ใช้ได้', type: 'warning' });
      throw err;
    }
  };


  return (
    <StoreContext.Provider
      value={{
        user,
        users,
        isHydrated,
        isSoundEnabled,
        toggleSound,
        playClick,
        playSuccess,
        playError,

        products,
        categories,
        serviceStatuses,
        orders,
        topups,
        hwidRecords,
        announcements,

        // Slides, Site Stats, Slip API Config
        slides,
        heroSliderEnabled,
        toggleHeroSlider,
        welcomeBanner,
        updateWelcomeBanner,
        recentOrdersFeedEnabled,
        toggleRecentOrdersFeed,
        updateSlide,
        addSlide,
        deleteSlide,
        moveSlide,
        siteStats,
        displayStats,
        realStats,
        updateSiteStats,
        slipConfig,
        updateSlipConfig,
        webhookSettings,
        updateWebhookSettings,
        webhookLogs,
        testDiscordWebhook,
        clearWebhookLogs,

        // Background Music
        bgmSettings,
        updateBgmSettings,

        // Site Content & FAQ & Contact Modal
        siteContent,
        updateSiteContent,
        isContactModalOpen,
        openContactModal,
        closeContactModal,

        login,
        logout,
        register,
        switchUser,

        isBuyModalOpen,
        selectedProduct,
        openBuyModal,
        closeBuyModal,

        isAuthModalOpen,
        authModalMode,
        openAuthModal,
        closeAuthModal,

        isCookieModalOpen,
        cookieConsentGiven,
        acceptAllCookies,
        closeCookieModal,

        purchasePackage,
        topupAngpao,
        topupSlip,
        requestHwidReset,

        updateServiceStatus,
        approveTopup,
        rejectTopup,
        addProduct,
        updateProduct,
        deleteProduct,
        applyGlobalPromotion,
        clearGlobalPromotion,
        updateProductPackages,
        updateProductStatus,
        updateProductStatusNote,

        // Stock Management
        addStockItem,
        addBulkStockItems,
        deleteStockItem,
        clearSoldStockItems,
        updatePackageStockItems,

        moveProduct,
        reorderProducts,
        moveCategory,
        reorderCategories,
        updateCategory,
        deleteCategory,
        addCategory,
        restoreDefaultCatalog,

        // User Management
        refreshUsers,
        updateUserProfile,
        adminUpdateUser,
        adminAddUserProduct,
        adminUpdateUserOrder,
        adminDeleteUserOrder,
        adminDeleteUser,
        adminCreateUser,

        toasts,
        showToast,
        removeToast,

        lang,
        setLang,
        toggleLang,
        t,

        theme,
        setTheme,
        toggleTheme,
        searchQuery,
        setSearchQuery
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return ctx;
}
